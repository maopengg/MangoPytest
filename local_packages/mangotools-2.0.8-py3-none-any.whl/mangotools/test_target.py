from pydantic import ValidationError

from mangotools.contracts.test_target import TestTargetConfig
from mangotools.exceptions.test_target import TestTargetResolutionError


def resolve_test_target(value, config, get_cache=None):
    if value:
        return value
    try:
        rules = TestTargetConfig.model_validate(config or {})
    except ValidationError:
        raise TestTargetResolutionError('测试地址配置无效，请检查默认地址和变量映射') from None
    if not rules.selector:
        return rules.default
    key = rules.selector
    selected = get_cache(key) if get_cache else None
    if isinstance(selected, (str, int, float)) and not isinstance(selected, bool):
        address = rules.mapping.get(str(selected))
        if address is not None:
            return address
    if rules.default:
        return rules.default
    raise TestTargetResolutionError('测试地址未匹配且未配置默认地址，无法确定被测地址')
