"""Assertions for converted DOCX artifacts."""

from contextlib import contextmanager
from pathlib import Path
from zipfile import BadZipFile, ZipFile

import requests
from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.opc.exceptions import PackageNotFoundError
from docx.oxml.ns import qn
from lxml import etree

from ...decorator import sync_method_callback
from ...models import MethodModel, MethodObjectFieldModel
from ._document import _materialize_file, _parse_json_value, _resolve_file_source


_ACTUAL = MethodModel(
    n='DOCX产物', f='actual', p='请输入已下载的文件路径、下载地址或缓存变量', d=True,
)
_IMAGE_ELEMENTS = {
    qn('a:blip'), '{http://schemas.microsoft.com/office/drawing/2016/SVG/main}svgBlip',
    '{urn:schemas-microsoft-com:vml}imagedata',
}
_STORY_TAGS = {qn(f'w:{tag}') for tag in ('hdr', 'ftr', 'footnotes', 'endnotes', 'comments')}
_DELETED = {qn('w:del'), qn('w:moveFrom')}
_COMMENT_MARKERS = {qn(f'w:{tag}') for tag in (
    'commentRangeStart', 'commentRangeEnd', 'commentReference',
)}
_TEXTBOX = qn('w:txbxContent')
_REVISION_TAGS = {qn(f'w:{tag}') for tag in '''
    ins del moveFrom moveTo moveFromRangeStart moveFromRangeEnd moveToRangeStart moveToRangeEnd
    customXmlInsRangeStart customXmlInsRangeEnd customXmlDelRangeStart customXmlDelRangeEnd
    customXmlMoveFromRangeStart customXmlMoveFromRangeEnd customXmlMoveToRangeStart
    customXmlMoveToRangeEnd pPrChange rPrChange sectPrChange tblPrChange tblGridChange
    trPrChange tcPrChange tblPrExChange cellIns cellDel cellMerge numberingChange delText delInstrText
'''.split()}
_TEXT = {qn('w:t'), qn('w:delText')}
_CONTROLS = {qn('w:tab'): '\t', qn('w:br'): '\n', qn('w:cr'): '\n'}


def _check_images(part, root):
    for element in root.iter(*_IMAGE_ELEMENTS):
        for attribute in (qn('r:embed'), qn('r:link'), qn('r:id')):
            reference = element.get(attribute)
            if reference is None:
                continue
            rel = part.rels.get(reference)
            if rel is None or rel.reltype != RT.IMAGE:
                raise AssertionError(f'DOCX图片引用无效：{part.partname} {reference}')
            if rel.is_external:
                if attribute == qn('r:embed'):
                    raise AssertionError(f'DOCX内嵌图片指向外部地址：{part.partname} {reference}')
                continue
            target = rel.target_part
            if not target.content_type.startswith('image/') or not target.blob:
                raise AssertionError(f'DOCX图片部件无效：{target.partname}')


@contextmanager
def _read_docx(actual):
    source, _ = _resolve_file_source(actual)
    try:
        path, temporary = _materialize_file(source)
    except (OSError, requests.RequestException) as error:
        raise AssertionError(f'DOCX产物无法读取：{type(error).__name__}') from None
    try:
        try:
            with ZipFile(path) as archive:
                names = archive.namelist()
                if len(set(names)) != len(names):
                    raise AssertionError('DOCX包包含重复部件')
                damaged_member = archive.testzip()
                if damaged_member is not None:
                    raise AssertionError(f'DOCX包部件校验失败：{damaged_member}')
            document = Document(path)
            root = document.element
            if root.tag != qn('w:document') or len(root.findall(qn('w:body'))) != 1:
                raise AssertionError('DOCX主文档必须包含一个正文部件')
            stories = [root]
            parser = etree.XMLParser(resolve_entities=False, no_network=True)
            for part in document.part.package.iter_parts():
                if not part.content_type.endswith(('+xml', '/xml')):
                    continue
                part_root = root if part is document.part else etree.fromstring(part.blob, parser)
                _check_images(part, part_root)
                if part_root.tag in _STORY_TAGS:
                    stories.append(part_root)
        except (BadZipFile, PackageNotFoundError, ValueError, KeyError, RuntimeError,
                AttributeError, etree.LxmlError, OSError) as error:
            raise AssertionError(f'DOCX产物无法解析：{type(error).__name__}，{error}') from None
        yield document, stories
    finally:
        if temporary:
            Path(path).unlink(missing_ok=True)


def _text(element, *, include_deleted=False):
    """Read native Word text independently of run splitting."""
    if element.tag in _DELETED and not include_deleted:
        return ''
    if element.tag == _TEXTBOX:
        return ''
    if element.tag in _TEXT:
        return element.text or ''
    if element.tag in _CONTROLS:
        return _CONTROLS[element.tag]
    return ''.join(_text(child, include_deleted=include_deleted) for child in element)


def _string_list(config, key):
    values = config.get(key, [])
    if not isinstance(values, list) or any(not isinstance(value, str) or not value.strip()
                                           for value in values):
        raise ValueError(f'{key} 必须为非空字符串组成的数组')
    return values


def _check_ordered_text(text, markers, label):
    offset = 0
    for index, marker in enumerate(markers, 1):
        position = text.find(marker, offset)
        if position < 0:
            raise AssertionError(f'DOCX{label}第{index}项缺失或顺序不符')
        offset = position + len(marker)


def _check_cells(document, cells):
    if not isinstance(cells, list):
        raise ValueError('cells 必须为数组')
    for cell in cells:
        if (not isinstance(cell, dict) or set(cell) != {'table', 'row', 'column', 'text'}
                or not isinstance(cell['text'], str)):
            raise ValueError('cells 每项必须包含 table、row、column 和字符串 text')
        indices = [cell[key] for key in ('table', 'row', 'column')]
        if any(type(index) is not int or index < 1 for index in indices):
            raise ValueError('表、行、列坐标必须为从 1 开始的整数')
        table, row, column = indices
        location = f'表{table}第{row}行第{column}列'
        try:
            table_row = document.tables[table - 1].rows[row - 1]
            index = column - 1 - table_row.grid_cols_before
            if index < 0:
                raise IndexError
            actual = table_row.cells[index]
        except IndexError:
            raise AssertionError(f'DOCX{location}不存在') from None
        text = '\n'.join(_text(paragraph._p) for paragraph in actual.paragraphs)
        if text != cell['text']:
            raise AssertionError(f'DOCX{location}内容不符')


def _check_expected_comments(comments):
    if not isinstance(comments, list) or any(
        not isinstance(item, dict) or set(item) != {'text', 'anchor'}
        or not isinstance(item['text'], str) or not item['text'].strip()
        or not isinstance(item['anchor'], str)
        for item in comments
    ):
        raise ValueError('comments 必须为包含批注 text 和锚定文本 anchor 的对象数组')


def _comment_evidence(document, body):
    definitions = {}
    for rel in document.part.rels.values():
        if rel.reltype != RT.COMMENTS or rel.is_external:
            continue
        root = etree.fromstring(rel.target_part.blob, etree.XMLParser(resolve_entities=False))
        for comment in root.findall(qn('w:comment')):
            identifier = comment.get(qn('w:id'))
            if identifier is None or identifier in definitions:
                raise AssertionError('DOCX批注标识缺失或重复')
            definitions[identifier] = '\n'.join(_text(p) for p in comment.iter(qn('w:p')))

    text = []
    starts, ends = {}, {}
    locations = {}
    for node in body.iter():
        if node.tag in (qn('w:t'), qn('w:delText')):
            text.append(node.text or '')
        elif node.tag in _CONTROLS:
            text.append(_CONTROLS[node.tag])
        elif node.tag in _COMMENT_MARKERS:
            identifier = node.get(qn('w:id'))
            positions = {qn('w:commentRangeStart'): starts, qn('w:commentRangeEnd'): ends,
                         qn('w:commentReference'): locations}[node.tag]
            if identifier not in definitions or identifier in positions:
                raise AssertionError('DOCX批注引用缺失或重复')
            positions[identifier] = len(text)

    if locations.keys() != definitions.keys() or starts.keys() != ends.keys():
        raise AssertionError('DOCX批注定义、范围与引用不匹配')
    evidence = []
    for identifier, location in locations.items():
        start = starts.get(identifier, location)
        end = ends.get(identifier, location)
        if not start <= end <= location:
            raise AssertionError('DOCX批注锚定范围无效')
        evidence.append({'text': definitions[identifier], 'anchor': ''.join(text[start:end])})
    return evidence


def _check_revisions(document, stories, config):
    keep = config.get('keepRevisions', False)
    if type(keep) is not bool:
        raise ValueError('keepRevisions 必须为布尔值，或省略以检查定稿')
    insertions = _string_list(config, 'insertions')
    deletions = _string_list(config, 'deletions')
    body = document.element.body
    if keep:
        if not {'insertions', 'deletions', 'comments'} <= config.keys():
            raise ValueError('keepRevisions=true 时需提供 insertions、deletions 和 comments')
        comments = config['comments']
        _check_expected_comments(comments)
        if not (insertions or deletions or comments):
            raise ValueError('keepRevisions=true 至少需要一项修订或批注预期')
        for tag, expected in (('ins', insertions), ('del', deletions)):
            evidence = [_text(node, include_deleted=True) for node in body.iter(qn(f'w:{tag}'))]
            if evidence != expected:
                raise AssertionError(f'DOCX修订内容或顺序不符：{tag}，预期{len(expected)}项，实际{len(evidence)}项')
        if _comment_evidence(document, body) != comments:
            raise AssertionError('DOCX批注内容、锚定文本或顺序不符')
        return

    if 'comments' in config:
        _check_expected_comments(config['comments'])
        if config['comments']:
            raise ValueError('定稿模式的 comments 应省略或为空数组')
    for story in stories:
        if next(story.iter(*_REVISION_TAGS), None) is not None:
            raise AssertionError('DOCX定稿仍有修订标记')
        if next(story.iter(*_COMMENT_MARKERS, qn('w:comment')), None) is not None:
            raise AssertionError('DOCX定稿仍有批注或批注引用')
    final_text = '\n'.join(_text(p) for p in body.iter(qn('w:p'))
                           if next(p.iterancestors(_TEXTBOX), None) is None)
    _check_ordered_text(final_text, insertions, '定稿插入文本')
    for index, marker in enumerate(deletions, 1):
        if marker in final_text:
            raise AssertionError(f'DOCX定稿仍包含第{index}项删除文本')


class DocxAssertion:
    """Assertions for converted DOCX files."""

    @staticmethod
    @sync_method_callback('文件断言', 'DOCX产物断言', 0, [_ACTUAL])
    def assert_docx_artifact_valid(actual, expect=None):
        """DOCX产物有效"""
        with _read_docx(actual):
            return 'DOCX产物有效'

    @staticmethod
    @sync_method_callback('文件断言', 'DOCX产物断言', 1, [
        _ACTUAL,
        MethodModel(
            n='预期内容与修订', f='expect', d=True, value_type='object', input_type='object',
            v={'body_markers': ['合同编号'], 'keepRevisions': False},
            object_fields=[
                MethodObjectFieldModel(f='body_markers', n='有序正文标记', value_type='array',
                                       input_type='json', p='原生正文段落中的有序字符串数组'),
                MethodObjectFieldModel(f='cells', n='预期单元格', value_type='array', input_type='json',
                                       p='如 [{"table":1,"row":2,"column":3,"text":"100元"}]'),
                MethodObjectFieldModel(f='keepRevisions', n='保留修订', value_type='boolean',
                                       p='省略或 false 检查定稿，true 检查保留修订和批注'),
                MethodObjectFieldModel(f='insertions', n='预期插入文本', value_type='array',
                                       input_type='json', p='有序字符串数组，定稿中应保留'),
                MethodObjectFieldModel(f='deletions', n='预期删除文本', value_type='array',
                                       input_type='json', p='有序字符串数组，定稿中应移除'),
                MethodObjectFieldModel(f='comments', n='预期批注与锚点', value_type='array',
                                       input_type='json', p='如 [{"text":"请确认","anchor":"付款条款"}]'),
            ],
        ),
    ])
    def assert_docx_structure_match(actual, expect):
        """DOCX内容、原生结构及修订状态符合预期"""
        config = _parse_json_value(expect)
        if not isinstance(config, dict):
            raise ValueError('DOCX结构预期必须为对象，可传空对象仅检查定稿状态')
        if config.keys() - {'body_markers', 'cells', 'keepRevisions', 'insertions', 'deletions', 'comments'}:
            raise ValueError('DOCX结构预期包含未知字段')
        with _read_docx(actual) as (document, stories):
            _check_revisions(document, stories, config)
            body = document.element.body
            paragraphs = (p for p in body.iter(qn('w:p'))
                          if next(p.iterancestors(qn('w:tbl'), _TEXTBOX, *_DELETED), None) is None)
            text = '\n'.join(_text(p) for p in paragraphs)
            _check_ordered_text(text, _string_list(config, 'body_markers'), '正文标记')
            _check_cells(document, config.get('cells', []))
        return 'DOCX内容、原生结构及修订状态符合预期'
