# -*- coding: utf-8 -*-

import json
import os
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path

import requests
from docx import Document
from docx.document import Document as DocumentObject
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.oxml.ns import qn
from openpyxl import load_workbook

from mangotools.decorator import sync_method_callback
from mangotools.models import MethodModel


@dataclass
class DocumentSnapshot:
    file_type: str
    text: str
    lines: list[str]
    paragraph_count: int = 0
    table_count: int = 0
    row_count: int = 0
    column_count: int = 0
    sheet_names: list[str] | None = None


def _parse_json_value(value):
    if not isinstance(value, str):
        return value
    stripped = value.strip()
    if stripped.startswith(('{', '[')):
        return json.loads(stripped)
    return value


def _resolve_file_source(actual):
    actual = _parse_json_value(actual)
    if isinstance(actual, dict):
        file_path = actual.get('文件路径') or actual.get('file_path') or actual.get('path')
        sheet_name = actual.get('工作表') or actual.get('sheet_name')
    else:
        file_path = actual
        sheet_name = None
    if not file_path:
        raise ValueError('文件路径不能为空')
    return str(file_path), sheet_name


def _materialize_file(file_path):
    if file_path.startswith(('http://', 'https://')):
        response = requests.get(file_path, timeout=30)
        response.raise_for_status()
        suffix = Path(file_path.split('?', 1)[0]).suffix
        file = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        file.write(response.content)
        file.close()
        return file.name, True
    resolved_path = str(Path(file_path).expanduser().resolve())
    if not os.path.isfile(resolved_path):
        raise FileNotFoundError(f'文件不存在：{resolved_path}')
    return resolved_path, False


def _detect_file_type(file_path):
    if zipfile.is_zipfile(file_path):
        with zipfile.ZipFile(file_path) as archive:
            names = set(archive.namelist())
        if 'word/document.xml' in names:
            return 'docx'
        if 'xl/workbook.xml' in names:
            return 'xlsx'
    suffix = Path(file_path).suffix.lower().lstrip('.')
    if suffix in {'txt', 'csv'}:
        return suffix
    if suffix in {'doc', 'xls'}:
        raise ValueError(f'暂不支持旧版文件格式：.{suffix}，请转换为 .docx 或 .xlsx')
    raise ValueError(f'不支持的文件类型：.{suffix or "未知"}')


def _normalize_text(text):
    lines = [line.rstrip() for line in str(text).replace('\r\n', '\n').replace('\r', '\n').split('\n')]
    return '\n'.join(lines).strip()


def _iter_word_blocks(document):
    if not isinstance(document, DocumentObject):
        return
    for child in document.element.body.iterchildren():
        if child.tag == qn('w:p'):
            yield Paragraph(child, document)
        elif child.tag == qn('w:tbl'):
            yield Table(child, document)


def _read_word(file_path):
    document = Document(file_path)
    lines = []
    paragraph_count = 0
    table_count = 0
    row_count = 0
    column_count = 0
    for block in _iter_word_blocks(document):
        if isinstance(block, Paragraph):
            text = _normalize_text(block.text)
            if text:
                lines.append(text)
                paragraph_count += 1
            continue
        table_count += 1
        for row in block.rows:
            values = [_normalize_text(cell.text) for cell in row.cells]
            if any(values):
                lines.append('\t'.join(values))
                row_count += 1
                column_count = max(column_count, len(values))
    return DocumentSnapshot(
        file_type='docx',
        text='\n'.join(lines),
        lines=lines,
        paragraph_count=paragraph_count,
        table_count=table_count,
        row_count=row_count,
        column_count=column_count,
    )


def _read_excel(file_path, sheet_name=None):
    workbook = load_workbook(file_path, read_only=True, data_only=True)
    try:
        if sheet_name and str(sheet_name).lower() not in {'全部', 'all', '*'}:
            if sheet_name not in workbook.sheetnames:
                raise ValueError(f'工作表不存在：{sheet_name}')
            sheets = [workbook[sheet_name]]
        else:
            sheets = list(workbook.worksheets)
        lines = []
        row_count = 0
        column_count = 0
        for sheet in sheets:
            for row in sheet.iter_rows(values_only=True):
                values = ['' if value is None else str(value) for value in row]
                while values and not values[-1]:
                    values.pop()
                if not any(values):
                    continue
                lines.append('\t'.join(values))
                row_count += 1
                column_count = max(column_count, len(values))
        return DocumentSnapshot(
            file_type='xlsx',
            text='\n'.join(lines),
            lines=lines,
            row_count=row_count,
            column_count=column_count,
            sheet_names=list(workbook.sheetnames),
        )
    finally:
        workbook.close()


def _read_plain_text(file_path, file_type):
    try:
        content = Path(file_path).read_text(encoding='utf-8-sig')
    except UnicodeDecodeError:
        content = Path(file_path).read_text(encoding='gb18030')
    text = _normalize_text(content)
    lines = [line for line in text.split('\n') if line.strip()]
    return DocumentSnapshot(file_type=file_type, text=text, lines=lines)


def read_document_snapshot(actual):
    file_path, sheet_name = _resolve_file_source(actual)
    local_path, temporary = _materialize_file(file_path)
    try:
        file_type = _detect_file_type(local_path)
        if file_type == 'docx':
            return _read_word(local_path)
        if file_type == 'xlsx':
            return _read_excel(local_path, sheet_name)
        return _read_plain_text(local_path, file_type)
    finally:
        if temporary:
            Path(local_path).unlink(missing_ok=True)


def _normalize_count_expect(expect, count_keys):
    expect = _parse_json_value(expect)
    if not isinstance(expect, dict):
        raise ValueError('数量断言的预期值必须是JSON对象')
    text = expect.get('目标文本') or expect.get('text')
    count = next((expect.get(key) for key in count_keys if expect.get(key) is not None), None)
    if not text:
        raise ValueError('目标文本不能为空')
    if count is None:
        raise ValueError('预期数量不能为空')
    count = int(count)
    if count < 0:
        raise ValueError('预期数量不能小于0')
    return str(text), count


def _normalize_integer_expect(expect, keys):
    expect = _parse_json_value(expect)
    if isinstance(expect, dict):
        value = next((expect.get(key) for key in keys if expect.get(key) is not None), None)
    else:
        value = expect
    if value is None:
        raise ValueError('预期数量不能为空')
    value = int(value)
    if value < 0:
        raise ValueError('预期数量不能小于0')
    return value


def _assert_count(actual_count, expected_count, comparison, label):
    comparisons = {
        'equal': (actual_count == expected_count, f'等于{expected_count}'),
        'at_least': (actual_count >= expected_count, f'不少于{expected_count}'),
        'at_most': (actual_count <= expected_count, f'不多于{expected_count}'),
    }
    passed, expectation = comparisons[comparison]
    assert passed, f'{label}不符合预期，实际={actual_count}，预期={expectation}'
    return f'{label}实际={actual_count}，预期={expectation}'


class DocumentAssertion:
    """Word、Excel、TXT 通用文件断言。"""

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 0, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期类型', f='expect', p='请输入 docx、xlsx、txt 或 csv', d=True),
    ])
    def assert_file_type(actual, expect):
        """文件类型等于预期"""
        snapshot = read_document_snapshot(actual)
        expected_type = str(expect).lower().lstrip('.')
        assert snapshot.file_type == expected_type, (
            f'文件类型不匹配，实际={snapshot.file_type}，预期={expected_type}'
        )
        return f'文件类型实际={snapshot.file_type}，预期={expected_type}'

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 1, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期文本', f='expect', p='请输入文件应包含的文本', d=True),
    ])
    def assert_file_text_contains(actual, expect):
        """文件包含文本"""
        snapshot = read_document_snapshot(actual)
        assert str(expect) in snapshot.text, f'文件未包含预期文本：{expect}'
        return f'文件包含预期文本：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 2, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='排除文本', f='expect', p='请输入文件不应包含的文本', d=True),
    ])
    def assert_file_text_not_contains(actual, expect):
        """文件不包含文本"""
        snapshot = read_document_snapshot(actual)
        assert str(expect) not in snapshot.text, f'文件包含了不应出现的文本：{expect}'
        return f'文件不包含文本：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 3, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期文本', f='expect', p='请输入文件完整文本', d=True),
    ])
    def assert_file_text_equal(actual, expect):
        """文件全文等于预期"""
        snapshot = read_document_snapshot(actual)
        expected_text = _normalize_text(expect)
        assert snapshot.text == expected_text, '文件文本与预期不一致'
        return '文件文本与预期一致'

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 4, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='排除文本', f='expect', p='请输入文件不应完全等于的文本', d=True),
    ])
    def assert_file_text_not_equal(actual, expect):
        """文件全文不等于预期"""
        snapshot = read_document_snapshot(actual)
        expected_text = _normalize_text(expect)
        assert snapshot.text != expected_text, '文件文本不应与排除文本完全相等'
        return '文件文本与排除文本不相等'

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 5, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '预期次数': '请输入预期出现次数'}),
    ])
    def assert_file_text_count_equal(actual, expect):
        """文件中文本数量等于预期"""
        text, expected_count = _normalize_count_expect(expect, ('预期次数', 'count'))
        actual_count = read_document_snapshot(actual).text.count(text)
        return _assert_count(actual_count, expected_count, 'equal', f'文本【{text}】出现次数')

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 6, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '最少次数': '请输入最少出现次数'}),
    ])
    def assert_file_text_count_at_least(actual, expect):
        """文件中文本数量不少于预期"""
        text, expected_count = _normalize_count_expect(expect, ('最少次数', 'count'))
        actual_count = read_document_snapshot(actual).text.count(text)
        return _assert_count(actual_count, expected_count, 'at_least', f'文本【{text}】出现次数')

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 7, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '最多次数': '请输入最多出现次数'}),
    ])
    def assert_file_text_count_at_most(actual, expect):
        """文件中文本数量不多于预期"""
        text, expected_count = _normalize_count_expect(expect, ('最多次数', 'count'))
        actual_count = read_document_snapshot(actual).text.count(text)
        return _assert_count(actual_count, expected_count, 'at_most', f'文本【{text}】出现次数')

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 8, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期行数', f='expect', p='请输入预期逻辑行数', d=True),
    ])
    def assert_file_line_count_equal(actual, expect):
        """文件逻辑行数等于预期"""
        expected_count = _normalize_integer_expect(expect, ('预期行数', 'count'))
        return _assert_count(
            len(read_document_snapshot(actual).lines), expected_count, 'equal', '文件逻辑行数',
        )

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 9, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='最少行数', f='expect', p='请输入最少逻辑行数', d=True),
    ])
    def assert_file_line_count_at_least(actual, expect):
        """文件逻辑行数不少于预期"""
        expected_count = _normalize_integer_expect(expect, ('最少行数', 'count'))
        return _assert_count(
            len(read_document_snapshot(actual).lines), expected_count, 'at_least', '文件逻辑行数',
        )

    @staticmethod
    @sync_method_callback('文件断言', '通用文件断言', 10, [
        MethodModel(n='文件路径', f='actual', p='请输入文件绝对路径、下载地址或缓存变量', d=True),
        MethodModel(n='最多行数', f='expect', p='请输入最多逻辑行数', d=True),
    ])
    def assert_file_line_count_at_most(actual, expect):
        """文件逻辑行数不多于预期"""
        expected_count = _normalize_integer_expect(expect, ('最多行数', 'count'))
        return _assert_count(
            len(read_document_snapshot(actual).lines), expected_count, 'at_most', '文件逻辑行数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 0, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径或缓存变量', d=True),
        MethodModel(n='预期段落数', f='expect', p='请输入预期非空段落数', d=True),
    ])
    def assert_word_paragraph_count_equal(actual, expect):
        """Word非空段落数等于预期"""
        snapshot = read_document_snapshot(actual)
        DocumentAssertion._ensure_file_type(snapshot, 'docx')
        expected_count = _normalize_integer_expect(expect, ('预期段落数', 'count'))
        return _assert_count(snapshot.paragraph_count, expected_count, 'equal', 'Word非空段落数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 1, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径或缓存变量', d=True),
        MethodModel(n='最少段落数', f='expect', p='请输入最少非空段落数', d=True),
    ])
    def assert_word_paragraph_count_at_least(actual, expect):
        """Word非空段落数不少于预期"""
        snapshot = read_document_snapshot(actual)
        DocumentAssertion._ensure_file_type(snapshot, 'docx')
        expected_count = _normalize_integer_expect(expect, ('最少段落数', 'count'))
        return _assert_count(snapshot.paragraph_count, expected_count, 'at_least', 'Word非空段落数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 2, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径或缓存变量', d=True),
        MethodModel(n='最多段落数', f='expect', p='请输入最多非空段落数', d=True),
    ])
    def assert_word_paragraph_count_at_most(actual, expect):
        """Word非空段落数不多于预期"""
        snapshot = read_document_snapshot(actual)
        DocumentAssertion._ensure_file_type(snapshot, 'docx')
        expected_count = _normalize_integer_expect(expect, ('最多段落数', 'count'))
        return _assert_count(snapshot.paragraph_count, expected_count, 'at_most', 'Word非空段落数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 3, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期文本', f='expect', p='请输入Word应包含的文本', d=True),
    ])
    def assert_word_text_contains(actual, expect):
        """包含文本"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        assert str(expect) in snapshot.text, f'Word未包含预期文本：{expect}'
        return f'Word包含预期文本：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 4, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='排除文本', f='expect', p='请输入Word不应包含的文本', d=True),
    ])
    def assert_word_text_not_contains(actual, expect):
        """不包含文本"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        assert str(expect) not in snapshot.text, f'Word包含了不应出现的文本：{expect}'
        return f'Word不包含文本：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 5, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期文本', f='expect', p='请输入Word完整文本', d=True),
    ])
    def assert_word_text_equal(actual, expect):
        """全文等于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_text = _normalize_text(expect)
        assert snapshot.text == expected_text, 'Word全文与预期不一致'
        return 'Word全文与预期一致'

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 6, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='排除文本', f='expect', p='请输入Word不应完全等于的文本', d=True),
    ])
    def assert_word_text_not_equal(actual, expect):
        """全文不等于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_text = _normalize_text(expect)
        assert snapshot.text != expected_text, 'Word全文不应与排除文本完全相等'
        return 'Word全文与排除文本不相等'

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 7, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='开头文本', f='expect', p='请输入Word开头文本', d=True),
    ])
    def assert_word_text_startswith(actual, expect):
        """以文本开头"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        assert snapshot.text.startswith(str(expect)), f'Word未以预期文本开头：{expect}'
        return f'Word以预期文本开头：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 8, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='结尾文本', f='expect', p='请输入Word结尾文本', d=True),
    ])
    def assert_word_text_endswith(actual, expect):
        """以文本结尾"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        assert snapshot.text.endswith(str(expect)), f'Word未以预期文本结尾：{expect}'
        return f'Word以预期文本结尾：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 9, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '预期次数': '请输入预期出现次数'}),
    ])
    def assert_word_text_count_equal(actual, expect):
        """文本出现次数等于"""
        text, expected_count = _normalize_count_expect(expect, ('预期次数', 'count'))
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        return _assert_count(snapshot.text.count(text), expected_count, 'equal', f'文本【{text}】出现次数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 10, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '最少次数': '请输入最少出现次数'}),
    ])
    def assert_word_text_count_at_least(actual, expect):
        """文本出现次数不少于"""
        text, expected_count = _normalize_count_expect(expect, ('最少次数', 'count'))
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        return _assert_count(
            snapshot.text.count(text), expected_count, 'at_least', f'文本【{text}】出现次数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 11, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '最多次数': '请输入最多出现次数'}),
    ])
    def assert_word_text_count_at_most(actual, expect):
        """文本出现次数不多于"""
        text, expected_count = _normalize_count_expect(expect, ('最多次数', 'count'))
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        return _assert_count(
            snapshot.text.count(text), expected_count, 'at_most', f'文本【{text}】出现次数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 12, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期行数', f='expect', p='请输入预期逻辑行数', d=True),
    ])
    def assert_word_line_count_equal(actual, expect):
        """逻辑行数等于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('预期行数', 'count'))
        return _assert_count(len(snapshot.lines), expected_count, 'equal', 'Word逻辑行数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 13, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最少行数', f='expect', p='请输入最少逻辑行数', d=True),
    ])
    def assert_word_line_count_at_least(actual, expect):
        """逻辑行数不少于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('最少行数', 'count'))
        return _assert_count(len(snapshot.lines), expected_count, 'at_least', 'Word逻辑行数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 14, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最多行数', f='expect', p='请输入最多逻辑行数', d=True),
    ])
    def assert_word_line_count_at_most(actual, expect):
        """逻辑行数不多于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('最多行数', 'count'))
        return _assert_count(len(snapshot.lines), expected_count, 'at_most', 'Word逻辑行数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 15, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期表格数', f='expect', p='请输入预期表格数', d=True),
    ])
    def assert_word_table_count_equal(actual, expect):
        """表格数等于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('预期表格数', 'count'))
        return _assert_count(snapshot.table_count, expected_count, 'equal', 'Word表格数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 16, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最少表格数', f='expect', p='请输入最少表格数', d=True),
    ])
    def assert_word_table_count_at_least(actual, expect):
        """表格数不少于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('最少表格数', 'count'))
        return _assert_count(snapshot.table_count, expected_count, 'at_least', 'Word表格数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 17, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最多表格数', f='expect', p='请输入最多表格数', d=True),
    ])
    def assert_word_table_count_at_most(actual, expect):
        """表格数不多于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('最多表格数', 'count'))
        return _assert_count(snapshot.table_count, expected_count, 'at_most', 'Word表格数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 18, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期表格行数', f='expect', p='请输入所有表格的预期非空行数', d=True),
    ])
    def assert_word_table_row_count_equal(actual, expect):
        """表格行数等于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('预期表格行数', 'count'))
        return _assert_count(snapshot.row_count, expected_count, 'equal', 'Word表格行数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 19, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最少表格行数', f='expect', p='请输入所有表格的最少非空行数', d=True),
    ])
    def assert_word_table_row_count_at_least(actual, expect):
        """表格行数不少于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('最少表格行数', 'count'))
        return _assert_count(snapshot.row_count, expected_count, 'at_least', 'Word表格行数')

    @staticmethod
    @sync_method_callback('文件断言', 'Word断言', 20, [
        MethodModel(n='Word文件路径', f='actual', p='请输入 .docx 文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最多表格行数', f='expect', p='请输入所有表格的最多非空行数', d=True),
    ])
    def assert_word_table_row_count_at_most(actual, expect):
        """表格行数不多于"""
        snapshot = DocumentAssertion._read_word_snapshot(actual)
        expected_count = _normalize_integer_expect(expect, ('最多表格行数', 'count'))
        return _assert_count(snapshot.row_count, expected_count, 'at_most', 'Word表格行数')

    @staticmethod
    def _read_word_snapshot(actual):
        snapshot = read_document_snapshot(actual)
        DocumentAssertion._ensure_file_type(snapshot, 'docx')
        return snapshot

    @staticmethod
    def _ensure_file_type(snapshot, expected_type):
        if snapshot.file_type != expected_type:
            raise ValueError(f'断言仅支持 {expected_type}，当前文件类型为 {snapshot.file_type}')
