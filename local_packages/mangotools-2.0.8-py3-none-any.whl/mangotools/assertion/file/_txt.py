# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: txt文件断言
# @Time   : 2025-07-04
# @Author : 毛鹏

from pathlib import Path

import requests

from mangotools.decorator import sync_method_callback
from mangotools.models import MethodModel
from mangotools.assertion.file._document import (
    _assert_count,
    _normalize_count_expect,
    _normalize_integer_expect,
    _normalize_text,
    _parse_json_value,
    read_document_snapshot,
)


def read_txt_file(file_path):
    """
    统一处理TXT文件读取逻辑，支持本地路径和URL下载
    
    Args:
        file_path (str): TXT文件路径或URL
        
    Returns:
        str: 文件内容
    """
    # 判断是否为URL
    is_url = file_path.startswith(('http://', 'https://'))
    
    if is_url:
        # 下载文件内容
        response = requests.get(file_path)
        response.raise_for_status()
        return response.text
    else:
        # 直接读取本地文件
        with open(file_path, encoding='utf-8') as f:
            return f.read()


def _read_txt_content(actual):
    parsed = _parse_json_value(actual)
    if isinstance(parsed, dict):
        snapshot = read_document_snapshot(parsed)
        if snapshot.file_type != 'txt':
            raise ValueError(f'断言仅支持 txt，当前文件类型为 {snapshot.file_type}')
        return snapshot.text
    text = str(parsed)
    if text.startswith(('http://', 'https://')) or Path(text).suffix.lower() == '.txt':
        snapshot = read_document_snapshot(text)
        if snapshot.file_type != 'txt':
            raise ValueError(f'断言仅支持 txt，当前文件类型为 {snapshot.file_type}')
        return snapshot.text
    return text


def _txt_lines(content):
    normalized = _normalize_text(content)
    return [line for line in normalized.split('\n') if line.strip()]


class TxtAssertion:
    """txt文件"""

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 0, [
        MethodModel(n='实际值', f='actual', p='实际内容或文件路径', d=True),
        MethodModel(n='预期值', f='expect', p='期望内容', d=True),
    ])
    def assert_txt_equal(actual: str, expect: str):
        """内容完全相等"""
        actual_content = _read_txt_content(actual)
        assert actual_content == expect, f'实际内容={actual_content}, 期望内容={expect}'
        return f'实际内容={actual_content}, 期望内容={expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 1, [
        MethodModel(n='实际值', f='actual', p='实际内容或文件路径', d=True),
        MethodModel(n='预期值', f='expect', p='期望包含内容', d=True),
    ])
    def assert_txt_contains(actual: str, expect: str):
        """内容包含指定字符串"""
        actual_content = _read_txt_content(actual)
        assert expect in actual_content, f'实际内容={actual_content}, 期望包含={expect}'
        return f'实际内容={actual_content}, 期望包含={expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 2, [
        MethodModel(n='实际值', f='actual', p='实际内容或文件路径', d=True),
        MethodModel(n='预期值', f='expect', p='期望长度', d=True),
    ])
    def assert_txt_length_equal(actual: str, expect: int):
        """内容长度等于期望值"""
        actual_content = _read_txt_content(actual)
        assert len(actual_content) == int(expect), f'实际长度={len(actual_content)}, 期望长度={expect}'
        return f'实际长度={len(actual_content)}, 期望长度={expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 3, [
        MethodModel(n='实际值', f='actual', p='实际内容或文件路径', d=True),
        MethodModel(n='预期值', f='expect', p='期望开头内容', d=True),
    ])
    def assert_txt_startswith(actual: str, expect: str):
        """内容以指定字符串开头"""
        actual_content = _read_txt_content(actual)
        assert actual_content.startswith(expect), f'实际内容={actual_content}, 期望开头={expect}'
        return f'实际内容={actual_content}, 期望开头={expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 4, [
        MethodModel(n='实际值', f='actual', p='实际内容或文件路径', d=True),
        MethodModel(n='预期值', f='expect', p='期望结尾内容', d=True),
    ])
    def assert_txt_endswith(actual: str, expect: str):
        """内容以指定字符串结尾"""
        actual_content = _read_txt_content(actual)
        assert actual_content.endswith(expect), f'实际内容={actual_content}, 期望结尾={expect}'
        return f'实际内容={actual_content}, 期望结尾={expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 5, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='排除文本', f='expect', p='请输入不应完全等于的文本', d=True),
    ])
    def assert_txt_not_equal(actual, expect):
        """内容不等于"""
        actual_content = _read_txt_content(actual)
        assert actual_content != str(expect), 'TXT内容不应与排除文本完全相等'
        return 'TXT内容与排除文本不相等'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 6, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='排除文本', f='expect', p='请输入不应包含的文本', d=True),
    ])
    def assert_txt_not_contains(actual, expect):
        """内容不包含文本"""
        actual_content = _read_txt_content(actual)
        assert str(expect) not in actual_content, f'TXT包含了不应出现的文本：{expect}'
        return f'TXT不包含文本：{expect}'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 7, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '预期次数': '请输入预期出现次数'}),
    ])
    def assert_txt_text_count_equal(actual, expect):
        """文本出现次数等于"""
        text, expected_count = _normalize_count_expect(expect, ('预期次数', 'count'))
        return _assert_count(
            _read_txt_content(actual).count(text), expected_count, 'equal', f'文本【{text}】出现次数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 8, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '最少次数': '请输入最少出现次数'}),
    ])
    def assert_txt_text_count_at_least(actual, expect):
        """文本出现次数不少于"""
        text, expected_count = _normalize_count_expect(expect, ('最少次数', 'count'))
        return _assert_count(
            _read_txt_content(actual).count(text),
            expected_count,
            'at_least',
            f'文本【{text}】出现次数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 9, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期值', f='expect', d=True,
                    v={'目标文本': '请输入需要统计的文本', '最多次数': '请输入最多出现次数'}),
    ])
    def assert_txt_text_count_at_most(actual, expect):
        """文本出现次数不多于"""
        text, expected_count = _normalize_count_expect(expect, ('最多次数', 'count'))
        return _assert_count(
            _read_txt_content(actual).count(text),
            expected_count,
            'at_most',
            f'文本【{text}】出现次数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 10, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='预期行数', f='expect', p='请输入预期非空行数', d=True),
    ])
    def assert_txt_line_count_equal(actual, expect):
        """非空行数等于"""
        expected_count = _normalize_integer_expect(expect, ('预期行数', 'count'))
        return _assert_count(
            len(_txt_lines(_read_txt_content(actual))), expected_count, 'equal', 'TXT非空行数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 11, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最少行数', f='expect', p='请输入最少非空行数', d=True),
    ])
    def assert_txt_line_count_at_least(actual, expect):
        """非空行数不少于"""
        expected_count = _normalize_integer_expect(expect, ('最少行数', 'count'))
        return _assert_count(
            len(_txt_lines(_read_txt_content(actual))),
            expected_count,
            'at_least',
            'TXT非空行数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 12, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最多行数', f='expect', p='请输入最多非空行数', d=True),
    ])
    def assert_txt_line_count_at_most(actual, expect):
        """非空行数不多于"""
        expected_count = _normalize_integer_expect(expect, ('最多行数', 'count'))
        return _assert_count(
            len(_txt_lines(_read_txt_content(actual))),
            expected_count,
            'at_most',
            'TXT非空行数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 13, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最少字符数', f='expect', p='请输入最少字符数', d=True),
    ])
    def assert_txt_length_at_least(actual, expect):
        """内容长度不少于"""
        expected_count = _normalize_integer_expect(expect, ('最少字符数', 'count'))
        return _assert_count(
            len(_read_txt_content(actual)), expected_count, 'at_least', 'TXT字符数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 14, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
        MethodModel(n='最多字符数', f='expect', p='请输入最多字符数', d=True),
    ])
    def assert_txt_length_at_most(actual, expect):
        """内容长度不多于"""
        expected_count = _normalize_integer_expect(expect, ('最多字符数', 'count'))
        return _assert_count(
            len(_read_txt_content(actual)), expected_count, 'at_most', 'TXT字符数',
        )

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 15, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
    ])
    def assert_txt_empty(actual):
        """内容为空"""
        actual_content = _read_txt_content(actual)
        assert not actual_content, f'TXT内容不为空，实际字符数={len(actual_content)}'
        return 'TXT内容为空'

    @staticmethod
    @sync_method_callback('文件断言', 'TXT断言', 16, [
        MethodModel(n='实际值', f='actual', p='实际内容、TXT文件路径、下载地址或缓存变量', d=True),
    ])
    def assert_txt_not_empty(actual):
        """内容不为空"""
        actual_content = _read_txt_content(actual)
        assert actual_content, 'TXT内容为空'
        return f'TXT内容不为空，实际字符数={len(actual_content)}'
