# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 14:10
# @Author : 毛鹏
from ...decorator import sync_method_callback
from ...models import MethodModel


EMPTY_VALUE_TYPES = (str, list, tuple, set, dict)


def _strict_type_error(actual, expected_type):
    raise AssertionError(
        f'实际={actual}({type(actual).__name__}), 预期类型={expected_type}'
    )


class WhatIsItAssertion:
    """类型是什么"""

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 0, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_not_none(actual, expect=None):
        """不是null"""
        if actual is None:
            raise AssertionError(f'实际={actual}, 预期=不是None')
        return f'实际={actual}, 预期=不是None'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 1, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_none(actual, expect=None):
        """是null"""
        if actual is not None:
            raise AssertionError(f'实际={actual}, 预期=是None')
        return f'实际={actual}, 预期=是None'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 2, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_empty(actual, expect=None):
        """是空值"""
        if not isinstance(actual, EMPTY_VALUE_TYPES):
            _strict_type_error(actual, '字符串或集合')
        if len(actual) != 0:
            raise AssertionError(f'实际={actual}, 预期=是空值')
        return f'实际={actual}, 预期=是空值'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 3, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_not_empty(actual, expect=None):
        """不是空值"""
        if not isinstance(actual, EMPTY_VALUE_TYPES):
            _strict_type_error(actual, '字符串或集合')
        if len(actual) == 0:
            raise AssertionError(f'实际={actual}, 预期=不是空值')
        return f'实际={actual}, 预期=不是空值'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 4, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_false(actual, expect=None):
        """是False"""
        if actual is not False:
            raise AssertionError(
                f'实际={actual}({type(actual).__name__}), 预期=False(bool)'
            )
        return f'实际={actual}, 预期=是False'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 5, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_true(actual, expect=None):
        """是True"""
        if actual is not True:
            raise AssertionError(
                f'实际={actual}({type(actual).__name__}), 预期=True(bool)'
            )
        return f'实际={actual}, 预期=是True'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 6, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_alpha(actual, expect=None):
        """是字母"""
        if not isinstance(actual, str):
            _strict_type_error(actual, '字符串')
        if not actual.isalpha():
            raise AssertionError(f'实际={actual}, 预期=是字母')
        return f'实际={actual}, 预期=是字母'

    @staticmethod
    @sync_method_callback('内容断言', '类型是什么', 7, [
        MethodModel(n='实际值', f='actual', d=True)])
    def p_is_digit(actual, expect=None):
        """是整数"""
        if not isinstance(actual, int) or isinstance(actual, bool):
            _strict_type_error(actual, '整数')
        return f'实际={actual}, 预期=是整数'
