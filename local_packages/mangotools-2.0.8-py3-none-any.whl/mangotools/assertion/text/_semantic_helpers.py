# -*- coding: utf-8 -*-
import json
import re
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

from ...models import MethodModel, MethodObjectFieldModel


def parse_number(value, field_name='值') -> Decimal:
    if isinstance(value, bool) or value is None:
        raise AssertionError(f'{field_name}={value} 不是有效数字')
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, TypeError, ValueError) as error:
        raise AssertionError(f'{field_name}={value} 不是有效数字') from error
    if not number.is_finite():
        raise AssertionError(f'{field_name}={value} 不是有效数字')
    return number


def parse_json(value, expected_type=None, field_name='预期值'):
    parsed = value
    if isinstance(value, str):
        try:
            parsed = json.loads(value.strip())
        except (json.JSONDecodeError, TypeError) as error:
            raise AssertionError(f'{field_name}不是合法JSON：{value}') from error
    if expected_type is not None and not isinstance(parsed, expected_type):
        expected_name = '或'.join(item.__name__ for item in expected_type) if isinstance(expected_type, tuple) else expected_type.__name__
        raise AssertionError(f'{field_name}必须是{expected_name}，实际类型={type(parsed).__name__}')
    return parsed


def parse_object(value, field_name='预期值') -> dict:
    return parse_json(value, dict, field_name)


def parse_list(value, field_name='预期值') -> list:
    return parse_json(value, list, field_name)


def parse_keys(value, field_name='预期字段') -> list[str]:
    if isinstance(value, (list, tuple, set)):
        keys = list(value)
    elif isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith('['):
            keys = parse_list(stripped, field_name)
        else:
            keys = [item.strip() for item in stripped.split(',') if item.strip()]
    else:
        keys = [value]
    if not keys:
        raise AssertionError(f'{field_name}不能为空')
    return [str(item) for item in keys]


def loose_equal(actual, expect) -> bool:
    if actual == expect:
        return True
    if isinstance(actual, (dict, list)) or isinstance(expect, (dict, list)):
        return False
    return str(actual) == str(expect)


def deep_loose_equal(actual, expect) -> bool:
    if isinstance(actual, dict) and isinstance(expect, dict):
        return set(actual) == set(expect) and all(
            deep_loose_equal(actual[key], expect[key]) for key in actual
        )
    if isinstance(actual, list) and isinstance(expect, list):
        return len(actual) == len(expect) and all(
            deep_loose_equal(left, right) for left, right in zip(actual, expect)
        )
    return loose_equal(actual, expect)


def deep_contains(actual, expect) -> bool:
    if isinstance(expect, dict):
        return isinstance(actual, dict) and all(
            key in actual and deep_contains(actual[key], value)
            for key, value in expect.items()
        )
    if isinstance(expect, list):
        return isinstance(actual, list) and unordered_equal(actual, expect)
    return loose_equal(actual, expect)


def unordered_equal(actual: list, expect: list) -> bool:
    if len(actual) != len(expect):
        return False
    remaining = list(actual)
    for expected_item in expect:
        matched_index = next(
            (index for index, actual_item in enumerate(remaining) if deep_loose_equal(actual_item, expected_item)),
            None,
        )
        if matched_index is None:
            return False
        remaining.pop(matched_index)
    return True


def list_contains_all(actual: list, expect: list) -> bool:
    return all(any(deep_loose_equal(item, expected_item) for item in actual) for expected_item in expect)


def canonical_value(value) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)
    except (TypeError, ValueError):
        return repr(value)


def parse_datetime_value(value, field_name='时间') -> datetime:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, date):
        parsed = datetime.combine(value, datetime.min.time())
    elif isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        timestamp = float(value)
        if abs(timestamp) >= 100_000_000_000:
            timestamp /= 1000
        try:
            parsed = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        except (OverflowError, OSError, ValueError) as error:
            raise AssertionError(f'{field_name}={value} 不是有效时间戳') from error
    else:
        text = str(value).strip()
        if re.fullmatch(r'-?\d+(?:\.\d+)?', text):
            return parse_datetime_value(Decimal(text), field_name)
        normalized = text[:-1] + '+00:00' if text.endswith(('Z', 'z')) else text
        parsed = None
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            for fmt in (
                '%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S',
                '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M',
                '%Y-%m-%d', '%Y/%m/%d',
            ):
                try:
                    parsed = datetime.strptime(text, fmt)
                    break
                except ValueError:
                    continue
        if parsed is None:
            raise AssertionError(f'{field_name}={value} 不是有效日期时间')
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone().replace(tzinfo=None)
    return parsed


def parse_config(value, required_keys: tuple[str, ...], field_name='预期配置') -> dict:
    config = parse_object(value, field_name)
    missing = [key for key in required_keys if config.get(key) in (None, '')]
    if missing:
        raise AssertionError(f'{field_name}缺少字段：{",".join(missing)}')
    return config


def object_config_parameter(name: str, fields: list[tuple]) -> MethodModel:
    """Create an object parameter whose field labels and controls come from mangotools."""
    examples = {}
    object_fields = []
    for field, field_name, example, placeholder, value_type in fields:
        examples[field] = example
        object_fields.append(
            MethodObjectFieldModel(
                f=field,
                n=field_name,
                p=placeholder,
                value_type=value_type,
                input_type='number' if value_type == 'number' else None,
            )
        )
    return MethodModel(
        n=name,
        f='expect',
        p=f'请输入{name}',
        v=examples,
        d=True,
        value_type='object',
        input_type='object',
        object_fields=object_fields,
    )
