# -*- coding: utf-8 -*-
import jsonpath

from ...decorator import sync_method_callback
from ...models import MethodModel
from ._semantic_helpers import (
    canonical_value,
    deep_contains,
    deep_loose_equal,
    list_contains_all,
    parse_json,
    parse_keys,
    parse_list,
    parse_object,
    unordered_equal,
    object_config_parameter,
)


def _actual_only(value_type='json'):
    return [MethodModel(n='实际值', f='actual', d=True, value_type=value_type, input_type='json')]


def _actual_expect(name='预期值', example='id', actual_type='object', expect_type=None):
    return [
        MethodModel(n='实际值', f='actual', d=True, value_type=actual_type, input_type='json'),
        MethodModel(
            n=name,
            f='expect',
            p=f'请输入{name}',
            v=example,
            d=True,
            value_type=expect_type,
            input_type='json' if expect_type in {'object', 'array', 'json'} else None,
        ),
    ]


def _dict(value, field_name='实际值') -> dict:
    return parse_json(value, dict, field_name)


def _list(value, field_name='实际值') -> list:
    return parse_json(value, list, field_name)


def _is_blank(value) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


class DictJsonAssertion:
    """字典与JSON对象断言"""

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 0, _actual_expect('字段名', 'id'))
    def p_has_key(actual, expect):
        """包含指定字段"""
        data = _dict(actual)
        key = str(expect)
        if key not in data:
            raise AssertionError(f'实际字段={list(data)}，缺少字段={key}')
        return f'实际对象包含字段={key}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 1, _actual_expect('字段名', 'password'))
    def p_does_not_have_key(actual, expect):
        """不包含指定字段"""
        data = _dict(actual)
        key = str(expect)
        if key in data:
            raise AssertionError(f'实际对象包含了不应存在的字段={key}')
        return f'实际对象不包含字段={key}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 2, _actual_expect('字段列表', '["id","name"]', expect_type='array'))
    def p_has_all_keys(actual, expect):
        """包含全部指定字段"""
        data = _dict(actual)
        keys = parse_keys(expect)
        missing = [key for key in keys if key not in data]
        if missing:
            raise AssertionError(f'实际字段={list(data)}，缺少字段={missing}')
        return f'实际对象包含全部字段={keys}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 3, _actual_expect('字段列表', '["id","code"]', expect_type='array'))
    def p_has_any_key(actual, expect):
        """至少包含一个指定字段"""
        data = _dict(actual)
        keys = parse_keys(expect)
        matched = [key for key in keys if key in data]
        if not matched:
            raise AssertionError(f'实际字段={list(data)}，预期至少包含一个={keys}')
        return f'实际对象包含字段={matched}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 4, _actual_expect('完整字段列表', '["id","name"]', expect_type='array'))
    def p_has_exact_keys(actual, expect):
        """字段集合与预期完全一致"""
        data = _dict(actual)
        keys = parse_keys(expect)
        if set(data) != set(keys):
            raise AssertionError(f'实际字段={list(data)}，预期字段={keys}')
        return f'实际字段与预期完全一致={keys}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 5, _actual_expect('预期JSON子集', '{"id":1}', expect_type='object'))
    def p_dict_contains(actual, expect):
        """对象包含预期字段和值"""
        data = _dict(actual)
        expected = parse_object(expect)
        if not deep_contains(data, expected):
            raise AssertionError(f'实际={data}，未包含预期={expected}')
        return f'实际对象包含预期内容={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 6, _actual_expect('排除JSON内容', '{"status":0}', expect_type='object'))
    def p_dict_not_contains(actual, expect):
        """对象不包含指定字段和值"""
        data = _dict(actual)
        expected = parse_object(expect)
        if deep_contains(data, expected):
            raise AssertionError(f'实际={data}，包含了不应出现的内容={expected}')
        return f'实际对象不包含指定内容={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 7, _actual_only())
    def p_all_values_not_none(actual, expect=None):
        """对象所有字段值都不是null"""
        data = _dict(actual)
        empty_keys = [key for key, value in data.items() if value is None]
        if empty_keys:
            raise AssertionError(f'值为null的字段={empty_keys}')
        return '对象所有字段值都不是null'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 8, _actual_only())
    def p_all_values_not_blank(actual, expect=None):
        """对象所有字段值都不是空白值"""
        data = _dict(actual)
        empty_keys = [key for key, value in data.items() if _is_blank(value)]
        if empty_keys:
            raise AssertionError(f'值为空白的字段={empty_keys}')
        return '对象所有字段值都不是空白值'

    @staticmethod
    def _jsonpath(actual, expect):
        data = parse_json(actual, (dict, list), '实际值')
        expression = str(expect).strip()
        if not expression:
            raise AssertionError('JSONPath不能为空')
        try:
            result = jsonpath.jsonpath(data, expression)
        except Exception as error:
            raise AssertionError(f'JSONPath表达式无效：{expression}，错误={error}') from error
        return expression, result

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 9, _actual_expect('JSONPath', '$.user.id'))
    def p_json_path_exists(actual, expect):
        """JSONPath存在"""
        expression, result = DictJsonAssertion._jsonpath(actual, expect)
        if result is False:
            raise AssertionError(f'JSONPath不存在：{expression}')
        return f'JSONPath存在：{expression}，匹配数量={len(result)}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 10, _actual_expect('JSONPath', '$.user.password'))
    def p_json_path_not_exists(actual, expect):
        """JSONPath不存在"""
        expression, result = DictJsonAssertion._jsonpath(actual, expect)
        if result is not False:
            raise AssertionError(f'JSONPath实际存在：{expression}，匹配数量={len(result)}')
        return f'JSONPath不存在：{expression}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 11, _actual_expect('JSONPath', '$.user.name'))
    def p_json_path_not_empty(actual, expect):
        """JSONPath存在且结果非空"""
        expression, result = DictJsonAssertion._jsonpath(actual, expect)
        if result is False:
            raise AssertionError(f'JSONPath不存在：{expression}')
        empty_indexes = [index for index, value in enumerate(result) if _is_blank(value) or value in ([], {})]
        if empty_indexes:
            raise AssertionError(f'JSONPath={expression} 的空结果位置={empty_indexes}')
        return f'JSONPath存在且结果非空：{expression}'


class ListSemanticAssertion:
    """列表语义断言"""

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 0, _actual_expect('预期列表', '[1,2,3]', 'array', 'array'))
    def p_list_equal_ordered(actual, expect):
        """列表按顺序与预期一致"""
        data = _list(actual)
        expected = parse_list(expect)
        if not deep_loose_equal(data, expected):
            raise AssertionError(f'实际列表={data}，预期有序列表={expected}')
        return f'实际列表与预期顺序一致={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 1, _actual_expect('预期列表', '[1,2,3]', 'array', 'array'))
    def p_list_equal_unordered(actual, expect):
        """列表忽略顺序与预期一致"""
        data = _list(actual)
        expected = parse_list(expect)
        if not unordered_equal(data, expected):
            raise AssertionError(f'实际列表={data}，预期无序列表={expected}')
        return f'实际列表忽略顺序后与预期一致={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 2, _actual_expect('预期元素列表', '[1,3]', 'array', 'array'))
    def p_list_contains_all(actual, expect):
        """列表包含全部预期元素"""
        data = _list(actual)
        expected = parse_list(expect)
        if not list_contains_all(data, expected):
            raise AssertionError(f'实际列表={data}，未包含全部预期元素={expected}')
        return f'实际列表包含全部预期元素={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 3, _actual_expect('候选元素列表', '[3,4]', 'array', 'array'))
    def p_list_contains_any(actual, expect):
        """列表包含任意一个预期元素"""
        data = _list(actual)
        expected = parse_list(expect)
        if not any(deep_loose_equal(item, expected_item) for item in data for expected_item in expected):
            raise AssertionError(f'实际列表={data}，未包含任何预期元素={expected}')
        return f'实际列表至少包含一个预期元素={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 4, _actual_expect('排除元素列表', '[3,4]', 'array', 'array'))
    def p_list_contains_none(actual, expect):
        """列表不包含任何排除元素"""
        data = _list(actual)
        expected = parse_list(expect)
        matched = [item for item in data if any(deep_loose_equal(item, expected_item) for expected_item in expected)]
        if matched:
            raise AssertionError(f'实际列表包含了排除元素={matched}')
        return f'实际列表不包含任何排除元素={expected}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 5, _actual_only('array'))
    def p_list_is_unique(actual, expect=None):
        """列表元素全部唯一"""
        data = _list(actual)
        seen = set()
        duplicates = []
        for item in data:
            key = canonical_value(item)
            if key in seen:
                duplicates.append(item)
            seen.add(key)
        if duplicates:
            raise AssertionError(f'列表存在重复元素={duplicates}')
        return '列表元素全部唯一'

    @staticmethod
    def _sorted(actual, reverse=False):
        data = _list(actual)
        try:
            expected = sorted(data, reverse=reverse)
        except TypeError as error:
            raise AssertionError(f'列表元素类型不一致，无法排序：{data}') from error
        if data != expected:
            direction = '降序' if reverse else '升序'
            raise AssertionError(f'实际列表={data}，预期{direction}={expected}')
        return data

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 6, _actual_only('array'))
    def p_list_is_sorted_ascending(actual, expect=None):
        """列表按升序排列"""
        data = ListSemanticAssertion._sorted(actual)
        return f'列表按升序排列={data}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 7, _actual_only('array'))
    def p_list_is_sorted_descending(actual, expect=None):
        """列表按降序排列"""
        data = ListSemanticAssertion._sorted(actual, reverse=True)
        return f'列表按降序排列={data}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 8, _actual_only('array'))
    def p_list_items_not_none(actual, expect=None):
        """列表所有元素都不是null"""
        data = _list(actual)
        indexes = [index for index, value in enumerate(data) if value is None]
        if indexes:
            raise AssertionError(f'值为null的元素位置={indexes}')
        return '列表所有元素都不是null'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 9, _actual_only('array'))
    def p_list_items_not_blank(actual, expect=None):
        """列表所有元素都不是空白值"""
        data = _list(actual)
        indexes = [index for index, value in enumerate(data) if _is_blank(value)]
        if indexes:
            raise AssertionError(f'值为空白的元素位置={indexes}')
        return '列表所有元素都不是空白值'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 10, _actual_expect('字段名', 'id', 'array'))
    def p_list_objects_have_key(actual, expect):
        """列表中每个对象都包含指定字段"""
        data = _list(actual)
        key = str(expect)
        invalid = [index for index, item in enumerate(data) if not isinstance(item, dict) or key not in item]
        if invalid:
            raise AssertionError(f'未包含字段={key}的元素位置={invalid}')
        return f'列表中每个对象都包含字段={key}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 11, _actual_expect('字段列表', '["id","name"]', 'array', 'array'))
    def p_list_objects_have_all_keys(actual, expect):
        """列表中每个对象都包含全部字段"""
        data = _list(actual)
        keys = parse_keys(expect)
        invalid = [
            index for index, item in enumerate(data)
            if not isinstance(item, dict) or any(key not in item for key in keys)
        ]
        if invalid:
            raise AssertionError(f'未包含全部字段={keys}的元素位置={invalid}')
        return f'列表中每个对象都包含全部字段={keys}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 12, _actual_expect('唯一字段名', 'id', 'array'))
    def p_list_field_unique(actual, expect):
        """对象列表指定字段值唯一"""
        data = _list(actual)
        key = str(expect)
        values = []
        missing = []
        for index, item in enumerate(data):
            if not isinstance(item, dict) or key not in item:
                missing.append(index)
            else:
                values.append(item[key])
        if missing:
            raise AssertionError(f'缺少字段={key}的元素位置={missing}')
        canonical = [canonical_value(value) for value in values]
        if len(canonical) != len(set(canonical)):
            raise AssertionError(f'字段={key}存在重复值，实际值={values}')
        return f'字段={key}的值全部唯一'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 13, [
        MethodModel(n='实际值', f='actual', d=True, value_type='array', input_type='json'),
        object_config_parameter('预期配置', [
            ('field', '字段名', 'id', '请输入需要比较的字段名', 'string'),
            ('values', '预期值列表', [1, 2], '请输入JSON数组', 'array'),
        ]),
    ])
    def p_list_field_values_equal(actual, expect):
        """对象列表指定字段值集合与预期一致"""
        data = _list(actual)
        config = parse_object(expect)
        if config.get('field') in (None, '') or not isinstance(config.get('values'), list):
            raise AssertionError('预期配置必须包含field和列表类型values')
        field = str(config['field'])
        missing = [index for index, item in enumerate(data) if not isinstance(item, dict) or field not in item]
        if missing:
            raise AssertionError(f'缺少字段={field}的元素位置={missing}')
        values = [item[field] for item in data]
        if not unordered_equal(values, config['values']):
            raise AssertionError(f'字段={field}的实际值={values}，预期值={config["values"]}')
        return f'字段={field}的值集合与预期一致={config["values"]}'


class CollectionStateAssertion:
    """集合和空值状态断言"""

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 0, _actual_only())
    def p_is_empty_collection(actual, expect=None):
        """是空集合"""
        if not isinstance(actual, (list, tuple, set, dict)):
            raise AssertionError(f'实际类型={type(actual).__name__}，预期为集合类型')
        if len(actual) != 0:
            raise AssertionError(f'实际集合长度={len(actual)}，预期为空集合')
        return '实际值是空集合'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 1, _actual_only())
    def p_is_not_empty_collection(actual, expect=None):
        """不是空集合"""
        if not isinstance(actual, (list, tuple, set, dict)):
            raise AssertionError(f'实际类型={type(actual).__name__}，预期为集合类型')
        if len(actual) == 0:
            raise AssertionError('实际值是空集合，预期为非空集合')
        return f'实际集合长度={len(actual)}'

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 2, _actual_only())
    def p_is_none_or_empty(actual, expect=None):
        """是null或空值"""
        if actual is None:
            return '实际值是null'
        if isinstance(actual, (str, list, tuple, set, dict)) and len(actual) == 0:
            return f'实际值是空{type(actual).__name__}'
        raise AssertionError(f'实际={actual}，预期为null或空值')

    @staticmethod
    @sync_method_callback('内容断言', '结构化数据断言', 3, _actual_only())
    def p_is_neither_none_nor_empty(actual, expect=None):
        """既不是null也不是空值"""
        if actual is None or (isinstance(actual, (str, list, tuple, set, dict)) and len(actual) == 0):
            raise AssertionError(f'实际={actual}，预期为非null且非空值')
        return f'实际={actual}，既不是null也不是空值'
