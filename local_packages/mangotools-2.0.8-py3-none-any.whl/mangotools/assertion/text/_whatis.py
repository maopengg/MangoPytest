# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 14:10
# @Author : 毛鹏
from assertpy import assert_that

from ...decorator import sync_method_callback
from ...models import MethodModel


def _assert_that(actual):
    if actual is None:
        raise AssertionError(f"实际值不能为 None ，可能是在获取实际值的时候就失败了！")
    return assert_that(actual)


class WhatIsEqualToAssertion:
    """值等于什么"""

    @staticmethod
    @sync_method_callback('内容断言', '值等于什么', 0, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_is_equal_to(actual, expect):
        """等于expect"""
        if actual == expect:
            return f'实际={actual}, 预期={expect}'

        if str(actual) == str(expect):
            return f'实际={actual}, 预期={expect}'

        raise AssertionError(
            f'实际={actual}({type(actual).__name__}), '
            f'预期={expect}({type(expect).__name__})'
        )

    @staticmethod
    @sync_method_callback('内容断言', '值等于什么', 1, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_is_not_equal_to(actual, expect):
        """不等于expect"""
        if actual == expect or str(actual) == str(expect):
            raise AssertionError(
                f'实际={actual}({type(actual).__name__}), '
                f'预期={expect}({type(expect).__name__})'
            )
        return f'实际={actual}, 预期={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '值等于什么', 2, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_is_length(actual: str, expect: str):
        """长度等于expect"""
        if actual is None or not hasattr(actual, '__len__'):
            raise AssertionError(f'实际={actual} 不支持长度判断')
        actual_length = len(actual)
        expected_length = int(expect)
        try:
            _assert_that(actual_length).is_equal_to(expected_length)
        except AssertionError as e:
            raise AssertionError(
                f'实际长度={actual_length}, 预期长度={expected_length}'
            ) from e
        return f'实际长度={actual_length}, 预期长度={expected_length}'

    @staticmethod
    @sync_method_callback('内容断言', '值等于什么', 4, [
        MethodModel(n='实际值', f='actual', d=True),
        MethodModel(n='期望长度', f='expect', d=True),
    ])
    def len_eq(actual, expect):
        """长度等于期望值"""
        try:
            if hasattr(actual, '__len__'):
                actual_len = len(actual)
                assert_that(actual_len).is_equal_to(int(expect))
                return f'实际长度={actual_len}, 期望长度={expect}'
            assert_that(actual).is_equal_to(int(expect))
            return f'实际值={actual}, 期望值={expect}'
        except AssertionError as error:
            if hasattr(actual, '__len__'):
                raise AssertionError(f'实际长度={len(actual)}, 期望长度={expect}') from error
            raise AssertionError(f'实际值={actual}, 期望值={expect}') from error
        except TypeError as error:
            raise AssertionError(f'不支持的类型: {type(actual).__name__}') from error

    @staticmethod
    @sync_method_callback('内容断言', '值等于什么', 3, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_sum_equal_expect(actual: list, expect: str):
        """合计等于expect"""
        actual_sum = sum(actual)
        if actual_sum == expect:
            return f'实际={actual_sum}, 预期={expect}'

        if str(actual_sum) == str(expect):
            return f'实际={actual_sum}, 预期={expect}'

        raise AssertionError(
            f'实际={actual_sum}({type(actual_sum).__name__}), '
            f'预期={expect}({type(expect).__name__})'
        )
