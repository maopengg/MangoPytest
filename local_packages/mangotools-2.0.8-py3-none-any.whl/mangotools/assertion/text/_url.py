# -*- coding: utf-8 -*-
import json
import re
from urllib.parse import urlparse

import requests

from ...decorator import sync_method_callback
from ...models import MethodModel
from ._semantic_helpers import object_config_parameter


DEFAULT_URL_TIMEOUT = 10
NO_PROXY = {'http': None, 'https': None}


def _validate_url(value) -> str:
    url = str(value or '').strip()
    parsed = urlparse(url)
    if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
        raise AssertionError(f'URL格式错误：{url or "未输入"}，仅支持http和https')
    return url


def _request_url(value):
    url = _validate_url(value)
    session = requests.Session()
    # 测试平台的URL断言必须直接访问目标地址，不继承HTTP_PROXY等环境代理。
    session.trust_env = False
    try:
        return session.request(
            method='GET',
            url=url,
            timeout=DEFAULT_URL_TIMEOUT,
            allow_redirects=True,
            proxies=NO_PROXY,
        )
    except requests.RequestException as error:
        raise AssertionError(f'URL请求失败：{url}，原因：{error}') from error
    finally:
        session.close()


def _expected_header(value) -> tuple[str, str]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as error:
            raise AssertionError('预期响应头必须是JSON对象，格式如：{"name":"Content-Type","value":"json"}') from error
    if not isinstance(value, dict):
        raise AssertionError('预期响应头必须是JSON对象')
    name = str(value.get('name') or '').strip()
    expected = str(value.get('value') or '')
    if not name:
        raise AssertionError('预期响应头缺少name字段')
    return name, expected


class UrlAssertion:
    """URL断言"""

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 0, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
    ])
    def p_url_is_accessible(actual, expect=None):
        """URL可以访问"""
        response = _request_url(actual)
        if response.status_code < 400:
            return f'URL可以访问，状态码={response.status_code}，最终地址={response.url}'
        raise AssertionError(f'URL不可访问，状态码={response.status_code}，地址={response.url}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 1, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com/not-found', d=True),
    ])
    def p_url_is_not_accessible(actual, expect=None):
        """URL不可访问"""
        try:
            response = _request_url(actual)
        except AssertionError as error:
            return f'URL不可访问，原因：{error}'
        if response.status_code >= 400:
            return f'URL不可访问，状态码={response.status_code}，地址={response.url}'
        raise AssertionError(f'URL实际可以访问，状态码={response.status_code}，地址={response.url}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 2, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
        MethodModel(n='预期状态码', f='expect', p='请输入HTTP状态码', v=200, d=True, value_type='number', input_type='number'),
    ])
    def p_url_status_code_is(actual, expect):
        """URL状态码等于预期值"""
        response = _request_url(actual)
        try:
            expected_status = int(expect)
        except (TypeError, ValueError) as error:
            raise AssertionError(f'预期状态码不是有效整数：{expect}') from error
        if response.status_code == expected_status:
            return f'URL状态码={response.status_code}'
        raise AssertionError(f'URL状态码={response.status_code}，预期状态码={expected_status}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 3, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
        MethodModel(n='预期内容', f='expect', p='请输入页面应包含的内容', v='Example Domain', d=True),
    ])
    def p_url_content_contains(actual, expect):
        """URL内容包含预期文本"""
        response = _request_url(actual)
        expected = str(expect)
        if expected in response.text:
            return f'URL内容包含：{expected}'
        raise AssertionError(f'URL内容不包含：{expected}，状态码={response.status_code}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 4, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
        MethodModel(n='排除内容', f='expect', p='请输入页面不应包含的内容', v='error', d=True),
    ])
    def p_url_content_not_contains(actual, expect):
        """URL内容不包含预期文本"""
        response = _request_url(actual)
        expected = str(expect)
        if expected not in response.text:
            return f'URL内容不包含：{expected}'
        raise AssertionError(f'URL内容包含了不应出现的文本：{expected}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 5, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
        MethodModel(n='正则表达式', f='expect', p='请输入匹配页面内容的正则表达式', v=r'Example\s+Domain', d=True),
    ])
    def p_url_content_matches_regex(actual, expect):
        """URL内容匹配正则表达式"""
        response = _request_url(actual)
        try:
            matched = re.search(str(expect), response.text)
        except re.error as error:
            raise AssertionError(f'正则表达式无效：{error}') from error
        if matched:
            return f'URL内容匹配正则：{expect}'
        raise AssertionError(f'URL内容未匹配正则：{expect}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 6, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
        object_config_parameter('预期响应头', [
            ('name', '响应头名称', 'Content-Type', '请输入响应头名称', 'string'),
            ('value', '包含值', 'text/html', '请输入响应头应包含的值', 'string'),
        ]),
    ])
    def p_url_header_contains(actual, expect):
        """URL响应头包含预期值"""
        response = _request_url(actual)
        name, expected = _expected_header(expect)
        actual_value = response.headers.get(name)
        if actual_value is None:
            raise AssertionError(f'URL响应头不存在：{name}')
        if expected in actual_value:
            return f'URL响应头{name}={actual_value}'
        raise AssertionError(f'URL响应头{name}={actual_value}，未包含预期值={expected}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 7, [
        MethodModel(n='URL', f='actual', p='请输入可能发生重定向的地址', v='http://example.com', d=True),
        MethodModel(n='预期最终地址', f='expect', p='请输入重定向后的完整URL', v='https://example.com/', d=True),
    ])
    def p_url_final_url_is(actual, expect):
        """URL重定向后的地址等于预期值"""
        response = _request_url(actual)
        expected_url = _validate_url(expect)
        if response.url == expected_url:
            return f'URL最终地址={response.url}'
        raise AssertionError(f'URL最终地址={response.url}，预期地址={expected_url}')

    @staticmethod
    @sync_method_callback('内容断言', 'URL断言', 8, [
        MethodModel(n='URL', f='actual', p='请输入http或https地址', v='https://example.com', d=True),
        MethodModel(n='最大耗时(ms)', f='expect', p='请输入允许的最大响应时间', v=1000, d=True, value_type='number', input_type='number'),
    ])
    def p_url_response_time_less_than(actual, expect):
        """URL响应耗时小于预期毫秒数"""
        response = _request_url(actual)
        try:
            expected_ms = float(expect)
        except (TypeError, ValueError) as error:
            raise AssertionError(f'最大耗时不是有效数字：{expect}') from error
        actual_ms = response.elapsed.total_seconds() * 1000
        if actual_ms < expected_ms:
            return f'URL响应耗时={actual_ms:.2f}ms，预期小于={expected_ms:g}ms'
        raise AssertionError(f'URL响应耗时={actual_ms:.2f}ms，预期小于={expected_ms:g}ms')
