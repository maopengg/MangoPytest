# -*- coding: utf-8 -*-
from datetime import datetime

from ...decorator import sync_method_callback
from ...models import MethodModel
from ._semantic_helpers import object_config_parameter, parse_config, parse_datetime_value, parse_number


def _actual_only():
    return [MethodModel(n='实际值', f='actual', d=True)]


def _actual_expect(name='预期时间', example='2026-08-09 12:00:00'):
    return [
        MethodModel(n='实际值', f='actual', d=True),
        MethodModel(n=name, f='expect', p=f'请输入{name}', v=example, d=True),
    ]


class DatetimeAssertion:
    """日期时间断言"""

    @staticmethod
    @sync_method_callback('内容断言', '时间断言', 0, _actual_expect())
    def p_datetime_before(actual, expect):
        """时间早于预期时间"""
        actual_time = parse_datetime_value(actual, '实际时间')
        expected_time = parse_datetime_value(expect, '预期时间')
        if actual_time >= expected_time:
            raise AssertionError(f'实际时间={actual}，预期早于={expect}')
        return f'实际时间={actual}，早于={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '时间断言', 1, _actual_expect())
    def p_datetime_after(actual, expect):
        """时间晚于预期时间"""
        actual_time = parse_datetime_value(actual, '实际时间')
        expected_time = parse_datetime_value(expect, '预期时间')
        if actual_time <= expected_time:
            raise AssertionError(f'实际时间={actual}，预期晚于={expect}')
        return f'实际时间={actual}，晚于={expect}'

    @staticmethod
    @sync_method_callback(
        '内容断言', '时间断言', 2,
        [
            MethodModel(n='实际值', f='actual', d=True),
            object_config_parameter('时间区间', [
                ('start', '开始时间', '2026-08-09 10:00:00', '请输入开始时间', 'string'),
                ('end', '结束时间', '2026-08-09 14:00:00', '请输入结束时间', 'string'),
            ]),
        ],
    )
    def p_datetime_between(actual, expect):
        """时间位于闭区间"""
        config = parse_config(expect, ('start', 'end'))
        actual_time = parse_datetime_value(actual, '实际时间')
        start = parse_datetime_value(config['start'], '开始时间')
        end = parse_datetime_value(config['end'], '结束时间')
        if start > end:
            raise AssertionError(f'开始时间={config["start"]} 不能晚于结束时间={config["end"]}')
        if not start <= actual_time <= end:
            raise AssertionError(f'实际时间={actual}，预期区间=[{config["start"]}, {config["end"]}]')
        return f'实际时间={actual}，位于区间=[{config["start"]}, {config["end"]}]'

    @staticmethod
    @sync_method_callback(
        '内容断言', '时间断言', 3,
        [
            MethodModel(n='实际值', f='actual', d=True),
            object_config_parameter('预期配置', [
                ('value', '目标时间', '2026-08-09 12:00:00', '请输入目标时间', 'string'),
                ('tolerance_seconds', '允许误差秒数', 10, '请输入允许误差秒数', 'number'),
            ]),
        ],
    )
    def p_datetime_close_to(actual, expect):
        """时间在允许误差秒数内"""
        config = parse_config(expect, ('value', 'tolerance_seconds'))
        tolerance = parse_number(config['tolerance_seconds'], '允许误差秒数')
        if tolerance < 0:
            raise AssertionError('允许误差秒数不能小于0')
        actual_time = parse_datetime_value(actual, '实际时间')
        expected_time = parse_datetime_value(config['value'], '目标时间')
        difference = abs((actual_time - expected_time).total_seconds())
        if difference > float(tolerance):
            raise AssertionError(
                f'实际时间={actual}，目标时间={config["value"]}，时间差={difference}秒，允许误差={tolerance}秒'
            )
        return f'实际时间与目标时间相差={difference}秒，允许误差={tolerance}秒'

    @staticmethod
    @sync_method_callback('内容断言', '时间断言', 4, _actual_only())
    def p_datetime_is_today(actual, expect=None):
        """日期是今天"""
        actual_time = parse_datetime_value(actual, '实际时间')
        today = datetime.now().date()
        if actual_time.date() != today:
            raise AssertionError(f'实际日期={actual_time.date()}，今天={today}')
        return f'实际日期={actual_time.date()}，是今天'

    @staticmethod
    @sync_method_callback('内容断言', '时间断言', 5, _actual_only())
    def p_datetime_is_future(actual, expect=None):
        """是未来时间"""
        actual_time = parse_datetime_value(actual, '实际时间')
        now = datetime.now()
        if actual_time <= now:
            raise AssertionError(f'实际时间={actual}，当前时间={now}，预期为未来时间')
        return f'实际时间={actual}，是未来时间'

    @staticmethod
    @sync_method_callback('内容断言', '时间断言', 6, _actual_only())
    def p_datetime_is_past(actual, expect=None):
        """是过去时间"""
        actual_time = parse_datetime_value(actual, '实际时间')
        now = datetime.now()
        if actual_time >= now:
            raise AssertionError(f'实际时间={actual}，当前时间={now}，预期为过去时间')
        return f'实际时间={actual}，是过去时间'
