# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 14:12
# @Author : 毛鹏
from assertpy import assert_that
from deepdiff import DeepDiff

from ...decorator import sync_method_callback
from ...models import MethodModel


def _assert_that(actual):
    if actual is None:
        raise AssertionError(f"实际值不能为 None ，可能是在获取实际值的时候就失败了！")
    return assert_that(actual)


class MatchingAssertion:
    """值匹配什么"""

    @staticmethod
    @sync_method_callback('内容断言', '值匹配什么', 0, [
        MethodModel(n='实际值', f='actual', d=True),
        MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)
    ])
    def p_in_dict(actual: dict, expect: dict):
        """实际JSON匹配预期JSON"""
        try:
            filtered_actual = filter_dict(dict(actual), dict(expect))
        except ValueError:
            assert False, f'实际={actual}, 预期={expect}, 预期或者实际不可序列化为json'
        diff = DeepDiff(filtered_actual, expect, ignore_order=True)
        assert not diff, f'实际={str(actual)}, 预期={expect}'
        return f'实际={str(actual)}, 预期={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '值匹配什么', 1, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_is_in(actual: str, expect: str):
        """在expect里面"""
        try:
            candidate = str(actual) if isinstance(expect, str) else actual
            assert candidate in expect
        except (AssertionError, TypeError) as error:
            raise AssertionError(f'实际={str(actual)}, 预期={expect}') from error
        return f'实际={str(actual)}, 预期={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '值匹配什么', 2, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_is_not_in(actual: str, expect: str):
        """不在expect里面"""
        try:
            candidate = str(actual) if isinstance(expect, str) else actual
            assert candidate not in expect
        except (AssertionError, TypeError) as error:
            raise AssertionError(f'实际={str(actual)}, 预期={expect}') from error
        return f'实际={str(actual)}, 预期={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '值匹配什么', 3, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_starts_with(actual: str, expect: str):
        """以expect开头"""
        try:
            _assert_that(str(actual)).starts_with(expect)
        except AssertionError as e:
            raise AssertionError(f'实际={str(actual)}, 预期={expect}') from e
        return f'实际={str(actual)}, 预期={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '值匹配什么', 4, [
        MethodModel(n='实际值', f='actual', d=True), MethodModel(n='预期值', f='expect', p='请输入断言值', d=True)])
    def p_ends_with(actual: str, expect: str):
        """以expect结尾"""
        try:
            _assert_that(str(actual)).ends_with(expect)
        except AssertionError as e:
            raise AssertionError(f'实际={str(actual)}, 预期={expect}') from e
        return f'实际={str(actual)}, 预期={expect}'

def filter_dict(actual, expect):
    """
    根据 expect 结构过滤 actual
    """
    # 如果actual不是dict，直接返回
    if not isinstance(actual, dict):
        return actual

    if not isinstance(expect, dict):
        return actual

    filtered = {}

    for key, expect_value in expect.items():

        if key not in actual:
            continue

        actual_value = actual[key]

        # dict递归
        if isinstance(expect_value, dict) and isinstance(actual_value, dict):
            filtered[key] = filter_dict(actual_value, expect_value)

        # list递归
        elif isinstance(expect_value, list) and isinstance(actual_value, list):

            if expect_value and isinstance(expect_value[0], dict):
                template = expect_value[0]

                filtered[key] = [
                    filter_dict(item, template) if isinstance(item, dict) else item
                    for item in actual_value
                ]

            else:
                filtered[key] = actual_value

        else:
            filtered[key] = actual_value

    return filtered
