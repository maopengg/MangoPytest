# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 14:09
# @Author : 毛鹏
from ._contain import ContainAssertion
from ._compare import CompareAssertion
from ._datetime_extra import DatetimeAssertion
from ._numeric_extra import NumericSemanticAssertion
from ._matching import MatchingAssertion
from ._string_format_extra import FormatAssertion, StringSemanticAssertion
from ._structured_extra import CollectionStateAssertion, DictJsonAssertion, ListSemanticAssertion
from ._url import UrlAssertion
from ._whatis import WhatIsEqualToAssertion
from ._whatisit import WhatIsItAssertion


class TextAssertion(
    CompareAssertion,
    NumericSemanticAssertion,
    StringSemanticAssertion,
    FormatAssertion,
    DictJsonAssertion,
    ListSemanticAssertion,
    CollectionStateAssertion,
    DatetimeAssertion,
    UrlAssertion,
    WhatIsItAssertion,
    ContainAssertion,
    MatchingAssertion,
    WhatIsEqualToAssertion,
):
    """内容断言"""
    pass


if __name__ == '__main__':
    TextAssertion.p_is_equal_to('1', '2')
