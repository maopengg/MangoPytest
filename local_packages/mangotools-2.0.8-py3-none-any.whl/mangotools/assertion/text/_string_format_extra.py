# -*- coding: utf-8 -*-
import base64
import binascii
import ipaddress
import json
import re
import uuid
from datetime import datetime
from urllib.parse import urlparse

from ...decorator import sync_method_callback
from ...models import MethodModel
from ._semantic_helpers import object_config_parameter, parse_config, parse_number


def _actual_only():
    return [MethodModel(n='实际值', f='actual', d=True)]


def _actual_expect(name='预期值', example='mango'):
    return [
        MethodModel(n='实际值', f='actual', d=True),
        MethodModel(n=name, f='expect', p=f'请输入{name}', v=example, d=True),
    ]


def _occurrence_parameters():
    return [
        MethodModel(n='实际值', f='actual', d=True),
        object_config_parameter('预期配置', [
            ('text', '目标文本', 'a', '请输入要统计的文本', 'string'),
            ('count', '预期次数', 2, '请输入预期出现次数', 'number'),
        ]),
    ]


def _text(actual, field_name='实际值') -> str:
    if actual is None:
        raise AssertionError(f'{field_name}不能为None')
    return str(actual)


class StringSemanticAssertion:
    """语义化字符串断言"""

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 0, _actual_expect())
    def p_equal_after_trim(actual, expect):
        """去除首尾空白后相等"""
        if _text(actual).strip() != _text(expect, '预期值').strip():
            raise AssertionError(f'实际={actual}，预期={expect}，去除首尾空白后不相等')
        return f'实际={actual}，预期={expect}，去除首尾空白后相等'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 1, _actual_expect())
    def p_equal_after_normalize_whitespace(actual, expect):
        """标准化空白字符后相等"""
        normalize = lambda value: ' '.join(_text(value).split())
        if normalize(actual) != normalize(expect):
            raise AssertionError(f'实际={actual}，预期={expect}，标准化空白后不相等')
        return f'实际={actual}，预期={expect}，标准化空白后相等'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 2, _actual_expect('预期开头', 'mango'))
    def p_starts_with_ignoring_case(actual, expect):
        """忽略大小写后以预期值开头"""
        if not _text(actual).casefold().startswith(_text(expect).casefold()):
            raise AssertionError(f'实际={actual}，未以={expect}开头（忽略大小写）')
        return f'实际={actual}，以={expect}开头（忽略大小写）'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 3, _actual_expect('预期结尾', '.json'))
    def p_ends_with_ignoring_case(actual, expect):
        """忽略大小写后以预期值结尾"""
        if not _text(actual).casefold().endswith(_text(expect).casefold()):
            raise AssertionError(f'实际={actual}，未以={expect}结尾（忽略大小写）')
        return f'实际={actual}，以={expect}结尾（忽略大小写）'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 4, _actual_only())
    def p_is_blank(actual, expect=None):
        """是空白字符串"""
        if not isinstance(actual, str):
            raise AssertionError(f'实际类型={type(actual).__name__}，预期类型=字符串')
        if actual.strip():
            raise AssertionError(f'实际={actual}，预期为空白字符串')
        return f'实际={actual}，是空白字符串'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 5, _actual_only())
    def p_is_not_blank(actual, expect=None):
        """不是空白字符串"""
        if not isinstance(actual, str):
            raise AssertionError(f'实际类型={type(actual).__name__}，预期类型=字符串')
        if not actual.strip():
            raise AssertionError(f'实际={actual}，预期为非空白字符串')
        return f'实际={actual}，不是空白字符串'

    @staticmethod
    def _occurrence(actual, expect, mode):
        config = parse_config(expect, ('text', 'count'))
        count = parse_number(config['count'], '预期次数')
        if count < 0 or count != count.to_integral_value():
            raise AssertionError('预期次数必须是非负整数')
        actual_count = _text(actual).count(_text(config['text']))
        expected_count = int(count)
        passed = {
            'equal': actual_count == expected_count,
            'at_least': actual_count >= expected_count,
            'at_most': actual_count <= expected_count,
        }[mode]
        if not passed:
            raise AssertionError(f'文本={config["text"]}，实际出现次数={actual_count}，预期次数={expected_count}')
        return f'文本={config["text"]}，实际出现次数={actual_count}，预期次数={expected_count}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 6, _occurrence_parameters())
    def p_occurrence_count_equal(actual, expect):
        """文本出现次数等于预期"""
        return StringSemanticAssertion._occurrence(actual, expect, 'equal')

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 7, _occurrence_parameters())
    def p_occurrence_count_at_least(actual, expect):
        """文本出现次数不少于预期"""
        return StringSemanticAssertion._occurrence(actual, expect, 'at_least')

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 8, _occurrence_parameters())
    def p_occurrence_count_at_most(actual, expect):
        """文本出现次数不多于预期"""
        return StringSemanticAssertion._occurrence(actual, expect, 'at_most')

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 9, [
        MethodModel(n='实际值', f='actual', d=True),
        object_config_parameter('长度区间', [
            ('min', '最小长度', 3, '请输入最小长度', 'number'),
            ('max', '最大长度', 10, '请输入最大长度', 'number'),
        ]),
    ])
    def p_string_length_between(actual, expect):
        """字符串长度位于闭区间"""
        if not isinstance(actual, str):
            raise AssertionError(f'实际类型={type(actual).__name__}，预期类型=字符串')
        config = parse_config(expect, ('min', 'max'))
        minimum_number = parse_number(config['min'], '最小长度')
        maximum_number = parse_number(config['max'], '最大长度')
        if (
            minimum_number < 0
            or minimum_number != minimum_number.to_integral_value()
            or maximum_number != maximum_number.to_integral_value()
        ):
            raise AssertionError('最小长度和最大长度必须是非负整数')
        minimum = int(minimum_number)
        maximum = int(maximum_number)
        if minimum > maximum:
            raise AssertionError(f'长度区间配置无效：min={minimum}, max={maximum}')
        if not minimum <= len(actual) <= maximum:
            raise AssertionError(f'实际长度={len(actual)}，预期区间=[{minimum}, {maximum}]')
        return f'实际长度={len(actual)}，位于区间=[{minimum}, {maximum}]'


class FormatAssertion:
    """常用格式断言"""

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 0, _actual_only())
    def p_is_valid_json(actual, expect=None):
        """是合法JSON"""
        if isinstance(actual, (dict, list, int, float, bool)) or actual is None:
            return f'实际值是合法JSON类型={type(actual).__name__}'
        try:
            json.loads(str(actual))
        except (json.JSONDecodeError, TypeError) as error:
            raise AssertionError(f'实际值不是合法JSON：{actual}') from error
        return '实际值是合法JSON文本'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 1, _actual_only())
    def p_is_valid_email(actual, expect=None):
        """是合法邮箱地址"""
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', _text(actual)):
            raise AssertionError(f'实际值不是合法邮箱：{actual}')
        return f'实际值是合法邮箱：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 2, _actual_only())
    def p_is_valid_url(actual, expect=None):
        """是合法URL"""
        parsed = urlparse(_text(actual))
        if parsed.scheme.lower() not in {'http', 'https'} or not parsed.netloc:
            raise AssertionError(f'实际值不是合法HTTP/HTTPS URL：{actual}')
        return f'实际值是合法URL：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 3, _actual_only())
    def p_is_valid_ipv4(actual, expect=None):
        """是合法IPv4地址"""
        try:
            parsed = ipaddress.ip_address(_text(actual))
        except ValueError as error:
            raise AssertionError(f'实际值不是合法IPv4：{actual}') from error
        if parsed.version != 4:
            raise AssertionError(f'实际值不是IPv4：{actual}')
        return f'实际值是合法IPv4：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 4, _actual_only())
    def p_is_valid_ipv6(actual, expect=None):
        """是合法IPv6地址"""
        try:
            parsed = ipaddress.ip_address(_text(actual))
        except ValueError as error:
            raise AssertionError(f'实际值不是合法IPv6：{actual}') from error
        if parsed.version != 6:
            raise AssertionError(f'实际值不是IPv6：{actual}')
        return f'实际值是合法IPv6：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 5, _actual_only())
    def p_is_valid_uuid(actual, expect=None):
        """是合法UUID"""
        try:
            uuid.UUID(_text(actual))
        except (ValueError, AttributeError) as error:
            raise AssertionError(f'实际值不是合法UUID：{actual}') from error
        return f'实际值是合法UUID：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 6, _actual_only())
    def p_is_valid_base64(actual, expect=None):
        """是合法Base64编码"""
        text = _text(actual)
        if not text:
            raise AssertionError('Base64内容不能为空')
        try:
            base64.b64decode(text, validate=True)
        except (binascii.Error, ValueError) as error:
            raise AssertionError(f'实际值不是合法Base64：{actual}') from error
        return '实际值是合法Base64编码'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 7, _actual_only())
    def p_is_valid_jwt(actual, expect=None):
        """是合法JWT结构"""
        parts = _text(actual).split('.')
        if len(parts) != 3 or not all(parts):
            raise AssertionError('JWT必须包含三个非空段')
        try:
            for part in parts[:2]:
                padding = '=' * (-len(part) % 4)
                json.loads(base64.urlsafe_b64decode(part + padding).decode('utf-8'))
            padding = '=' * (-len(parts[2]) % 4)
            base64.urlsafe_b64decode(parts[2] + padding)
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError, binascii.Error) as error:
            raise AssertionError('JWT段不是合法Base64URL或JSON') from error
        return '实际值具有合法JWT结构（未校验签名）'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 8, _actual_only())
    def p_is_valid_phone(actual, expect=None):
        """是合法中国大陆手机号"""
        if not re.fullmatch(r'1[3-9]\d{9}', _text(actual)):
            raise AssertionError(f'实际值不是合法中国大陆手机号：{actual}')
        return f'实际值是合法中国大陆手机号：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 9, _actual_only())
    def p_is_valid_timestamp(actual, expect=None):
        """是合法秒或毫秒时间戳"""
        text = _text(actual).strip()
        if not re.fullmatch(r'\d{10}|\d{13}', text):
            raise AssertionError(f'时间戳必须是10位秒或13位毫秒：{actual}')
        timestamp = int(text) / (1000 if len(text) == 13 else 1)
        try:
            datetime.fromtimestamp(timestamp)
        except (ValueError, OverflowError, OSError) as error:
            raise AssertionError(f'实际值不是有效时间戳：{actual}') from error
        return f'实际值是合法时间戳：{actual}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 10, _actual_expect('日期格式（可留空）', '%Y-%m-%d'))
    def p_is_valid_date(actual, expect=None):
        """符合日期格式"""
        fmt = expect or '%Y-%m-%d'
        try:
            datetime.strptime(_text(actual), str(fmt))
        except ValueError as error:
            raise AssertionError(f'实际={actual}，不符合日期格式={fmt}') from error
        return f'实际={actual}，符合日期格式={fmt}'

    @staticmethod
    @sync_method_callback('内容断言', '字符串与格式断言', 11, _actual_expect('日期时间格式（可留空）', '%Y-%m-%d %H:%M:%S'))
    def p_is_valid_datetime(actual, expect=None):
        """符合日期时间格式"""
        fmt = expect or '%Y-%m-%d %H:%M:%S'
        try:
            datetime.strptime(_text(actual), str(fmt))
        except ValueError as error:
            raise AssertionError(f'实际={actual}，不符合日期时间格式={fmt}') from error
        return f'实际={actual}，符合日期时间格式={fmt}'
