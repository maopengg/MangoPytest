# -*- coding: utf-8 -*-
from ...decorator import sync_method_callback
from ...models import MethodModel
from ._semantic_helpers import object_config_parameter, parse_config, parse_number


def _parameters(expect_name='预期值', expect_example='10'):
    return [
        MethodModel(n='实际值', f='actual', d=True),
        MethodModel(n=expect_name, f='expect', p=f'请输入{expect_name}', v=expect_example, d=True),
    ]


def _range_parameters(name):
    return [
        MethodModel(n='实际值', f='actual', d=True),
        object_config_parameter(name, [
            ('min', '最小值', 10, '请输入区间最小值', 'number'),
            ('max', '最大值', 20, '请输入区间最大值', 'number'),
        ]),
    ]


class NumericSemanticAssertion:
    """语义化数值断言"""

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 0, _parameters())
    def p_number_equal(actual, expect):
        """数值相等"""
        if parse_number(actual, '实际值') != parse_number(expect, '预期值'):
            raise AssertionError(f'实际={actual}，预期数值={expect}')
        return f'实际={actual}，预期数值={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 1, _parameters())
    def p_number_not_equal(actual, expect):
        """数值不相等"""
        if parse_number(actual, '实际值') == parse_number(expect, '预期值'):
            raise AssertionError(f'实际={actual}，不应等于={expect}')
        return f'实际={actual}，不等于={expect}'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 2, [
        MethodModel(n='实际值', f='actual', d=True),
        object_config_parameter('预期配置', [
            ('value', '目标值', 10, '请输入目标值', 'number'),
            ('tolerance', '允许误差', 0.01, '请输入允许误差', 'number'),
        ]),
    ])
    def p_number_close_to(actual, expect):
        """数值在允许误差内"""
        config = parse_config(expect, ('value', 'tolerance'))
        tolerance = parse_number(config['tolerance'], '允许误差')
        if tolerance < 0:
            raise AssertionError('允许误差不能小于0')
        difference = abs(parse_number(actual, '实际值') - parse_number(config['value'], '目标值'))
        if difference > tolerance:
            raise AssertionError(f'实际={actual}，目标={config["value"]}，差值={difference}，允许误差={tolerance}')
        return f'实际={actual}，目标={config["value"]}，差值={difference}，允许误差={tolerance}'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 3, _range_parameters('预期区间'))
    def p_number_between(actual, expect):
        """数值位于闭区间"""
        config = parse_config(expect, ('min', 'max'))
        value = parse_number(actual, '实际值')
        minimum = parse_number(config['min'], '最小值')
        maximum = parse_number(config['max'], '最大值')
        if minimum > maximum:
            raise AssertionError(f'最小值={minimum} 不能大于最大值={maximum}')
        if not minimum <= value <= maximum:
            raise AssertionError(f'实际={actual}，预期区间=[{minimum}, {maximum}]')
        return f'实际={actual}，位于区间=[{minimum}, {maximum}]'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 4, _range_parameters('排除区间'))
    def p_number_not_between(actual, expect):
        """数值不在闭区间"""
        config = parse_config(expect, ('min', 'max'))
        value = parse_number(actual, '实际值')
        minimum = parse_number(config['min'], '最小值')
        maximum = parse_number(config['max'], '最大值')
        if minimum > maximum:
            raise AssertionError(f'最小值={minimum} 不能大于最大值={maximum}')
        if minimum <= value <= maximum:
            raise AssertionError(f'实际={actual}，不应位于区间=[{minimum}, {maximum}]')
        return f'实际={actual}，不在区间=[{minimum}, {maximum}]'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 5, [MethodModel(n='实际值', f='actual', d=True)])
    def p_is_positive(actual, expect=None):
        """是正数"""
        if parse_number(actual, '实际值') <= 0:
            raise AssertionError(f'实际={actual}，预期为正数')
        return f'实际={actual}，是正数'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 6, [MethodModel(n='实际值', f='actual', d=True)])
    def p_is_negative(actual, expect=None):
        """是负数"""
        if parse_number(actual, '实际值') >= 0:
            raise AssertionError(f'实际={actual}，预期为负数')
        return f'实际={actual}，是负数'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 7, [MethodModel(n='实际值', f='actual', d=True)])
    def p_is_zero(actual, expect=None):
        """数值为零"""
        if parse_number(actual, '实际值') != 0:
            raise AssertionError(f'实际={actual}，预期为0')
        return f'实际={actual}，数值为0'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 8, [MethodModel(n='实际值', f='actual', d=True)])
    def p_is_non_negative(actual, expect=None):
        """是非负数"""
        if parse_number(actual, '实际值') < 0:
            raise AssertionError(f'实际={actual}，预期为非负数')
        return f'实际={actual}，是非负数'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 9, _parameters('除数', '5'))
    def p_is_multiple_of(actual, expect):
        """是指定数的倍数"""
        divisor = parse_number(expect, '除数')
        if divisor == 0:
            raise AssertionError('除数不能为0')
        if parse_number(actual, '实际值') % divisor != 0:
            raise AssertionError(f'实际={actual}，不是{expect}的倍数')
        return f'实际={actual}，是{expect}的倍数'

    @staticmethod
    @sync_method_callback('内容断言', '数值语义', 10, _parameters('预期小数位数', '2'))
    def p_decimal_places_equal(actual, expect):
        """小数位数等于预期"""
        expected_places = parse_number(expect, '预期小数位数')
        if expected_places < 0 or expected_places != expected_places.to_integral_value():
            raise AssertionError(f'预期小数位数={expect} 必须是非负整数')
        text = str(actual).strip().lower()
        if 'e' in text:
            actual_places = max(0, -parse_number(actual, '实际值').as_tuple().exponent)
        else:
            actual_places = len(text.partition('.')[2]) if '.' in text else 0
        if actual_places != int(expected_places):
            raise AssertionError(f'实际小数位数={actual_places}，预期小数位数={int(expected_places)}')
        return f'实际小数位数={actual_places}，预期小数位数={int(expected_places)}'
