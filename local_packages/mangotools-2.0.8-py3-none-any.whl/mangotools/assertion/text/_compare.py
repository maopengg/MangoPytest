# -*- coding: utf-8 -*-
import re
from decimal import Decimal, InvalidOperation

from assertpy import assert_that

from ...decorator import sync_method_callback
from ...models import MethodModel


def _number(value, field_name):
    if isinstance(value, bool):
        raise AssertionError(f'{field_name}={value} 不是有效数字')
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, TypeError, ValueError) as error:
        raise AssertionError(f'{field_name}={value} 不是有效数字') from error
    if not number.is_finite():
        raise AssertionError(f'{field_name}={value} 不是有效数字')
    return number


def _length(value):
    if value is None or not hasattr(value, '__len__'):
        raise AssertionError(f'实际值={value} 不支持长度判断')
    return len(value)


def _expected_length(value):
    number = _number(value, '预期长度')
    if number < 0 or number != number.to_integral_value():
        raise AssertionError(f'预期长度={value} 必须是非负整数')
    return int(number)


def _type_result(actual, expected_type, expected_name):
    if isinstance(actual, expected_type):
        return f'实际类型={type(actual).__name__}，预期类型={expected_name}'
    raise AssertionError(
        f'实际类型={type(actual).__name__}，预期类型={expected_name}，实际值={actual}'
    )


class CompareAssertion:
    """数值、长度、正则和数据类型断言"""

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 0, [
        MethodModel(n='实际值', f='actual', v='10', d=True),
        MethodModel(n='预期值', f='expect', p='请输入比较值', v='5', d=True),
    ])
    def p_is_greater_than(actual, expect):
        """大于"""
        actual_number = _number(actual, '实际值')
        expected_number = _number(expect, '预期值')
        if actual_number > expected_number:
            return f'实际={actual}，预期大于={expect}'
        raise AssertionError(f'实际={actual}，预期大于={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 1, [
        MethodModel(n='实际值', f='actual', v='10', d=True),
        MethodModel(n='预期值', f='expect', p='请输入比较值', v='10', d=True),
    ])
    def p_is_greater_than_or_equal_to(actual, expect):
        """大于等于"""
        actual_number = _number(actual, '实际值')
        expected_number = _number(expect, '预期值')
        if actual_number >= expected_number:
            return f'实际={actual}，预期大于等于={expect}'
        raise AssertionError(f'实际={actual}，预期大于等于={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 2, [
        MethodModel(n='实际值', f='actual', v='5', d=True),
        MethodModel(n='预期值', f='expect', p='请输入比较值', v='10', d=True),
    ])
    def p_is_less_than(actual, expect):
        """小于"""
        actual_number = _number(actual, '实际值')
        expected_number = _number(expect, '预期值')
        if actual_number < expected_number:
            return f'实际={actual}，预期小于={expect}'
        raise AssertionError(f'实际={actual}，预期小于={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 3, [
        MethodModel(n='实际值', f='actual', v='10', d=True),
        MethodModel(n='预期值', f='expect', p='请输入比较值', v='10', d=True),
    ])
    def p_is_less_than_or_equal_to(actual, expect):
        """小于等于"""
        actual_number = _number(actual, '实际值')
        expected_number = _number(expect, '预期值')
        if actual_number <= expected_number:
            return f'实际={actual}，预期小于等于={expect}'
        raise AssertionError(f'实际={actual}，预期小于等于={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 0, [
        MethodModel(n='实际值', f='actual', v='mango', d=True),
        MethodModel(n='预期长度', f='expect', p='请输入最小长度', v='3', d=True),
    ])
    def p_length_at_least(actual, expect):
        """长度不少于"""
        actual_length = _length(actual)
        expected_length = _expected_length(expect)
        if actual_length >= expected_length:
            return f'实际长度={actual_length}，预期不少于={expected_length}'
        raise AssertionError(f'实际长度={actual_length}，预期不少于={expected_length}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 1, [
        MethodModel(n='实际值', f='actual', v='mango', d=True),
        MethodModel(n='预期长度', f='expect', p='请输入最大长度', v='8', d=True),
    ])
    def p_length_at_most(actual, expect):
        """长度不多于"""
        actual_length = _length(actual)
        expected_length = _expected_length(expect)
        if actual_length <= expected_length:
            return f'实际长度={actual_length}，预期不多于={expected_length}'
        raise AssertionError(f'实际长度={actual_length}，预期不多于={expected_length}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 2, [
        MethodModel(n='实际值', f='actual', v='mango', d=True),
        MethodModel(n='预期长度', f='expect', p='请输入比较长度', v='3', d=True),
    ])
    def p_length_greater_than(actual, expect):
        """长度大于"""
        actual_length = _length(actual)
        expected_length = _expected_length(expect)
        if actual_length > expected_length:
            return f'实际长度={actual_length}，预期大于={expected_length}'
        raise AssertionError(f'实际长度={actual_length}，预期大于={expected_length}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 3, [
        MethodModel(n='实际值', f='actual', v='mango', d=True),
        MethodModel(n='预期长度', f='expect', p='请输入比较长度', v='8', d=True),
    ])
    def p_length_less_than(actual, expect):
        """长度小于"""
        actual_length = _length(actual)
        expected_length = _expected_length(expect)
        if actual_length < expected_length:
            return f'实际长度={actual_length}，预期小于={expected_length}'
        raise AssertionError(f'实际长度={actual_length}，预期小于={expected_length}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 5, [
        MethodModel(n='实际值', f='actual', d=True),
        MethodModel(n='最小长度', f='expect', d=True),
    ])
    def len_gt(actual, expect):
        """长度大于指定值"""
        try:
            if hasattr(actual, '__len__'):
                actual_len = len(actual)
                assert_that(actual_len).is_greater_than(int(expect))
                return f'实际长度={actual_len}, 期望大于={expect}'
            assert_that(actual).is_greater_than(int(expect))
            return f'实际值={actual}, 期望值={expect}'
        except AssertionError as error:
            if hasattr(actual, '__len__'):
                raise AssertionError(f'实际长度={len(actual)}, 期望大于={expect}') from error
            raise AssertionError(f'实际值={actual}, 期望值={expect}') from error
        except TypeError as error:
            raise AssertionError(f'不支持的类型: {type(actual).__name__}') from error

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 0, [
        MethodModel(n='实际值', f='actual', v='order-2026', d=True),
        MethodModel(n='正则表达式', f='expect', p='请输入正则表达式', v=r'^order-\d+$', d=True),
    ])
    def p_matches_regex(actual, expect):
        """完全匹配正则"""
        try:
            matched = re.fullmatch(str(expect), str(actual))
        except re.error as error:
            raise AssertionError(f'正则表达式无效：{error}') from error
        if matched:
            return f'实际={actual}，正则={expect}'
        raise AssertionError(f'实际={actual}，未完全匹配正则={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 1, [
        MethodModel(n='实际值', f='actual', v='order-2026-finished', d=True),
        MethodModel(n='正则表达式', f='expect', p='请输入正则表达式', v=r'order-\d+', d=True),
    ])
    def p_contains_regex(actual, expect):
        """包含正则匹配"""
        try:
            matched = re.search(str(expect), str(actual))
        except re.error as error:
            raise AssertionError(f'正则表达式无效：{error}') from error
        if matched:
            return f'实际={actual}，包含正则匹配={expect}'
        raise AssertionError(f'实际={actual}，不包含正则匹配={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 2, [
        MethodModel(n='实际值', f='actual', v='finished', d=True),
        MethodModel(n='正则表达式', f='expect', p='请输入正则表达式', v=r'error|failed', d=True),
    ])
    def p_does_not_contain_regex(actual, expect):
        """不包含正则匹配"""
        try:
            matched = re.search(str(expect), str(actual))
        except re.error as error:
            raise AssertionError(f'正则表达式无效：{error}') from error
        if not matched:
            return f'实际={actual}，不包含正则匹配={expect}'
        raise AssertionError(f'实际={actual}，包含了正则匹配={expect}')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 0, [
        MethodModel(n='实际值', f='actual', d=True),
    ])
    def p_is_string(actual, expect=None):
        """是字符串"""
        return _type_result(actual, str, '字符串')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 1, [
        MethodModel(n='实际值', f='actual', d=True),
    ])
    def p_is_list(actual, expect=None):
        """是列表"""
        return _type_result(actual, list, '列表')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 2, [
        MethodModel(n='实际值', f='actual', d=True),
    ])
    def p_is_dict(actual, expect=None):
        """是字典"""
        return _type_result(actual, dict, '字典')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 3, [
        MethodModel(n='实际值', f='actual', d=True),
    ])
    def p_is_boolean(actual, expect=None):
        """是布尔值"""
        return _type_result(actual, bool, '布尔值')

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 4, [
        MethodModel(n='实际值', f='actual', d=True),
    ])
    def p_is_integer(actual, expect=None):
        """是整数类型"""
        if isinstance(actual, int) and not isinstance(actual, bool):
            return f'实际类型={type(actual).__name__}，预期类型=整数'
        raise AssertionError(
            f'实际类型={type(actual).__name__}，预期类型=整数，实际值={actual}'
        )

    @staticmethod
    @sync_method_callback('内容断言', '比较断言', 5, [
        MethodModel(n='实际值', f='actual', d=True),
    ])
    def p_is_number(actual, expect=None):
        """是数字类型"""
        if isinstance(actual, (int, float, Decimal)) and not isinstance(actual, bool):
            return f'实际类型={type(actual).__name__}，预期类型=数字'
        raise AssertionError(
            f'实际类型={type(actual).__name__}，预期类型=数字，实际值={actual}'
        )
