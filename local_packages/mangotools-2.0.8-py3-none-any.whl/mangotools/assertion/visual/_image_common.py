"""Input, image decoding and report generation shared by image assertions."""
import json
import math
import tempfile
from pathlib import Path

from ._pixels import compare_rgb, write_diff

IMAGE_FORMATS = {'png': 'PNG', 'jpg': 'JPEG'}


def parse_number(config, key, minimum, maximum=None, *, integer=False):
    value = config[key]
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError) as error:
        raise ValueError(f'{key}必须是数字') from error
    if (isinstance(value, bool) or not math.isfinite(number) or number < minimum
            or (maximum is not None and number > maximum) or (integer and not number.is_integer())):
        raise ValueError(f'{key}超出范围或精度无效')
    return int(number) if integer else number


def parse_inputs(actual, expect, compare):
    if isinstance(actual, str) and actual.lstrip().startswith('{'):
        actual = json.loads(actual)
    if isinstance(actual, dict):
        actual = actual.get('文件路径')
    if not isinstance(actual, str) or not actual.strip():
        raise ValueError('文件路径必须是非空字符串')

    if isinstance(expect, str):
        expect = json.loads(expect)
    if not isinstance(expect, dict):
        raise ValueError('预期值必须是JSON对象')
    config = expect.copy()
    mode = config.get('交付模式', 'zip')
    if mode not in ('zip', 'long'):
        raise ValueError('交付模式必须为 zip 或 long')
    fields = {'交付模式', '图片格式', '输出目录'}
    if mode == 'zip' or compare:
        fields.add('预期页数')
    if mode == 'long':
        fields.update({'预期宽度', '预期高度'})
        if compare:
            fields.update({'页面区间', '基准分页ZIP路径'})
    if compare:
        fields.update({'基准文件路径', '颜色通道容差', '最大颜色差异率', '最大颜色差异像素数'})
    unknown = set(config) - fields
    if unknown:
        raise ValueError(f'不支持的图片断言参数：{", ".join(sorted(map(str, unknown)))}')
    image_format = config.get('图片格式')
    if not isinstance(image_format, str) or image_format.lower() not in IMAGE_FORMATS:
        raise ValueError('图片格式必须为 png 或 jpg')
    config['图片格式'] = image_format.lower()
    if mode == 'zip' and not compare and '预期页数' not in config:
        raise ValueError('预期页数不能为空')
    if '预期页数' in config:
        config['预期页数'] = parse_number(config, '预期页数', 1, integer=True)
    if compare:
        config.setdefault('颜色通道容差', 0)
        config['颜色通道容差'] = parse_number(config, '颜色通道容差', 0, 255, integer=True)
        if '最大颜色差异像素数' not in config:
            config.setdefault('最大颜色差异率', 0)
        if '最大颜色差异率' in config:
            config['最大颜色差异率'] = parse_number(config, '最大颜色差异率', 0, 1)
        if '最大颜色差异像素数' in config:
            config['最大颜色差异像素数'] = parse_number(config, '最大颜色差异像素数', 0, integer=True)
    baseline_key = '基准分页ZIP路径' if '基准分页ZIP路径' in config else '基准文件路径'
    for key in ('基准文件路径', '基准分页ZIP路径', '输出目录'):
        if key in config or (compare and key == baseline_key):
            value = config.get(key)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f'{key}必须是非空字符串')
            config[key] = value.strip()
    return actual.strip(), config, mode


def _check_image_format(image, image_format):
    if image.format != IMAGE_FORMATS[image_format]:
        raise ValueError(f'真实编码为 {image.format}，预期 {IMAGE_FORMATS[image_format]}')
    if getattr(image, 'n_frames', 1) != 1:
        raise ValueError('图片必须是单帧')


def image_size(stream, image_format, Image):
    with Image.open(stream) as image:
        _check_image_format(image, image_format)
        if image.getexif().get(274) in (5, 6, 7, 8):  # EXIF orientation swaps width and height.
            return image.height, image.width
        return image.size


def decode_image(stream, image_format, Image, ImageOps, *, verify_zip_member=False):
    with Image.open(stream) as image:
        _check_image_format(image, image_format)
        image.verify()
    stream.seek(0)
    with Image.open(stream) as image:
        image.load()
        if verify_zip_member:
            # Drain the ZIP member to verify its CRC.
            while stream.read(64 * 1024):
                pass
        ImageOps.exif_transpose(image, in_place=True)
        if not image.has_transparency_data:
            return image.convert('RGB')
        with image.convert('RGBA') as rgba, rgba.getchannel('A') as alpha:
            with Image.new('RGB', rgba.size, 'white') as background:
                background.paste(rgba, mask=alpha)
                return background.copy()


def compare_region(actual, baseline, result, config, output, np, Image, *, gap=False):
    region = 'gap' if gap else 'page'
    if actual.size != baseline.size:
        result['errors'].append(f'尺寸或方向不一致，实际={actual.size}，基准={baseline.size}')
        return
    actual_pixels, baseline_pixels = np.asarray(actual), np.asarray(baseline)
    blank_mismatch = bool(np.all(actual_pixels == 255)) != bool(np.all(baseline_pixels == 255))
    if blank_mismatch and not gap:
        result['errors'].append('异常空白，仅一侧为空白页')
    metrics, changed = compare_rgb(actual_pixels, baseline_pixels, config['颜色通道容差'], np)
    result.update(metrics)
    ratio, count = metrics['color_difference_ratio'], metrics['color_difference_pixels']
    if (ratio > config.get('最大颜色差异率', 1)
            or count > config.get('最大颜色差异像素数', math.inf)):
        result['errors'].append(f'颜色差异超阈值，差异率={ratio:.6g}，差异像素数={count}')
    if output and result['errors']:
        path = output / f"{region}_{result[region]:03d}_diff.png"
        if blank_mismatch:
            changed = np.any(actual_pixels != baseline_pixels, axis=2)
        write_diff(path, changed, None, np, Image)
        result['diff_image'] = str(path)


def run_assertion(source, config, *, compare, mode, check):
    label = '长图' if mode == 'long' else '分页图片ZIP'
    output = None
    if '输出目录' in config:
        root = Path(config['输出目录']).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        output = Path(tempfile.mkdtemp(prefix=f'image-{mode}-', dir=root))
    report = {'mode': 'compare' if compare else 'validate', 'image_format': config['图片格式'],
              'parameters': {key: value for key, value in config.items() if not key.endswith(('路径', '目录'))},
              'pages': [], 'failures': []}
    if mode == 'long':
        report['delivery_mode'] = mode
        report['gaps'] = []
    try:
        check(source, config, report, output, compare)
    except AssertionError as error:
        report['failures'].append(str(error))
    for page in report['pages']:
        location = f"第{page['page']}页"
        if 'row_range' in page:
            start, end = page['row_range']
            location += f"（Y=[{start}, {end})）"
        report['failures'].extend(f"{location}{error}" for error in page['errors'])
    for gap in report.get('gaps', []):
        start, end = gap['row_range']
        report['failures'].extend(f"页面间隔（Y=[{start}, {end})）{error}" for error in gap['errors'])
    failures = report['failures']
    report['passed'] = not failures
    suffix = ''
    if output:
        path = output / 'report.json'
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        suffix = f'，报告={path}'
    if failures:
        summary = '；'.join(failures[:5])
        if len(failures) > 5:
            summary += f'；共{len(failures)}处失败'
        raise AssertionError(f'{label}断言失败：{summary}{suffix}')
    if mode == 'zip':
        detail = f"页数={report['actual_page_count']}"
    else:
        width, height = report['actual_size']
        detail = f'尺寸={width}×{height}px'
        if compare:
            detail += f"，页面区间数={len(report['pages'])}"
    return f"{label}断言通过，{detail}{suffix}"
