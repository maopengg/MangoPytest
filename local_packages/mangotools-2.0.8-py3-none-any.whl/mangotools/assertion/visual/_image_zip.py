"""Validate and compare the paginated ZIP produced by document conversion."""
import re
import zlib
from contextlib import ExitStack
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from ._image_common import compare_region, decode_image

PAGE_NAME = re.compile(r'page-([0-9]{1,10})\.(png|jpg)', re.IGNORECASE)
ZIP_ERRORS = (BadZipFile, OSError, EOFError, RuntimeError, zlib.error)


def _page_entries(archive, image_format, label):
    pages = {}
    for entry in archive.infolist():
        match = PAGE_NAME.fullmatch(entry.filename)
        if not match or match[2].lower() != image_format:
            raise AssertionError(f'{label}ZIP包含非预期条目：{entry.filename!r}，应为 page-<页号>.{image_format}')
        number = int(match[1])
        if number in pages:
            raise AssertionError(f'{label}ZIP页号重复：第{number}页')
        pages[number] = entry
    if not pages:
        raise AssertionError(f'{label}ZIP没有分页图片')
    ordered = sorted(pages.items())
    for expected, (number, _) in enumerate(ordered, 1):
        if number != expected:
            raise AssertionError(f'{label}ZIP页号不连续：预期第{expected}页，实际第{number}页')
    return [entry for _, entry in ordered]


def open_page_zip(stack, path, image_format, label):
    try:
        archive = stack.enter_context(ZipFile(Path(path).expanduser()))
        return archive, _page_entries(archive, image_format, label)
    except ZIP_ERRORS as error:
        raise AssertionError(f'{label}文件无法作为ZIP打开：{error}') from error


def decode_zip_page(archive, member, image_format, Image, ImageOps):
    with archive.open(member) as stream:
        return decode_image(stream, image_format, Image, ImageOps, verify_zip_member=True)


def check_zip(source, config, report, output, compare):
    import numpy as np
    from PIL import Image, ImageOps

    decode_errors = ZIP_ERRORS + (ValueError, SyntaxError, Image.DecompressionBombError)
    image_format = config['图片格式']
    with ExitStack() as stack:
        actual, actual_entries = open_page_zip(stack, source, image_format, '实际')
        report['actual_page_count'] = len(actual_entries)
        expected = config.get('预期页数', len(actual_entries))
        if compare:
            baseline, baseline_entries = open_page_zip(stack, config['基准文件路径'], image_format, '基准')
            report['baseline_page_count'] = len(baseline_entries)
            expected = config.get('预期页数', len(baseline_entries))
            if len(baseline_entries) != expected:
                raise AssertionError(f'基准ZIP页数不一致：预期={expected}，基准={len(baseline_entries)}')
        if len(actual_entries) != expected:
            raise AssertionError(f'实际ZIP页数不一致：预期={expected}，实际={len(actual_entries)}')

        for index, entry in enumerate(actual_entries):
            result = {'page': index + 1, 'actual_entry': entry.filename, 'errors': []}
            report['pages'].append(result)
            entries = [('actual', '实际', actual, entry)]
            if compare:
                baseline_entry = baseline_entries[index]
                result['baseline_entry'] = baseline_entry.filename
                entries.append(('baseline', '基准', baseline, baseline_entry))
            with ExitStack() as images:
                decoded = {}
                for side, label, archive, member in entries:
                    try:
                        image = images.enter_context(decode_zip_page(archive, member, image_format, Image, ImageOps))
                    except decode_errors as error:
                        result['errors'].append(f'{label}图片 {member.filename!r} 无法解码：{error}')
                    else:
                        decoded[side] = image
                        result[f'{side}_size'] = image.size
                if compare and not result['errors']:
                    compare_region(decoded['actual'], decoded['baseline'], result, config, output, np, Image)
