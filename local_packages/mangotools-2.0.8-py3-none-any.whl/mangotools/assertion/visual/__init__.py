# -*- coding: utf-8 -*-
from ._pdf_comparison import PdfComparisonAssertion
from ._image_comparison import ImageZipAssertion


class FileVisualAssertion(PdfComparisonAssertion, ImageZipAssertion):
    """文件视觉识别"""


__all__ = ['FileVisualAssertion', 'ImageZipAssertion', 'PdfComparisonAssertion']
