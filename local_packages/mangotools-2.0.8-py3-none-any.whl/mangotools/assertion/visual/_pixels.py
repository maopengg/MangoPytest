"""Pixel comparison and diff rendering shared by PDF and image assertions."""


def compare_rgb(actual, baseline, tolerance, np):
    """Compare RGB intensity at identical coordinates, including pale imagery."""
    if actual.shape != baseline.shape:
        raise ValueError('RGB图像尺寸不一致')
    delta = np.abs(actual.astype(np.int16) - baseline.astype(np.int16)).max(axis=2)
    changed = delta > tolerance
    content = np.any(actual != 255, axis=2) | np.any(baseline != 255, axis=2)
    count, denominator = int(changed.sum()), int(content.sum())
    return {
        'color_difference_pixels': count,
        'color_difference_ratio': count / denominator if denominator else 0.0,
        'max_channel_difference': int(delta.max()),
    }, changed


def write_diff(path, actual_residual, baseline_residual, np, Image):
    pixels = np.full((*actual_residual.shape, 3), 255, dtype=np.uint8)
    pixels[actual_residual] = [220, 40, 40]
    if baseline_residual is not None:
        pixels[baseline_residual] = [40, 80, 220]
        pixels[actual_residual & baseline_residual] = [180, 40, 180]
    Image.fromarray(pixels).save(path)
