"""File comparison assertion registration and the existing two-argument API."""
from ...decorator import sync_method_callback
from ...models import MethodModel, MethodObjectFieldModel
from ._pdf_comparison_engine import compare_pdfs, evaluate_report, parse_inputs


def _assert_comparison(actual, expect, mode):
    source, baseline, config = parse_inputs(actual, expect)
    report = compare_pdfs(source, baseline, config, mode)
    failures = evaluate_report(report, config)
    suffix = f"，报告={report['report_path']}" if report.get('report_path') else ''
    if failures:
        raise AssertionError('PDF对比失败：' + '；'.join(failures) + suffix)
    summary = f"PDF对比通过，页数={report['actual_page_count']}，模式={mode}"
    if mode in {'all', 'visual'}:
        summary += f"，墨迹差异率={report['visual_summary']['ink_difference_ratio']:.6g}"
    return summary + suffix


class PdfComparisonAssertion:
    """PDF像素、文字内容和原生版式对比。"""

    @staticmethod
    @sync_method_callback('文件视觉识别', 'PDF对比断言', 0, [
        MethodModel(
            n='待测文件', f='actual', d=True, v={'文件路径': '/data/actual.pdf'},
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='文件路径', n='文件路径', p='PDF绝对路径或下载地址', value_type='string'),
            ],
        ),
        MethodModel(
            n='基准文件及比较标准', f='expect', d=True,
            v={
                '基准文件路径': '/data/baseline.pdf',
                '最大颜色差异率': 0,
                '最大颜色差异面积': 0,
                '颜色通道容差': 0,
                '最大墨迹差异率': 0,
                '最大未匹配面积': 0,
                '最大跨页字符数': 0,
                '最大换行变化数': 0,
                '最大位移字符数': 0,
                '最大字号变化字符数': 0,
            },
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='基准文件路径', n='基准文件路径', p='PDF绝对路径或下载地址', value_type='string'),
                MethodObjectFieldModel(f='最大颜色差异率', n='最大颜色差异率', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大颜色差异面积', n='最大颜色差异面积', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='颜色通道容差', n='颜色通道容差', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大墨迹差异率', n='最大墨迹差异率', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大未匹配面积', n='最大未匹配面积', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大跨页字符数', n='最大跨页字符数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大换行变化数', n='最大换行变化数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大位移字符数', n='最大位移字符数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大字号变化字符数', n='最大字号变化字符数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='输出目录', n='输出目录（可选）', p='报告及差异图保存目录', value_type='string'),
            ],
        ),
    ])
    def assert_pdf_comparison_pass(actual, expect):
        """PDF综合对比通过"""
        return _assert_comparison(actual, expect, 'all')

    @staticmethod
    @sync_method_callback('文件视觉识别', 'PDF对比断言', 1, [
        MethodModel(
            n='待测文件', f='actual', d=True, v={'文件路径': '/data/actual.pdf'},
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='文件路径', n='文件路径', p='PDF绝对路径或下载地址', value_type='string'),
            ],
        ),
        MethodModel(
            n='基准文件及比较标准', f='expect', d=True,
            v={
                '基准文件路径': '/data/baseline.pdf',
                '最大墨迹差异率': 0,
                '最大未匹配面积': 0,
            },
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='基准文件路径', n='基准文件路径', p='PDF绝对路径或下载地址', value_type='string'),
                MethodObjectFieldModel(f='最大墨迹差异率', n='最大墨迹差异率', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大未匹配面积', n='最大未匹配面积', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='输出目录', n='输出目录（可选）', p='报告及差异图保存目录', value_type='string'),
            ],
        ),
    ])
    def assert_pdf_visual_match(actual, expect):
        """PDF视觉差异符合预期"""
        return _assert_comparison(actual, expect, 'visual')

    @staticmethod
    @sync_method_callback('文件视觉识别', 'PDF对比断言', 2, [
        MethodModel(
            n='待测文件', f='actual', d=True, v={'文件路径': '/data/actual.pdf'},
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='文件路径', n='文件路径', p='PDF绝对路径或下载地址', value_type='string'),
            ],
        ),
        MethodModel(
            n='基准文件及比较标准', f='expect', d=True,
            v={
                '基准文件路径': '/data/baseline.pdf',
            },
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='基准文件路径', n='基准文件路径', p='PDF绝对路径或下载地址', value_type='string'),
                MethodObjectFieldModel(f='输出目录', n='输出目录（可选）', p='报告及差异图保存目录', value_type='string'),
            ],
        ),
    ])
    def assert_pdf_text_match(actual, expect):
        """PDF文字内容一致"""
        return _assert_comparison(actual, expect, 'text')

    @staticmethod
    @sync_method_callback('文件视觉识别', 'PDF对比断言', 3, [
        MethodModel(
            n='待测文件', f='actual', d=True, v={'文件路径': '/data/actual.pdf'},
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='文件路径', n='文件路径', p='PDF绝对路径或下载地址', value_type='string'),
            ],
        ),
        MethodModel(
            n='基准文件及比较标准', f='expect', d=True,
            v={
                '基准文件路径': '/data/baseline.pdf',
                '最大跨页字符数': 0,
                '最大换行变化数': 0,
                '最大位移字符数': 0,
                '最大字号变化字符数': 0,
            },
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='基准文件路径', n='基准文件路径', p='PDF绝对路径或下载地址', value_type='string'),
                MethodObjectFieldModel(f='最大跨页字符数', n='最大跨页字符数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大换行变化数', n='最大换行变化数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大位移字符数', n='最大位移字符数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大字号变化字符数', n='最大字号变化字符数', value_type='number', input_type='number'),
                MethodObjectFieldModel(f='输出目录', n='输出目录（可选）', p='报告及差异图保存目录', value_type='string'),
            ],
        ),
    ])
    def assert_pdf_layout_match(actual, expect):
        """PDF原生版式一致"""
        return _assert_comparison(actual, expect, 'layout')

    @staticmethod
    @sync_method_callback('文件视觉识别', 'PDF对比断言', 4, [
        MethodModel(n='待测文件', f='actual', d=True,
                    v={'文件路径': '/data/actual.pdf'}, value_type='object', input_type='object',
                    object_fields=[MethodObjectFieldModel(f='文件路径', n='文件路径', value_type='string')]),
        MethodModel(n='基准文件及颜色标准', f='expect', d=True,
                    v={'基准文件路径': '/data/baseline.pdf', '最大颜色差异率': 0,
                       '最大颜色差异面积': 0, '颜色通道容差': 0},
                    value_type='object', input_type='object', object_fields=[
                        MethodObjectFieldModel(f='基准文件路径', n='基准文件路径', value_type='string'),
                        MethodObjectFieldModel(f='最大颜色差异率', n='最大颜色差异率', value_type='number', input_type='number'),
                        MethodObjectFieldModel(f='最大颜色差异面积', n='最大颜色差异面积', value_type='number', input_type='number'),
                        MethodObjectFieldModel(f='颜色通道容差', n='颜色通道容差', p='0到255的整数', value_type='number', input_type='number'),
                        MethodObjectFieldModel(f='输出目录', n='输出目录（可选）', value_type='string'),
                    ]),
    ])
    def assert_pdf_color_match(actual, expect):
        """PDF图片与颜色一致"""
        return _assert_comparison(actual, expect, 'color')
