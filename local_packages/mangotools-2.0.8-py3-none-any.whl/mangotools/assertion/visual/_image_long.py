"""Validate a stitched image and compare vertical page regions against its baseline."""
from contextlib import ExitStack
from pathlib import Path
from zlib import error as ZlibError

from ._image_common import compare_region, decode_image, image_size, parse_number
from ._image_zip import ZIP_ERRORS, decode_zip_page, open_page_zip

# Document conversion's Windows render and long-image layout limits.
PAGE_GAP = 16
MAX_LONG_EDGE = 16000
MAX_LONG_PAGES = 35
MIN_LONG_SCALE = 0.25


def _page_ranges(config):
    regions = config.get('页面区间')
    if not isinstance(regions, list) or not regions:
        raise ValueError('页面区间必须是非空数组，按页序填写起始行和结束行（左闭右开）')
    if config.get('预期页数', len(regions)) != len(regions):
        raise ValueError('页面区间数量与预期页数不一致')
    previous = 0
    ranges = []
    for page, region in enumerate(regions, 1):
        if not isinstance(region, dict) or region.keys() != {'起始行', '结束行'}:
            raise ValueError(f'第{page}页区间必须包含起始行和结束行')
        start = parse_number(region, '起始行', 0, integer=True)
        end = parse_number(region, '结束行', 1, integer=True)
        if start < previous or end <= start:
            raise ValueError(f'第{page}页区间顺序错误、重叠或为空')
        ranges.append((start, end))
        previous = end
    return ranges


def prepare_long_config(config, compare):
    dimensions = ('预期宽度', '预期高度')
    has_dimensions = [field in config for field in dimensions]
    if not all(has_dimensions) and (not compare or any(has_dimensions)):
        raise ValueError('预期宽度和预期高度必须同时填写')
    for field in dimensions:
        if field in config:
            config[field] = parse_number(config, field, 1, integer=True)
    if '基准分页ZIP路径' in config:
        if '基准文件路径' in config or '页面区间' in config:
            raise ValueError('基准分页ZIP路径与基准文件路径、页面区间不能同时填写')
    elif compare:
        ranges = _page_ranges(config)
        config['页面区间'] = [{'起始行': start, '结束行': end} for start, end in ranges]


def _load_image(path, image_format, label, Image, ImageOps):
    try:
        with Path(path).expanduser().open('rb') as stream:
            return decode_image(stream, image_format, Image, ImageOps)
    except (OSError, EOFError, ValueError, SyntaxError, ZlibError, Image.DecompressionBombError) as error:
        raise AssertionError(f'{label}长图无法解码：{error}') from error


def _compare_gap(actual, reference, start, end, report, config, output, np, Image):
    bounds = (0, start, actual.width, end)
    result = {'gap': len(report['gaps']) + 1, 'row_range': [start, end], 'bounds': bounds, 'errors': []}
    with actual.crop(bounds) as region:
        compare_region(region, reference, result, config, output, np, Image, gap=True)
    report['gaps'].append(result)


def _compare_regions(actual, baseline, ranges, report, config, output, np, Image):
    width, height = baseline.size
    end = 0
    gaps = []
    for number, (start, bottom) in enumerate(ranges, 1):
        if end < start:
            gaps.append((end, start))
        end = bottom
        bounds = (0, start, width, bottom)
        result = {'page': number, 'row_range': [start, bottom], 'bounds': bounds, 'errors': []}
        with actual.crop(bounds) as a, baseline.crop(bounds) as b:
            compare_region(a, b, result, config, output, np, Image)
        report['pages'].append(result)
    if end < height:
        gaps.append((end, height))
    for start, bottom in gaps:
        with baseline.crop((0, start, width, bottom)) as reference:
            _compare_gap(actual, reference, start, bottom, report, config, output, np, Image)


def _zip_page_sizes(archive, entries, image_format, Image):
    sizes = []
    decode_errors = ZIP_ERRORS + (ValueError, SyntaxError, Image.DecompressionBombError)
    for page, member in enumerate(entries, 1):
        try:
            with archive.open(member) as stream:
                sizes.append(image_size(stream, image_format, Image))
        except decode_errors as error:
            raise AssertionError(f'基准ZIP第{page}页 {member.filename!r} 无法读取尺寸：{error}') from error
    return sizes


def _compare_zip_pages(actual, archive, entries, sizes, config, report, output, np, Image, ImageOps):
    y = 0
    decode_errors = ZIP_ERRORS + (ValueError, SyntaxError, Image.DecompressionBombError)
    for page, (entry, (width, height)) in enumerate(zip(entries, sizes, strict=True), 1):
        x = (actual.width - width) // 2
        bottom = y + height
        bounds = (0, y, actual.width, bottom)
        result = {'page': page, 'row_range': [y, bottom], 'bounds': bounds,
                  'content_bounds': (x, y, x + width, bottom), 'baseline_entry': entry.filename, 'errors': []}
        report['pages'].append(result)
        try:
            reference = decode_zip_page(archive, entry, config['图片格式'], Image, ImageOps)
        except decode_errors as error:
            result['errors'].append(f'基准ZIP图片 {entry.filename!r} 无法解码：{error}')
        else:
            with reference, Image.new('RGB', (actual.width, height), 'white') as band, actual.crop(bounds) as region:
                if reference.size == (width, height):
                    band.paste(reference, (x, 0))
                else:
                    with reference.resize((width, height), Image.Resampling.LANCZOS) as scaled:
                        band.paste(scaled, (x, 0))
                compare_region(region, band, result, config, output, np, Image)
        if page < len(entries):
            with Image.new('RGB', (actual.width, PAGE_GAP), 'white') as gap:
                _compare_gap(actual, gap, bottom, bottom + PAGE_GAP, report, config, output, np, Image)
        y = bottom + PAGE_GAP


def _project_pages(sizes):
    count = len(sizes)
    width = max(w for w, _ in sizes)
    page_height = sum(h for _, h in sizes)
    gap_height = (count - 1) * PAGE_GAP
    # Windows rescales the PDF before rasterization. Reserve one pixel per page for rounding.
    scale = min(1.0, MAX_LONG_EDGE / width, (MAX_LONG_EDGE - gap_height - count) / page_height)
    if scale < MIN_LONG_SCALE:
        raise AssertionError(f'基准ZIP推算缩放倍率={scale:.4f}，低于服务长图下限 {MIN_LONG_SCALE}')
    projected = [(max(1, round(w * scale)), max(1, round(h * scale))) for w, h in sizes]
    canvas = (max(w for w, _ in projected), sum(h for _, h in projected) + gap_height)
    return scale, projected, canvas


def _compare_with_zip(stack, actual, config, report, output, expected_size, np, Image, ImageOps):
    report['layout_source'] = 'baseline_zip'
    image_format = config['图片格式']
    archive, entries = open_page_zip(stack, config['基准分页ZIP路径'], image_format, '基准')
    count = len(entries)
    report['baseline_page_count'] = count
    if count != config.get('预期页数', count):
        raise AssertionError(f"基准ZIP页数不一致，实际={count}，预期={config['预期页数']}")
    if count > MAX_LONG_PAGES:
        raise AssertionError(f'基准ZIP有{count}页，超出长图的{MAX_LONG_PAGES}页上限')
    sizes = _zip_page_sizes(archive, entries, image_format, Image)
    report['baseline_page_sizes'] = sizes
    scale, projected, size = _project_pages(sizes)
    report['page_gap_px'] = PAGE_GAP if count > 1 else 0
    report['estimated_render_scale'] = scale
    report['projected_page_sizes'] = projected
    report['expected_size'] = size
    if expected_size and size != expected_size:
        raise AssertionError(f'基准ZIP推算的长图尺寸={size}，配置预期尺寸={expected_size}')
    if actual.size != size:
        raise AssertionError(f'实际长图尺寸不一致，实际={actual.size}，基准ZIP推算={size}；'
                             '请核对转换配置；若原始页尺寸取整造成推算偏差，请使用基准长图和页面区间')
    _compare_zip_pages(actual, archive, entries, projected, config, report, output, np, Image, ImageOps)


def check_long(source, config, report, output, compare):
    import numpy as np
    from PIL import Image, ImageOps

    image_format = config['图片格式']
    with ExitStack() as stack:
        actual = stack.enter_context(_load_image(source, image_format, '实际', Image, ImageOps))
        report['actual_size'] = actual.size
        expected_size = (config['预期宽度'], config['预期高度']) if '预期宽度' in config else None
        if '基准分页ZIP路径' in config:
            _compare_with_zip(stack, actual, config, report, output, expected_size, np, Image, ImageOps)
            return
        if compare:
            baseline = stack.enter_context(_load_image(config['基准文件路径'], image_format, '基准', Image, ImageOps))
            report['baseline_size'] = baseline.size
            expected_size = expected_size or baseline.size
        report['expected_size'] = expected_size
        if compare and baseline.size != expected_size:
            raise AssertionError(f'基准长图尺寸不一致，基准={baseline.size}，预期={expected_size}')
        if actual.size != expected_size:
            raise AssertionError(f'实际长图尺寸不一致，实际={actual.size}，预期={expected_size}')
        if compare:
            ranges = [(region['起始行'], region['结束行']) for region in config['页面区间']]
            if ranges[-1][1] > baseline.height:
                raise AssertionError(f'第{len(ranges)}页区间结束行超出长图高度 {baseline.height}')
            _compare_regions(actual, baseline, ranges, report, config, output, np, Image)
