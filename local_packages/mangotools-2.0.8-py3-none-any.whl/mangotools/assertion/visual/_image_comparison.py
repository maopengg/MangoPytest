"""Mango assertion registration for document-to-image outputs."""
from ...decorator import sync_method_callback
from ...models import MethodModel, MethodObjectFieldModel
from ._image_common import parse_inputs, run_assertion
from ._image_long import check_long, prepare_long_config
from ._image_zip import check_zip

_ACTUAL = MethodModel(
    n='待测图片产物', f='actual', d=True, v={'文件路径': '/data/actual.zip'},
    value_type='object', input_type='object', object_fields=[
        MethodObjectFieldModel(f='文件路径', n='文件路径', p='已下载的分页ZIP或长图本地路径', value_type='string'),
    ],
)
_FORMAT = MethodObjectFieldModel(f='图片格式', n='图片格式', p='png 或 jpg', value_type='string')
_MODE = MethodObjectFieldModel(f='交付模式', n='交付模式', p='zip 或 long，默认 zip', value_type='string')
_OUTPUT = MethodObjectFieldModel(f='输出目录', n='输出目录（可选）', p='保存报告和差异图', value_type='string')
_DIMENSIONS = [
    MethodObjectFieldModel(f=field, n=field, p='长图画布像素尺寸', value_type='number', input_type='number')
    for field in ('预期宽度', '预期高度')
]


def _assert_image(actual, expect, *, compare):
    source, config, mode = parse_inputs(actual, expect, compare)
    check = check_zip
    if mode == 'long':
        prepare_long_config(config, compare)
        check = check_long
    return run_assertion(source, config, compare=compare, mode=mode, check=check)


class ImageZipAssertion:
    """文档转图片的分页ZIP和长图断言。"""

    @staticmethod
    @sync_method_callback('文件视觉识别', '图片产物断言', 0, [
        _ACTUAL,
        MethodModel(
            n='预期图片产物', f='expect', d=True, v={'图片格式': 'png', '预期页数': 3},
            value_type='object', input_type='object', object_fields=[
                _MODE,
                _FORMAT,
                MethodObjectFieldModel(f='预期页数', n='预期页数', p='分页ZIP必填',
                                       value_type='number', input_type='number'),
                *_DIMENSIONS,
                _OUTPUT,
            ],
        ),
    ])
    def assert_image_artifact_valid(actual, expect):
        """图片产物格式及分页ZIP页数、页号或长图画布尺寸正确"""
        return _assert_image(actual, expect, compare=False)

    @staticmethod
    @sync_method_callback('文件视觉识别', '图片产物断言', 1, [
        _ACTUAL,
        MethodModel(
            n='基准产物及比较标准', f='expect', d=True,
            v={'基准文件路径': '/data/baseline.zip', '图片格式': 'png', '颜色通道容差': 0, '最大颜色差异率': 0},
            value_type='object', input_type='object', object_fields=[
                MethodObjectFieldModel(f='基准文件路径', n='基准文件路径', p='已审核的ZIP或长图本地路径', value_type='string'),
                MethodObjectFieldModel(f='基准分页ZIP路径', n='基准分页ZIP路径', value_type='string',
                                       p='长图模式可用，从审核过的同配置分页ZIP推算长图布局及等比缩放'),
                _MODE,
                _FORMAT,
                MethodObjectFieldModel(f='预期页数', n='预期页数（可选）', p='默认使用分页ZIP页数或长图页面区间数',
                                       value_type='number', input_type='number'),
                *_DIMENSIONS,
                MethodObjectFieldModel(f='页面区间', n='页面区间', value_type='array', input_type='json',
                                       p='使用基准长图时填写，例如 [{"起始行":0,"结束行":1754}]'),
                MethodObjectFieldModel(f='颜色通道容差', n='颜色通道容差', p='0到255的整数，默认0',
                                       value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大颜色差异率', n='最大颜色差异率', p='0到1，按两侧非白内容的并集计算',
                                       value_type='number', input_type='number'),
                MethodObjectFieldModel(f='最大颜色差异像素数', n='最大颜色差异像素数（可选）', p='每页上限，单位 px²',
                                       value_type='number', input_type='number'),
                _OUTPUT,
            ],
        ),
    ])
    def assert_image_visual_match(actual, expect):
        """分页ZIP或长图的逐页像素内容符合预期"""
        return _assert_image(actual, expect, compare=True)
