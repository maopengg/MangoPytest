# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 14:09
# @Author : 毛鹏
from ...data_processor import DataProcessor
from ...decorator import sync_method_callback
from ...exceptions import MangoToolsError
from ...exceptions.error_msg import ERROR_MSG_0061
from ...models import MethodModel

v = """
def func(self):
    # 函数名称必须是func并带有self参数，可以通过self.test_data使用缓存和测试数据方法
    self.test_data.set_cache('账号A', 'auto_test@qq.com')
    user = self.test_data.get_cache('账号A')
    assert user == 'auto_test@qq.com', f'用户邮箱不匹配，实际={user}，预期=auto_test@qq.com'
    return f'用户邮箱校验通过：{user}'
"""


class CustomAssertion:
    """自定义断言与函数断言"""

    def __init__(self, test_data: DataProcessor):
        self.test_data = test_data

    @sync_method_callback('函数断言', '函数断言', 7, [
        MethodModel(
            n='函数代码',
            f='actual',
            p='请输入一个python函数，函数名称必须是：func',
            d=True,
            v=v,
            input_type='code',
        )
    ])
    def ass_func(self, actual, expect=None):
        """输入断言代码"""
        try:
            global_namespace = {}
            exec(actual, global_namespace)
            return global_namespace['func'](self)
        except (KeyError, SyntaxError, TypeError):
            import traceback
            traceback.print_exc()
            raise MangoToolsError(*ERROR_MSG_0061)

    @sync_method_callback('自定义断言', 'Demo断言', 0, [
        MethodModel(n='实际值', f='actual', p='请输入实际值', d=True, v='mango'),
        MethodModel(n='预期值', f='expect', p='请输入预期值', d=True, v='mango'),
    ])
    def demo_custom_assert_equal(self, actual, expect=None):
        """Demo：实际值等于预期值"""
        assert actual == expect, f'自定义断言失败，实际={actual!r}，预期={expect!r}'
        return f'自定义断言通过，实际={actual!r}，预期={expect!r}'

    def func(self):
        # 示例函数由断言帮助页展示，实际执行使用上方 v 中的代码。
        self.test_data.set_cache('账号A', 'auto_test@qq.com')
        user = self.test_data.get_cache('账号A')
        assert user == 'auto_test@qq.com', f'用户邮箱不匹配，实际={user}，预期=auto_test@qq.com'
        return f'用户邮箱校验通过：{user}'
