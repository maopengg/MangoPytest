# -*- coding: utf-8 -*-
from dataclasses import dataclass, field
from typing import Any


@dataclass
class GitProviderConfig:
    provider: str
    base_url: str
    access_token: str
    default_project: str | int | None = None
    default_branch: str = "master"
    work_branch_prefix: str = "mango/"


@dataclass
class GitLocalConfig:
    repo_url: str
    root_path: str
    username: str | None = None
    password: str | None = None
    warehouse_name: str = "mango_pytest"


@dataclass
class GitBranchInfo:
    name: str
    commit_hash: str | None = None
    protected: bool = False
    default: bool = False
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class GitFileInfo:
    file_path: str
    content: str
    encoding: str = "utf-8"
    ref: str | None = None
    commit_hash: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class GitTreeItem:
    path: str
    type: str = "file"
    name: str | None = None
    commit_hash: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class GitMergeRequestInfo:
    id: str | int
    title: str
    source_branch: str
    target_branch: str
    state: str
    iid: str | int | None = None
    web_url: str | None = None
    mergeable: bool | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class PytestExecutionTarget:
    file_path: str
    nodeid: str
    node_type: str
    class_name: str | None = None
    method_name: str | None = None
    parameter_id: str | None = None
    display_name: str | None = None
