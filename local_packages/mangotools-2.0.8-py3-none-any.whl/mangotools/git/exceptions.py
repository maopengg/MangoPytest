# -*- coding: utf-8 -*-
from mangotools.exceptions import MangoToolsError


class GitToolsError(MangoToolsError):
    pass


GIT_ERROR_UNSUPPORTED_PROVIDER = (2401, "暂不支持的 Git 平台：{}")
GIT_ERROR_MISSING_BASE_URL = (2402, "请先配置 Git 平台域名")
GIT_ERROR_MISSING_TOKEN = (2403, "请先配置 Git 平台访问令牌")
GIT_ERROR_REQUEST_FAILED = (2404, "Git 平台请求失败：{}")
GIT_ERROR_UNAUTHORIZED = (2405, "Git 平台访问令牌无效或权限不足")
GIT_ERROR_PROJECT_NOT_FOUND = (2406, "Git 项目不存在或当前令牌无权限访问")
GIT_ERROR_BRANCH_EXISTS = (2407, "Git 分支已存在：{}")
GIT_ERROR_BRANCH_NOT_FOUND = (2408, "Git 分支不存在：{}")
GIT_ERROR_FILE_NOT_FOUND = (2409, "Git 文件不存在：{}")
GIT_ERROR_MERGE_NOT_ALLOWED = (2410, "合并请求当前不可合并，请检查冲突或审核状态")
GIT_ERROR_REPO_BUSY = (2411, "Git 仓库正在执行其他操作，请稍后重试")
GIT_ERROR_LOCAL_REPO = (2412, "本地 Git 仓库操作失败：{}")
GIT_ERROR_COMMAND_MISSING = (2413, "当前运行环境未安装 git 命令，请在后端/执行器镜像中安装 git 后重试")
