# -*- coding: utf-8 -*-
import hashlib
import re
from urllib.parse import quote


_SECRET_PATTERNS = (
    re.compile(r"(https?://)([^:/@\s]+):([^@\s]+)@", re.IGNORECASE),
    re.compile(r"((?:private[-_]?token|access[-_]?token|token|password|authorization)=)([^&\s]+)", re.IGNORECASE),
    re.compile(r"(Bearer\s+)([A-Za-z0-9._\-]+)", re.IGNORECASE),
)


def mask_secret(value: str | None) -> str | None:
    if value is None:
        return value
    masked = str(value)
    for pattern in _SECRET_PATTERNS:
        masked = pattern.sub(lambda match: f"{match.group(1)}***", masked)
    return masked


def stable_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def quote_path(value: str | int) -> str:
    return quote(str(value), safe="")
