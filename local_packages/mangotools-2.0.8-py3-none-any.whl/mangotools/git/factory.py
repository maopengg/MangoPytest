# -*- coding: utf-8 -*-
from mangotools.git.enums import GitProviderEnum
from mangotools.git.exceptions import GIT_ERROR_UNSUPPORTED_PROVIDER, GitToolsError
from mangotools.git.local_client import LocalGitClient
from mangotools.git.models import GitLocalConfig, GitProviderConfig
from mangotools.git.providers import GiteeApiClient, GitHubApiClient, GitLabApiClient


class GitClientFactory:
    @staticmethod
    def create_api_client(config: GitProviderConfig, log=None):
        provider = (config.provider or "").lower()
        if provider == GitProviderEnum.GITLAB.value:
            return GitLabApiClient(config, log=log)
        if provider == GitProviderEnum.GITEE.value:
            return GiteeApiClient(config, log=log)
        if provider == GitProviderEnum.GITHUB.value:
            return GitHubApiClient(config, log=log)
        raise GitToolsError(*GIT_ERROR_UNSUPPORTED_PROVIDER, value=(config.provider,))

    @staticmethod
    def create_local_client(config: GitLocalConfig, log=None) -> LocalGitClient:
        return LocalGitClient(config, log=log)
