# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path
from threading import RLock

from dulwich import porcelain
from dulwich.client import HTTPUnauthorized
from dulwich.repo import Repo

from mangotools.git.exceptions import GIT_ERROR_COMMAND_MISSING, GIT_ERROR_LOCAL_REPO, GIT_ERROR_UNAUTHORIZED, GitToolsError
from mangotools.git.models import GitLocalConfig
from mangotools.git.utils import mask_secret


class LocalGitClient:
    _locks: dict[str, RLock] = {}
    _locks_guard = RLock()

    def __init__(self, config: GitLocalConfig, log=None):
        self.config = config
        self.log = log
        self.local_dir = os.path.join(config.root_path, config.warehouse_name)

    @property
    def repo_url(self) -> str:
        return self.config.repo_url

    @property
    def username(self) -> str | None:
        return self.config.username

    @property
    def password(self) -> str | None:
        return self.config.password

    @property
    def repo(self) -> Repo:
        return Repo(self.local_dir)

    def clone(self, force: bool = False) -> bool:
        with self._repo_lock():
            try:
                if os.path.exists(self.local_dir):
                    if not force and self.is_usable_repo():
                        self._debug("Git 仓库已存在，复用本地仓库")
                        return True
                    self._archive_existing_repo()
                os.makedirs(self.local_dir, exist_ok=True)
                porcelain.clone(self._auth_url(), self.local_dir, checkout=True)
                return True
            except HTTPUnauthorized:
                raise GitToolsError(*GIT_ERROR_UNAUTHORIZED)
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def fetch(self) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._sync_origin_url()
                porcelain.fetch(self.repo, remote_location=self._auth_url())
                return True
            except HTTPUnauthorized:
                raise GitToolsError(*GIT_ERROR_UNAUTHORIZED)
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def pull(self, ref: str | None = None, accept_remote: bool = True) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._sync_origin_url()
                if ref:
                    self.checkout(ref)
                porcelain.pull(self.repo, remote_location=self._auth_url(), force=accept_remote)
                return True
            except HTTPUnauthorized:
                raise GitToolsError(*GIT_ERROR_UNAUTHORIZED)
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def checkout(self, ref: str) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._sync_origin_url()
                self._run_git("fetch", "--all", "--prune")
                target = ref
                branches = self._run_git("branch", "--all", "--format=%(refname:short)").splitlines()
                if f"origin/{ref}" in branches and ref not in branches:
                    self._run_git("checkout", "-B", ref, f"origin/{ref}")
                else:
                    self._run_git("checkout", "--force", target)
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def checkout_new_branch(self, branch: str, start_point: str) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._sync_origin_url()
                self._run_git("fetch", "--all", "--prune")
                self._run_git("checkout", "-B", branch, start_point)
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def reset_hard_clean(self) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._run_git("reset", "--hard")
                self._run_git("clean", "-fd")
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def merge_branch(self, source_branch: str, target_branch: str, push: bool = False) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self.checkout(target_branch)
                self.pull(target_branch)
                self._run_git("merge", "--no-edit", source_branch)
                if push:
                    self.push(target_branch)
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def abort_merge(self) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._run_git("merge", "--abort")
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def commit(self, message: str, paths: list[str] | None = None) -> str | None:
        with self._repo_lock():
            self.ensure_repo()
            try:
                if paths:
                    self._run_git("add", *paths)
                else:
                    self._run_git("add", ".")
                if not self.is_dirty():
                    return self.get_repo_info().get("commit_hash")
                self._run_git("commit", "-m", message)
                return self.get_repo_info().get("commit_hash")
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def push(self, branch: str, force: bool = False) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                args = ["push"]
                if force:
                    args.append("--force")
                args.extend([self._auth_url(), f"HEAD:{branch}"])
                self._run_git(*args)
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def delete_local_branch(self, branch: str, force: bool = True) -> bool:
        with self._repo_lock():
            self.ensure_repo()
            try:
                self._run_git("branch", "-D" if force else "-d", branch)
                return True
            except Exception as error:
                raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=(mask_secret(str(error)),))

    def get_repo_info(self) -> dict:
        if not os.path.exists(self.local_dir) or not self.is_usable_repo():
            return {
                "active_branch": "unknown",
                "commit_hash": "unknown",
                "is_dirty": False,
                "remote_url": self.config.repo_url,
                "local_dir": self.local_dir,
            }
        branch = self._run_git("rev-parse", "--abbrev-ref", "HEAD").strip()
        commit_hash = self._run_git("rev-parse", "--short", "HEAD").strip()
        return {
            "active_branch": branch,
            "commit_hash": commit_hash,
            "is_dirty": self.is_dirty(),
            "remote_url": self.config.repo_url,
            "local_dir": self.local_dir,
        }

    def get_file_last_commit_time(self, file_path: str):
        self.ensure_repo()
        if os.path.isabs(file_path):
            file_path = os.path.relpath(file_path, self.local_dir)
        output = self._run_git("log", "-1", "--format=%ct", "--", file_path).strip()
        if not output:
            return None
        return datetime.fromtimestamp(int(output))

    def read_file(self, file_path: str) -> str:
        path = self._safe_path(file_path)
        with open(path, "r", encoding="utf-8") as file:
            return file.read()

    def list_files(
            self,
            root_dirs: list[str] | None = None,
            extensions: list[str] | None = None,
    ) -> list[str]:
        self.ensure_repo()
        normalized_extensions = {
            item.lower() if item.startswith(".") else f".{item.lower()}"
            for item in (extensions or [])
            if item
        }
        roots = root_dirs or [""]
        files = []
        for root_dir in roots:
            root_path = self._safe_path(root_dir)
            if not os.path.isdir(root_path):
                continue
            for current_root, dir_names, file_names in os.walk(root_path):
                dir_names[:] = [item for item in dir_names if item != ".git"]
                for file_name in file_names:
                    if normalized_extensions and Path(file_name).suffix.lower() not in normalized_extensions:
                        continue
                    full_path = os.path.join(current_root, file_name)
                    relative_path = os.path.relpath(full_path, self.local_dir).replace(os.sep, "/")
                    files.append(relative_path)
        return sorted(set(files))

    def write_file(self, file_path: str, content: str) -> None:
        path = self._safe_path(file_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as file:
            file.write(content)

    def is_dirty(self) -> bool:
        self.ensure_repo()
        return bool(self._run_git("status", "--porcelain").strip())

    def is_usable_repo(self) -> bool:
        git_dir = os.path.join(self.local_dir, ".git")
        if not os.path.isdir(git_dir):
            return False
        try:
            Repo(self.local_dir)
            return True
        except Exception:
            return False

    def ensure_repo(self):
        if not self.is_usable_repo():
            self.clone()

    def _safe_path(self, file_path: str) -> str:
        root = Path(self.local_dir).resolve()
        path = (root / file_path).resolve()
        if root not in path.parents and path != root:
            raise GitToolsError(*GIT_ERROR_LOCAL_REPO, value=("文件路径越界",))
        return str(path)

    def _auth_url(self) -> str:
        if self.config.username and self.config.password and self.config.repo_url.startswith("https://"):
            return self.config.repo_url.replace(
                "https://",
                f"https://{self.config.username}:{self.config.password}@",
                1,
            )
        return self.config.repo_url

    def _sync_origin_url(self) -> None:
        remote_url = self._auth_url()
        remotes = self._run_git("remote").splitlines()
        if "origin" in remotes:
            self._run_git("remote", "set-url", "origin", remote_url)
            return
        self._run_git("remote", "add", "origin", remote_url)

    def _run_git(self, *args: str) -> str:
        env = os.environ.copy()
        command = ["git", "-C", self.local_dir, *args]
        try:
            result = subprocess.run(command, capture_output=True, text=True, env=env)
        except FileNotFoundError as error:
            raise GitToolsError(*GIT_ERROR_COMMAND_MISSING) from error
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip())
        return result.stdout

    def _archive_existing_repo(self):
        base_dir = os.path.dirname(self.local_dir)
        repo_name = os.path.basename(self.local_dir)
        archive_dir = os.path.join(base_dir, f"{repo_name}.bak.{time.strftime('%Y%m%d%H%M%S')}")
        try:
            os.replace(self.local_dir, archive_dir)
        except OSError:
            shutil.rmtree(self.local_dir)

    def _repo_lock(self):
        key = os.path.abspath(self.local_dir)
        with self._locks_guard:
            if key not in self._locks:
                self._locks[key] = RLock()
            return self._locks[key]

    def _debug(self, message: str):
        if self.log:
            self.log.debug(message)
