# -*- coding: utf-8 -*-
from mangotools.git.models import GitBranchInfo, GitFileInfo, GitMergeRequestInfo, GitTreeItem
from mangotools.git.providers.base import BaseGitApiClient


class GitHubApiClient(BaseGitApiClient):
    provider = "github"

    def get_current_user(self) -> dict:
        return self._request("GET", "user")

    def _repo(self, project=None) -> str:
        return str(self._project(project)).strip("/")

    def get_project(self, project=None) -> dict:
        return self._request("GET", f"repos/{self._repo(project)}")

    def list_branches(self, project=None, keyword: str | None = None) -> list[GitBranchInfo]:
        data = self._request("GET", f"repos/{self._repo(project)}/branches")
        branches = [
            GitBranchInfo(
                name=item.get("name"),
                commit_hash=(item.get("commit") or {}).get("sha"),
                protected=bool(item.get("protected")),
                raw=item,
            )
            for item in data
        ]
        if keyword:
            branches = [item for item in branches if keyword in item.name]
        return branches

    def create_branch(self, branch: str, ref: str, project=None) -> GitBranchInfo:
        repo = self._repo(project)
        base_ref = self._request("GET", f"repos/{repo}/git/ref/heads/{ref}")
        sha = (base_ref.get("object") or {}).get("sha") or ref
        item = self._request("POST", f"repos/{repo}/git/refs", json={"ref": f"refs/heads/{branch}", "sha": sha})
        return GitBranchInfo(name=branch, commit_hash=(item.get("object") or {}).get("sha"), raw=item)

    def delete_branch(self, branch: str, project=None) -> dict:
        return self._request("DELETE", f"repos/{self._repo(project)}/git/refs/heads/{branch}")

    def get_file(self, file_path: str, ref: str, project=None) -> GitFileInfo:
        item = self._request("GET", f"repos/{self._repo(project)}/contents/{file_path}", params={"ref": ref})
        return GitFileInfo(
            file_path=item.get("path") or file_path,
            content=self._decode_base64_content(item.get("content", "")),
            ref=ref,
            commit_hash=item.get("sha"),
            raw=item,
        )

    def list_tree(self, path: str = "", ref: str | None = None, recursive: bool = True, project=None) -> list[GitTreeItem]:
        ref_value = ref or self.config.default_branch
        data = self._request(
            "GET",
            f"repos/{self._repo(project)}/git/trees/{ref_value}",
            params={"recursive": "1" if recursive else "0"},
        )
        prefix = (path or "").strip("/")
        items: list[GitTreeItem] = []
        for item in data.get("tree", []):
            item_path = item.get("path") or ""
            if prefix and item_path != prefix and not item_path.startswith(f"{prefix}/"):
                continue
            items.append(
                GitTreeItem(
                    path=item_path,
                    name=item_path.rsplit("/", 1)[-1],
                    type=item.get("type") or "",
                    commit_hash=item.get("sha"),
                    raw=item,
                )
            )
        return items

    def download_archive(self, ref: str, project=None) -> bytes:
        return self._request_raw("GET", f"repos/{self._repo(project)}/zipball/{ref}")

    def upsert_file(self, file_path: str, content: str, branch: str, message: str, project=None) -> GitFileInfo:
        sha = None
        try:
            sha = self.get_file(file_path, branch, project).commit_hash
        except Exception:
            sha = None
        payload = {
            "message": message,
            "content": self._encode_base64_content(content),
            "branch": branch,
        }
        if sha:
            payload["sha"] = sha
        self._request("PUT", f"repos/{self._repo(project)}/contents/{file_path}", json=payload)
        return self.get_file(file_path, branch, project)

    def delete_file(self, file_path: str, branch: str, message: str, project=None) -> dict:
        file_info = self.get_file(file_path, branch, project)
        return self._request(
            "DELETE",
            f"repos/{self._repo(project)}/contents/{file_path}",
            json={"message": message, "branch": branch, "sha": file_info.commit_hash},
        )

    def create_merge_request(self, source_branch: str, target_branch: str, title: str, description: str = "", project=None):
        item = self._request(
            "POST",
            f"repos/{self._repo(project)}/pulls",
            json={"head": source_branch, "base": target_branch, "title": title, "body": description},
        )
        return self._pr_info(item)

    def get_merge_request(self, mr_id, project=None):
        item = self._request("GET", f"repos/{self._repo(project)}/pulls/{mr_id}")
        return self._pr_info(item)

    def merge_merge_request(self, mr_id, project=None):
        self._request("PUT", f"repos/{self._repo(project)}/pulls/{mr_id}/merge")
        return self.get_merge_request(mr_id, project)

    def list_pipelines(self, ref: str | None = None, project=None) -> list[dict]:
        params = {}
        if ref:
            params["branch"] = ref
        data = self._request("GET", f"repos/{self._repo(project)}/actions/runs", params=params)
        return data.get("workflow_runs", [])

    @staticmethod
    def _pr_info(item: dict) -> GitMergeRequestInfo:
        return GitMergeRequestInfo(
            id=item.get("number") or item.get("id"),
            iid=item.get("number"),
            title=item.get("title") or "",
            source_branch=((item.get("head") or {}).get("ref")) or "",
            target_branch=((item.get("base") or {}).get("ref")) or "",
            state=item.get("state") or "unknown",
            web_url=item.get("html_url"),
            mergeable=item.get("mergeable"),
            raw=item,
        )
