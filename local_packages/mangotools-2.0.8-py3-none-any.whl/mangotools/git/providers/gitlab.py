# -*- coding: utf-8 -*-
from mangotools.git.enums import GitMergeRequestStateEnum
from mangotools.git.models import GitBranchInfo, GitFileInfo, GitMergeRequestInfo, GitTreeItem
from mangotools.git.providers.base import BaseGitApiClient
from mangotools.git.utils import quote_path


class GitLabApiClient(BaseGitApiClient):
    provider = "gitlab"

    def _headers(self) -> dict[str, str]:
        return {"PRIVATE-TOKEN": self.config.access_token}

    def _api(self, path: str) -> str:
        base = self.config.base_url.rstrip("/")
        if base.endswith("/api/v4"):
            return f"{base}/{path.lstrip('/')}"
        return f"{base}/api/v4/{path.lstrip('/')}"

    def _request(self, method: str, path: str, **kwargs):
        return super()._request(method, self._api(path), **kwargs)

    def _request_raw(self, method: str, path: str, **kwargs):
        return super()._request_raw(method, self._api(path), **kwargs)

    def _project_path(self, project=None):
        return quote_path(self._project(project))

    def get_current_user(self) -> dict:
        return self._request("GET", "user")

    def get_project(self, project=None) -> dict:
        return self._request("GET", f"projects/{self._project_path(project)}")

    def list_branches(self, project=None, keyword: str | None = None) -> list[GitBranchInfo]:
        params = {}
        if keyword:
            params["search"] = keyword
        data = self._request("GET", f"projects/{self._project_path(project)}/repository/branches", params=params)
        return [
            GitBranchInfo(
                name=item.get("name"),
                commit_hash=(item.get("commit") or {}).get("id"),
                protected=bool(item.get("protected")),
                default=bool(item.get("default")),
                raw=item,
            )
            for item in data
        ]

    def create_branch(self, branch: str, ref: str, project=None) -> GitBranchInfo:
        item = self._request(
            "POST",
            f"projects/{self._project_path(project)}/repository/branches",
            data={"branch": branch, "ref": ref},
        )
        return GitBranchInfo(
            name=item.get("name"),
            commit_hash=(item.get("commit") or {}).get("id"),
            protected=bool(item.get("protected")),
            default=bool(item.get("default")),
            raw=item,
        )

    def delete_branch(self, branch: str, project=None) -> dict:
        return self._request(
            "DELETE",
            f"projects/{self._project_path(project)}/repository/branches/{quote_path(branch)}",
        )

    def get_file(self, file_path: str, ref: str, project=None) -> GitFileInfo:
        item = self._request(
            "GET",
            f"projects/{self._project_path(project)}/repository/files/{quote_path(file_path)}",
            params={"ref": ref},
        )
        return GitFileInfo(
            file_path=item.get("file_path") or file_path,
            content=self._decode_base64_content(item.get("content", "")),
            encoding="utf-8",
            ref=ref,
            commit_hash=item.get("last_commit_id"),
            raw=item,
        )

    def list_tree(self, path: str = "", ref: str | None = None, recursive: bool = True, project=None) -> list[GitTreeItem]:
        params = {
            "path": path or "",
            "ref": ref or self.config.default_branch,
            "recursive": "true" if recursive else "false",
            "per_page": 100,
            "page": 1,
        }
        items: list[GitTreeItem] = []
        while True:
            data = self._request(
                "GET",
                f"projects/{self._project_path(project)}/repository/tree",
                params=params,
            )
            if not data:
                break
            for item in data:
                items.append(
                    GitTreeItem(
                        path=item.get("path") or "",
                        name=item.get("name"),
                        type=item.get("type") or "",
                        commit_hash=item.get("id"),
                        raw=item,
                    )
                )
            if len(data) < params["per_page"]:
                break
            params["page"] += 1
        return items

    def download_archive(self, ref: str, project=None) -> bytes:
        return self._request_raw(
            "GET",
            f"projects/{self._project_path(project)}/repository/archive.zip",
            params={"sha": ref},
        )

    def upsert_file(self, file_path: str, content: str, branch: str, message: str, project=None) -> GitFileInfo:
        path = f"projects/{self._project_path(project)}/repository/files/{quote_path(file_path)}"
        payload = {"branch": branch, "content": content, "commit_message": message}
        try:
            self._request("PUT", path, data=payload)
        except Exception:
            self._request("POST", path, data=payload)
        return self.get_file(file_path, branch, project)

    def delete_file(self, file_path: str, branch: str, message: str, project=None) -> dict:
        return self._request(
            "DELETE",
            f"projects/{self._project_path(project)}/repository/files/{quote_path(file_path)}",
            data={"branch": branch, "commit_message": message},
        )

    def create_merge_request(self, source_branch: str, target_branch: str, title: str, description: str = "", project=None):
        item = self._request(
            "POST",
            f"projects/{self._project_path(project)}/merge_requests",
            data={
                "source_branch": source_branch,
                "target_branch": target_branch,
                "title": title,
                "description": description,
            },
        )
        return self._mr_info(item)

    def get_merge_request(self, mr_id, project=None):
        item = self._request("GET", f"projects/{self._project_path(project)}/merge_requests/{mr_id}")
        return self._mr_info(item)

    def merge_merge_request(self, mr_id, project=None):
        item = self._request("PUT", f"projects/{self._project_path(project)}/merge_requests/{mr_id}/merge")
        return self._mr_info(item)

    def list_pipelines(self, ref: str | None = None, project=None) -> list[dict]:
        params = {}
        if ref:
            params["ref"] = ref
        return self._request("GET", f"projects/{self._project_path(project)}/pipelines", params=params)

    @staticmethod
    def _mr_info(item: dict) -> GitMergeRequestInfo:
        state = item.get("state") or GitMergeRequestStateEnum.UNKNOWN.value
        return GitMergeRequestInfo(
            id=item.get("id"),
            iid=item.get("iid"),
            title=item.get("title") or "",
            source_branch=item.get("source_branch") or "",
            target_branch=item.get("target_branch") or "",
            state=state,
            web_url=item.get("web_url"),
            mergeable=item.get("merge_status") in ("can_be_merged", "mergeable"),
            raw=item,
        )
