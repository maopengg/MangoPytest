# -*- coding: utf-8 -*-
from mangotools.git.models import GitBranchInfo, GitFileInfo, GitMergeRequestInfo, GitTreeItem
from mangotools.git.providers.base import BaseGitApiClient
from mangotools.git.utils import quote_path


class GiteeApiClient(BaseGitApiClient):
    provider = "gitee"

    def _headers(self) -> dict[str, str]:
        return {}

    def _token_params(self, params=None) -> dict:
        data = dict(params or {})
        data["access_token"] = self.config.access_token
        return data

    def get_current_user(self) -> dict:
        return self._request("GET", "api/v5/user", params=self._token_params())

    def _repo_parts(self, project=None) -> tuple[str, str]:
        value = str(self._project(project)).strip("/")
        owner, repo = value.split("/", 1)
        return owner, repo

    def get_project(self, project=None) -> dict:
        owner, repo = self._repo_parts(project)
        return self._request("GET", f"api/v5/repos/{owner}/{repo}", params=self._token_params())

    def list_branches(self, project=None, keyword: str | None = None) -> list[GitBranchInfo]:
        owner, repo = self._repo_parts(project)
        data = self._request("GET", f"api/v5/repos/{owner}/{repo}/branches", params=self._token_params())
        branches = [
            GitBranchInfo(
                name=item.get("name"),
                commit_hash=(item.get("commit") or {}).get("sha"),
                protected=bool(item.get("protected")),
                raw=item,
            )
            for item in data
        ]
        if keyword:
            branches = [item for item in branches if keyword in item.name]
        return branches

    def create_branch(self, branch: str, ref: str, project=None) -> GitBranchInfo:
        owner, repo = self._repo_parts(project)
        item = self._request(
            "POST",
            f"api/v5/repos/{owner}/{repo}/branches",
            data=self._token_params({"refs": ref, "branch_name": branch}),
        )
        return GitBranchInfo(name=item.get("name") or branch, commit_hash=(item.get("commit") or {}).get("sha"), raw=item)

    def delete_branch(self, branch: str, project=None) -> dict:
        owner, repo = self._repo_parts(project)
        return self._request(
            "DELETE",
            f"api/v5/repos/{owner}/{repo}/branches/{quote_path(branch)}",
            params=self._token_params(),
        )

    def get_file(self, file_path: str, ref: str, project=None) -> GitFileInfo:
        owner, repo = self._repo_parts(project)
        item = self._request(
            "GET",
            f"api/v5/repos/{owner}/{repo}/contents/{file_path}",
            params=self._token_params({"ref": ref}),
        )
        return GitFileInfo(
            file_path=item.get("path") or file_path,
            content=self._decode_base64_content(item.get("content", "")),
            ref=ref,
            commit_hash=item.get("sha"),
            raw=item,
        )

    def list_tree(self, path: str = "", ref: str | None = None, recursive: bool = True, project=None) -> list[GitTreeItem]:
        owner, repo = self._repo_parts(project)
        ref_value = ref or self.config.default_branch
        root = (path or "").strip("/")
        items: list[GitTreeItem] = []

        def walk(current_path: str):
            data = self._request(
                "GET",
                f"api/v5/repos/{owner}/{repo}/contents/{current_path}",
                params=self._token_params({"ref": ref_value}),
            )
            if isinstance(data, dict):
                data = [data]
            for item in data or []:
                item_path = item.get("path") or item.get("name") or ""
                item_type = item.get("type") or ""
                git_item = GitTreeItem(
                    path=item_path,
                    name=item.get("name"),
                    type="file" if item_type == "file" else "tree",
                    commit_hash=item.get("sha"),
                    raw=item,
                )
                items.append(git_item)
                if recursive and item_type in ("dir", "tree"):
                    walk(item_path)

        walk(root)
        return items

    def download_archive(self, ref: str, project=None) -> bytes:
        owner, repo = self._repo_parts(project)
        return self._request_raw(
            "GET",
            f"api/v5/repos/{owner}/{repo}/zipball",
            params=self._token_params({"ref": ref}),
        )

    def upsert_file(self, file_path: str, content: str, branch: str, message: str, project=None) -> GitFileInfo:
        owner, repo = self._repo_parts(project)
        payload = self._token_params({"content": content, "branch": branch, "message": message})
        try:
            self.get_file(file_path, branch, project)
            self._request("PUT", f"api/v5/repos/{owner}/{repo}/contents/{file_path}", data=payload)
        except Exception:
            self._request("POST", f"api/v5/repos/{owner}/{repo}/contents/{file_path}", data=payload)
        return self.get_file(file_path, branch, project)

    def delete_file(self, file_path: str, branch: str, message: str, project=None) -> dict:
        owner, repo = self._repo_parts(project)
        return self._request(
            "DELETE",
            f"api/v5/repos/{owner}/{repo}/contents/{file_path}",
            data=self._token_params({"branch": branch, "message": message}),
        )

    def create_merge_request(self, source_branch: str, target_branch: str, title: str, description: str = "", project=None):
        owner, repo = self._repo_parts(project)
        item = self._request(
            "POST",
            f"api/v5/repos/{owner}/{repo}/pulls",
            data=self._token_params(
                {"head": source_branch, "base": target_branch, "title": title, "body": description}
            ),
        )
        return self._pr_info(item)

    def get_merge_request(self, mr_id, project=None):
        owner, repo = self._repo_parts(project)
        item = self._request("GET", f"api/v5/repos/{owner}/{repo}/pulls/{mr_id}", params=self._token_params())
        return self._pr_info(item)

    def merge_merge_request(self, mr_id, project=None):
        owner, repo = self._repo_parts(project)
        item = self._request("PUT", f"api/v5/repos/{owner}/{repo}/pulls/{mr_id}/merge", data=self._token_params())
        return self._pr_info(item)

    def list_pipelines(self, ref: str | None = None, project=None) -> list[dict]:
        return []

    @staticmethod
    def _pr_info(item: dict) -> GitMergeRequestInfo:
        return GitMergeRequestInfo(
            id=item.get("number") or item.get("id"),
            iid=item.get("number"),
            title=item.get("title") or "",
            source_branch=item.get("head") or "",
            target_branch=item.get("base") or "",
            state=item.get("state") or "unknown",
            web_url=item.get("html_url"),
            mergeable=item.get("mergeable"),
            raw=item,
        )
