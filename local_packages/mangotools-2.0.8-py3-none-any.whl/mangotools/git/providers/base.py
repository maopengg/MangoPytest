# -*- coding: utf-8 -*-
from __future__ import annotations

import base64
from typing import Any
from urllib.parse import urljoin

import requests

from mangotools.git.exceptions import (
    GIT_ERROR_MISSING_BASE_URL,
    GIT_ERROR_MISSING_TOKEN,
    GIT_ERROR_PROJECT_NOT_FOUND,
    GIT_ERROR_REQUEST_FAILED,
    GIT_ERROR_UNAUTHORIZED,
    GitToolsError,
)
from mangotools.git.models import GitProviderConfig
from mangotools.git.utils import mask_secret


class BaseGitApiClient:
    provider = "base"

    def __init__(self, config: GitProviderConfig, timeout: int = 15, log=None):
        if not config.base_url:
            raise GitToolsError(*GIT_ERROR_MISSING_BASE_URL)
        if not config.access_token:
            raise GitToolsError(*GIT_ERROR_MISSING_TOKEN)
        self.config = config
        self.timeout = timeout
        self.log = log

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.config.access_token}"}

    def _url(self, path: str) -> str:
        base_url = self.config.base_url.rstrip("/") + "/"
        return urljoin(base_url, path.lstrip("/"))

    def _request(self, method: str, path: str, **kwargs) -> Any:
        url = self._url(path)
        headers = kwargs.pop("headers", {})
        headers.update(self._headers())
        try:
            response = requests.request(method, url, headers=headers, timeout=self.timeout, **kwargs)
        except requests.RequestException as error:
            raise GitToolsError(*GIT_ERROR_REQUEST_FAILED, value=(mask_secret(str(error)),))
        if response.status_code in (401, 403):
            raise GitToolsError(*GIT_ERROR_UNAUTHORIZED)
        if response.status_code == 404:
            raise GitToolsError(*GIT_ERROR_PROJECT_NOT_FOUND)
        if response.status_code >= 400:
            message = response.text[:300] if response.text else response.reason
            raise GitToolsError(*GIT_ERROR_REQUEST_FAILED, value=(mask_secret(message),))
        if not response.content:
            return {}
        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            return response.json()
        return response.text

    def _request_raw(self, method: str, path: str, **kwargs) -> bytes:
        url = self._url(path)
        headers = kwargs.pop("headers", {})
        headers.update(self._headers())
        try:
            response = requests.request(method, url, headers=headers, timeout=self.timeout, **kwargs)
        except requests.RequestException as error:
            raise GitToolsError(*GIT_ERROR_REQUEST_FAILED, value=(mask_secret(str(error)),))
        if response.status_code in (401, 403):
            raise GitToolsError(*GIT_ERROR_UNAUTHORIZED)
        if response.status_code == 404:
            raise GitToolsError(*GIT_ERROR_PROJECT_NOT_FOUND)
        if response.status_code >= 400:
            message = response.text[:300] if response.text else response.reason
            raise GitToolsError(*GIT_ERROR_REQUEST_FAILED, value=(mask_secret(message),))
        return response.content

    def _project(self, project: str | int | None = None) -> str | int:
        return project or self.config.default_project

    @staticmethod
    def _decode_base64_content(content: str) -> str:
        return base64.b64decode(content).decode("utf-8")

    @staticmethod
    def _encode_base64_content(content: str) -> str:
        return base64.b64encode(content.encode("utf-8")).decode("utf-8")

    def test_connection(self) -> dict:
        return self.get_current_user()

    def get_current_user(self) -> dict:
        raise NotImplementedError

    def get_project(self, project: str | int | None = None) -> dict:
        raise NotImplementedError

    def list_branches(self, project: str | int | None = None, keyword: str | None = None):
        raise NotImplementedError

    def create_branch(self, branch: str, ref: str, project: str | int | None = None):
        raise NotImplementedError

    def delete_branch(self, branch: str, project: str | int | None = None):
        raise NotImplementedError

    def get_file(self, file_path: str, ref: str, project: str | int | None = None):
        raise NotImplementedError

    def list_tree(
        self,
        path: str = "",
        ref: str | None = None,
        recursive: bool = True,
        project: str | int | None = None,
    ):
        raise NotImplementedError

    def list_files(
        self,
        root_dirs: list[str] | tuple[str, ...] | None = None,
        extensions: list[str] | tuple[str, ...] | None = None,
        ref: str | None = None,
        project: str | int | None = None,
    ) -> list[str]:
        roots = [str(item).strip("/\\") for item in (root_dirs or [""]) if str(item).strip("/\\")]
        if not roots:
            roots = [""]
        suffixes = tuple((extensions or []))
        files: list[str] = []
        seen: set[str] = set()
        for root in roots:
            for item in self.list_tree(path=root, ref=ref, recursive=True, project=project):
                item_path = getattr(item, "path", "") or ""
                item_type = getattr(item, "type", "")
                if item_type not in ("file", "blob"):
                    continue
                if suffixes and not item_path.endswith(suffixes):
                    continue
                if item_path not in seen:
                    seen.add(item_path)
                    files.append(item_path)
        return sorted(files)

    def download_archive(self, ref: str, project: str | int | None = None) -> bytes:
        raise NotImplementedError

    def upsert_file(self, file_path: str, content: str, branch: str, message: str, project: str | int | None = None):
        raise NotImplementedError

    def delete_file(self, file_path: str, branch: str, message: str, project: str | int | None = None):
        raise NotImplementedError

    def create_merge_request(
        self,
        source_branch: str,
        target_branch: str,
        title: str,
        description: str = "",
        project: str | int | None = None,
    ):
        raise NotImplementedError

    def get_merge_request(self, mr_id: str | int, project: str | int | None = None):
        raise NotImplementedError

    def merge_merge_request(self, mr_id: str | int, project: str | int | None = None):
        raise NotImplementedError

    def list_pipelines(self, ref: str | None = None, project: str | int | None = None) -> list[dict]:
        raise NotImplementedError
