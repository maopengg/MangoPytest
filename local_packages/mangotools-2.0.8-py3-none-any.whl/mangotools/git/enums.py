# -*- coding: utf-8 -*-
from enum import Enum


class GitProviderEnum(str, Enum):
    GITLAB = "gitlab"
    GITEE = "gitee"
    GITHUB = "github"


class GitMergeRequestStateEnum(str, Enum):
    OPENED = "opened"
    MERGED = "merged"
    CLOSED = "closed"
    CONFLICT = "conflict"
    UNKNOWN = "unknown"


class GitFileActionEnum(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"


class GitOperationModeEnum(str, Enum):
    DIRECT_PUSH = "direct_push"
    MERGE_REQUEST = "merge_request"


class PytestNodeTypeEnum(str, Enum):
    FILE = "file"
    CLASS = "class"
    METHOD = "method"
    PARAMETER = "parameter"
