# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-08-11 11:12
# @Author : 毛鹏
import hashlib
import hmac
import base64
import zlib

from mangotools.decorator import data_method
from mangotools.exceptions import MangoToolsError
from mangotools.exceptions.error_msg import ERROR_MSG_0027, ERROR_MSG_0028


class EncryptionTool:
    """ 加密 """

    @classmethod
    @data_method('security', '摘要与哈希', 'MD5 32位小写摘要')
    def md5_32_small(cls, string) -> str:
        """MD5_32位小写加密"""
        md5 = hashlib.md5()
        md5.update(string.encode('utf-8'))
        encrypted_string = md5.hexdigest()
        return encrypted_string

    @classmethod
    @data_method('security', '摘要与哈希', 'MD5 32位大写摘要')
    def md5_32_large(cls, string) -> str:
        """MD5_32位大写加密"""
        md5 = hashlib.md5()
        md5.update(string.encode('utf-8'))
        encrypted_string = md5.hexdigest().upper()
        return encrypted_string

    @classmethod
    @data_method('security', '摘要与哈希', 'MD5 16位小写摘要')
    def md5_16_small(cls, string) -> str:
        """MD5_16位小写加密"""
        md5 = hashlib.md5()
        md5.update(string.encode('utf-8'))
        encrypted_string = md5.hexdigest()[8:-8]
        return encrypted_string

    @classmethod
    @data_method('security', '摘要与哈希', 'MD5 16位大写摘要')
    def md5_16_large(cls, string) -> str:
        """MD5_16位大写加密"""
        md5 = hashlib.md5()
        md5.update(string.encode('utf-8'))
        encrypted_string = md5.hexdigest().upper()[8:-8]
        return encrypted_string

    @classmethod
    def _digest(cls, algorithm: str, data) -> str:
        try:
            return hashlib.new(algorithm, str(data).encode('utf-8')).hexdigest()
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0027, value=(algorithm.upper(), str(error))) from error

    @classmethod
    @data_method('security', '摘要与哈希', 'SHA-256摘要')
    def sha256(cls, data) -> str:
        return cls._digest('sha256', data)

    @classmethod
    @data_method('security', '摘要与哈希', 'SHA-224摘要')
    def sha224(cls, data) -> str:
        return cls._digest('sha224', data)

    @classmethod
    @data_method('security', '摘要与哈希', 'SHA-384摘要')
    def sha384(cls, data) -> str:
        return cls._digest('sha384', data)

    @classmethod
    @data_method('security', '摘要与哈希', 'SHA-512摘要')
    def sha512(cls, data) -> str:
        return cls._digest('sha512', data)

    @classmethod
    @data_method('security', '摘要与哈希', 'SM3国密摘要')
    def sm3(cls, data) -> str:
        return cls._digest('sm3', data)

    @classmethod
    @data_method('security', '摘要与哈希', 'CRC32校验和')
    def crc32(cls, data) -> str:
        try:
            return f'{zlib.crc32(str(data).encode("utf-8")) & 0xffffffff:08x}'
        except (UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0027, value=('CRC32', str(error))) from error

    @classmethod
    def _hmac_digest(cls, algorithm: str, data, key) -> str:
        try:
            return hmac.new(
                str(key).encode('utf-8'),
                str(data).encode('utf-8'),
                digestmod=algorithm,
            ).hexdigest()
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0028, value=(f'HMAC-{algorithm.upper()}', str(error))) from error

    @classmethod
    def _hmac_digest_base64(cls, algorithm: str, data, key) -> str:
        try:
            digest = hmac.new(
                str(key).encode('utf-8'),
                str(data).encode('utf-8'),
                digestmod=algorithm,
            ).digest()
            return base64.b64encode(digest).decode('ascii')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0028, value=(f'HMAC-{algorithm.upper()} Base64', str(error))) from error

    @classmethod
    @data_method('security', '消息认证', 'HMAC-MD5消息认证')
    def hmac_md5(cls, data, key) -> str:
        return cls._hmac_digest('md5', data, key)

    @classmethod
    @data_method('security', '消息认证', 'HMAC-SHA256消息认证')
    def hmac_sha256(cls, data, key) -> str:
        return cls._hmac_digest('sha256', data, key)

    @classmethod
    @data_method('security', '消息认证', 'HMAC-SHA256消息认证（Base64输出）')
    def hmac_sha256_base64(cls, data, key) -> str:
        return cls._hmac_digest_base64('sha256', data, key)

    @classmethod
    @data_method('security', '消息认证', 'HMAC-SHA384消息认证')
    def hmac_sha384(cls, data, key) -> str:
        return cls._hmac_digest('sha384', data, key)

    @classmethod
    @data_method('security', '消息认证', 'HMAC-SHA512消息认证')
    def hmac_sha512(cls, data, key) -> str:
        return cls._hmac_digest('sha512', data, key)
