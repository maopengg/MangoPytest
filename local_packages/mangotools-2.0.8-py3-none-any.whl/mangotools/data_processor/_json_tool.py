# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-05-24 23:20
# @Author : 毛鹏
import json

import jsonpath

from mangotools.decorator import data_method
from ..exceptions import *
from ..exceptions.error_msg import ERROR_MSG_0003, ERROR_MSG_0004, ERROR_MSG_0005


class JsonTool:
    """ json """

    @staticmethod
    def _validate_json_path_expression(expr):
        if not isinstance(expr, str) or not expr.strip():
            raise MangoToolsError(*ERROR_MSG_0005, value=(expr, '表达式不能为空'))
        if expr.count('[') != expr.count(']'):
            raise MangoToolsError(*ERROR_MSG_0005, value=(expr, '方括号不完整'))

    @staticmethod
    def _simple_json_path_tokens(expr):
        """Parse only simple field/index paths for a best-effort miss diagnosis."""
        if not isinstance(expr, str) or not expr.startswith('$'):
            return None
        tokens = []
        index = 1
        while index < len(expr):
            char = expr[index]
            if char == '.':
                index += 1
                start = index
                while index < len(expr) and expr[index] not in '.[':
                    index += 1
                token = expr[start:index]
                if not token or any(symbol in token for symbol in '*?@()'):
                    return None
                tokens.append(token)
                continue
            if char == '[':
                end = expr.find(']', index + 1)
                if end < 0:
                    return None
                token = expr[index + 1:end].strip()
                if len(token) >= 2 and token[0] == token[-1] and token[0] in {'\"', "'"}:
                    token = token[1:-1]
                elif not token.isdigit():
                    return None
                tokens.append(token)
                index = end + 1
                continue
            return None
        return tokens

    @classmethod
    def _describe_json_path_miss(cls, obj, expr):
        tokens = cls._simple_json_path_tokens(expr)
        if tokens is None:
            return '响应中没有符合该表达式的数据，请检查响应内容和筛选条件'

        current = obj
        current_path = '$'
        for token in tokens:
            if isinstance(current, dict):
                if token not in current:
                    available = list(current.keys())[:8]
                    available_text = '、'.join(str(key) for key in available)
                    if len(current) > len(available):
                        available_text += ' 等'
                    suffix = f'；当前对象可用字段：{available_text}' if available_text else '；当前对象为空'
                    return f'路径【{current_path}】下不存在字段【{token}】{suffix}'
                current = current[token]
                current_path = f'{current_path}.{token}'
                continue

            if isinstance(current, list):
                if not token.isdigit():
                    return f'路径【{current_path}】是数组，下一段【{token}】应为数组下标'
                item_index = int(token)
                if not current:
                    return f'路径【{current_path}】是空数组，无法读取下标【{item_index}】'
                if item_index >= len(current):
                    return f'路径【{current_path}】仅有【{len(current)}】项，无法读取下标【{item_index}】'
                current = current[item_index]
                current_path = f'{current_path}[{item_index}]'
                continue

            if current is None:
                value_type = '空值(null)'
            elif isinstance(current, bool):
                value_type = '布尔值(boolean)'
            elif isinstance(current, str):
                value_type = '字符串(string)'
            elif isinstance(current, (int, float)):
                value_type = '数字(number)'
            else:
                value_type = type(current).__name__
            return f'路径【{current_path}】的值类型为【{value_type}】，无法继续读取【{token}】'

        return '响应中没有符合该表达式的数据，请检查响应内容和表达式'

    @classmethod
    @data_method('json', 'JSON处理', '将json字符串转换成Python对象')
    def load(cls, json_str) -> dict | list:
        """将json字符串转换成Python对象"""
        try:
            return json.loads(json_str)
        except (TypeError, json.decoder.JSONDecodeError) as error:
            raise MangoToolsError(*ERROR_MSG_0004) from error

    @classmethod
    @data_method('json', 'JSON处理', '将Python对象转换成json字符串')
    def dump(cls, obj, indent=None) -> str:
        """将Python对象转换成json字符串"""
        try:
            return json.dumps(obj, indent=indent)
        except (TypeError, ValueError) as error:
            raise MangoToolsError(*ERROR_MSG_0004) from error

    @classmethod
    @data_method('json', 'JSON处理', '将json数组字符串转换成Python列表')
    def loads(cls, json_list_str: str) -> list | dict:
        """将json数组字符串转换成Python列表"""
        try:
            return json.loads(json_list_str)
        except (TypeError, json.decoder.JSONDecodeError):
            data_str = str(json_list_str).replace("'", '"')
            try:
                return json.loads(data_str)
            except json.decoder.JSONDecodeError as error:
                raise MangoToolsError(*ERROR_MSG_0004) from error

    @classmethod
    @data_method('json', 'JSON处理', '将Python列表转换成json数组字符串')
    def dumps(cls, obj_list: list | dict, indent=None) -> str:
        """将Python列表转换成json数组字符串"""
        try:
            return json.dumps(obj_list, indent=indent)
        except (TypeError, ValueError) as error:
            raise MangoToolsError(*ERROR_MSG_0004) from error

    @classmethod
    @data_method('json', 'JSON处理', '将嵌套的json对象展开成扁平的字典')
    def flatten(cls, json_obj, sep='_', prefix=''):
        """将嵌套的json对象展开成扁平的字典"""
        if not isinstance(json_obj, dict):
            raise MangoToolsError(*ERROR_MSG_0004)
        result = {}
        for key, value in json_obj.items():
            new_key = prefix + key
            if isinstance(value, dict):
                result.update(cls.flatten(value, sep, new_key + sep))
            else:
                result[new_key] = value
        return result

    @classmethod
    @data_method('json', 'JSON处理', '在dict中根绝jsonpath取出值')
    def get_json_path_value(cls, obj: dict, expr, index=0):
        """在dict中根绝jsonpath取出值"""
        cls._validate_json_path_expression(expr)
        try:
            res = jsonpath.jsonpath(obj, expr)
            if res is False:
                reason = cls._describe_json_path_miss(obj, expr)
                raise MangoToolsError(*ERROR_MSG_0003, value=(expr, reason))
            if len(res) == 1:
                return res[0]
            elif len(res) > 1 and index == 0:
                return res
            else:
                return res[index]
        except MangoToolsError:
            raise
        except Exception as error:
            raise MangoToolsError(*ERROR_MSG_0005, value=(expr, str(error))) from error
