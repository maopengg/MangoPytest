# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-03-07 8:24
# @Author : 毛鹏
import json
import re

from ..data_processor._cache_tool import CacheTool
from ..data_processor._coding_tool import CodingTool
from ..data_processor._crypto_tool import CryptoTool
from ..data_processor._encryption_tool import EncryptionTool
from ..data_processor._json_tool import JsonTool
from ..data_processor._random_character_info_data import RandomCharacterInfoData
from ..data_processor._random_number_data import RandomNumberData
from ..data_processor._random_string_data import RandomStringData
from ..data_processor._random_time_data import RandomTimeData
from ..data_processor._sql_cache import SqlCache
from ..exceptions import MangoToolsError
from ..exceptions.error_msg import ERROR_MSG_0047, ERROR_MSG_0002, ERROR_MSG_0022, ERROR_MSG_0023
from ..mangos import Mango

"""
ObtainRandomData类的函数注释必须是： “”“中间写值”“”
"""


def _find_balanced_expression(data: str):
    """查找包含 JSON/数组参数的表达式，返回完整文本及其位置。"""
    start = data.find('${{')
    while start >= 0:
        depth = 0
        quote = None
        escaped = False
        index = start + 3
        while index < len(data) - 1:
            character = data[index]
            if escaped:
                escaped = False
            elif character == '\\' and quote:
                escaped = True
            elif quote:
                if character == quote:
                    quote = None
            elif character in {'\'', '"'}:
                quote = character
            elif character in '([{':
                depth += 1
            elif character in ')]}':
                if character == '}' and depth == 0 and data[index:index + 2] == '}}':
                    return data[start:index + 2], start, index + 2
                depth -= 1
                if depth < 0:
                    break
            index += 1
        start = data.find('${{', start + 3)
    return None


@staticmethod
def replace_str(self, data, m_0002, mango_tools_error):
    while self.is_extract(str(data)):
        # 优先匹配最内层的表达式（非贪婪模式）
        innermost_match = re.search(r'\$\{\{([^{}]*)\}\}', str(data))
        if innermost_match:
            full_match = innermost_match.group(0)
            start, end = innermost_match.span()
        else:
            balanced_match = _find_balanced_expression(str(data))
            if not balanced_match:
                break
            full_match, start, end = balanced_match
        key_text = self.remove_parentheses(full_match)
        args = key_text.split("|")
        key_text, key = (args[0], args[1]) if len(args) == 2 else (args[0], None)

        if self.is_extract(key_text):
            value = replace_str(self, f"${{{{{key_text}}}}}", m_0002, mango_tools_error)
        else:
            if self.identify_parentheses(key_text):
                value = self.regular(key_text)
            else:
                if not self.has_cache(key_text):
                    raise mango_tools_error(*m_0002, value=(key_text,))
                value = self.get_cache(key_text)

        if key:
            self.set_cache(key, value)

        if data == full_match:
            return '' if value is None else value

        replacement = '' if value is None else str(value)
        if (
                isinstance(data, str)
                and start > 0
                and end < len(data)
                and data[start - 1] == '"'
                and data[end] == '"'
        ):
            replacement = json.dumps(value, ensure_ascii=False)
            data = data[:start - 1] + replacement + data[end + 1:]
        else:
            data = data[:start] + replacement + data[end:]

    return data.strip() if isinstance(data, str) else data


class ObtainRandomData(RandomNumberData, RandomCharacterInfoData, RandomTimeData, RandomStringData):
    """ 获取随机数据 """

    def regular(self, func: str):
        try:
            return Mango.regular(self, func, MangoToolsError, ERROR_MSG_0022, ERROR_MSG_0023)
        except MangoToolsError:
            raise
        except AttributeError as e:
            raise MangoToolsError(*ERROR_MSG_0047, value=(func, e))
        except Exception as e:
            raise MangoToolsError(*ERROR_MSG_0047, value=(func, e)) from e


class DataClean(JsonTool, CacheTool, EncryptionTool, CodingTool, CryptoTool):
    """存储或处理随机数据"""
    pass


class DataProcessor(DataClean, ObtainRandomData):

    def __init__(self):
        ObtainRandomData.__init__(self)
        DataClean.__init__(self)



    def replace(self, data: list | dict | str | None) -> list | dict | str | None:
        if not data:
            return data
        if isinstance(data, list):
            return [self.replace(item) for item in data]
        elif isinstance(data, dict):
            return {self.replace(key): self.replace(value) for key, value in data.items()}
        else:
            return replace_str(self, data, ERROR_MSG_0002, MangoToolsError)

    @classmethod
    def remove_parentheses(cls, data: str) -> str:
        value = str(data)
        if value.startswith('${{') and value.endswith('}}'):
            return value[3:-2].strip()
        return value.strip()

    @classmethod
    def identify_parentheses(cls, value: str):
        return re.search(r'\((.*?)\)', str(value))

    @classmethod
    def is_extract(cls, string: str) -> bool:
        value = str(string)
        return bool(re.search(r'\$\{\{(?:[^{}]|\{[^{}]*\})*\}\}', value) or _find_balanced_expression(value))


__all__ = [
    'CacheTool',
    'CodingTool',
    'CryptoTool',
    'EncryptionTool',
    'JsonTool',
    'RandomCharacterInfoData',
    'RandomNumberData',
    'RandomStringData',
    'RandomTimeData',
    'ObtainRandomData',
    'DataClean',
    'DataProcessor',
    'SqlCache'
]

if __name__ == '__main__':
    processor = DataProcessor()
    print(processor.is_extract('我是基于时间戳的5位随机数：${{number_time_5()|flow名称}}'))
