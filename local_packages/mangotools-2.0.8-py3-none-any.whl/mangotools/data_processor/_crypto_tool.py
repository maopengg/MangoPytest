import base64
import hashlib
import hmac
import json
import os

from cryptography.exceptions import InvalidSignature, InvalidTag, UnsupportedAlgorithm
from cryptography.hazmat.primitives import hashes, padding as symmetric_padding, serialization
from cryptography.hazmat.primitives.asymmetric import padding as asymmetric_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from mangotools.decorator import data_method
from mangotools.exceptions import MangoToolsError
from mangotools.exceptions.error_msg import ERROR_MSG_0029, ERROR_MSG_0030, ERROR_MSG_0031, ERROR_MSG_0032


class CryptoTool:
    """接口自动化常用的令牌、对称加密、非对称加密和签名工具。"""

    @staticmethod
    def _material(value, name: str) -> bytes:
        text = str(value)
        try:
            if text.startswith('hex:'):
                return bytes.fromhex(text[4:])
            if text.startswith('base64:'):
                return base64.b64decode(text[7:], validate=True)
            return text.encode('utf-8')
        except (UnicodeError, ValueError, TypeError) as error:
            raise ValueError(f'{name}格式错误：{error}') from error

    @classmethod
    def _aes_key(cls, value) -> bytes:
        key = cls._material(value, 'AES密钥')
        if len(key) not in {16, 24, 32}:
            raise ValueError('AES密钥必须是16、24或32字节，可使用hex:或base64:前缀')
        return key

    @classmethod
    def _aes_iv(cls, value) -> bytes:
        iv = cls._material(value, 'AES IV')
        if len(iv) != 16:
            raise ValueError('AES CBC的IV必须是16字节，可使用hex:或base64:前缀')
        return iv

    @staticmethod
    def _pkcs7_pad(data: bytes) -> bytes:
        padder = symmetric_padding.PKCS7(128).padder()
        return padder.update(data) + padder.finalize()

    @staticmethod
    def _pkcs7_unpad(data: bytes) -> bytes:
        unpadder = symmetric_padding.PKCS7(128).unpadder()
        return unpadder.update(data) + unpadder.finalize()

    @staticmethod
    def _pem_bytes(value) -> bytes:
        return str(value).replace('\\n', '\n').strip().encode('utf-8')

    @classmethod
    def _load_public_key(cls, value):
        key_data = cls._pem_bytes(value)
        try:
            if b'-----BEGIN' in key_data:
                key = serialization.load_pem_public_key(key_data)
            else:
                key = serialization.load_der_public_key(base64.b64decode(key_data, validate=True))
            if not hasattr(key, 'encrypt') or not hasattr(key, 'verify'):
                raise ValueError('提供的不是RSA公钥')
            return key
        except (UnsupportedAlgorithm, ValueError, TypeError) as error:
            raise ValueError(f'RSA公钥格式错误：{error}') from error

    @classmethod
    def _load_private_key(cls, value, password=''):
        key_data = cls._pem_bytes(value)
        password_bytes = str(password).encode('utf-8') if password else None
        try:
            if b'-----BEGIN' in key_data:
                key = serialization.load_pem_private_key(key_data, password=password_bytes)
            else:
                key = serialization.load_der_private_key(
                    base64.b64decode(key_data, validate=True),
                    password=password_bytes,
                )
            if not hasattr(key, 'decrypt') or not hasattr(key, 'sign'):
                raise ValueError('提供的不是RSA私钥')
            return key
        except (UnsupportedAlgorithm, ValueError, TypeError) as error:
            raise ValueError(f'RSA私钥格式或密码错误：{error}') from error

    @staticmethod
    def _b64url_encode(value: bytes) -> str:
        return base64.urlsafe_b64encode(value).decode('ascii').rstrip('=')

    @staticmethod
    def _b64url_decode(value: str) -> bytes:
        encoded = str(value)
        return base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4))

    @staticmethod
    def _jwt_payload(payload_json) -> dict:
        value = json.loads(str(payload_json))
        if not isinstance(value, dict):
            raise ValueError('JWT载荷必须是JSON对象')
        return value

    @classmethod
    def _jwt_parts(cls, payload: dict, algorithm: str) -> tuple[str, str]:
        header = cls._b64url_encode(
            json.dumps({'alg': algorithm, 'typ': 'JWT'}, separators=(',', ':'), sort_keys=True).encode()
        )
        body = cls._b64url_encode(
            json.dumps(payload, ensure_ascii=False, separators=(',', ':'), sort_keys=True).encode()
        )
        return header, body

    @classmethod
    @data_method('security', '令牌与JWT', 'JWT HS256生成')
    def jwt_hs256_encode(cls, payload_json, secret) -> str:
        try:
            header, body = cls._jwt_parts(cls._jwt_payload(payload_json), 'HS256')
            signature = hmac.new(str(secret).encode(), f'{header}.{body}'.encode(), hashlib.sha256).digest()
            return f'{header}.{body}.{cls._b64url_encode(signature)}'
        except (json.JSONDecodeError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0031, value=('JWT HS256', str(error))) from error

    @classmethod
    @data_method('security', '令牌与JWT', 'JWT HS256验签并解码')
    def jwt_hs256_decode(cls, token, secret) -> str:
        try:
            header, body, signature = str(token).split('.')
            expected = hmac.new(str(secret).encode(), f'{header}.{body}'.encode(), hashlib.sha256).digest()
            if not hmac.compare_digest(expected, cls._b64url_decode(signature)):
                raise ValueError('JWT签名不匹配')
            return json.dumps(json.loads(cls._b64url_decode(body)), ensure_ascii=False, separators=(',', ':'))
        except (json.JSONDecodeError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0032, value=('JWT HS256', str(error))) from error

    @classmethod
    @data_method('security', '加密与解密', 'AES-CBC加密（PKCS7，输出Base64）')
    def aes_cbc_encrypt(cls, data, key, iv) -> str:
        try:
            encryptor = Cipher(algorithms.AES(cls._aes_key(key)), modes.CBC(cls._aes_iv(iv))).encryptor()
            encrypted = encryptor.update(cls._pkcs7_pad(str(data).encode())) + encryptor.finalize()
            return base64.b64encode(encrypted).decode('ascii')
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0029, value=('AES-CBC', str(error))) from error

    @classmethod
    @data_method('security', '加密与解密', 'AES-CBC解密（PKCS7，输入Base64）')
    def aes_cbc_decrypt(cls, data, key, iv) -> str:
        try:
            decryptor = Cipher(algorithms.AES(cls._aes_key(key)), modes.CBC(cls._aes_iv(iv))).decryptor()
            decrypted = decryptor.update(base64.b64decode(str(data), validate=True)) + decryptor.finalize()
            return cls._pkcs7_unpad(decrypted).decode()
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0030, value=('AES-CBC', str(error))) from error

    @classmethod
    @data_method('security', '加密与解密', 'AES-GCM认证加密（推荐）')
    def aes_gcm_encrypt(cls, data, key, associated_data='') -> str:
        try:
            nonce = os.urandom(12)
            aad = str(associated_data).encode() if associated_data else None
            encrypted = AESGCM(cls._aes_key(key)).encrypt(nonce, str(data).encode(), aad)
            return base64.b64encode(nonce + encrypted).decode('ascii')
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0029, value=('AES-GCM', str(error))) from error

    @classmethod
    @data_method('security', '加密与解密', 'AES-GCM认证解密（推荐）')
    def aes_gcm_decrypt(cls, data, key, associated_data='') -> str:
        try:
            combined = base64.b64decode(str(data), validate=True)
            if len(combined) < 29:
                raise ValueError('AES-GCM密文长度不足')
            aad = str(associated_data).encode() if associated_data else None
            return AESGCM(cls._aes_key(key)).decrypt(combined[:12], combined[12:], aad).decode()
        except (InvalidTag, UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0030, value=('AES-GCM', str(error) or '认证标签不匹配')) from error

    @classmethod
    @data_method('security', '非对称加密', 'RSA-OAEP SHA256公钥加密（推荐）')
    def rsa_oaep_encrypt(cls, data, public_key) -> str:
        try:
            encrypted = cls._load_public_key(public_key).encrypt(
                str(data).encode(),
                asymmetric_padding.OAEP(
                    mgf=asymmetric_padding.MGF1(hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None,
                ),
            )
            return base64.b64encode(encrypted).decode('ascii')
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0029, value=('RSA-OAEP', str(error))) from error

    @classmethod
    @data_method('security', '非对称加密', 'RSA-OAEP SHA256私钥解密（推荐）')
    def rsa_oaep_decrypt(cls, data, private_key, password='') -> str:
        try:
            decrypted = cls._load_private_key(private_key, password).decrypt(
                base64.b64decode(str(data), validate=True),
                asymmetric_padding.OAEP(
                    mgf=asymmetric_padding.MGF1(hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None,
                ),
            )
            return decrypted.decode()
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0030, value=('RSA-OAEP', str(error))) from error

    @classmethod
    @data_method('security', '签名与验签', 'RSA-PSS SHA256签名（推荐）')
    def rsa_pss_sign(cls, data, private_key, password='') -> str:
        try:
            signature = cls._load_private_key(private_key, password).sign(
                str(data).encode(),
                asymmetric_padding.PSS(
                    mgf=asymmetric_padding.MGF1(hashes.SHA256()),
                    salt_length=asymmetric_padding.PSS.DIGEST_LENGTH,
                ),
                hashes.SHA256(),
            )
            return base64.b64encode(signature).decode('ascii')
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0031, value=('RSA-PSS', str(error))) from error

    @classmethod
    @data_method('security', '签名与验签', 'RSA-PSS SHA256验签（推荐）')
    def rsa_pss_verify(cls, data, signature, public_key) -> bool:
        try:
            cls._load_public_key(public_key).verify(
                base64.b64decode(str(signature), validate=True),
                str(data).encode(),
                asymmetric_padding.PSS(
                    mgf=asymmetric_padding.MGF1(hashes.SHA256()),
                    salt_length=asymmetric_padding.PSS.DIGEST_LENGTH,
                ),
                hashes.SHA256(),
            )
            return True
        except InvalidSignature as error:
            raise MangoToolsError(*ERROR_MSG_0032, value=('RSA-PSS', '签名不匹配')) from error
        except (UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0032, value=('RSA-PSS', str(error))) from error

    @classmethod
    @data_method('security', '令牌与JWT', 'JWT RS256生成')
    def jwt_rs256_encode(cls, payload_json, private_key, password='') -> str:
        try:
            payload = cls._jwt_payload(payload_json)
            header, body = cls._jwt_parts(payload, 'RS256')
            signing_input = f'{header}.{body}'
            signature = cls._load_private_key(private_key, password).sign(
                signing_input.encode(), asymmetric_padding.PKCS1v15(), hashes.SHA256()
            )
            return f'{signing_input}.{cls._b64url_encode(signature)}'
        except (json.JSONDecodeError, UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0031, value=('JWT RS256', str(error))) from error

    @classmethod
    @data_method('security', '令牌与JWT', 'JWT RS256验签并解码')
    def jwt_rs256_decode(cls, token, public_key) -> str:
        try:
            header, body, signature = str(token).split('.')
            cls._load_public_key(public_key).verify(
                cls._b64url_decode(signature),
                f'{header}.{body}'.encode(),
                asymmetric_padding.PKCS1v15(),
                hashes.SHA256(),
            )
            return json.dumps(json.loads(cls._b64url_decode(body)), ensure_ascii=False, separators=(',', ':'))
        except InvalidSignature as error:
            raise MangoToolsError(*ERROR_MSG_0032, value=('JWT RS256', '签名不匹配')) from error
        except (json.JSONDecodeError, UnsupportedAlgorithm, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0032, value=('JWT RS256', str(error))) from error
