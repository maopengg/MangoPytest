import ast
import re

from ..exceptions import MangoToolsError
from ..exceptions.error_msg import ERROR_MSG_0005


def validate_jsonpath(expression):
    """校验现有引擎支持的路径结构；不依赖响应中是否恰好有匹配数据。"""
    def invalid(reason):
        raise MangoToolsError(*ERROR_MSG_0005, value=(expression, reason))

    if not isinstance(expression, str) or not expression.strip():
        invalid('表达式必须是非空字符串，例如 $.data.id')
    path = expression.strip()
    if not path.startswith('$'):
        invalid('表达式必须以根节点 $ 开头，例如 $.data.id')

    def validate_calculation(value):
        # 只做语法解析，不执行用户的筛选或下标计算表达式。
        pieces = re.split(r'''('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")''', value)
        for i in range(0, len(pieces), 2):
            pieces[i] = re.sub(r'(?<!\\)@', '__node', pieces[i])
            pieces[i] = pieces[i].replace('&&', ' and ').replace('||', ' or ')
            pieces[i] = re.sub(r'!(?!=)', ' not ', pieces[i])
        try:
            ast.parse(''.join(pieces).strip(), mode='eval')
        except (SyntaxError, ValueError, RecursionError):
            invalid('筛选或下标计算语法错误，请检查比较符、括号和操作数')

    def validate_selector(value):
        if not value:
            invalid('方括号内不能为空，请填写字段名、数组下标或 *')
        if value.startswith('?(') and value.endswith(')'):
            validate_calculation(value[2:-1])
            return
        if value.startswith('(') and value.endswith(')'):
            validate_calculation(value[1:-1])
            return
        selectors = re.split(r''',(?=(?:[^'"]|'[^']*'|"[^"]*")*$)''', value)
        for selector in selectors:
            selector = selector.strip()
            if not selector:
                invalid('字段或下标列表中存在空项，请检查逗号')
            if selector[0] in "'\"":
                try:
                    quoted = ast.literal_eval(selector)
                except (SyntaxError, ValueError):
                    invalid('字段名引号或转义不正确，例如 $[\'data\']')
                if not isinstance(quoted, str):
                    invalid('方括号中的字段名必须是字符串')
            elif selector == '*' or re.fullmatch(r'-?\d+', selector):
                continue
            elif re.fullmatch(r'-?\d*:-?\d*(?::-?\d*)?', selector):
                parts = selector.split(':')
                if len(parts) == 3 and parts[2] and int(parts[2]) == 0:
                    invalid('数组切片的步长不能为 0')
            elif not re.fullmatch(r'[\w$-]+', selector):
                invalid('方括号中的字段、下标或切片不合法，例如 [0]、[0:3]、[\'name\']')

    index = 1
    while index < len(path):
        if path[index] == '.':
            index += 1
            if index < len(path) and path[index] == '.':
                index += 1
            if index == len(path) or path[index] == '.':
                invalid('点号后缺少字段名或 *，表达式不能以 . 或 .. 结尾')
            if path[index] != '[':
                match = re.match(r'\*|[\w$-]+', path[index:])
                if not match:
                    invalid(f'第 {index + 1} 个字符处缺少字段名；特殊字段名请使用方括号和引号')
                index += len(match.group())
                continue
        if path[index] != '[':
            invalid(f'第 {index + 1} 个字符处应使用 . 或 [ 连接下一段路径')
        start = index
        stack = ['[']
        quote = None
        escaped = False
        index += 1
        while index < len(path) and stack:
            char = path[index]
            if quote:
                if escaped:
                    escaped = False
                elif char == '\\':
                    escaped = True
                elif char == quote:
                    quote = None
            elif char in "'\"":
                quote = char
            elif char in '[(':
                stack.append(char)
            elif char in '])':
                expected = '[' if char == ']' else '('
                if stack[-1] != expected:
                    invalid('括号不配对，请检查 ] 和 ) 的位置')
                stack.pop()
            index += 1
        if quote:
            invalid('字段名或筛选条件的引号未闭合')
        if stack:
            invalid('方括号不完整或圆括号未闭合，请检查 ] 和 )')
        validate_selector(path[start + 1:index - 1].strip())
    return path
