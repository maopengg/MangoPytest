# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-08-29 10:23
# @Author : 毛鹏

from cachetools import LRUCache

from mangotools.decorator import data_method


class CacheTool:
    """ 内存缓存 """

    def __init__(self):
        self._cache: LRUCache = LRUCache(maxsize=10_000)

    @data_method('cache', '内存缓存', '得到缓存key的value')
    def get_cache(self, key: str) -> any:
        """得到缓存key的value"""
        return self._cache.get(key)

    @data_method('cache', '内存缓存', '设置一个内容到缓存')
    def set_cache(self, key: str, value: any) -> None:
        """设置一个内容到缓存"""
        self._cache[key] = value

    @data_method('cache', '内存缓存', '删除一个缓存')
    def delete_cache(self, key: str) -> None:
        """删除一个缓存"""
        if key in self._cache:
            del self._cache[key]

    @data_method('cache', '内存缓存', '清理所有缓存')
    def clear_cache(self) -> None:
        """清理所有缓存"""
        self._cache.clear()

    @data_method('cache', '内存缓存', '判断缓存是否存在')
    def has_cache(self, key: str) -> bool:
        """判断缓存是否存在"""
        return key in self._cache

    @data_method('cache', '内存缓存', '获取全部的缓存数据')
    def get_all(self, ) -> dict:
        """获取全部的缓存数据"""
        return {k: v for k, v in self._cache.items()}

    @data_method('cache', '内存缓存', '根据sql进行缓存数据')
    def set_sql_cache(self, key: str, value: dict) -> None:
        """根据sql进行缓存数据"""
        if key is None or key == '':
            return
        cache_keys = [part.strip() for part in key.split(',') if part.strip()]
        column_values = list(value.values())
        if len(cache_keys) == 1:
            self.set_cache(cache_keys[0], column_values[0] if column_values else None)
            return
        for index, cache_key in enumerate(cache_keys):
            cache_value = value.get(cache_key) if cache_key in value else (
                column_values[index] if index < len(column_values) else None
            )
            self.set_cache(cache_key, cache_value)

    @data_method('cache', '内存缓存', '设置list缓存')
    def set_list_cache(self, key: list, value: list) -> None:
        """设置list缓存"""
        if key is None or key == '':
            return
        for k, v in zip(key, value):
            self.set_cache(k, v)

    @data_method('cache', '内存缓存', '设置dict缓存')
    def set_dict_cache(self, data: dict) -> None:
        """设置dict缓存"""
        for k, v in data.items():
            self.set_cache(k, v)
