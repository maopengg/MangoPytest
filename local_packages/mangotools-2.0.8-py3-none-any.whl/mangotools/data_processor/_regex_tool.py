import re

from ..exceptions import MangoToolsError
from ..exceptions.error_msg import REGEX_EXPRESSION_INVALID, REGEX_SOURCE_INVALID


class RegexTool:
    @staticmethod
    def compile(expression):
        if not isinstance(expression, str) or not expression:
            raise MangoToolsError(*REGEX_EXPRESSION_INVALID,
                                  value=(expression, '表达式必须是非空字符串，例如 id=(\\d+)'))
        try:
            return re.compile(expression)
        except (OverflowError, RecursionError) as error:
            raise MangoToolsError(*REGEX_EXPRESSION_INVALID,
                                  value=(expression, '重复次数或分组嵌套过大，请简化表达式')) from error
        except re.error as error:
            reason = '语法不正确，请检查括号、转义字符和量词'
            descriptions = (
                ('unterminated character set', '字符集合未闭合，请补齐右方括号 ]'),
                ('unterminated subpattern', '分组未闭合，请补齐右圆括号 )'),
                ('unbalanced parenthesis', '右圆括号 ) 多余或位置不正确'),
                ('nothing to repeat', '量词前缺少要重复的内容'),
                ('multiple repeat', '量词重复，请检查 *、+、? 的组合'),
                ('bad escape', '转义字符无效，请检查反斜杠后的字符'),
                ('bad character range', '字符范围无效，请检查方括号中的 -'),
                ('invalid group reference', '引用了不存在的捕获组'),
                ('look-behind requires fixed-width', '后向断言必须使用固定长度，不能使用可变长度的 + 或 *'),
                ('unknown extension', '分组语法不支持，请检查 (?...) 的写法'),
            )
            for fragment, description in descriptions:
                if fragment in error.msg:
                    reason = description
                    break
            if error.pos is not None:
                reason = f'第 {error.pos + 1} 个字符附近：{reason}'
            raise MangoToolsError(*REGEX_EXPRESSION_INVALID, value=(expression, reason)) from error

    @classmethod
    def search(cls, source, expression):
        pattern = cls.compile(expression)
        if not isinstance(source, str):
            raise MangoToolsError(*REGEX_SOURCE_INVALID)
        return pattern.search(source)

    @staticmethod
    def extracted_value(match):
        if match is None:
            return None
        groups = match.groups()
        if not groups:
            return match.group(0)
        return groups[0] if len(groups) == 1 else list(groups)
