# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2023-11-03 10:48
# @Author : 毛鹏

from faker import Faker
from mangotools.decorator import data_method


class RandomCharacterInfoData:
    """ 随机的人物信息测试数据 """
    faker = Faker(locale='zh_CN')

    @classmethod
    @data_method('data', '人物信息测试数据', '随机生成手机号码')
    def character_phone(cls) -> str:
        """随机生成手机号码"""
        return cls.faker.phone_number()

    @classmethod
    @data_method('data', '人物信息测试数据', '随机生成身份证号码')
    def character_id_number(cls) -> str:
        """随机生成身份证号码"""
        return cls.faker.ssn()

    @classmethod
    @data_method('data', '人物信息测试数据', '女生姓名')
    def character_female_name(cls) -> str:
        """女生姓名"""
        return cls.faker.name_female()

    @classmethod
    @data_method('data', '人物信息测试数据', '男生姓名')
    def character_male_name(cls) -> str:
        """男生姓名"""
        return cls.faker.name_male()

    @classmethod
    @data_method('data', '人物信息测试数据', '获取简单的人物信息')
    def character_simple_profile(cls):
        """获取简单的人物信息"""
        res = cls.faker.simple_profile()
        return str(res)

    @classmethod
    @data_method('data', '人物信息测试数据', '获取带公司的人物信息')
    def character_profile(cls):
        """获取带公司的人物信息"""
        res = cls.faker.profile()
        return str(res)

    @classmethod
    @data_method('data', '人物信息测试数据', '生成邮箱')
    def character_email(cls) -> str:
        """生成邮箱"""
        return cls.faker.email()

    @classmethod
    @data_method('data', '人物信息测试数据', '银行卡')
    def character_bank_card(cls):
        """银行卡"""
        return cls.faker.credit_card_number()

    @classmethod
    @data_method('data', '人物信息测试数据', '带邮政编码的地址')
    def character_address(cls):
        """带邮政编码的地址"""
        return cls.faker.address()

    @classmethod
    @data_method('data', '人物信息测试数据', '获取职称')
    def character_job(cls):
        """获取职称"""
        return cls.faker.job()

    @classmethod
    @data_method('data', '人物信息测试数据', '获取公司名称')
    def character_company(cls):
        """获取公司名称"""
        return cls.faker.company()

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机公司职位')
    def str_company_job(cls):
        """生成随机公司职位"""
        return cls.faker.job()

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机职业')
    def str_job(cls):
        """生成随机职业"""
        return cls.faker.job()

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机大学名')
    def str_university(cls):
        """生成随机大学名"""
        return cls.faker.university()

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机国际电话号码字符串')
    def str_intl_phone(cls):
        """生成随机国际电话号码字符串"""
        return cls.faker.phone_number().replace('-', ' ')

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机车牌号')
    def str_license_plate(cls):
        """生成随机车牌号"""
        return cls.faker.license_plate()

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机邮政编码')
    def str_postcode(cls):
        """生成随机邮政编码"""
        return cls.faker.postcode()

    @classmethod
    @data_method('data', '人物信息测试数据', '生成随机公司邮箱')
    def str_company_email(cls):
        """生成随机公司邮箱"""
        return cls.faker.company_email()

