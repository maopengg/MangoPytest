# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-08-30 14:14
# @Author : 毛鹏
import base64
import gzip
import html
import json
import zlib
from urllib.parse import parse_qs, quote, unquote, urlencode

from mangotools.decorator import data_method
from mangotools.exceptions import MangoToolsError
from mangotools.exceptions.error_msg import ERROR_MSG_0004, ERROR_MSG_0025, ERROR_MSG_0026


class CodingTool:
    """编码"""

    @classmethod
    @data_method('security', '编码与解码', 'Base64 JSON编码')
    def base64_encode(cls, data: str) -> str:
        """先将数据转换为JSON字符串，再进行Base64编码。"""
        try:
            return base64.b64encode(json.dumps(data).encode('utf-8')).decode('utf-8')
        except (TypeError, ValueError) as error:
            raise MangoToolsError(*ERROR_MSG_0004) from error

    @classmethod
    @data_method('security', '编码与解码', '响应Unicode转义解码')
    def response_decoding(cls, data) -> str:
        """对响应文本进行Unicode转义解码。"""
        return cls.unicode_escape_decode(data)

    @classmethod
    @data_method('security', '编码与解码', 'Base64文本编码')
    def base64_text_encode(cls, data: str, charset: str = 'utf-8') -> str:
        """按指定字符集对普通文本进行Base64编码。"""
        try:
            return base64.b64encode(str(data).encode(charset)).decode('ascii')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('Base64', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Base64文本解码')
    def base64_decode(cls, data: str, charset: str = 'utf-8') -> str:
        """将标准Base64文本按指定字符集解码。"""
        try:
            decoded = base64.b64decode(str(data), validate=True)
            return decoded.decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('Base64', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'URL安全Base64编码')
    def base64_urlsafe_encode(cls, data: str, charset: str = 'utf-8') -> str:
        """生成去除等号补位的URL安全Base64文本。"""
        try:
            return base64.urlsafe_b64encode(str(data).encode(charset)).decode('ascii').rstrip('=')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('URL安全Base64', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'URL安全Base64解码')
    def base64_urlsafe_decode(cls, data: str, charset: str = 'utf-8') -> str:
        """支持有补位和无补位的URL安全Base64文本。"""
        try:
            encoded = str(data)
            encoded += '=' * (-len(encoded) % 4)
            decoded = base64.b64decode(encoded, altchars=b'-_', validate=True)
            return decoded.decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('URL安全Base64', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'URL编码')
    def url_encode(cls, data: str, charset: str = 'utf-8') -> str:
        """对完整文本进行URL百分号编码。"""
        try:
            return quote(str(data), safe='', encoding=charset, errors='strict')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('URL', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'URL解码')
    def url_decode(cls, data: str, charset: str = 'utf-8') -> str:
        """对URL百分号编码文本进行解码。"""
        try:
            return unquote(str(data), encoding=charset, errors='strict')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('URL', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', '十六进制编码')
    def hex_encode(cls, data: str, charset: str = 'utf-8') -> str:
        """将文本编码为小写十六进制字符串。"""
        try:
            return str(data).encode(charset).hex()
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('十六进制', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', '十六进制解码')
    def hex_decode(cls, data: str, charset: str = 'utf-8') -> str:
        """将十六进制字符串解码为文本。"""
        try:
            return bytes.fromhex(str(data)).decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('十六进制', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Unicode转义编码')
    def unicode_escape_encode(cls, data: str) -> str:
        """将非ASCII字符编码为Unicode转义文本。"""
        try:
            return str(data).encode('unicode_escape').decode('ascii')
        except (UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('Unicode转义', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Unicode转义解码')
    def unicode_escape_decode(cls, data: str) -> str:
        """将Unicode转义文本解码为普通文本。"""
        try:
            return str(data).encode('latin-1').decode('unicode_escape')
        except (UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('Unicode转义', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Base32编码')
    def base32_encode(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return base64.b32encode(str(data).encode(charset)).decode('ascii')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('Base32', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Base32解码')
    def base32_decode(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            encoded = str(data).upper()
            encoded += '=' * (-len(encoded) % 8)
            return base64.b32decode(encoded, casefold=True).decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('Base32', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Base85编码')
    def base85_encode(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return base64.b85encode(str(data).encode(charset)).decode('ascii')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('Base85', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'Base85解码')
    def base85_decode(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return base64.b85decode(str(data)).decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('Base85', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'HTML实体编码')
    def html_escape(cls, data: str) -> str:
        return html.escape(str(data), quote=True)

    @classmethod
    @data_method('security', '编码与解码', 'HTML实体解码')
    def html_unescape(cls, data: str) -> str:
        return html.unescape(str(data))

    @classmethod
    @data_method('security', '编码与解码', 'HTTP Basic Auth编码')
    def basic_auth_encode(cls, username, password, charset: str = 'utf-8') -> str:
        try:
            credentials = f'{username}:{password}'.encode(charset)
            return f'Basic {base64.b64encode(credentials).decode("ascii")}'
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('HTTP Basic Auth', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', 'HTTP Basic Auth解码')
    def basic_auth_decode(cls, data, charset: str = 'utf-8') -> str:
        try:
            value = str(data).strip()
            if value.lower().startswith('basic '):
                value = value[6:].strip()
            return base64.b64decode(value, validate=True).decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('HTTP Basic Auth', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', '表单URL编码')
    def form_urlencode(cls, data: str) -> str:
        """将JSON对象编码为application/x-www-form-urlencoded格式。"""
        try:
            value = json.loads(str(data))
            if not isinstance(value, dict):
                raise ValueError('输入内容必须是JSON对象')
            return urlencode(value, doseq=True)
        except (json.JSONDecodeError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('表单URL', str(error))) from error

    @classmethod
    @data_method('security', '编码与解码', '表单URL解码')
    def form_urldecode(cls, data: str) -> str:
        """将表单URL编码文本解码为JSON对象，重复参数保留为数组。"""
        try:
            value = parse_qs(str(data), keep_blank_values=True, strict_parsing=True)
            return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
        except (UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('表单URL', str(error))) from error

    @classmethod
    @data_method('security', '压缩与解压', 'Gzip压缩并输出Base64')
    def gzip_compress_base64(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return base64.b64encode(gzip.compress(str(data).encode(charset), mtime=0)).decode('ascii')
        except (LookupError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('Gzip+Base64', str(error))) from error

    @classmethod
    @data_method('security', '压缩与解压', 'Base64输入的Gzip解压')
    def gzip_decompress_base64(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return gzip.decompress(base64.b64decode(str(data), validate=True)).decode(charset)
        except (LookupError, OSError, UnicodeError, ValueError, TypeError) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('Gzip+Base64', str(error))) from error

    @classmethod
    @data_method('security', '压缩与解压', 'Zlib压缩并输出Base64')
    def zlib_compress_base64(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return base64.b64encode(zlib.compress(str(data).encode(charset))).decode('ascii')
        except (LookupError, UnicodeError, ValueError, TypeError, zlib.error) as error:
            raise MangoToolsError(*ERROR_MSG_0025, value=('Zlib+Base64', str(error))) from error

    @classmethod
    @data_method('security', '压缩与解压', 'Base64输入的Zlib解压')
    def zlib_decompress_base64(cls, data: str, charset: str = 'utf-8') -> str:
        try:
            return zlib.decompress(base64.b64decode(str(data), validate=True)).decode(charset)
        except (LookupError, UnicodeError, ValueError, TypeError, zlib.error) as error:
            raise MangoToolsError(*ERROR_MSG_0026, value=('Zlib+Base64', str(error))) from error
