K6_SCRIPT_SOURCE = r'''
import http from "k6/http";
import { check, sleep } from "k6";
import crypto from "k6/crypto";
import { Counter } from "k6/metrics";

const IR = JSON.parse(__ENV.MANGO_PERF_IR_JSON);
const SHARD_COUNT = Number(__ENV.MANGO_SHARD_COUNT || "1");
const SHARD_INDEX = Number(__ENV.MANGO_SHARD_INDEX || "0");
const RUN_ID = Number(__ENV.MANGO_PERF_RUN_ID || "0");
const CAPTURE_REQUEST = __ENV.MANGO_PERF_CAPTURE_REQUEST === "1";
const CAPTURE_RESPONSE = __ENV.MANGO_PERF_CAPTURE_RESPONSE === "1";
let runtimeVariables = JSON.parse(__ENV.MANGO_RUNTIME_VARIABLES || "{}");
const checkFailures = new Counter("mango_check_failures");
const perfFunctions = Object.fromEntries((IR.perf_functions || []).map((item) => [item.expression, item]));
let uniqueCounter = 0;

function globalVuIndex() {
  return SHARD_INDEX + ((__VU - 1) * SHARD_COUNT);
}

function randomCharacters(alphabet, length) {
  let result = "";
  for (let index = 0; index < length; index += 1) result += alphabet[Math.floor(Math.random() * alphabet.length)];
  return result;
}

function uuidV4() {
  const bytes = new Uint8Array(crypto.randomBytes(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function nextSnowflakeId() {
  const vu = globalVuIndex();
  uniqueCounter += 1;
  if (!Number.isInteger(RUN_ID) || RUN_ID < 1 || RUN_ID >= 8388608 || vu < 0 || vu >= 1048576 || uniqueCounter >= 1048576) {
    throw new Error("性能雪花式 ID 超出运行号、VU 数或单 VU 生成次数上限");
  }
  if (typeof BigInt !== "function") throw new Error("当前 k6 版本不支持雪花式 ID 所需的 BigInt");
  return ((BigInt(RUN_ID) << BigInt(40)) | (BigInt(vu) << BigInt(20)) | BigInt(uniqueCounter)).toString();
}

function evaluatePerfFunction(item, variables) {
  const args = item.args || {};
  let value;
  switch (item.name) {
    case "perf_uuid": value = uuidV4(); break;
    case "perf_uuid_hex":
    case "perf_trace_id": value = uuidV4().replace(/-/g, ""); break;
    case "perf_snowflake_id": value = nextSnowflakeId(); break;
    case "perf_timestamp_ms": value = String(Date.now()); break;
    case "perf_timestamp_s": value = String(Math.floor(Date.now() / 1000)); break;
    case "perf_random_string": value = randomCharacters("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", args.length); break;
    case "perf_random_digits": value = randomCharacters("0123456789", args.length); break;
    case "perf_random_hex": value = randomCharacters("0123456789abcdef", args.length); break;
    case "perf_random_lowercase": value = randomCharacters("abcdefghijklmnopqrstuvwxyz", args.length); break;
    case "perf_random_int": value = args.left + Math.floor(Math.random() * (args.right - args.left + 1)); break;
    case "perf_random_email": value = `perf-${uuidV4().replace(/-/g, "")}@example.com`; break;
    case "perf_unique_string": value = `${args.prefix}-${uuidV4().replace(/-/g, "")}`; break;
    default: throw new Error(`未适配的性能数据方法：${item.name}`);
  }
  if (item.cache_key) variables[item.cache_key] = value;
  return value;
}

function render(value, variables) {
  if (Array.isArray(value)) return value.map((item) => render(item, variables));
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, render(item, variables)]));
  if (typeof value !== "string") return value;
  const full = value.match(/^\$\{\{([^{}]+)\}\}$/) || value.match(/^\$\{([^{}]+)\}$/);
  if (full && perfFunctions[full[0]]) return evaluatePerfFunction(perfFunctions[full[0]], variables);
  if (full && Object.prototype.hasOwnProperty.call(variables, full[1])) return variables[full[1]];
  return value
    .replace(/\$\{\{([^{}]+)\}\}/g, (match, key) => perfFunctions[match] ? String(evaluatePerfFunction(perfFunctions[match], variables)) : Object.prototype.hasOwnProperty.call(variables, key) ? String(variables[key]) : match)
    .replace(/\$\{([^{}]+)\}/g, (match, key) => Object.prototype.hasOwnProperty.call(variables, key) ? String(variables[key]) : match);
}

function envMatches(item) {
  return !item.test_envs || !item.test_envs.length || item.test_envs.includes(IR.test_env);
}

function applyValues(variables, items) {
  for (const item of items || []) if (envMatches(item)) variables[item.key] = render(item.value, variables);
}

function stageTarget(stage) {
  const raw = IR.load_type === "concurrency" ? stage.target_users : stage.target_rate;
  // Rate is represented per minute so fractional per-second targets remain exact across shards.
  const total = IR.load_type === "concurrency" ? raw : Math.round(raw * 60);
  const base = Math.floor(total / SHARD_COUNT); const remainder = total % SHARD_COUNT;
  return base + (SHARD_INDEX < remainder ? 1 : 0);
}

const profile = IR.load_profile || "constant_concurrency";
const first = IR.stages[0];
const duration = IR.stages.reduce((total, stage) => total + stage.duration_seconds, 0);
const stages = IR.stages.flatMap((stage, index) => {
  const target = stageTarget(stage);
  if (stage.ramp_type !== "step") return [{ duration: `${stage.duration_seconds}s`, target }];
  if (index === 0 && profile === "spike") return [{ duration: `${stage.duration_seconds}s`, target }];
  if (stage.duration_seconds === 1) return [{ duration: "1s", target }];
  return [{ duration: "1s", target }, { duration: `${stage.duration_seconds - 1}s`, target }];
});
const shardIterations = IR.total_iterations ? Math.floor(IR.total_iterations / SHARD_COUNT) + (SHARD_INDEX < IR.total_iterations % SHARD_COUNT ? 1 : 0) : 0;
const shardVus = (total) => Math.floor(total / SHARD_COUNT) + (SHARD_INDEX < total % SHARD_COUNT ? 1 : 0);
let executorOptions;
if (profile === "fixed_iterations") {
  executorOptions = { executor: "shared-iterations", vus: stageTarget(first), iterations: shardIterations,
    maxDuration: `${duration}s`, gracefulStop: "0s" };
} else if (profile === "constant_concurrency" || profile === "soak") {
  executorOptions = { executor: "constant-vus", vus: stageTarget(first), duration: `${duration}s`, gracefulStop: "0s" };
} else if (IR.load_type === "concurrency") {
  executorOptions = { executor: "ramping-vus", startVUs: profile === "spike" ? shardVus(IR.stages[0].target_users) :
    profile === "linear_ramp" ? shardVus(IR.start_users || 0) : 0, stages, gracefulRampDown: "0s", gracefulStop: "0s" };
} else {
  executorOptions = { executor: "constant-arrival-rate", rate: stageTarget(first), timeUnit: "1m", duration: `${duration}s`,
    preAllocatedVUs: shardVus(first.preallocated_vus || 10), maxVUs: shardVus(first.max_vus || 100), gracefulStop: "0s" };
}
export const options = { scenarios: { mango: executorOptions } };

function requestConfig(step) {
  const root = step.request || {};
  let value = root;
  for (const key of ["runtime_snapshot", "http_config", "request", "config"]) {
    if (value[key] && typeof value[key] === "object") value = value[key];
  }
  const override = step.request_override || {};
  const methodMap = { 0: "GET", 1: "POST", 2: "PUT", 3: "DELETE", 4: "OPTIONS", 6: "PATCH" };
  const method = methodMap[value.method] || String(value.method || "GET").toUpperCase();
  let baseHeaders = value.headers || {};
  if (typeof baseHeaders === "string") { try { baseHeaders = JSON.parse(baseHeaders); } catch (_) { baseHeaders = {}; } }
  const headers = Object.assign({}, baseHeaders, override.headers || {});
  let baseParams = value.params || {};
  if (typeof baseParams === "string") {
    try { baseParams = JSON.parse(baseParams); } catch (_) { baseParams = Object.fromEntries(baseParams.split("&").filter(Boolean).map((item) => item.split("=").map(decodeURIComponent))); }
  }
  const params = Object.assign({}, baseParams, override.params || {});
  const bodyType = value.body_type || "none";
  let body = override.body !== undefined && override.body !== null ? override.body : (value.body_config || value.body);
  if ((override.body === undefined || override.body === null) && body && typeof body === "object") {
    if (bodyType === "json") body = body.source_type === "template" ? body.body_text : body.body;
    else if (bodyType === "form") body = Object.fromEntries((body.fields || []).filter((item) => item.key).map((item) => [item.key, item.value]));
    else if (bodyType === "raw") { headers["Content-Type"] ||= body.content_type || "application/json"; body = body.body_text || ""; }
  }
  let url = value.url || value.path || "/";
  const base = root.base_url || root.host || value.base_url || value.host || "";
  if (base && /^https?:\/\//.test(url)) {
    url = url.replace(/^https?:\/\/[^/]+/, "") || "/";
  }
  if (base && !/^https?:\/\//.test(url)) url = base.replace(/\/$/, "") + "/" + url.replace(/^\//, "");
  return { method, url, headers, params, body, bodyType, timeout: override.timeout_seconds || 60 };
}

function compare(actual, operator, expected) {
  const equal = (left, right) => (left && typeof left === "object") || (right && typeof right === "object") ? JSON.stringify(left) === JSON.stringify(right) : left === right;
  const contains = (left, right) => {
    if (Array.isArray(right)) {
      if (!Array.isArray(left) || left.length !== right.length) return false;
      const used = new Set();
      return right.every((expectedItem) => {
        const index = left.findIndex((actualItem, itemIndex) => !used.has(itemIndex) && contains(actualItem, expectedItem));
        if (index < 0) return false;
        used.add(index);
        return true;
      });
    }
    if (right && typeof right === "object") {
      if (!left || typeof left !== "object" || Array.isArray(left)) return false;
      return Object.entries(right).every(([key, value]) => Object.prototype.hasOwnProperty.call(left, key) && contains(left[key], value));
    }
    if (typeof left === "string") return left.includes(String(right));
    return equal(left, right);
  };
  if (operator === "eq") return equal(actual, expected);
  if (operator === "ne") return !equal(actual, expected);
  if (operator === "lt") return actual < expected;
  if (operator === "lte") return actual <= expected;
  if (operator === "gt") return actual > expected;
  if (operator === "gte") return actual >= expected;
  if (operator === "contains") return actual != null && contains(actual, expected);
  if (operator === "exists") return actual !== undefined && actual !== null;
  return operator === "not_exists" ? actual === undefined || actual === null : false;
}

function jsonPath(value, expression) {
  const path = String(expression || "").trim();
  if (!path || path === "$") return value;
  const tokens = [];
  const pattern = /(?:^|\.)([^.\[\]]+)|\[(?:(\d+)|["']([^"']+)["'])\]/g;
  let match;
  while ((match = pattern.exec(path.replace(/^\$/, ""))) !== null) {
    tokens.push(match[1] !== undefined ? match[1] : match[2] !== undefined ? Number(match[2]) : match[3]);
  }
  let current = value;
  for (const token of tokens) current = current == null ? undefined : current[token];
  return current;
}

function captureValue(value) {
  if (Array.isArray(value)) return value.map(captureValue);
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, item]) =>
    [key, /authorization|cookie|password|passwd|secret|token|api[_-]?key/i.test(key) ? "***" : captureValue(item)]));
  return value;
}

function captureBody(value) {
  if (typeof value !== "string") return value == null ? "" : JSON.stringify(captureValue(value));
  try { return JSON.stringify(captureValue(JSON.parse(value))); } catch (_) { /* 非 JSON 内容按原格式处理 */ }
  if (value.includes("=")) return value.split("&").map((part) => {
    const equal = part.indexOf("=");
    if (equal < 0) return part;
    const key = part.slice(0, equal);
    let decoded = key;
    try { decoded = decodeURIComponent(key); } catch (_) { /* 保留原键 */ }
    return /authorization|cookie|password|passwd|secret|token|api[_-]?key/i.test(decoded) ? `${key}=***` : part;
  }).join("&");
  return value;
}

function captureUrl(value) {
  const question = value.indexOf("?");
  if (question < 0) return value;
  const fragment = value.indexOf("#", question);
  const end = fragment < 0 ? value.length : fragment;
  const query = value.slice(question + 1, end).split("&").map((part) => {
    const equal = part.indexOf("=");
    const key = equal < 0 ? part : part.slice(0, equal);
    let decoded = key;
    try { decoded = decodeURIComponent(key); } catch (_) { /* 保留原键 */ }
    return /authorization|cookie|password|passwd|secret|token|api[_-]?key/i.test(decoded) ? `${key}=***` : part;
  });
  return value.slice(0, question + 1) + query.join("&") + value.slice(end);
}

function emitCapture(step, config, url, body, params, response, error) {
  if (!CAPTURE_REQUEST && !CAPTURE_RESPONSE) return;
  console.log("MANGO_CAPTURE " + JSON.stringify({
    timestamp: new Date().toISOString(), step_key: step.step_key, step_name: step.name,
    vu: __VU, iteration: __ITER,
    method: CAPTURE_REQUEST ? config.method : "",
    url: CAPTURE_REQUEST ? captureUrl(url) : "",
    request_headers: CAPTURE_REQUEST ? JSON.stringify(captureValue(params.headers)) : "",
    request_body: CAPTURE_REQUEST ? captureBody(body) : "",
    response_status: CAPTURE_RESPONSE && response ? response.status : "",
    response_headers: CAPTURE_RESPONSE && response ? JSON.stringify(captureValue(response.headers)) : "",
    response_body: CAPTURE_RESPONSE && response ? captureBody(response.body) : "",
    duration_ms: response ? response.timings.duration : "",
    error: error ? String(error) : response && response.error ? String(response.error) : "",
  }));
}

function runStepOnce(step, variables) {
  const config = requestConfig(step);
  const tags = { name: step.name, step_key: step.step_key };
  const params = { headers: render(config.headers, variables), tags, timeout: `${config.timeout}s` };
  let body = render(config.body, variables);
  if (config.bodyType === "form" && body && typeof body === "object") {
    body = Object.entries(body).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join("&");
    params.headers["Content-Type"] ||= "application/x-www-form-urlencoded";
  } else if (body !== undefined && body !== null && typeof body !== "string") {
    body = JSON.stringify(body); params.headers["Content-Type"] ||= "application/json";
  }
  let url = render(config.url, variables);
  const query = render(config.params, variables);
  const queryString = Object.entries(query || {}).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join("&");
  if (queryString) url += (url.includes("?") ? "&" : "?") + queryString;
  let response;
  try { response = http.request(config.method, url, body, params); }
  catch (error) { emitCapture(step, config, url, body, params, null, error); throw error; }
  emitCapture(step, config, url, body, params, response, null);
  let passedAll = !response.error_code;
  for (const assertion of step.checks || []) {
    let actual;
    if (assertion.source === "status") actual = response.status;
    else if (assertion.source === "elapsed_ms") actual = response.timings.duration;
    else if (assertion.source === "header") actual = response.headers[assertion.expression];
    else if (assertion.source === "regex") actual = (response.body.match(new RegExp(assertion.expression)) || [])[1];
    else if (assertion.source === "json") actual = response.json();
    else if (assertion.source === "text") actual = response.body;
    else if (assertion.source === "variable") actual = variables[assertion.expression];
    else if (assertion.source === "jsonpath") {
      actual = jsonPath(response.json(), assertion.expression);
    }
    const passed = compare(actual, assertion.operator, render(assertion.expected, variables));
    passedAll = passedAll && passed;
    check(response, { [`${step.name}:${assertion.source}`]: () => passed }, tags);
    if (!passed) checkFailures.add(1, tags);
  }
  for (const extractor of step.extractors || []) {
    let actual;
    if (extractor.source === "header") actual = response.headers[extractor.expression];
    else if (extractor.source === "regex") actual = (response.body.match(new RegExp(extractor.expression)) || [])[1];
    else {
      actual = jsonPath(response.json(), extractor.expression);
    }
    if (actual !== undefined && actual !== null) variables[extractor.name] = actual;
    else if (extractor.required !== false) { passedAll = false; check(response, { [`${step.name}:extract:${extractor.name}`]: () => false }, tags); checkFailures.add(1, tags); }
  }
  if (step.think_time_ms) sleep(step.think_time_ms / 1000);
  return passedAll;
}

function runStep(step, variables) {
  const attempts = Math.max(1, Number(step.retries || 0) + 1);
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      if (runStepOnce(step, variables) || step.allow_failure) return;
      if (attempt + 1 >= attempts) throw new Error(`Case 步骤 ${step.name} 检查失败`);
      if (step.retry_interval_ms) sleep(step.retry_interval_ms / 1000);
    }
    catch (error) {
      if (attempt + 1 >= attempts) {
        if (!step.allow_failure) throw error;
        return;
      }
      if (step.retry_interval_ms) sleep(step.retry_interval_ms / 1000);
    }
  }
}

export default function () {
  const variables = Object.assign({}, runtimeVariables);
  applyValues(variables, IR.initial_variables);
  for (const step of IR.steps) runStep(step, variables);
  const waitMin = Number(IR.user_wait_min_ms || 0);
  const waitMax = Math.max(waitMin, Number(IR.user_wait_max_ms || 0));
  if (waitMax > 0) sleep((waitMin + Math.random() * (waitMax - waitMin)) / 1000);
}
'''
