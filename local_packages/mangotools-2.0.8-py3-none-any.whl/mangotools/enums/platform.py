"""芒果测试平台后端与执行器共享的跨进程协议枚举。"""

from enum import Enum

from ._base_enum import BaseEnum


class TaskEnum(BaseEnum):
    FAIL = 0
    SUCCESS = 1
    STAY_BEGIN = 2
    PROCEED = 3
    WARNING = 4
    STOPPED = 5

    @classmethod
    def obj(cls):
        return {0: "失败", 1: "通过", 2: "待开始", 3: "进行中", 4: "警告", 5: "已停止"}


class TestCaseTypeEnum(BaseEnum):
    UI = 0
    API = 1
    PYTEST = 2
    OTHER = 3

    @classmethod
    def obj(cls):
        return {0: "前端自动化", 1: "服务自动化", 2: "脚本自动化", 3: "其他自动化"}


class ClientTypeEnum(BaseEnum):
    SERVER = 0
    WEB = 1
    ACTUATOR = 2
    MCP = 3

    @classmethod
    def obj(cls):
        return {0: "芒果服务端", 1: "芒果用户端", 2: "芒果执行端", 3: "MCP"}


class ClientNameEnum(BaseEnum):
    DRIVER = "测试平台执行器"
    SERVER = "测试平台服务器"
    WEB = "测试平台用户端"
    PLATFORM_CHINESE = "智书测试平台"
    PLATFORM_ENGLISH = "MangoTestPlatform"

    @classmethod
    def obj(cls):
        return {"DRIVER": "芒果执行器", "SERVER": "芒果服务器", "WEB": "芒果用户端"}


class SocketEnum(BaseEnum):
    WEB_PATH = "/ws/web/socket"
    CLIENT_PATH = "/ws/client/socket"
    OPEN = "open"
    CLIENT_CONN_OBJ = "client_obj"
    WEB_CONN_OBJ = "web_obj"


class DriveTypeEnum(BaseEnum):
    WEB = 0
    ANDROID = 1
    DESKTOP = 2
    IOS = 3

    @classmethod
    def obj(cls):
        return {0: "WEB", 1: "安卓", 2: "PC桌面", 3: "iOS"}


class BrowserTypeEnum(BaseEnum):
    CHROMIUM = 0
    EDGE = 1
    FIREFOX = 2
    WEBKIT = 3

    @classmethod
    def obj(cls):
        return {0: "谷歌浏览器", 1: "EDGE", 2: "火狐", 3: "WEBKIT"}


class MethodEnum(BaseEnum):
    GET = 0
    POST = 1
    PUT = 2
    DELETE = 3
    OPTIONS = 4
    DEAD = 5
    PATCH = 6
    MCP_CALL = 7
    GRPC_CALL = 8
    WEBSOCKET_CONNECT = 9

    @classmethod
    def obj(cls):
        return {
            0: "GET", 1: "POST", 2: "PUT", 3: "DELETE", 4: "OPTIONS",
            5: "DEAD", 6: "PATCH", 7: "MCP_CALL", 8: "GRPC_CALL", 9: "WEBSOCKET_CONNECT",
        }


class ApiTypeEnum(BaseEnum):
    batch = 0
    debug = 1
    success = 2

    @classmethod
    def obj(cls):
        return {0: "批量生成", 1: "调试接口", 2: "调试完成"}


class UiPublicTypeEnum(BaseEnum):
    CUSTOM = 0
    SQL = 1
    CODE = 2

    @classmethod
    def obj(cls):
        return {0: "自定义-第一加载", 1: "SQL-第二加载", 2: "代码变量-第三加载"}


class ServerApiCommandEnum(str, Enum):
    API_INFO = "a_api_info"
    API_CASE = "a_api_case"


class ServerUiCommandEnum(str, Enum):
    PAGE_STEPS = "u_page_step"
    OPEN_TARGET_PAGE = "u_open_target_page"
    ELEMENT_CHECK = "u_element_check"
    CASE_BATCH = "u_case"
    NEW_PAGE_OBJ = "u_page_new_obj"
    AUTH_AUTO = "u_auth_auto"
    AUTH_AUTO_CAPTURE = "u_auth_auto_capture"
    MANGO_PYTEST = "t_mango_pytest"
    RECORDING = "u_recording"
    SET_OPEN_STATUS = "t_set_open_status"
    SET_DEBUG = "t_set_debug"
    LIVE_STREAM_START = "u_live_stream_start"
    LIVE_STREAM_STOP = "u_live_stream_stop"
    LIVE_WORKSPACE_START = "u_live_workspace_start"
    LIVE_WORKSPACE_STOP = "u_live_workspace_stop"
    PAGE_SCAN = "u_page_scan"


class ServerToolsCommandEnum(str, Enum):
    REFRESH_METHOD_OPTIONS = "t_refresh_method_options"
    TASK_AVAILABLE = "t_task_available"
    STOP_TEST_SUITE = "t_stop_test_suite"
    GET_ACTUATOR_CONFIG = "t_get_actuator_config"
    UPDATE_ACTUATOR_CONFIG = "t_update_actuator_config"
    SET_ACTUATOR_CONFIG_SNAPSHOT = "t_set_actuator_config_snapshot"
    SET_ACTUATOR_CONFIG_SAVE_RESULT = "t_set_actuator_config_save_result"


class ServerPytestCommandEnum(str, Enum):
    TEST_CASE = "p_case"


class ServerPerfEventEnum(str, Enum):
    RUN_UPDATE = "perf_run_update"


class ActuatorApiEventEnum(str, Enum):
    RECORDING_API = "a_recording_api"


class ActuatorUiEventEnum(str, Enum):
    PAGE_STEPS = "u_page_steps"
    PAGE_STEP_NODE_PROGRESS = "u_page_step_node_progress"
    TEST_CASE = "u_test_case"
    TEST_CASE_BATCH = "u_test_suite_details"
    LIVE_WORKSPACE_STATUS = "u_live_workspace_status"


class ActuatorPytestEventEnum(str, Enum):
    TEST_CASE_BATCH = "p_test_suite_details"
    TEST_CASE = "p_test_case"


class ActuatorToolsEventEnum(str, Enum):
    SET_OPERATION_OPTIONS = "t_set_operation_options"
    SET_USERINFO = "t_set_userinfo"
    REFRESH_METHOD_OPTIONS = "t_refresh_method_options"
    GET_TASK = "t_get_task"
    TASK_AVAILABLE = "t_task_available"
    STOP_TEST_SUITE = "t_stop_test_suite"
    SET_ACTUATOR_CONFIG_SNAPSHOT = "t_set_actuator_config_snapshot"
    SET_ACTUATOR_CONFIG_SAVE_RESULT = "t_set_actuator_config_save_result"
