# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-09-26 18:31
# @Author : 毛鹏

def find_start_node(nodes, edges):
    """找到开始节点（没有入边的节点）"""
    target_nodes = set(edge['target']['node_id'] for edge in edges)
    start_nodes = [node for node in nodes if node['id'] not in target_nodes]
    return start_nodes[0] if start_nodes else None

def build_flow_graph(edges):
    """构建流程图的有向图结构"""
    graph = {}
    for edge in edges:
        source = edge['source']['node_id']
        target = edge['target']['node_id']
        if source not in graph:
            graph[source] = []
        graph[source].append(target)
    return graph

def get_node_by_id(nodes, node_id):
    """根据节点ID获取节点信息"""
    for node in nodes:
        if node['id'] == node_id:
            return node
    return None

def find_end_nodes(nodes, edges):
    """找到结束节点（没有出边的节点）"""
    source_nodes = set(edge['source']['node_id'] for edge in edges)
    end_nodes = [node for node in nodes if node['id'] not in source_nodes]
    return [node['id'] for node in end_nodes]

def build_decision_tree(flow_data):
    """构建决策树，显示条件分支结构"""
    nodes = flow_data.get('nodes')
    edges = flow_data.get('edges')

    # 找到开始节点
    start_node = find_start_node(nodes, edges)
    if not start_node:
        return None

    # 构建图结构
    graph = build_flow_graph(edges)

    def build_tree_node(node_id, visited):
        if node_id in visited:
            return None

        visited.add(node_id)
        node = get_node_by_id(nodes, node_id)

        if not node:
            return None

        tree_node = {
            'id': node['config']['id'],
            'type': node.get('type'),
            'children': []
        }

        # 递归构建子节点
        if node_id in graph:
            children = graph[node_id]

            # 如果是条件节点且有多个子节点，给分支命名
            if node.get('type') == 4 and len(children) > 1:
                branch_names = [f'分支{i + 1}' for i in range(len(children))]
            else:
                branch_names = [None] * len(children)

            for child_id, branch_name in zip(children, branch_names):
                child_tree = build_tree_node(child_id, visited.copy())
                if child_tree:
                    tree_node['children'].append(child_tree)

        return tree_node

    return build_tree_node(start_node['id'], set())


def get_execution_order_with_config_ids(flow_data):
    nodes = flow_data["nodes"]
    edges = flow_data["edges"]

    node_to_config = {node["id"]: node["config"]["id"] for node in nodes}

    # 构建邻接表
    graph = {}
    for edge in edges:
        source = edge["source"]["node_id"]
        target = edge["target"]["node_id"]
        if source not in graph:
            graph[source] = []
        graph[source].append(target)

    # 找到起始节点（没有入边的节点）
    all_targets = set()
    for edge in edges:
        all_targets.add(edge["target"]["node_id"])

    start_nodes = [node["id"] for node in nodes if node["id"] not in all_targets]

    # 执行顺序列表（存储config ID）
    execution_order = []

    def traverse(node_id):
        if node_id in execution_order:
            return

        # 添加config ID到执行顺序
        execution_order.append(node_to_config[node_id])

        # 如果有后续节点，继续遍历
        if node_id in graph:
            for next_node in graph[node_id]:
                traverse(next_node)

    # 从所有起始节点开始遍历
    for start_node in start_nodes:
        traverse(start_node)

    return execution_order
