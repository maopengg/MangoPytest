import asyncio
import ast
import copy
import json
import re
from threading import Thread


# -*- coding: utf-8 -*-


def _split_function_parameters(value: str) -> list[str]:
    """按顶层逗号切分参数，保留 JSON、数组、引号内的逗号。"""
    parameters = []
    start = 0
    depth = 0
    quote = None
    escaped = False
    pairs = {'(': ')', '[': ']', '{': '}'}
    closing = set(pairs.values())

    for index, character in enumerate(value):
        if escaped:
            escaped = False
            continue
        if character == '\\' and quote:
            escaped = True
            continue
        if quote:
            if character == quote:
                quote = None
            continue
        if character in {'\'', '"'}:
            quote = character
        elif character in pairs:
            depth += 1
        elif character in closing:
            depth -= 1
            if depth < 0:
                raise ValueError('参数括号不匹配')
        elif character == ',' and depth == 0:
            parameters.append(value[start:index].strip())
            start = index + 1

    if quote or depth != 0:
        raise ValueError('参数引号或括号不匹配')
    parameters.append(value[start:].strip())
    return [parameter for parameter in parameters if parameter]


def _normalize_function_parameter(value: str) -> str:
    """表达式兼容历史裸字符串，同时允许用引号包裹逗号、等号等字符。"""
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'\'', '"'}:
        try:
            normalized = ast.literal_eval(value)
        except (SyntaxError, ValueError):
            return value
        return normalized if isinstance(normalized, str) else value
    return value


class AsyncioThread(Thread):

    def __init__(self, loop):
        super().__init__()
        self._loop = loop
        self.daemon = True

    def run(self) -> None:
        self._loop.run_forever()


class Mango:

    @staticmethod
    def v(v, s=None):
        if v == v:
            if s:
                print('测试通过')
            pass
        else:
            raise Exception('21312')


    @staticmethod
    def t():
        loop = asyncio.new_event_loop()
        thd = AsyncioThread(loop)
        thd.start()
        return loop

    @staticmethod
    def add_from_data(self, ):
        form_data = copy.deepcopy(self.form_data)
        for i in form_data:
            if callable(i.select):
                if hasattr(self, 'form_data_callback'):
                    i.select = self.form_data_callback(i)
                else:
                    i.select = i.select()
        return form_data

    @staticmethod
    def edit_form_data(self, row, form_data, methods):
        form_data = copy.deepcopy(form_data)
        for i in form_data:
            if isinstance(row[i.key], dict):
                i.value = row[i.key].get('id', None)
                if i.value is None and row[i.key]:
                    i.value = json.dumps(row[i.key], ensure_ascii=False)
            elif isinstance(row[i.key], list):
                i.value = json.dumps(row[i.key], ensure_ascii=False)
            else:
                i.value = row[i.key]
            if callable(i.select):
                if hasattr(self, 'form_data_callback'):
                    i.select = self.form_data_callback(i)
                else:
                    i.select = i.select()
            if i.subordinate and i.subordinate == 'module':
                result = next((item for item in form_data if item.key == i.subordinate), None)
                result.select = methods.get_product_module_label(int(i.value))
            elif i.subordinate:
                result = next((item for item in form_data if item.key == i.subordinate), None)
                result.select = self.subordinate_callback(i)
        return form_data

    @staticmethod
    def put_save_data(self, row, data):
        data['id'] = row.get('id')
        if hasattr(self, 'save_callback'):
            self.save_callback(data, False)
        else:
            return self.put(data)

    @staticmethod
    def post_save_data(self, data):
        if hasattr(self, 'save_callback'):
            self.save_callback(data, True)
        else:
            return self.post(data)

    @staticmethod
    def regular(self, func, error_type, m022, m023):
        match = re.match(r'^(\w+)\((.*)\)$', func)
        if not match:
            return getattr(self, func)()  # 处理无括号的简单调用

        import inspect
        method_name = match.group(1)
        params_str = match.group(2).strip()
        _func = getattr(self, method_name)

        # 获取方法参数签名
        sig = inspect.signature(_func)
        params = list(sig.parameters.keys())

        if not params_str:
            return _func()  # 无参数情况

        try:
            args = _split_function_parameters(params_str)
        except ValueError as error:
            raise error_type(*m023) from error

        keyword_matches = []
        for arg in args:
            keyword_match = re.match(r'^([A-Za-z_]\w*)\s*=', arg)
            keyword_matches.append(
                keyword_match if keyword_match and keyword_match.group(1) in params else None
            )
        if all(keyword_matches):  # 键值对模式
            data_dict = {}
            for pair, keyword_match in zip(args, keyword_matches):
                key = keyword_match.group(1)
                value = pair[keyword_match.end():]
                data_dict[key.strip()] = _normalize_function_parameter(value.strip())
            return _func(**data_dict)
        if any(keyword_matches):
            raise error_type(*m023)

        # 顺序传参模式
        if len(args) > len(params):
            raise error_type(*m022)
        return _func(*[_normalize_function_parameter(arg) for arg in args])

    @staticmethod
    def replace_str(self, data, m_0002, mango_tools_error):
        while self.is_extract(str(data)):
            # 优先匹配最内层的表达式（非贪婪模式）
            innermost_match = re.search(r'\$\{\{([^{}]*)\}\}', str(data))
            if not innermost_match:
                break

            full_match = innermost_match.group(0)
            key_text = self.remove_parentheses(full_match)
            args = key_text.split("|")
            key_text, key = (args[0], args[1]) if len(args) == 2 else (args[0], None)

            if self.is_extract(key_text):
                value = self.replace_str(f"${{{{{key_text}}}}}", m_0002, mango_tools_error)
            else:
                value = (
                    self.regular(key_text)
                    if self.identify_parentheses(key_text)
                    else self.get_cache(key_text)
                )

            if value is None:
                raise mango_tools_error(*m_0002, value=(key_text,))

            if key:
                self.set_cache(key, value)

            data = data.replace(full_match, str(value))

        return data.strip() if isinstance(data, str) else data
