from typing import Any

from mangotools.contracts.base import ContractModel
from mangotools.enums import TestCaseTypeEnum


class TaskPullRequest(ContractModel):
    type: TestCaseTypeEnum
    username: str


class TestSuiteDetailResultContract(ContractModel):
    id: int
    type: TestCaseTypeEnum
    test_suite: int
    status: int
    error_message: str | None = None
    result_data: Any


__all__ = ["TaskPullRequest", "TestSuiteDetailResultContract"]
