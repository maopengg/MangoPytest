"""Versioned request contracts for the database-backed executor task API."""

from typing import Any

from pydantic import Field

from mangotools.contracts.base import ContractModel


class ExecutorTaskProgressContract(ContractModel):
    percent: int | None = Field(default=None, ge=0, le=100)
    current: int | None = Field(default=None, ge=0)
    total: int | None = Field(default=None, ge=0)
    message: str | None = None
    current_node_id: int | str | None = None


class ExecutorTaskClaimContract(ContractModel):
    connection_id: str | None = None
    capacity: int = Field(default=1, ge=1, le=20)
    supported_task_types: list[str] = Field(default_factory=list)
    protocol_versions: dict[str, int] = Field(default_factory=dict)
    capability_capacities: dict[str, int] = Field(default_factory=dict)
    task_type_capacities: dict[str, int] = Field(default_factory=dict)


class ExecutorTaskHeartbeatContract(ContractModel):
    connection_id: str | None = None


class ExecutorTaskDrainingContract(ExecutorTaskHeartbeatContract):
    draining: bool = True


class ExecutorTaskProgressRequestContract(ExecutorTaskHeartbeatContract):
    progress: ExecutorTaskProgressContract


class ExecutorTaskResultContract(ExecutorTaskHeartbeatContract):
    attempt: int = Field(default=0, ge=0)
    success: bool
    result_data: dict[str, Any] | list[Any] | None = None
    error_code: str | None = None
    error_message: str | None = None


class ActuatorSystemErrorContract(ContractModel):
    operation: str = Field(min_length=1, max_length=255)
    exception_type: str = Field(min_length=1, max_length=128)
    message: str = Field(min_length=1, max_length=500)
    traceback: str | None = Field(default=None, max_length=50000)


__all__ = [
    "ActuatorSystemErrorContract",
    "ExecutorTaskClaimContract",
    "ExecutorTaskDrainingContract",
    "ExecutorTaskHeartbeatContract",
    "ExecutorTaskProgressContract",
    "ExecutorTaskProgressRequestContract",
    "ExecutorTaskResultContract",
]
