"""Base classes for versioned wire contracts shared by platform processes."""

from pydantic import BaseModel, ConfigDict


class ContractModel(BaseModel):
    """Additive wire contract tolerant of fields from a newer peer."""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)


__all__ = ["ContractModel"]
