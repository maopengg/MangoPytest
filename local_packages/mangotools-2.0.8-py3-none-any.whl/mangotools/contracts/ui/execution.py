from typing import Any

from pydantic import Field

from mangotools.contracts.base import ContractModel


class UiEnvironmentContract(ContractModel):
    id: int
    test_object_value: str


class UiAuthStorageItemContract(ContractModel):
    origin: str
    key: str
    value: str = ""


class UiFlowRuntimeNodeContract(ContractModel):
    id: int
    type: int | None = None
    children: list["UiFlowRuntimeNodeContract"] = Field(default_factory=list)


class UiPublicVariableContract(ContractModel):
    id: int | None = None
    type: int
    key: str
    value: str
    datasource_alias: int | None = None


class UiRecordingCommand(ContractModel):
    url_list: list[dict]


class UiStepDataContract(ContractModel):
    type: int
    ope_key: str | None = None
    page_step_details_id: int
    page_step_details_data: list | None = None
    page_step_details_name: str | None = None
    condition_value: dict[str, Any] | None = None


class UiPageStepExecutionContract(ContractModel):
    id: int
    name: str
    project_product: int
    project_product_name: str
    module_name: str
    test_env: int | None = None
    type: int
    url: str
    switch_step_open_url: bool
    error_retry: int | None = None
    element_list: Any = Field(default_factory=list)
    environment_config: UiEnvironmentContract
    public_data_list: list[UiPublicVariableContract] = Field(default_factory=list)
    flow_data: Any = None
    step_control: Any = None
    is_auth_step: bool = False
    config_version: int = 1
    goal: str | None = None
    entry_criteria: dict | None = Field(default_factory=dict)
    success_criteria: dict | None = Field(default_factory=dict)
    healing_enabled: bool = False
    healing_policy: dict = Field(default_factory=dict)


class UiCaseExecutionContract(ContractModel):
    execution_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    send_user: str
    test_suite_details: int | None
    test_suite_id: int | None
    id: int
    name: str
    project_product: int
    project_product_name: str
    module_name: str
    test_env: int
    case_people: str
    front_custom: list[Any]
    front_sql: list[Any]
    posterior_sql: list[Any]
    parametrize: list[Any]
    data_factory_cache_data: dict = Field(default_factory=dict)
    data_factory_execution_ids: list[int] = Field(default_factory=list)
    data_factory_auto_cleanup_execution_ids: list[int] = Field(default_factory=list)
    gray_config_ids: list[int] = Field(default_factory=list)
    gray_execution_log_ids: list[int] = Field(default_factory=list)
    ui_auth_cache: Any = None
    steps: list[Any]


class UiPageStepResultContract(ContractModel):
    execution_id: str | None = None
    progress_sequence: int = 0
    workspace_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    id: int
    name: str
    type: int
    project_product_id: int
    project_product_name: str
    test_env: int | None = None
    case_step_details_id: int | None = None
    test_time: str | None = None
    stop_time: str | None = None
    cache_data: dict
    data_factory_cache_data: dict = Field(default_factory=dict)
    test_object: str
    is_auth_step: bool = False
    is_final: bool = False
    status: int
    error_message: str | None = None
    element_result_list: Any = Field(default_factory=list)


class UiCaseResultContract(ContractModel):
    execution_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    id: int
    name: str
    project_product_id: int
    project_product_name: str
    module_name: str
    test_env: int
    status: int
    test_time: str | None = None
    stop_time: str | None = None
    error_message: str | None = None
    video_path: str | None = None
    data_factory_cache_data: dict = Field(default_factory=dict)
    data_factory_execution_ids: list[int] = Field(default_factory=list)
    data_factory_auto_cleanup_execution_ids: list[int] = Field(default_factory=list)
    gray_config_ids: list[int] = Field(default_factory=list)
    gray_execution_log_ids: list[int] = Field(default_factory=list)
    steps: list[Any] = Field(default_factory=list)


__all__ = [
    "UiEnvironmentContract",
    "UiAuthStorageItemContract",
    "UiFlowRuntimeNodeContract",
    "UiCaseExecutionContract",
    "UiCaseResultContract",
    "UiPageStepExecutionContract",
    "UiPageStepResultContract",
    "UiPublicVariableContract",
    "UiRecordingCommand",
    "UiStepDataContract",
]
