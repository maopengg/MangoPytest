from typing import Any

from pydantic import Field

from mangotools.contracts.base import ContractModel


class ApiRecordingContract(ContractModel):
    """API recording payload emitted by an actuator and consumed by the server."""

    project_product: int
    username: str
    type: int = 0
    module: int | None = None
    name: str
    client: int = 0
    url: str
    method: int
    header: dict[str, Any] | None = None
    params: str | None = None
    data: str | dict[str, Any] | list[Any] | None = None
    json_data: str | dict[str, Any] | list[Any] | None = Field(
        default=None,
        validation_alias="json",
        serialization_alias="json",
    )
    file: list[Any] | dict[str, Any] | None = None
    protocol_type: str = "http"
    body_type: str | None = None
    body_config: dict[str, Any] | None = None
    sse_config: dict[str, Any] | None = None
    status: int | None = None


__all__ = ["ApiRecordingContract"]
