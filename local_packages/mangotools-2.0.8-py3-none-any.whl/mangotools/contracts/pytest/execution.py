from typing import Any

from mangotools.contracts.base import ContractModel


class PytestSourceSnapshotContract(ContractModel):
    version: int = 1
    repository_id: int
    repository_name: str
    pytest_project_id: int
    pytest_project_name: str | None = None
    branch: str | None = None
    commit_hash: str
    project_path: str
    working_directory: str
    pytest_config_path: str | None = None
    file_path: str
    nodeid: str | None = None


class PytestExecutionCommand(ContractModel):
    dispatch_id: str
    send_user: str
    test_suite_details: int | None
    test_suite_id: int | None
    id: int
    name: str
    project_product: int
    project_product_name: str
    module_name: str | None = None
    test_env: int
    case_people: str
    file_path: str
    repository_id: int
    repository_name: str
    pytest_project_id: int
    pytest_project_name: str | None = None
    project_path: str
    working_directory: str
    pytest_config_path: str | None = None
    source_snapshot: dict[str, Any]
    git_url: str
    commit_hash: str
    git_username: str | None = None
    git_password: str | None = None
    git_provider: str
    git_api_base_url: str | None = None
    git_project: str | int
    git_access_token: str | None = None
    git_credential_ref: str
    git_ref: str
    nodeid: str | None = None
    node_type: str | None = None
    class_name: str | None = None
    method_name: str | None = None
    parameter_id: str | None = None


class PytestExecutionResult(ContractModel):
    dispatch_id: str
    source_snapshot: dict[str, Any]
    id: int
    name: str
    status: int
    error_message: str | None = None
    result_data: dict[str, Any] | list[Any] | None = None


__all__ = ["PytestExecutionCommand", "PytestExecutionResult", "PytestSourceSnapshotContract"]
