from mangotools.contracts.base import ContractModel


class ActuatorPresenceUpdate(ContractModel):
    username: str
    status: bool | None = None
    is_open: bool | None = None
    debug: bool | None = None
    web_live_stream_supported: bool | None = None


__all__ = ["ActuatorPresenceUpdate"]
