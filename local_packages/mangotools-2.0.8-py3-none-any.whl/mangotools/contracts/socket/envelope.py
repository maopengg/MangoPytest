import uuid
from typing import Any

from pydantic import ConfigDict, Field

from mangotools.contracts.base import ContractModel
from mangotools.enums import ClientTypeEnum


class SocketCommandContract(ContractModel):
    func_name: str
    func_args: list[Any] | Any | None = None
    message_id: str | None = None
    dispatch_id: str | None = None


class SocketEnvelopeContract(ContractModel):
    model_config = ConfigDict(extra="ignore", use_enum_values=True)

    message_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    protocol_version: int = 1
    dispatch_id: str | None = None
    connection_id: str | None = None
    sent_at: int | None = None
    code: int
    msg: str
    user: str | None = None
    is_notice: ClientTypeEnum | int | None = None
    data: SocketCommandContract | None = None


__all__ = ["SocketCommandContract", "SocketEnvelopeContract"]
