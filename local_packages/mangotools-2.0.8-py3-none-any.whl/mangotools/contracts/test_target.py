import re

from pydantic import ConfigDict, Field, field_validator, model_validator

from mangotools.contracts.base import ContractModel


class TestTargetConfig(ContractModel):
    """按执行缓存变量选择地址，未命中时统一使用默认地址。"""

    model_config = ConfigDict(extra='forbid')
    default: str = Field(default='', max_length=1024)
    selector: str = Field(default='', max_length=128)
    mapping: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode='before')
    @classmethod
    def remove_old_fallback_flag(cls, value):
        if isinstance(value, dict):
            value = dict(value)
            value.pop('fallback_to_default', None)
        return value

    @field_validator('default', 'selector')
    @classmethod
    def trim(cls, value):
        return value.strip()

    @field_validator('selector')
    @classmethod
    def validate_selector(cls, value):
        if value and not re.fullmatch(r'[^{}$|()]+', value):
            raise ValueError('条件变量直接填写缓存键名，不使用模板、函数或脚本')
        return value

    @field_validator('mapping')
    @classmethod
    def validate_mapping(cls, value):
        if len(value) > 200:
            raise ValueError('映射最多支持 200 项')
        if any(not key or key != key.strip() or not address.strip() or len(address) > 1024
               for key, address in value.items()):
            raise ValueError('条件值不能为空或带首尾空格，地址必须为 1 至 1024 个字符')
        return {key: address.strip() for key, address in value.items()}

    @model_validator(mode='after')
    def validate_rules(self):
        if not self.selector and (self.mapping or not self.default):
            raise ValueError('固定地址必须填写默认地址；映射必须设置条件变量')
        if self.selector and not self.mapping:
            raise ValueError('请至少配置一项地址映射')
        return self
