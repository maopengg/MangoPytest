# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 测试数据方法元信息装饰器
# @Time   : 2026-05-21
# @Author : 毛鹏
import inspect
from collections.abc import Callable

from mangotools.models import MethodModel


data_method_info: list[dict] = []
_data_method_names: set[str] = set()


def _data_method_info_add(_type, class_name, name, func, parameter, sort):
    class_dict = next((item for item in data_method_info if item.get("value") == _type), None)
    if not class_dict:
        new_entry = {
            "label": _type,
            "value": _type,
            "children": [],
        }
        data_method_info.append(new_entry)
        class_dict = new_entry
    found_dict = next((item for item in class_dict["children"] if item.get("value") == class_name), None)
    if not found_dict:
        new_entry = {
            "label": class_name,
            "value": class_name,
            "children": [],
        }
        class_dict["children"].append(new_entry)
        found_dict = new_entry
    if func.__name__ not in _data_method_names:
        _data_method_names.add(func.__name__)
        found_dict["children"].append({
            "value": func.__name__,
            "label": name,
            "parameter": [i.model_dump() for i in parameter] if parameter else None,
            "sort": sort,
        })


def data_method(
        _type: str,
        class_name: str,
        name: str,
        parameter: list[MethodModel] | None = None,
        sort: int = -1,
):
    def decorator(func: Callable):
        method_name = func.__name__
        params = parameter
        if params is None:
            params = []
            for item in inspect.signature(func).parameters.values():
                if item.name in {'self', 'cls'}:
                    continue
                default_value = None if item.default is inspect.Parameter.empty else item.default
                params.append(MethodModel(
                    f=item.name,
                    n=item.name,
                    p=f'请输入{item.name}',
                    d=True,
                    v=default_value,
                ))
        method_info = {
            "value": method_name,
            "label": name,
            "parameter": [i.model_dump() for i in params] if params else None,
            "sort": sort,
        }
        setattr(func, '__data_method__', method_info)
        _data_method_info_add(_type, class_name, name, func, params, sort)
        return func

    return decorator


def get_data_method_info() -> list[dict]:
    return data_method_info
