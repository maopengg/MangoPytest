"""Blank-page and full RGB comparison regressions using generated PDF fixtures."""
import io
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pymupdf
from PIL import Image

from mangotools.assertion import MangoAssertion
from mangotools.assertion.visual._pdf_comparison_engine import compare_rgb, parse_inputs


class TestPdfColor(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.ass = MangoAssertion().ass

    def pdf(self, name, color=None, image=False):
        path = self.root / (name + '.pdf')
        with pymupdf.open() as doc:
            page = doc.new_page(width=80, height=80)
            if color is not None:
                if image:
                    stream = io.BytesIO()
                    Image.new('RGB', (20, 20), color).save(stream, format='PNG')
                    page.insert_image(pymupdf.Rect(20, 20, 40, 40), stream=stream.getvalue())
                else:
                    page.draw_rect(pymupdf.Rect(20, 20, 40, 40), fill=color, color=color)
            doc.save(path)
        return str(path)

    def test_same_outline_different_color(self):
        a, b = self.pdf('red', (1, 0, 0)), self.pdf('blue', (0, 0, 1))
        self.assertIn('通过', self.ass('assert_pdf_visual_match', a, {'基准文件路径': b}))
        with self.assertRaisesRegex(AssertionError, '颜色差异'):
            self.ass('assert_pdf_color_match', a, {'基准文件路径': b})
        with self.assertRaisesRegex(AssertionError, '颜色差异'):
            self.ass('assert_pdf_comparison_pass', a, {'基准文件路径': b})

    def test_image_intensity_and_identical_images(self):
        a = self.pdf('dark', (10, 10, 10), image=True)
        b = self.pdf('light', (100, 100, 100), image=True)
        self.assertIn('通过', self.ass('assert_pdf_visual_match', a, {'基准文件路径': b}))
        with self.assertRaisesRegex(AssertionError, '颜色差异'):
            self.ass('assert_pdf_color_match', a, {'基准文件路径': b})
        self.assertIn('通过', self.ass('assert_pdf_color_match', a, {'基准文件路径': a}))

    def test_unilateral_blank_never_waived_by_color_thresholds(self):
        blank, pale = self.pdf('blank'), self.pdf('pale', (254, 254, 254), image=True)
        for a, b in [(blank, pale), (pale, blank)]:
            for method in ('assert_pdf_comparison_pass', 'assert_pdf_color_match',
                           'assert_pdf_text_match', 'assert_pdf_layout_match', 'assert_pdf_visual_match'):
                with self.subTest(method=method, a=a), self.assertRaisesRegex(AssertionError, '异常空白'):
                    self.ass(method, a, {'基准文件路径': b, '最大颜色差异率': 1,
                                        '最大颜色差异面积': 100000, '颜色通道容差': 255})

    def test_removed_or_added_blank_page_fails(self):
        blank = self.pdf('blank')
        extra = self.root / 'extra.pdf'
        with pymupdf.open(blank) as doc:
            doc.new_page(width=80, height=80)
            doc.save(extra)
        with self.assertRaisesRegex(AssertionError, '页数不一致'):
            self.ass('assert_pdf_comparison_pass', str(extra), {'基准文件路径': blank})

    def test_color_metrics_and_channel_boundary(self):
        a = np.array([[[10, 20, 30], [255, 255, 255]]], dtype=np.uint8)
        b = np.array([[[20, 20, 30], [255, 255, 255]]], dtype=np.uint8)
        metrics, mask = compare_rgb(a, b, 10)
        self.assertEqual(metrics['color_difference_pixels'], 0)
        metrics, mask = compare_rgb(a, b, 9)
        self.assertEqual(metrics['color_difference_ratio'], 1)
        self.assertAlmostEqual(metrics['color_difference_area_pt2'], 1 / 9)
        self.assertEqual(mask.tolist(), [[True, False]])
        white = np.full((1, 1, 3), 255, dtype=np.uint8)
        black = np.zeros_like(white)
        self.assertEqual(compare_rgb(white, black)[0]['max_channel_difference'], 255)
        self.assertEqual(compare_rgb(white, white)[0]['color_difference_ratio'], 0)

    def test_reports_and_exact_limits(self):
        a, b = self.pdf('red', (1, 0, 0)), self.pdf('blue', (0, 0, 1))
        config = {'基准文件路径': b, '输出目录': str(self.root / 'reports')}
        with self.assertRaisesRegex(AssertionError, '报告='):
            self.ass('assert_pdf_color_match', a, config)
        report_path = next((self.root / 'reports').glob('*/report.json'))
        report = json.loads(report_path.read_text())
        page = report['pages'][0]
        self.assertFalse(report['passed'])
        with Image.open(page['color_diff_image']) as image:
            self.assertEqual(image.size, (240, 240))
        self.assertIn('通过', self.ass('assert_pdf_color_match', a, {
            '基准文件路径': b, '最大颜色差异率': page['color_difference_ratio'],
            '最大颜色差异面积': page['color_difference_area_pt2']}))
        with self.assertRaises(AssertionError):
            self.ass('assert_pdf_color_match', a, {'基准文件路径': b, '最大颜色差异率': 1})

    def test_color_limits_are_per_page(self):
        paths = []
        for name, color in [('red', (1, 0, 0)), ('blue', (0, 0, 1))]:
            source = self.pdf(name, color)
            target = self.root / (name + '_two.pdf')
            with pymupdf.open(source) as doc:
                doc.new_page(width=80, height=80)
                doc.save(target)
            paths.append(str(target))
        with self.assertRaisesRegex(AssertionError, '第1页颜色差异'):
            self.ass('assert_pdf_color_match', paths[0], {
                '基准文件路径': paths[1], '最大颜色差异率': 0.5, '最大颜色差异面积': 100000})

    def test_color_parameter_validation(self):
        for key, value in [('颜色通道容差', -1), ('颜色通道容差', 256), ('颜色通道容差', 0.5),
                           ('颜色通道容差', True), ('最大颜色差异率', 1.1),
                           ('最大颜色差异面积', float('inf'))]:
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                parse_inputs('/a.pdf', {'基准文件路径': '/b.pdf', key: value})
