# -*- coding: utf-8 -*-
import unittest
from datetime import timedelta
from unittest.mock import Mock, patch

import requests
from requests.structures import CaseInsensitiveDict

from mangotools.assertion import MangoAssertion
from mangotools.decorator import func_info


class TestUrlAssertion(unittest.TestCase):

    def setUp(self):
        self.assertion = MangoAssertion()

    @staticmethod
    def response(
            status_code=200,
            text='Example Domain',
            url='https://example.com/',
            headers=None,
            elapsed_ms=120,
    ):
        response = Mock()
        response.status_code = status_code
        response.text = text
        response.url = url
        response.headers = CaseInsensitiveDict(headers or {'Content-Type': 'text/html; charset=UTF-8'})
        response.elapsed = timedelta(milliseconds=elapsed_ms)
        return response

    @patch('mangotools.assertion.text._url.requests.Session')
    def test_request_disables_environment_proxy(self, session_class):
        session = session_class.return_value
        session.request.return_value = self.response()

        self.assertion.ass('p_url_is_accessible', 'https://example.com')

        self.assertFalse(session.trust_env)
        session.request.assert_called_once_with(
            method='GET',
            url='https://example.com',
            timeout=10,
            allow_redirects=True,
            proxies={'http': None, 'https': None},
        )
        session.close.assert_called_once()

    @patch('mangotools.assertion.text._url.requests.Session')
    def test_url_content_status_header_redirect_and_time_assertions(self, session_class):
        session_class.return_value.request.return_value = self.response()

        self.assertion.ass('p_url_status_code_is', 'https://example.com', 200)
        self.assertion.ass('p_url_content_contains', 'https://example.com', 'Example')
        self.assertion.ass('p_url_content_not_contains', 'https://example.com', 'error')
        self.assertion.ass('p_url_content_matches_regex', 'https://example.com', r'Example\s+Domain')
        self.assertion.ass(
            'p_url_header_contains',
            'https://example.com',
            {'name': 'content-type', 'value': 'text/html'},
        )
        self.assertion.ass('p_url_final_url_is', 'http://example.com', 'https://example.com/')
        self.assertion.ass('p_url_response_time_less_than', 'https://example.com', 200)

    @patch('mangotools.assertion.text._url.requests.Session')
    def test_url_unavailable_accepts_http_error_and_connection_error(self, session_class):
        session_class.return_value.request.return_value = self.response(status_code=404)
        self.assertion.ass('p_url_is_not_accessible', 'https://example.com/not-found')

        session_class.return_value.request.side_effect = requests.ConnectionError('connection refused')
        self.assertion.ass('p_url_is_not_accessible', 'https://example.invalid')

    @patch('mangotools.assertion.text._url.requests.Session')
    def test_url_assertion_failures_are_clear(self, session_class):
        session_class.return_value.request.return_value = self.response()

        with self.assertRaisesRegex(AssertionError, 'URL内容不包含'):
            self.assertion.ass('p_url_content_contains', 'https://example.com', 'missing')
        with self.assertRaisesRegex(AssertionError, '正则表达式无效'):
            self.assertion.ass('p_url_content_matches_regex', 'https://example.com', '[')
        with self.assertRaisesRegex(AssertionError, 'URL格式错误'):
            self.assertion.ass('p_url_is_accessible', 'example.com')

    def test_url_assertions_are_registered_in_one_file_category(self):
        content_group = next(group for group in func_info if group.get('value') == '内容断言')
        url_group = next(
            group for group in content_group.get('children', [])
            if group.get('value') == 'URL断言'
        )
        methods = {method.get('value') for method in url_group.get('children', [])}
        self.assertEqual(9, len(methods))
        self.assertIn('p_url_is_accessible', methods)
        self.assertIn('p_url_content_contains', methods)


if __name__ == '__main__':
    unittest.main()
