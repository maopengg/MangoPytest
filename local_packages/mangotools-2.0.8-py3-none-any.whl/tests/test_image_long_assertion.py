import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZIP_DEFLATED, ZipFile

from PIL import Image, ImageDraw

from mangotools.assertion import MangoAssertion


class TestImageLongAssertion(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.assertion = MangoAssertion()
        self.options = {'交付模式': 'long', '图片格式': 'png'}
        self.width, self.height = 30, 34
        self.ranges = [{'起始行': start, '结束行': end} for start, end in ((0, 10), (12, 22), (24, 34))]
        self.baseline = self.image('baseline')

    def image(self, name, order=(0, 1, 2), *, size=None, gap_mark=False, encoding='PNG'):
        path = self.root / f'{name}.png'
        with Image.new('RGB', size or (self.width, self.height), 'white') as image:
            draw = ImageDraw.Draw(image)
            for page, region in zip(order, self.ranges):
                x = 2 + page * 8
                y = region['起始行'] + 1
                draw.rectangle((x, y, x + 3, y + 3), fill='red')
            if gap_mark:
                draw.point((3, 11), fill='black')
            image.save(path, format=encoding)
        return str(path)

    def validate(self, actual, **options):
        return self.assertion.ass('assert_image_artifact_valid', actual, {
            **self.options, '预期宽度': self.width, '预期高度': self.height, **options,
        })

    def compare(self, actual, **options):
        return self.assertion.ass('assert_image_visual_match', {'文件路径': actual}, {
            **self.options, '基准文件路径': self.baseline, '预期页数': 3, '页面区间': self.ranges, **options,
        })

    def test_validate_true_image_encoding_and_canvas_geometry(self):
        self.assertIn('30×34px', self.validate(self.baseline))
        with self.assertRaisesRegex(AssertionError, '实际长图尺寸不一致'):
            self.validate(self.image('cropped', size=(30, 33)))
        with self.assertRaisesRegex(AssertionError, '真实编码为 JPEG'):
            self.validate(self.image('renamed', encoding='JPEG'))
        with self.assertRaisesRegex(ValueError, '必须同时填写'):
            self.assertion.ass('assert_image_artifact_valid', self.baseline, self.options)

    def test_accept_baseline_geometry_and_reject_invalid_page_ranges(self):
        self.assertIn('页面区间数=3', self.compare(self.baseline))
        with self.assertRaisesRegex(ValueError, '区间数量'):
            self.compare(self.baseline, 预期页数=4)
        with self.assertRaisesRegex(ValueError, '顺序错误、重叠或为空'):
            self.compare(self.baseline, 页面区间=list(reversed(self.ranges)))
        with self.assertRaisesRegex(AssertionError, '结束行超出长图高度'):
            self.compare(self.baseline, 页面区间=[*self.ranges[:2], {'起始行': 24, '结束行': 35}])

    def test_swap_pages_and_report_long_image_coordinates(self):
        wrong = self.image('wrong-order', (0, 2, 1))
        self.assertIn('通过', self.validate(wrong))
        with self.assertRaisesRegex(AssertionError, r'第2页（Y=\[12, 22\)）.*第3页') as failure:
            self.compare(wrong, 输出目录=str(self.root / 'reports'))
        path = Path(str(failure.exception).split('报告=', 1)[1])
        report = json.loads(path.read_text(encoding='utf-8'))
        self.assertEqual(report['actual_size'], [30, 34])
        self.assertEqual([item['color_difference_pixels'] for item in report['pages']], [0, 32, 32])
        self.assertEqual(report['pages'][1]['bounds'], [0, 12, 30, 22])
        with Image.open(report['pages'][1]['diff_image']) as diff:
            self.assertEqual(diff.size, (30, 10))
            self.assertEqual(diff.getpixel((10, 1)), (220, 40, 40))

    def test_gap_difference_is_checked_outside_page_ranges(self):
        changed = self.image('changed-gap', gap_mark=True)
        with self.assertRaisesRegex(AssertionError, r'页面间隔（Y=\[10, 12\)）'):
            self.compare(changed)

    def test_zip_reference_infers_numeric_page_order_varied_sizes_and_centering(self):
        reference = self.root / 'reference.zip'
        with ZipFile(reference, 'w', compression=ZIP_DEFLATED) as archive:
            for name, size, color in (('page-002.png', (30, 12), 'blue'), ('page-1.png', (17, 10), 'red')):
                with Image.new('RGB', size, color) as image, io.BytesIO() as data:
                    image.save(data, format='PNG')
                    archive.writestr(name, data.getvalue())

        correct = self.root / 'inferred.png'
        bad_margin = self.root / 'margin.png'
        bad_size = self.root / 'size.png'
        with Image.new('RGB', (30, 38), 'white') as image:
            draw = ImageDraw.Draw(image)
            draw.rectangle((6, 0, 22, 9), fill='red')
            draw.rectangle((0, 26, 29, 37), fill='blue')
            image.save(correct)
            draw.point((0, 3), fill='black')
            image.save(bad_margin)
            with image.crop((0, 0, 30, 37)) as clipped:
                clipped.save(bad_size)

        options = {**self.options, '基准分页ZIP路径': str(reference), '输出目录': str(self.root / 'reports')}
        message = self.assertion.ass('assert_image_visual_match', str(correct), options)
        report = json.loads(Path(message.split('报告=', 1)[1]).read_text(encoding='utf-8'))
        self.assertEqual(report['layout_source'], 'baseline_zip')
        self.assertEqual(report['expected_size'], [30, 38])
        self.assertEqual([p['content_bounds'] for p in report['pages']], [[6, 0, 23, 10], [0, 26, 30, 38]])
        self.assertEqual([g['row_range'] for g in report['gaps']], [[10, 26]])
        with self.assertRaisesRegex(AssertionError, r'第1页.*差异像素数=1'):
            self.assertion.ass('assert_image_visual_match', str(bad_margin), options)
        with self.assertRaisesRegex(AssertionError, '实际长图尺寸不一致'):
            self.assertion.ass('assert_image_visual_match', str(bad_size), options)
        with self.assertRaisesRegex(ValueError, '不能同时填写'):
            self.assertion.ass('assert_image_visual_match', str(correct), {**options, '页面区间': self.ranges})

    def test_zip_reference_projects_scaled_pages_and_detects_regional_swap(self):
        reference = self.root / 'scaled-reference.zip'
        colors = ('red', 'blue')
        with ZipFile(reference, 'w', compression=ZIP_DEFLATED) as archive:
            for number, color in enumerate(colors, 1):
                with Image.new('RGB', (80, 64), color) as image, io.BytesIO() as data:
                    image.save(data, format='PNG')
                    archive.writestr(f'page-{number:03d}.png', data.getvalue())

        actual = self.root / 'scaled.png'
        wrong = self.root / 'scaled-swapped.png'
        cropped = self.root / 'scaled-cropped.png'
        for path, order in ((actual, colors), (wrong, colors[::-1])):
            with Image.new('RGB', (51, 98), 'white') as image:
                image.paste(order[0], (0, 0, 51, 41))
                image.paste(order[1], (0, 57, 51, 98))
                image.save(path)
                if path == actual:
                    with image.crop((0, 0, 51, 97)) as shortened:
                        shortened.save(cropped)

        options = {**self.options, '基准分页ZIP路径': str(reference), '输出目录': str(self.root / 'reports')}
        with patch('mangotools.assertion.visual._image_long.MAX_LONG_EDGE', 100):
            message = self.assertion.ass('assert_image_visual_match', str(actual), options)
            with self.assertRaisesRegex(AssertionError, r'第1页（Y=\[0, 41\)）.*第2页（Y=\[57, 98\)）'):
                self.assertion.ass('assert_image_visual_match', str(wrong), options)
            with self.assertRaisesRegex(AssertionError, '实际长图尺寸不一致'):
                self.assertion.ass('assert_image_visual_match', str(cropped), options)
        report = json.loads(Path(message.split('报告=', 1)[1]).read_text(encoding='utf-8'))
        self.assertEqual(report['estimated_render_scale'], 82 / 128)
        self.assertEqual(report['projected_page_sizes'], [[51, 41], [51, 41]])
        self.assertEqual([page['row_range'] for page in report['pages']], [[0, 41], [57, 98]])
        self.assertEqual([gap['row_range'] for gap in report['gaps']], [[41, 57]])

    def test_zip_reference_rejects_scaling_below_service_limit(self):
        reference = self.root / 'over-limit.zip'
        with ZipFile(reference, 'w', compression=ZIP_DEFLATED) as archive:
            with Image.new('RGB', (1, 40000), 'white') as image, io.BytesIO() as data:
                image.save(data, format='PNG')
                for number in (1, 2):
                    archive.writestr(f'page-{number:03d}.png', data.getvalue())
        with self.assertRaisesRegex(AssertionError, '低于服务长图下限'):
            self.assertion.ass('assert_image_visual_match', self.baseline,
                               {**self.options, '基准分页ZIP路径': str(reference)})
