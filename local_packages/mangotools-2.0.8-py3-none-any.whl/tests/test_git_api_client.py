import unittest
from unittest.mock import Mock, patch

from mangotools.git.exceptions import GIT_ERROR_MISSING_TOKEN, GIT_ERROR_UNAUTHORIZED, GitToolsError
from mangotools.git.models import GitFileInfo, GitProviderConfig
from mangotools.git.providers.gitee import GiteeApiClient
from mangotools.git.providers.github import GitHubApiClient
from mangotools.git.providers.gitlab import GitLabApiClient


class PublicGitApiClientTests(unittest.TestCase):
    def test_gitee_public_snapshot_reports_token_requirement(self):
        client = GiteeApiClient(GitProviderConfig(
            provider='gitee', base_url='https://git.example.com',
            access_token='', default_project='example/repository',
        ))
        with patch.object(client, '_request_raw', side_effect=GitToolsError(*GIT_ERROR_UNAUTHORIZED)):
            with self.assertRaises(GitToolsError) as error:
                client.download_archive('abc123')

        self.assertEqual(error.exception.code, GIT_ERROR_MISSING_TOKEN[0])

    def test_gitee_update_file_sends_base64_content_and_blob_sha(self):
        client = GiteeApiClient(GitProviderConfig(
            provider='gitee', base_url='https://git.example.com',
            access_token='placeholder', default_project='example/repository',
        ))
        existing = GitFileInfo(file_path='tests/test_example.py', content='old', commit_hash='blob123')
        with patch.object(client, 'get_file', return_value=existing), patch.object(client, '_request') as request:
            client.upsert_file('tests/test_example.py', 'new', 'main', 'Update example')

        self.assertEqual(request.call_args.args[0], 'PUT')
        self.assertEqual(request.call_args.kwargs['data']['content'], 'bmV3')
        self.assertEqual(request.call_args.kwargs['data']['sha'], 'blob123')

    @patch('mangotools.git.providers.base.requests.request')
    def test_gitee_public_repository_request_has_no_token(self, request):
        request.return_value = Mock(
            status_code=200,
            content=b'{}',
            headers={'content-type': 'application/json'},
            json=lambda: {'full_name': 'example/repository'},
        )
        client = GiteeApiClient(GitProviderConfig(
            provider='gitee', base_url='https://git.example.com',
            access_token='', default_project='example/repository',
        ))

        client.get_project()

        self.assertEqual(request.call_args.kwargs['headers'], {})
        self.assertEqual(request.call_args.kwargs['params'], {})

    @patch('mangotools.git.providers.base.requests.request')
    def test_gitlab_public_branch_request_has_no_private_token(self, request):
        request.return_value = Mock(
            status_code=200,
            content=b'{}',
            headers={'content-type': 'application/json'},
            json=lambda: {'name': 'main', 'commit': {'id': 'abc123'}},
        )
        client = GitLabApiClient(GitProviderConfig(
            provider='gitlab', base_url='https://git.example.com',
            access_token='', default_project='example/repository',
        ))

        branch = client.get_branch('main')

        self.assertEqual(branch.commit_hash, 'abc123')
        self.assertEqual(request.call_args.kwargs['headers'], {})

    @patch('mangotools.git.providers.base.requests.request')
    def test_github_basic_auth_is_only_used_when_credentials_exist(self, request):
        request.return_value = Mock(
            status_code=200,
            content=b'{}',
            headers={'content-type': 'application/json'},
            json=lambda: {'name': 'main', 'commit': {'sha': 'abc123'}},
        )
        client = GitHubApiClient(GitProviderConfig(
            provider='github', base_url='https://api.example.com',
            access_token='', username='example', password='placeholder',
            default_project='example/repository',
        ))

        branch = client.get_branch('main')

        self.assertEqual(branch.commit_hash, 'abc123')
        self.assertTrue(request.call_args.kwargs['headers']['Authorization'].startswith('Basic '))


if __name__ == '__main__':
    unittest.main()
