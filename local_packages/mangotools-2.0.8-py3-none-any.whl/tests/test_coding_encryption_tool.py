import base64
import hashlib
import hmac
import json
import unittest
import zlib

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from mangotools.data_processor import DataProcessor
from mangotools.decorator import get_data_method_info
from mangotools.exceptions import MangoToolsError


class TestCodingEncryptionTool(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.private_key = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode()
        cls.public_key = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()

    def setUp(self):
        self.processor = DataProcessor()

    def test_security_method_groups(self):
        security_group = next(item for item in get_data_method_info() if item['value'] == 'security')
        class_names = {item['value'] for item in security_group['children']}
        self.assertEqual(
            class_names,
            {
                '编码与解码',
                '压缩与解压',
                '摘要与哈希',
                '消息认证',
                '令牌与JWT',
                '加密与解密',
                '非对称加密',
                '签名与验签',
            },
        )

    def test_base64_methods_and_legacy_compatibility(self):
        self.assertEqual(self.processor.base64_encode('abc'), 'ImFiYyI=')
        self.assertEqual(self.processor.base64_text_encode('abc'), 'YWJj')
        self.assertEqual(self.processor.base64_decode('YWJj'), 'abc')
        encoded = self.processor.base64_urlsafe_encode('芒果+/')
        self.assertNotIn('=', encoded)
        self.assertEqual(self.processor.base64_urlsafe_decode(encoded), '芒果+/')

    def test_url_hex_and_unicode_methods(self):
        text = '芒果 test+1'
        self.assertEqual(self.processor.url_decode(self.processor.url_encode(text)), text)
        self.assertEqual(self.processor.hex_decode(self.processor.hex_encode(text)), text)
        escaped = self.processor.unicode_escape_encode('芒果')
        self.assertEqual(escaped, r'\u8292\u679c')
        self.assertEqual(self.processor.unicode_escape_decode(escaped), '芒果')
        self.assertEqual(self.processor.response_decoding(escaped), '芒果')

    def test_additional_encoding_and_form_methods(self):
        text = '芒果 API <test>'
        self.assertEqual(self.processor.base32_decode(self.processor.base32_encode(text)), text)
        self.assertEqual(self.processor.base85_decode(self.processor.base85_encode(text)), text)
        self.assertEqual(self.processor.html_unescape(self.processor.html_escape(text)), text)

        encoded = self.processor.form_urlencode('{"name":"mango","roles":["admin","tester"]}')
        self.assertEqual(encoded, 'name=mango&roles=admin&roles=tester')
        self.assertEqual(
            json.loads(self.processor.form_urldecode(encoded)),
            {'name': ['mango'], 'roles': ['admin', 'tester']},
        )
        basic_auth = self.processor.basic_auth_encode('mango', 'secret')
        self.assertEqual(self.processor.basic_auth_decode(basic_auth), 'mango:secret')

    def test_compression_methods(self):
        text = '{"name":"芒果","enabled":true}'
        self.assertEqual(self.processor.gzip_decompress_base64(self.processor.gzip_compress_base64(text)), text)
        self.assertEqual(self.processor.zlib_decompress_base64(self.processor.zlib_compress_base64(text)), text)

    def test_hash_methods(self):
        data = '123456'
        self.assertEqual(self.processor.sha224(data), hashlib.sha224(data.encode()).hexdigest())
        self.assertEqual(self.processor.sha256(data), hashlib.sha256(data.encode()).hexdigest())
        self.assertEqual(self.processor.sha384(data), hashlib.sha384(data.encode()).hexdigest())
        self.assertEqual(self.processor.sha512(data), hashlib.sha512(data.encode()).hexdigest())
        self.assertEqual(self.processor.sm3(data), hashlib.new('sm3', data.encode()).hexdigest())
        self.assertEqual(self.processor.crc32(data), f'{zlib.crc32(data.encode()) & 0xffffffff:08x}')

    def test_hmac_methods(self):
        data = 'payload'
        key = 'secret'
        for algorithm in ('md5', 'sha256', 'sha512'):
            expected = hmac.new(key.encode(), data.encode(), digestmod=algorithm).hexdigest()
            self.assertEqual(getattr(self.processor, f'hmac_{algorithm}')(data, key), expected)
        expected_sha384 = hmac.new(key.encode(), data.encode(), digestmod='sha384').hexdigest()
        self.assertEqual(self.processor.hmac_sha384(data, key), expected_sha384)
        expected_base64 = base64.b64encode(hmac.new(key.encode(), data.encode(), digestmod='sha256').digest()).decode()
        self.assertEqual(self.processor.hmac_sha256_base64(data, key), expected_base64)

    def test_expression_execution(self):
        self.assertEqual(self.processor.regular('base64_text_encode(abc)'), 'YWJj')
        self.assertEqual(
            self.processor.regular('sha256(123456)'),
            hashlib.sha256(b'123456').hexdigest(),
        )
        self.assertEqual(self.processor.regular('base64_decode(YQ==)'), 'a')
        self.assertEqual(
            self.processor.regular('form_urlencode({"name":"mango","roles":["admin","tester"]})'),
            'name=mango&roles=admin&roles=tester',
        )
        self.assertEqual(
            self.processor.regular('hmac_sha256(data=payload,key=secret)'),
            hmac.new(b'secret', b'payload', digestmod='sha256').hexdigest(),
        )
        self.assertEqual(
            self.processor.regular('hmac_sha256("payload,part","secret=key")'),
            hmac.new(b'secret=key', b'payload,part', digestmod='sha256').hexdigest(),
        )
        self.assertEqual(
            self.processor.replace('${{form_urlencode({"name":"mango","roles":["admin","tester"]})}}'),
            'name=mango&roles=admin&roles=tester',
        )
        jwt_token = self.processor.replace(
            '${{jwt_hs256_encode({"sub":"1001","context":{"role":"admin"}},secret)}}'
        )
        self.assertEqual(
            json.loads(self.processor.jwt_hs256_decode(jwt_token, 'secret')),
            {'context': {'role': 'admin'}, 'sub': '1001'},
        )

    def test_jwt_hs256_methods(self):
        token = self.processor.jwt_hs256_encode('{"sub":"1001","name":"芒果"}', 'secret')
        self.assertEqual(
            json.loads(self.processor.jwt_hs256_decode(token, 'secret')),
            {'name': '芒果', 'sub': '1001'},
        )
        with self.assertRaises(MangoToolsError) as context:
            self.processor.jwt_hs256_decode(token, 'wrong-secret')
        self.assertEqual(context.exception.code, 3032)

    def test_aes_methods(self):
        data = '芒果 API payload'
        key = '1234567890abcdef'
        iv = 'abcdef1234567890'

        cbc = self.processor.aes_cbc_encrypt(data, key, iv)
        self.assertEqual(self.processor.aes_cbc_decrypt(cbc, key, iv), data)
        gcm = self.processor.aes_gcm_encrypt(data, key, 'request-id')
        self.assertEqual(self.processor.aes_gcm_decrypt(gcm, key, 'request-id'), data)

        with self.assertRaises(MangoToolsError) as context:
            self.processor.aes_cbc_encrypt(data, 'short-key', iv)
        self.assertEqual(context.exception.code, 3029)

    def test_rsa_encryption_signing_and_jwt_methods(self):
        data = '芒果 API payload'
        oaep = self.processor.rsa_oaep_encrypt(data, self.public_key)
        self.assertEqual(self.processor.rsa_oaep_decrypt(oaep, self.private_key), data)

        signature = self.processor.rsa_pss_sign(data, self.private_key)
        self.assertTrue(self.processor.rsa_pss_verify(data, signature, self.public_key))
        with self.assertRaises(MangoToolsError) as context:
            self.processor.rsa_pss_verify(f'{data}-changed', signature, self.public_key)
        self.assertEqual(context.exception.code, 3032)

        token = self.processor.jwt_rs256_encode('{"sub":"1001","name":"芒果"}', self.private_key)
        self.assertEqual(
            json.loads(self.processor.jwt_rs256_decode(token, self.public_key)),
            {'name': '芒果', 'sub': '1001'},
        )

    def test_decode_error_is_business_error(self):
        with self.assertRaises(MangoToolsError) as context:
            self.processor.base64_decode('not-base64')
        self.assertEqual(context.exception.code, 3026)

    def test_replace_preserves_cached_types_and_dict_keys(self):
        self.processor.set_cache('empty_value', '')
        self.processor.set_cache('null_value', None)
        self.processor.set_cache('query_key', 'user_id_type')
        self.processor.set_cache('contract_id', 1071830070739337582)
        self.processor.set_cache('user_ids', ['dg8689b9'])

        self.assertEqual(self.processor.replace('${{empty_value}}'), '')
        self.assertEqual(self.processor.replace('${{null_value}}'), '')
        self.assertEqual(self.processor.replace('${{user_ids}}'), ['dg8689b9'])
        self.assertEqual(
            self.processor.replace({'${{query_key}}': 'user_id'}),
            {'user_id_type': 'user_id'},
        )
        replaced = self.processor.replace(
            '{"contract_id": "${{contract_id}}", "user_ids": "${{user_ids}}"}'
        )
        self.assertEqual(
            json.loads(replaced),
            {'contract_id': 1071830070739337582, 'user_ids': ['dg8689b9']},
        )

    def test_set_sql_cache_uses_names_then_column_order(self):
        self.processor.set_sql_cache('id,name', {'name': 'mango', 'id': 21})
        self.assertEqual(self.processor.get_cache('id'), 21)
        self.assertEqual(self.processor.get_cache('name'), 'mango')

        self.processor.set_sql_cache('id,name', {'id': 22, 'neme': 'qfei'})
        self.assertEqual(self.processor.get_cache('id'), 22)
        self.assertEqual(self.processor.get_cache('name'), 'qfei')

        self.processor.set_sql_cache('user', {'id': 23, 'name': 'single'})
        self.assertEqual(self.processor.get_cache('user'), 23)


if __name__ == '__main__':
    unittest.main()
