import io
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from PIL import Image, ImageDraw

from mangotools.assertion import MangoAssertion
from mangotools.decorator import func_info


class TestImageZipAssertion(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.assertion = MangoAssertion()
        self.pages = [self.page(x) for x in (5, 20, 35)]
        self.baseline = self.zip('baseline', self.entries(self.pages))

    def page(self, x, *, size=(50, 30), color='red', encoding='PNG'):
        with Image.new('RGB', size, 'white') as image, io.BytesIO() as data:
            if x is not None:
                ImageDraw.Draw(image).rectangle((x, 5, x + 4, 10), fill=color)
            image.save(data, format=encoding)
            return data.getvalue()

    def entries(self, pages, extension='png'):
        return [(f'page-{number:03d}.{extension}', data) for number, data in enumerate(pages, 1)]

    def zip(self, name, entries):
        path = self.root / f'{name}.zip'
        with ZipFile(path, 'w', compression=ZIP_DEFLATED) as archive:
            for member, data in entries:
                archive.writestr(member, data)
        return str(path)

    def validate(self, path, **options):
        return self.assertion.ass('assert_image_artifact_valid', {'文件路径': path},
                                  {'图片格式': 'png', '预期页数': 3, **options})

    def compare(self, path, **options):
        return self.assertion.ass('assert_image_visual_match', path,
                                  {'基准文件路径': self.baseline, '图片格式': 'png', **options})

    def test_registration_and_png_comparison_by_numeric_page(self):
        category = next(item for item in func_info if item['value'] == '文件视觉识别')
        group = next(item for item in category['children'] if item['value'] == '图片产物断言')
        self.assertEqual({item['value'] for item in group['children']},
                         {'assert_image_artifact_valid', 'assert_image_visual_match'})
        a, b, c = self.pages
        actual = self.zip('out-of-entry-order', [('page-003.png', c), ('page-1.png', a), ('page-002.png', b)])
        self.assertIn('页数=3', self.validate(actual))
        self.assertIn('页数=3', self.assertion.ass('assert_image_visual_match',
            json.dumps({'文件路径': actual}), json.dumps({'图片格式': 'png', '基准文件路径': self.baseline})))

    def test_jpg_identity_and_optional_expected_count(self):
        path = self.zip('jpeg', self.entries([self.page(5, encoding='JPEG')], 'jpg'))
        self.assertIn('页数=1', self.validate(path, 图片格式='jpg', 预期页数=1))
        self.assertIn('通过', self.compare(path, 基准文件路径=path, 图片格式='jpg'))
        with self.assertRaisesRegex(AssertionError, '基准ZIP页数不一致'):
            self.compare(path, 基准文件路径=path, 图片格式='jpg', 预期页数=2)

    def test_missing_page_duplicate_number_and_wrong_member_format(self):
        entries = self.entries(self.pages)
        for name, members, error in (
            ('missing-tail', entries[:2], '页数不一致'),
            ('missing-middle', [entries[0], entries[2]], '页号不连续'),
            ('duplicate', [*entries, ('page-1.png', self.pages[0])], '页号重复'),
            ('wrong-extension', [('page-001.jpg', self.pages[0])], '非预期条目'),
            ('unexpected-member', [*entries, ('other.png', self.pages[0])], '非预期条目'),
        ):
            with self.subTest(name=name), self.assertRaisesRegex(AssertionError, error):
                self.validate(self.zip(name, members))

    def test_renamed_or_truncated_images_and_non_zip(self):
        for name, payload, error in (
            ('renamed-jpeg', self.page(5, encoding='JPEG'), '真实编码为 JPEG'),
            ('renamed-pdf', b'%PDF-1.7\n', '无法解码'),
            ('truncated-png', self.pages[0][:-24], '无法解码'),
        ):
            with self.subTest(name=name), self.assertRaisesRegex(AssertionError, f'第2页.*{error}'):
                path = self.zip(name, self.entries([self.pages[0], payload, self.pages[2]]))
                self.validate(path)
        fake = self.root / 'fake.zip'
        fake.write_bytes(self.pages[0])
        with self.assertRaisesRegex(AssertionError, '无法作为ZIP打开'):
            self.validate(str(fake))

    def test_content_order_duplicate_content_and_crop(self):
        a, b, c = self.pages
        for name, pages, error in (
            ('swapped-content', [b, a, c], '第1页.*颜色差异'),
            ('repeated-content', [a, a, c], '第2页.*颜色差异'),
            ('cropped-canvas', [a, self.page(20, size=(40, 30)), c], '第2页尺寸或方向'),
            ('cropped-content', [a, self.page(None), c], '第2页异常空白'),
        ):
            with self.subTest(name=name), self.assertRaisesRegex(AssertionError, error):
                self.compare(self.zip(name, self.entries(pages)))

    def test_color_difference_report_and_per_page_pixel_cap(self):
        a, _, c = self.pages
        actual = self.zip('changed-color', self.entries([a, self.page(20, color='blue'), c]))
        with self.assertRaisesRegex(AssertionError, '第2页.*差异像素数=30') as failure:
            self.compare(actual, 输出目录=str(self.root / 'reports'))
        path = Path(str(failure.exception).split('报告=', 1)[1])
        report = json.loads(path.read_text(encoding='utf-8'))
        self.assertFalse(report['passed'])
        self.assertEqual([page['color_difference_pixels'] for page in report['pages']], [0, 30, 0])
        with Image.open(report['pages'][1]['diff_image']) as diff:
            self.assertEqual(diff.getpixel((20, 5)), (220, 40, 40))
            self.assertEqual(diff.getpixel((0, 0)), (255, 255, 255))
        self.assertIn('通过', self.compare(actual, 最大颜色差异像素数=30))
        with self.assertRaisesRegex(AssertionError, '第2页.*颜色差异'):
            self.compare(actual, 最大颜色差异率=1, 最大颜色差异像素数=29)
