import os
import tempfile
import unittest

from openpyxl import Workbook

from mangotools.assertion import MangoAssertion
from mangotools.decorator import func_info


class TestExcelAssertionUnit(unittest.TestCase):

    def setUp(self):
        file_handle, self.file_path = tempfile.mkstemp(suffix='.xlsx')
        os.close(file_handle)
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = '数据'
        sheet.append(['编号', '名称', '状态'])
        sheet.append([1, '合同', '完成'])
        workbook.save(self.file_path)
        workbook.close()

    def tearDown(self):
        if os.path.exists(self.file_path):
            os.unlink(self.file_path)

    def test_column_count_accepts_form_string_value(self):
        message = MangoAssertion().ass(
            'assert_excel_column_count',
            {'文件路径': self.file_path, '工作表': '数据'},
            {'预期列数': '3'},
        )

        self.assertIn('实际=3', message)
        self.assertIn('预期=3', message)

    def test_column_count_metadata_matches_runtime_key(self):
        file_group = next(item for item in func_info if item['value'] == '文件断言')
        excel_group = next(item for item in file_group['children'] if item['value'] == 'Excel断言')
        method = next(
            item for item in excel_group['children']
            if item['value'] == 'assert_excel_column_count'
        )
        expect = next(item for item in method['parameter'] if item['f'] == 'expect')

        self.assertEqual(expect['v'], {'预期列数': '请输入期望列数'})


if __name__ == '__main__':
    unittest.main()
