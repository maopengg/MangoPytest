import os
import sys

# 添加当前目录到Python路径，确保在虚拟环境中也能找到mangotools模块
current_dir = os.path.dirname(os.path.abspath(__file__))
project_dir = os.path.join(current_dir, '..')
sys.path.insert(0, os.path.abspath(project_dir))

# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-01-30 10:30
# @Author : 毛鹏
import unittest
from unittest.mock import Mock, patch

from mangotools.models import EmailNoticeModel, TestReportModel, WeChatNoticeModel, FeiShuNoticeModel
from mangotools.notice._mail_send import EmailSend
from mangotools.notice._wechat_send import WeChatSend
from mangotools.notice._feishu_send import FeiShuSend


class TestNotice(unittest.TestCase):

    def setUp(self):
        # 邮件配置
        self.email_config = EmailNoticeModel(
            send_user='sender@example.com',
            email_host='smtp.example.com',
            stamp_key='example-stamp-key',
            send_list=['receiver@example.com']
        )
        
        # 企业微信配置
        self.wechat_config = WeChatNoticeModel(
            webhook='https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=11491e1a-11db-4b17-8eff-dd5a4c6ccdf2'
        )
        
        # 飞书配置
        self.feishu_config = FeiShuNoticeModel(
            webhook=os.getenv(
                'MANGO_FEISHU_WEBHOOK',
                'https://open.feishu.cn/open-apis/bot/v2/hook/0b73243f-6eb5-40ab-bca2-1bcb510923d7'
            )
        )
        
        # 测试报告数据
        self.test_report = TestReportModel(
            test_suite_id=1,
            task_name='测试任务',
            project_name='芒果测试平台',
            product_name='测试产品',
            test_environment='生产环境',
            case_sum=10,
            api_case_sum=5,
            api_fail=1,
            ui_case_sum=3,
            ui_fail=0,
            pytest_case_sum=2,
            pytest_fail=0,
            success=8,
            success_rate=80.0,
            warning=1,
            fail=1,
            execution_duration='10秒',
            test_time='2025-01-30 10:30:00'
        )

    def test_email_send(self):
        """测试邮件发送功能"""
        email_sender = EmailSend(
            notice_config=self.email_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        # 注意：实际运行时需要真实的邮箱配置和网络连接
        # 这里主要是验证代码逻辑无误
        try:
            email_sender.send_main()
            print("邮件发送功能初始化正常")
            self.assertTrue(True)
        except Exception as e:
            print(f"邮件发送出错: {e}")
            # 不抛出异常，因为在测试环境中可能无法连接邮箱服务器
            self.assertTrue(True)

    def test_email_send_test_report_html_real(self):
        """使用真实邮箱配置发送 HTML 测试报告邮件"""
        email_sender = EmailSend(
            notice_config=self.email_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        email_sender.send_main()
        print("真实 HTML 测试报告邮件发送完成")

    def test_wechat_send(self):
        """测试企业微信发送功能"""
        wechat_sender = WeChatSend(
            notice_config=self.wechat_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        # 注意：实际运行时需要真实的企业微信webhook配置
        try:
            wechat_sender.send_wechat_notification() 
            print("企业微信发送功能初始化正常")
            self.assertTrue(True)
        except Exception as e:
            print(f"企业微信发送出错: {e}")
            # 不抛出异常，因为在测试环境中webhook可能无效
            self.assertTrue(True)

    def test_feishu_send(self):
        """测试飞书发送功能"""
        feishu_sender = FeiShuSend(
            notice_config=self.feishu_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        # 注意：实际运行时需要真实的飞书webhook配置
        try:
            feishu_sender.send_feishu_notification()  
            print("飞书发送功能初始化正常")
            self.assertTrue(True)
        except Exception as e:
            print(f"飞书发送出错: {e}")
            # 不抛出异常，因为在测试环境中webhook可能无效
            self.assertTrue(True)

    def test_feishu_build_test_report_card(self):
        """测试飞书自动化测试报告卡片内容"""
        feishu_sender = FeiShuSend(
            notice_config=self.feishu_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        card = feishu_sender.build_test_report_card()

        self.assertEqual(card['header']['template'], 'red')
        self.assertIn('自动化测试报告', card['header']['title']['content'])
        self.assertTrue(card['config']['wide_screen_mode'])
        self.assertIn('非测试人员可忽略告警用例', str(card))
        self.assertEqual(card['elements'][-1]['tag'], 'action')
        self.assertEqual(card['elements'][-1]['actions'][0]['url'], 'http://mango-test-platform.com')

    def test_email_build_test_report_html(self):
        """测试邮件自动化测试报告 HTML 内容"""
        email_sender = EmailSend(
            notice_config=self.email_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        content = email_sender.build_test_report_html()

        print(content)
        self.assertIn('芒果测试平台自动化测试报告', content)
        self.assertIn('芒果测试平台 / 测试产品', content)
        self.assertIn('成功率', content)
        self.assertIn('80%', content)
        self.assertIn('非测试人员可忽略告警用例', content)
        self.assertIn('查看完整测试报告', content)

    @patch.object(EmailSend, 'send_mail')
    def test_email_send_test_report_html(self, mock_send_mail):
        """测试邮件测试报告发送时使用 HTML 模板"""
        email_sender = EmailSend(
            notice_config=self.email_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        email_sender.send_main()

        args, kwargs = mock_send_mail.call_args
        self.assertEqual(args[0], '测试报告通知')
        self.assertIn('芒果测试平台自动化测试报告', args[1])
        self.assertEqual(kwargs['subtype'], 'html')

    def test_wechat_build_test_report_markdown(self):
        """测试企业微信自动化测试报告 markdown 内容"""
        wechat_sender = WeChatSend(
            notice_config=self.wechat_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        content = wechat_sender.build_test_report_markdown()

        print(content)
        self.assertIn('芒果测试平台自动化测试报告', content)
        self.assertIn('**项目产品：** 芒果测试平台 / 测试产品', content)
        self.assertIn('**测试环境：** 生产环境', content)
        self.assertIn('**成功率：** <font color="warning">80%</font>', content)
        self.assertIn('**接口用例：** 5 个，失败 <font color="warning">1</font> 个', content)
        self.assertIn(
            '**告警用例：** <font color="warning">1</font>（非测试人员可忽略告警用例）',
            content,
        )
        self.assertIn('[查看测试报告](http://mango-test-platform.com)', content)

    def test_warning_ignore_note_is_hidden_when_warning_is_zero(self):
        report = self.test_report.model_copy(update={'warning': 0})
        email_content = EmailSend(self.email_config, report).build_test_report_html()
        wechat_content = WeChatSend(self.wechat_config, report).build_test_report_markdown()
        feishu_card = FeiShuSend(self.feishu_config, report).build_test_report_card()

        self.assertNotIn('非测试人员可忽略告警用例', email_content)
        self.assertNotIn('非测试人员可忽略告警用例', wechat_content)
        self.assertNotIn('非测试人员可忽略告警用例', str(feishu_card))

    @patch('mangotools.notice._wechat_send.requests.post')
    def test_wechat_send_test_report_markdown_payload(self, mock_post):
        """测试企业微信测试报告 markdown payload"""
        mock_response = Mock()
        mock_response.json.return_value = {'errcode': 0}
        mock_post.return_value = mock_response

        wechat_sender = WeChatSend(
            notice_config=self.wechat_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        wechat_sender.send_wechat_notification()

        payload = mock_post.call_args.kwargs['json']
        self.assertEqual(payload['msgtype'], 'markdown')
        self.assertIn('芒果测试平台自动化测试报告', payload['markdown']['content'])
        self.assertIn('**项目产品：**', payload['markdown']['content'])
        self.assertIn('**执行耗时：**', payload['markdown']['content'])

    @patch('mangotools.notice._feishu_send.requests.post')
    def test_feishu_send_test_report_card(self, mock_post):
        """测试飞书自动化测试报告卡片发送 payload"""
        mock_response = Mock()
        mock_response.json.return_value = {'code': 0}
        mock_post.return_value = mock_response

        feishu_sender = FeiShuSend(
            notice_config=self.feishu_config,
            test_report=self.test_report,
            domain_name='http://mango-test-platform.com'
        )
        feishu_sender.send_test_report_card()

        payload = mock_post.call_args.kwargs['json']
        self.assertEqual(payload['msg_type'], 'interactive')
        self.assertEqual(payload['card']['header']['template'], 'red')
        self.assertIn('芒果测试平台自动化测试报告', payload['card']['header']['title']['content'])
        self.assertIn('项目产品', payload['card']['elements'][0]['text']['content'])

    def test_email_send_with_custom_content(self):
        """测试使用自定义内容发送邮件"""
        custom_content = "这是一封自定义内容的测试邮件"
        email_sender = EmailSend(
            notice_config=self.email_config,
            content=custom_content
        )
        try:
            email_sender.send_main()
            print("自定义内容邮件发送功能初始化正常")
            self.assertTrue(True)
        except Exception as e:
            print(f"自定义内容邮件发送出错: {e}")
            self.assertTrue(True)

    def test_wechat_send_text_message(self):
        """测试企业微信发送文本消息"""
        wechat_sender = WeChatSend(
            notice_config=self.wechat_config,
            content="这是一条测试文本消息"
        )
        try:
            wechat_sender.send_markdown(wechat_sender.content)
            print("企业微信文本消息发送功能初始化正常")
            self.assertTrue(True)
        except Exception as e:
            print(f"企业微信文本消息发送出错: {e}")
            self.assertTrue(True)

    def test_feishu_send_text_message(self):
        """测试飞书发送文本消息"""
        feishu_sender = FeiShuSend(
            notice_config=self.feishu_config,
            content="这是一条飞书测试文本消息"
        )
        try:
            feishu_sender.send_text(feishu_sender.content)
            print("飞书文本消息发送功能初始化正常")
            self.assertTrue(True)
        except Exception as e:
            print(f"飞书文本消息发送出错: {e}")
            self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()
