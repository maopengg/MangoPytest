# -*- coding: utf-8 -*-
import base64
import json
import unittest
from datetime import datetime, timedelta

from mangotools.assertion import MangoAssertion
from mangotools.decorator import func_info


def _jwt_segment(value):
    raw = json.dumps(value, separators=(',', ':')).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip('=')


class TestSemanticAssertion(unittest.TestCase):

    def setUp(self):
        self.assertion = MangoAssertion()

    def ass(self, method, actual, expect=None):
        return self.assertion.ass(method, actual, expect)

    def test_object_parameter_metadata_comes_from_mangotools(self):
        method = next(
            item
            for method_type in func_info
            for method_class in method_type['children']
            for item in method_class['children']
            if item['value'] == 'p_number_close_to'
        )
        parameter = method['parameter'][1]

        self.assertEqual({'value': 10, 'tolerance': 0.01}, parameter['v'])
        self.assertEqual('object', parameter['input_type'])
        self.assertEqual(
            [('value', '目标值'), ('tolerance', '允许误差')],
            [(field['f'], field['n']) for field in parameter['object_fields']],
        )

    def test_numeric_semantic_assertions(self):
        success_cases = [
            ('p_number_equal', 1, '1.0'),
            ('p_number_not_equal', 1, '2'),
            ('p_number_close_to', '10.001', '{"value":10,"tolerance":0.01}'),
            ('p_number_between', 15, '{"min":"10","max":"20"}'),
            ('p_number_not_between', 25, '{"min":10,"max":20}'),
            ('p_is_positive', '1', None),
            ('p_is_negative', '-1', None),
            ('p_is_zero', '0.0', None),
            ('p_is_non_negative', '0', None),
            ('p_is_multiple_of', '10', '5'),
            ('p_decimal_places_equal', '10.25', '2'),
        ]
        for method, actual, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, actual, expect))

        failure_cases = [
            ('p_number_equal', 1, '2'),
            ('p_number_close_to', 11, '{"value":10,"tolerance":0.1}'),
            ('p_number_between', 30, '{"min":10,"max":20}'),
            ('p_is_positive', 0, None),
            ('p_is_multiple_of', 10, 3),
            ('p_decimal_places_equal', '10.2', 2),
        ]
        for method, actual, expect in failure_cases:
            with self.subTest(method=method):
                with self.assertRaises(AssertionError):
                    self.ass(method, actual, expect)

    def test_string_semantic_assertions(self):
        success_cases = [
            ('p_equal_after_trim', ' mango ', 'mango'),
            ('p_equal_after_normalize_whitespace', 'hello\n  mango', 'hello mango'),
            ('p_starts_with_ignoring_case', 'MangoServer', 'mango'),
            ('p_ends_with_ignoring_case', 'report.JSON', '.json'),
            ('p_is_blank', ' \n ', None),
            ('p_is_not_blank', ' mango ', None),
            ('p_occurrence_count_equal', 'a-b-a', '{"text":"a","count":2}'),
            ('p_occurrence_count_at_least', 'a-a-a', '{"text":"a","count":2}'),
            ('p_occurrence_count_at_most', 'a-b', '{"text":"a","count":2}'),
            ('p_string_length_between', 'mango', '{"min":3,"max":10}'),
        ]
        for method, actual, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, actual, expect))

        with self.assertRaises(AssertionError):
            self.ass('p_is_blank', [])
        with self.assertRaises(AssertionError):
            self.ass('p_occurrence_count_equal', 'a', '{"text":"a","count":2}')

    def test_format_assertions(self):
        jwt = '.'.join([
            _jwt_segment({'alg': 'HS256', 'typ': 'JWT'}),
            _jwt_segment({'sub': '1'}),
            base64.urlsafe_b64encode(b'signature').decode().rstrip('='),
        ])
        success_cases = [
            ('p_is_valid_json', '{"id":1}', None),
            ('p_is_valid_email', 'user@test.com', None),
            ('p_is_valid_url', 'https://example.com/a', None),
            ('p_is_valid_ipv4', '192.168.1.1', None),
            ('p_is_valid_ipv6', '2001:db8::1', None),
            ('p_is_valid_uuid', '550e8400-e29b-41d4-a716-446655440000', None),
            ('p_is_valid_base64', 'aGVsbG8=', None),
            ('p_is_valid_jwt', jwt, None),
            ('p_is_valid_phone', '13800138000', None),
            ('p_is_valid_timestamp', '1786233600', None),
            ('p_is_valid_timestamp', '1786233600000', None),
            ('p_is_valid_date', '2026-08-09', '%Y-%m-%d'),
            ('p_is_valid_datetime', '2026-08-09 12:30:00', '%Y-%m-%d %H:%M:%S'),
        ]
        for method, actual, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, actual, expect))

        invalid_cases = [
            ('p_is_valid_json', '{id:1}'),
            ('p_is_valid_email', 'user@'),
            ('p_is_valid_url', 'example.com'),
            ('p_is_valid_ipv4', '999.1.1.1'),
            ('p_is_valid_uuid', 'bad-uuid'),
            ('p_is_valid_base64', '%%%'),
            ('p_is_valid_jwt', 'a.b'),
            ('p_is_valid_phone', '123'),
            ('p_is_valid_timestamp', '123'),
        ]
        for method, actual in invalid_cases:
            with self.subTest(method=method):
                with self.assertRaises(AssertionError):
                    self.ass(method, actual)

    def test_dict_and_jsonpath_assertions(self):
        actual = {'id': 1, 'name': 'mango', 'status': 1, 'user': {'name': 'tester'}}
        success_cases = [
            ('p_has_key', actual, 'id'),
            ('p_does_not_have_key', actual, 'password'),
            ('p_has_all_keys', actual, '["id","name"]'),
            ('p_has_any_key', actual, 'code,id'),
            ('p_has_exact_keys', {'id': 1, 'name': 'mango'}, '["id","name"]'),
            ('p_dict_contains', actual, '{"id":"1","status":1}'),
            ('p_dict_not_contains', actual, '{"status":0}'),
            ('p_all_values_not_none', {'id': 1, 'name': 'mango'}, None),
            ('p_all_values_not_blank', {'id': 1, 'name': 'mango'}, None),
            ('p_json_path_exists', actual, '$.user.name'),
            ('p_json_path_not_exists', actual, '$.user.password'),
            ('p_json_path_not_empty', actual, '$.user.name'),
        ]
        for method, value, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, value, expect))

        with self.assertRaises(AssertionError):
            self.ass('p_has_key', actual, 'password')
        with self.assertRaises(AssertionError):
            self.ass('p_json_path_not_empty', {'name': ''}, '$.name')

    def test_list_assertions(self):
        objects = [{'id': 1, 'name': 'a'}, {'id': 2, 'name': 'b'}]
        success_cases = [
            ('p_list_equal_ordered', [1, 2, 3], '["1",2,3]'),
            ('p_list_equal_unordered', [3, 1, 2], '[1,2,3]'),
            ('p_list_contains_all', [1, 2, 3], '["1",3]'),
            ('p_list_contains_any', [1, 2, 3], '[3,4]'),
            ('p_list_contains_none', [1, 2], '[3,4]'),
            ('p_list_is_unique', [1, 2, 3], None),
            ('p_list_is_sorted_ascending', [1, 2, 3], None),
            ('p_list_is_sorted_descending', [3, 2, 1], None),
            ('p_list_items_not_none', [1, 2, 3], None),
            ('p_list_items_not_blank', ['a', 'b'], None),
            ('p_list_objects_have_key', objects, 'id'),
            ('p_list_objects_have_all_keys', objects, '["id","name"]'),
            ('p_list_field_unique', objects, 'id'),
            ('p_list_field_values_equal', objects, '{"field":"id","values":[2,1]}'),
        ]
        for method, actual, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, actual, expect))

        with self.assertRaises(AssertionError):
            self.ass('p_list_is_unique', [1, 1])
        with self.assertRaises(AssertionError):
            self.ass('p_list_objects_have_key', [{'id': 1}, {}], 'id')

    def test_datetime_assertions(self):
        now = datetime.now()
        success_cases = [
            ('p_datetime_before', '2026-08-09 10:00:00', '2026-08-09 12:00:00'),
            ('p_datetime_after', '2026-08-09 13:00:00', '2026-08-09 12:00:00'),
            ('p_datetime_between', '2026-08-09 12:00:00', '{"start":"2026-08-09 10:00:00","end":"2026-08-09 14:00:00"}'),
            ('p_datetime_close_to', '2026-08-09 12:00:05', '{"value":"2026-08-09 12:00:00","tolerance_seconds":10}'),
            ('p_datetime_is_today', now.strftime('%Y-%m-%d %H:%M:%S'), None),
            ('p_datetime_is_future', (now + timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S'), None),
            ('p_datetime_is_past', (now - timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S'), None),
        ]
        for method, actual, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, actual, expect))

        with self.assertRaises(AssertionError):
            self.ass('p_datetime_before', '2026-08-09 13:00:00', '2026-08-09 12:00:00')

    def test_collection_state_assertions(self):
        success_cases = [
            ('p_is_empty_collection', [], None),
            ('p_is_not_empty_collection', {'id': 1}, None),
            ('p_is_none_or_empty', None, None),
            ('p_is_none_or_empty', '', None),
            ('p_is_neither_none_nor_empty', 'mango', None),
        ]
        for method, actual, expect in success_cases:
            with self.subTest(method=method):
                self.assertTrue(self.ass(method, actual, expect))

        with self.assertRaises(AssertionError):
            self.ass('p_is_empty_collection', '')


if __name__ == '__main__':
    unittest.main()
