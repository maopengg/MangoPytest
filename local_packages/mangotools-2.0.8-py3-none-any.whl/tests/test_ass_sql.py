# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-07 16:38
# @Author : 毛鹏
import unittest

from mangotools.assertion import MangoAssertion

class FakeMysqlConnect:

    def __init__(self, rows):
        self.rows = rows
        self.executed_sql = []

    def condition_execute(self, sql):
        self.executed_sql.append(sql)
        return self.rows


class TestAssSql(unittest.TestCase):

    def assert_sql(self, method, rows, expect=None):
        connection = FakeMysqlConnect(rows)
        message = MangoAssertion(connection).ass(method, 'SELECT value FROM demo', expect)
        self.assertEqual(connection.executed_sql, ['SELECT value FROM demo'])
        return message

    def test_count_and_first_row(self):
        message = self.assert_sql('assert_sql_count', [{'id': 1}, {'id': 2}], 2)
        self.assertIn('实际条数=2', message)

        message = self.assert_sql('assert_sql_first_row', [{'id': 1, 'name': 'demo'}], {
            'id': 1,
            'name': 'demo',
        })
        self.assertIn("'name': 'demo'", message)
        self.assertNotIn('SELECT value FROM demo', message)

    def test_value_comparison_methods_receive_expected_value(self):
        cases = [
            ('assert_sql_is_in', 'demo', 'prefix-demo-suffix'),
            ('assert_sql_is_not_in', 'demo', 'other'),
            ('assert_sql_starts_with', 'demo-value', 'demo'),
            ('assert_sql_ends_with', 'demo-value', 'value'),
        ]
        for method, actual, expect in cases:
            with self.subTest(method=method):
                message = self.assert_sql(method, [{'value': actual}], expect)
                self.assertIn('实际=', message)
                self.assertIn('预期=', message)

    def test_failed_assertion_reports_query_result(self):
        with self.assertRaises(AssertionError) as context:
            self.assert_sql('assert_sql_first_row', [{'id': 1}], {'id': 2})

        self.assertIn("'id': 1", str(context.exception))
        self.assertNotIn('SELECT value FROM demo', str(context.exception))
