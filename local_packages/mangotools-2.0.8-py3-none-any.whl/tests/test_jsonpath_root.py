import unittest

from mangotools.assertion import MangoAssertion
from mangotools.data_processor import DataProcessor, JsonTool
from mangotools.exceptions import MangoToolsError


class JsonPathRootTests(unittest.TestCase):
    def test_root_is_one_node_even_when_empty_or_false(self):
        for source in ({'data': {'id': 1}}, [{'id': 1}], {}, [], None, False, 0, ''):
            for expression in ('$', ' $ ', '\n$\t'):
                with self.subTest(source=source, expression=expression):
                    matches = JsonTool.match_json_path(source, expression)
                    self.assertEqual(len(matches), 1)
                    self.assertIs(matches[0], source)
                    self.assertIs(JsonTool.get_json_path_value(source, expression), source)
                    self.assertIs(DataProcessor.get_json_path_value(source, expression), source)

    def test_field_values_are_not_confused_with_missing_fields(self):
        for value in (None, False, 0, '', [], {}):
            with self.subTest(value=value):
                self.assertEqual(JsonTool.match_json_path({'data': value}, '$.data'), [value])
                self.assertEqual(JsonTool.get_json_path_value({'data': value}, ' $.data '), value)
        self.assertEqual(JsonTool.match_json_path({'code': 200}, '$.data'), [])
        with self.assertRaises(MangoToolsError) as raised:
            JsonTool.get_json_path_value({'code': 200}, '$.data')
        self.assertEqual(raised.exception.code, 3003)
        self.assertIn('不存在字段【data】', raised.exception.msg)

    def test_root_array_is_not_unwrapped_as_multiple_matches(self):
        self.assertEqual(JsonTool.match_json_path([1, 2], '$'), [[1, 2]])
        self.assertEqual(JsonTool.get_json_path_value([1, 2], '$'), [1, 2])
        self.assertEqual(JsonTool.match_json_path([1, 2], '$[*]'), [1, 2])
        self.assertEqual(JsonTool.get_json_path_value([1, 2], '$[0]'), 1)

    def test_existing_multi_match_and_index_semantics_are_unchanged(self):
        source = {'items': [{'id': 1}, {'id': 2}, {'id': 3}]}
        self.assertEqual(JsonTool.get_json_path_value(source, '$.items[*].id'), [1, 2, 3])
        self.assertEqual(JsonTool.get_json_path_value(source, '$.items[*].id', index=1), 2)
        self.assertEqual(JsonTool.get_json_path_value(source, '$.items[*].id', index=-1), 3)
        with self.assertRaises(MangoToolsError) as raised:
            JsonTool.get_json_path_value(source, '$.items[*].id', index=5)
        self.assertEqual(raised.exception.code, 3005)

    def test_invalid_expressions_remain_errors(self):
        for expression in (None, '', '  ', '$.data['):
            with self.subTest(expression=expression):
                with self.assertRaises(MangoToolsError) as raised:
                    JsonTool.match_json_path({'data': 1}, expression)
                self.assertEqual(raised.exception.code, 3005)

    def test_root_existence_and_nonempty_assertions_are_distinct(self):
        assertion = MangoAssertion()
        for source in ({}, [], {'data': None}, [0], '{"data":1}'):
            with self.subTest(source=source):
                self.assertTrue(assertion.ass('p_json_path_exists', source, ' $ '))
                with self.assertRaises(AssertionError):
                    assertion.ass('p_json_path_not_exists', source, '$')
        for source in ({}, []):
            with self.subTest(empty_source=source), self.assertRaises(AssertionError):
                assertion.ass('p_json_path_not_empty', source, '$')
        for source in ({'data': None}, [0]):
            self.assertTrue(assertion.ass('p_json_path_not_empty', source, '$'))

    def test_field_existence_does_not_weaken_nonempty_assertions(self):
        assertion = MangoAssertion()
        for value in (None, False, 0, '', [], {}):
            with self.subTest(value=value):
                source = {'data': value}
                self.assertTrue(assertion.ass('p_json_path_exists', source, '$.data'))
                with self.assertRaises(AssertionError):
                    assertion.ass('p_json_path_not_exists', source, '$.data')
        for value in (None, '', [], {}):
            with self.subTest(empty=value), self.assertRaises(AssertionError):
                assertion.ass('p_json_path_not_empty', {'data': value}, '$.data')
        for value in (False, 0):
            self.assertTrue(assertion.ass('p_json_path_not_empty', {'data': value}, '$.data'))
        self.assertTrue(assertion.ass('p_json_path_not_exists', {}, '$.data'))
        with self.assertRaises(AssertionError):
            assertion.ass('p_json_path_exists', {}, '$.data')


if __name__ == '__main__':
    unittest.main()
