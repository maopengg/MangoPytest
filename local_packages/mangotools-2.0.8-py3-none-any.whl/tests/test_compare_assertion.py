# -*- coding: utf-8 -*-
import unittest

from mangotools.assertion import MangoAssertion
from mangotools.decorator import func_info


class TestCompareAssertion(unittest.TestCase):

    def setUp(self):
        self.assertion = MangoAssertion()

    def test_numeric_comparisons_accept_numeric_strings(self):
        cases = [
            ('p_is_greater_than', '10.5', '10'),
            ('p_is_greater_than_or_equal_to', '10', '10'),
            ('p_is_less_than', '-2', '-1'),
            ('p_is_less_than_or_equal_to', '10', '10.0'),
        ]
        for method, actual, expect in cases:
            with self.subTest(method=method):
                self.assertIn('实际=', self.assertion.ass(method, actual, expect))

        with self.assertRaisesRegex(AssertionError, '不是有效数字'):
            self.assertion.ass('p_is_greater_than', 'mango', '1')

    def test_equal_comparison_preserves_text_compatible_semantics(self):
        self.assertion.ass('p_is_equal_to', 1, '1')
        with self.assertRaises(AssertionError):
            self.assertion.ass('p_is_not_equal_to', 1, '1')

    def test_legacy_length_assertions_are_registered_in_compare_group(self):
        self.assertion.ass('len_eq', 'mango', '5')
        self.assertion.ass('len_gt', 'mango', '3')
        content_group = next(group for group in func_info if group.get('value') == '内容断言')
        compare_group = next(
            group for group in content_group.get('children', [])
            if group.get('value') == '比较断言'
        )
        equal_group = next(
            group for group in content_group.get('children', [])
            if group.get('value') == '值等于什么'
        )
        self.assertIn('len_gt', {method.get('value') for method in compare_group.get('children', [])})
        self.assertIn('len_eq', {method.get('value') for method in equal_group.get('children', [])})
        self.assertFalse(any(group.get('value') == '自定义断言' for group in func_info))

    def test_length_comparisons_support_strings_and_collections(self):
        self.assertion.ass('p_is_length', [1, 2], '2')
        self.assertion.ass('p_length_at_least', 'mango', '5')
        self.assertion.ass('p_length_at_most', [1, 2], '2')
        self.assertion.ass('p_length_greater_than', {'id': 1, 'name': 'demo'}, '1')
        self.assertion.ass('p_length_less_than', (), '1')

        with self.assertRaisesRegex(AssertionError, '实际长度=2'):
            self.assertion.ass('p_length_at_least', [1, 2], '3')
        with self.assertRaisesRegex(AssertionError, '必须是非负整数'):
            self.assertion.ass('p_length_at_least', 'mango', '2.5')

    def test_regex_comparisons(self):
        self.assertion.ass('p_matches_regex', 'order-2026', r'^order-\d+$')
        self.assertion.ass('p_contains_regex', 'prefix-order-2026-suffix', r'order-\d+')
        self.assertion.ass('p_does_not_contain_regex', 'finished', r'error|failed')

        with self.assertRaisesRegex(AssertionError, '正则表达式无效'):
            self.assertion.ass('p_matches_regex', 'demo', '[')

    def test_data_type_comparisons(self):
        cases = [
            ('p_is_string', 'mango'),
            ('p_is_list', []),
            ('p_is_dict', {}),
            ('p_is_boolean', True),
            ('p_is_integer', 1),
            ('p_is_number', 1.5),
        ]
        for method, actual in cases:
            with self.subTest(method=method):
                self.assertIn('实际类型=', self.assertion.ass(method, actual))

        with self.assertRaises(AssertionError):
            self.assertion.ass('p_is_integer', True)

    def test_legacy_type_assertions_preserve_supported_runtime_types(self):
        self.assertion.ass('p_is_digit', 1)
        self.assertion.ass('p_is_true', True)
        self.assertion.ass('p_is_false', False)
        self.assertion.ass('p_is_empty', '')
        self.assertion.ass('p_is_empty', [])
        self.assertion.ass('p_is_empty', {})
        self.assertion.ass('p_is_not_empty', 'mango')
        self.assertion.ass('p_is_not_empty', [1])
        self.assertion.ass('p_is_not_empty', {'id': 1})
        self.assertion.ass('p_is_alpha', 'mango')

        invalid_cases = [
            ('p_is_digit', '1'),
            ('p_is_digit', True),
            ('p_is_true', 1),
            ('p_is_false', 0),
            ('p_is_empty', [1]),
            ('p_is_not_empty', []),
            ('p_is_empty', 0),
            ('p_is_not_empty', 1),
            ('p_is_alpha', 123),
        ]
        for method, actual in invalid_cases:
            with self.subTest(method=method, actual=actual):
                with self.assertRaises(AssertionError):
                    self.assertion.ass(method, actual)

    def test_methods_are_registered_for_frontend(self):
        content_group = next(group for group in func_info if group.get('value') == '内容断言')
        groups = {
            item.get('value'): {method.get('value') for method in item.get('children', [])}
            for item in content_group.get('children', [])
        }
        self.assertIn('p_is_greater_than', groups['比较断言'])
        self.assertIn('p_length_at_least', groups['比较断言'])
        self.assertIn('p_matches_regex', groups['比较断言'])
        self.assertIn('p_is_dict', groups['比较断言'])


if __name__ == '__main__':
    unittest.main()
