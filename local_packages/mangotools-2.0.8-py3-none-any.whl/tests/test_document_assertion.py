# -*- coding: utf-8 -*-

import json
import tempfile
import unittest
from pathlib import Path

from docx import Document
from openpyxl import Workbook

from mangotools.assertion import DocumentAssertion, FileAssertion, MangoAssertion
from mangotools.assertion.file._document import read_document_snapshot
from mangotools.decorator import func_info


class TestDocumentAssertion(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)

        self.word_path = root / 'contract.docx'
        word = Document()
        word.add_paragraph('办公用品合同')
        word.add_paragraph('办公用品明细')
        table = word.add_table(rows=2, cols=2)
        table.cell(0, 0).text = '名称'
        table.cell(0, 1).text = '数量'
        table.cell(1, 0).text = '办公用品'
        table.cell(1, 1).text = '3'
        word.save(self.word_path)

        self.excel_path = root / 'contract.xlsx'
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = '智能起草'
        sheet.append(['名称', '数量'])
        sheet.append(['办公用品', 3])
        sheet.append(['打印纸', 2])
        workbook.save(self.excel_path)
        workbook.close()

        self.txt_path = root / 'contract.txt'
        self.txt_path.write_text('第一行\n办公用品\n第三行', encoding='utf-8')

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_word_snapshot_contains_paragraphs_and_tables(self):
        snapshot = read_document_snapshot(str(self.word_path))

        self.assertEqual(snapshot.file_type, 'docx')
        self.assertEqual(snapshot.paragraph_count, 2)
        self.assertEqual(snapshot.table_count, 1)
        self.assertEqual(snapshot.row_count, 2)
        self.assertEqual(len(snapshot.lines), 4)
        self.assertIn('办公用品\t3', snapshot.text)

    def test_excel_snapshot_supports_sheet_scope(self):
        snapshot = read_document_snapshot({
            '文件路径': str(self.excel_path),
            '工作表': '智能起草',
        })

        self.assertEqual(snapshot.file_type, 'xlsx')
        self.assertEqual(snapshot.row_count, 3)
        self.assertEqual(snapshot.column_count, 2)
        self.assertEqual(snapshot.sheet_names, ['智能起草'])
        self.assertIn('办公用品\t3', snapshot.text)

    def test_common_file_text_assertions_support_word_and_excel(self):
        assertion = MangoAssertion()

        self.assertIn(
            '包含预期文本',
            assertion.ass('assert_file_text_contains', str(self.word_path), '办公用品'),
        )
        self.assertIn(
            '不少于3',
            assertion.ass(
                'assert_file_text_count_at_least',
                str(self.word_path),
                json.dumps({'目标文本': '办公用品', '最少次数': 3}, ensure_ascii=False),
            ),
        )
        self.assertIn(
            '不少于3',
            assertion.ass(
                'assert_file_line_count_at_least',
                str(self.excel_path),
                3,
            ),
        )

    def test_file_type_and_exact_text_assertions(self):
        assertion = MangoAssertion()

        self.assertIn('docx', assertion.ass('assert_file_type', str(self.word_path), 'docx'))
        self.assertIn(
            '一致',
            assertion.ass(
                'assert_file_text_equal',
                str(self.txt_path),
                '第一行\n办公用品\n第三行',
            ),
        )

    def test_word_paragraph_and_excel_row_column_limits(self):
        assertion = MangoAssertion()

        self.assertIn(
            '不少于2',
            assertion.ass('assert_word_paragraph_count_at_least', str(self.word_path), 2),
        )
        excel_actual = json.dumps({
            '文件路径': str(self.excel_path),
            '工作表': '智能起草',
        }, ensure_ascii=False)
        self.assertIn(
            '不少于3',
            assertion.ass(
                'assert_excel_row_count_at_least',
                excel_actual,
                json.dumps({'最少行数': 3}, ensure_ascii=False),
            ),
        )
        self.assertIn(
            '不多于2',
            assertion.ass(
                'assert_excel_column_count_at_most',
                excel_actual,
                json.dumps({'最多列数': 2}, ensure_ascii=False),
            ),
        )

    def test_word_content_and_structure_assertions(self):
        assertion = MangoAssertion()
        word_text = '办公用品合同\n办公用品明细\n名称\t数量\n办公用品\t3'

        self.assertIn(
            '包含预期文本',
            assertion.ass('assert_word_text_contains', str(self.word_path), '办公用品明细'),
        )
        self.assertIn(
            '不包含文本',
            assertion.ass('assert_word_text_not_contains', str(self.word_path), '违约'),
        )
        self.assertIn(
            '预期一致',
            assertion.ass('assert_word_text_equal', str(self.word_path), word_text),
        )
        self.assertIn(
            '实际=3',
            assertion.ass(
                'assert_word_text_count_equal',
                str(self.word_path),
                json.dumps({'目标文本': '办公用品', '预期次数': 3}, ensure_ascii=False),
            ),
        )
        self.assertIn(
            '不少于4',
            assertion.ass('assert_word_line_count_at_least', str(self.word_path), 4),
        )
        self.assertIn(
            '实际=1',
            assertion.ass('assert_word_table_count_equal', str(self.word_path), 1),
        )
        self.assertIn(
            '实际=2',
            assertion.ass('assert_word_table_row_count_equal', str(self.word_path), 2),
        )

    def test_txt_content_count_line_and_length_assertions(self):
        assertion = MangoAssertion()
        txt_actual = json.dumps({'文件路径': str(self.txt_path)}, ensure_ascii=False)

        self.assertIn(
            '不包含文本',
            assertion.ass('assert_txt_not_contains', txt_actual, '第四行'),
        )
        self.assertIn(
            '实际=1',
            assertion.ass(
                'assert_txt_text_count_equal',
                txt_actual,
                json.dumps({'目标文本': '办公用品', '预期次数': 1}, ensure_ascii=False),
            ),
        )
        self.assertIn(
            '实际=3',
            assertion.ass('assert_txt_line_count_equal', txt_actual, 3),
        )
        self.assertIn(
            '不少于10',
            assertion.ass('assert_txt_length_at_least', txt_actual, 10),
        )
        self.assertIn(
            '内容不为空',
            FileAssertion.assert_txt_not_empty(txt_actual),
        )

    def test_document_methods_are_registered_in_file_assertion_tree(self):
        file_group = next(item for item in func_info if item['value'] == '文件断言')
        group_names = {item['value'] for item in file_group['children']}

        self.assertIn('通用文件断言', group_names)
        self.assertIn('Word断言', group_names)
        self.assertIn('TXT断言', group_names)
        word_group = next(item for item in file_group['children'] if item['value'] == 'Word断言')
        txt_group = next(item for item in file_group['children'] if item['value'] == 'TXT断言')
        self.assertGreaterEqual(len(word_group['children']), 21)
        self.assertGreaterEqual(len(txt_group['children']), 17)
        self.assertTrue(hasattr(FileAssertion, DocumentAssertion.assert_file_type.__name__))


if __name__ == '__main__':
    unittest.main()
