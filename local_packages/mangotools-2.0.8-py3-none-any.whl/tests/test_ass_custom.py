# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 11:13
# @Author : 毛鹏
import unittest

from mangotools.assertion import MangoAssertion
from mangotools.assertion.custom import v
from mangotools.data_processor import DataProcessor
from mangotools.decorator import func_info


class TestCustomAssertion(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def test_txt_equal(self):
        self.test_data = DataProcessor()
        self.test_data.set_cache('账号A', 'maopeng@qq.com')
        MangoAssertion(test_data=self.test_data).ass(MangoAssertion.ass_func.__name__, v)

    def test_demo_custom_assert_equal(self):
        assertion = MangoAssertion(test_data=DataProcessor())

        result = assertion.ass('demo_custom_assert_equal', 'mango', 'mango')

        self.assertIn('自定义断言通过', result)
        with self.assertRaises(AssertionError):
            assertion.ass('demo_custom_assert_equal', 'mango', 'other')

    def test_ass_func_uses_code_editor(self):
        function = next(
            item
            for method_type in func_info
            for method_class in method_type['children']
            for item in method_class['children']
            if item['value'] == 'ass_func'
        )

        self.assertEqual('code', function['parameter'][0]['input_type'])
