import base64
import json
import tempfile
import unittest
from io import BytesIO
from pathlib import Path
from unittest.mock import Mock, patch
from zipfile import ZipFile

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree

from mangotools.assertion import MangoAssertion
from mangotools.decorator import func_info


_PNG = base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jf9sAAAAASUVORK5CYII='
)
_INSERTED = '定稿总价 1200 元'
_DELETED = '草案总价 990 元'
_COMMENT = '按审批单复核金额'
_MARKERS = ['测试合同编号 D42', _INSERTED, '末尾交付条款']
_CELLS = [{'table': 1, 'row': 2, 'column': 2, 'text': '1200 元'}]
_FINAL = {
    'body_markers': _MARKERS, 'cells': _CELLS, 'insertions': [_INSERTED], 'deletions': [_DELETED],
}
_RETAINED = {
    **_FINAL, 'keepRevisions': True, 'comments': [{'text': _COMMENT, 'anchor': _INSERTED}],
}


def _tracked_text(paragraph, kind, identifier, text):
    wrapper = OxmlElement(f'w:{kind}')
    wrapper.set(qn('w:id'), str(identifier))
    wrapper.set(qn('w:author'), '样本作者')
    run = OxmlElement('w:r')
    node = OxmlElement('w:delText' if kind == 'del' else 'w:t')
    node.text = text
    run.append(node)
    wrapper.append(run)
    paragraph._p.append(wrapper)


def _rewrite_package(path, target, changes):
    with ZipFile(path) as original, ZipFile(target, 'w') as rewritten:
        for entry in original.namelist():
            data = changes.get(entry, original.read(entry))
            if data is not None:
                rewritten.writestr(entry, data)
        for entry in changes.keys() - set(original.namelist()):
            rewritten.writestr(entry, changes[entry])
    return target


def _add_comment_part(source, output, note):
    with ZipFile(source) as archive:
        types = etree.fromstring(archive.read('[Content_Types].xml'))
        rels = etree.fromstring(archive.read('word/_rels/document.xml.rels'))
    etree.SubElement(
        types, f'{{{types.nsmap[None]}}}Override', PartName='/word/comments.xml',
        ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml',
    )
    etree.SubElement(
        rels, f'{{{rels.nsmap[None]}}}Relationship', Id='rId99', Target='comments.xml',
        Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments',
    )
    comments = OxmlElement('w:comments')
    comment = OxmlElement('w:comment')
    comment.set(qn('w:id'), '7')
    comment.set(qn('w:author'), '样本作者')
    paragraph, run, text = [OxmlElement(tag) for tag in ('w:p', 'w:r', 'w:t')]
    text.text = note
    run.append(text)
    paragraph.append(run)
    comment.append(paragraph)
    comments.append(comment)
    return _rewrite_package(source, output, {
        '[Content_Types].xml': etree.tostring(types),
        'word/_rels/document.xml.rels': etree.tostring(rels),
        'word/comments.xml': etree.tostring(comments),
    })


class TestDocxAssertion(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.mango = MangoAssertion()
        self.final = self.sample('final.docx')
        self.retained = self.sample('retained.docx', retained=True)

    def sample(self, filename, *, retained=False, amount=_INSERTED, deleted=_DELETED,
               anchor_inserted=True, note=_COMMENT, last='末尾交付条款', cell='1200 元',
               body=True, header_revision=False):
        document = Document()
        if body:
            title = document.add_paragraph()
            title.add_run('测试合同编号')
            title.add_run(' D42')
        paragraph = document.add_paragraph()
        if retained:
            if anchor_inserted:
                paragraph._p.append(self.comment_marker('commentRangeStart'))
            _tracked_text(paragraph, 'ins', 1, amount)
            if not anchor_inserted:
                paragraph._p.append(self.comment_marker('commentRangeStart'))
            if not anchor_inserted or amount != _INSERTED:
                paragraph.add_run('辅助文字')
            paragraph._p.append(self.comment_marker('commentRangeEnd'))
            reference = OxmlElement('w:r')
            reference.append(self.comment_marker('commentReference'))
            paragraph._p.append(reference)
            _tracked_text(paragraph, 'del', 2, deleted)
        else:
            paragraph.add_run(amount)
        document.add_paragraph(last)
        table = document.add_table(rows=2, cols=2)
        table.cell(0, 0).text = '商品'
        table.cell(0, 1).text = '价格'
        table.cell(1, 0).text = '办公用品'
        table.cell(1, 1).text = cell
        if not body:
            table.cell(0, 0).text = '测试合同编号 D42'
        document.add_picture(BytesIO(_PNG))
        if header_revision:
            _tracked_text(document.sections[0].header.paragraphs[0], 'ins', 3, '页眉修订')
        path = self.root / filename
        if retained:
            source = path.with_suffix('.base')
            document.save(source)
            return _add_comment_part(source, path, note)
        document.save(path)
        return path

    @staticmethod
    def comment_marker(kind):
        marker = OxmlElement(f'w:{kind}')
        marker.set(qn('w:id'), '7')
        return marker

    def validate(self, path):
        return self.mango.ass('assert_docx_artifact_valid', path)

    def structure(self, path, config):
        return self.mango.ass('assert_docx_structure_match', path, config)

    def test_valid_artifact_and_registration(self):
        self.assertEqual(self.validate({'文件路径': str(self.final)}), 'DOCX产物有效')
        without_suffix = self.final.rename(self.root / 'artifact')
        self.assertEqual(self.validate(without_suffix), 'DOCX产物有效')
        group = next(item for item in func_info if item['value'] == '文件断言')
        docx_group = next(item for item in group['children'] if item['value'] == 'DOCX产物断言')
        self.assertEqual({item['value'] for item in docx_group['children']},
                         {'assert_docx_artifact_valid', 'assert_docx_structure_match'})

    def test_remote_artifact_uses_existing_file_input(self):
        response = Mock(content=self.final.read_bytes())
        with patch('mangotools.assertion.file._document.requests.get', return_value=response):
            self.assertEqual(self.validate('https://example.test/artifact?token=sample'), 'DOCX产物有效')

    def test_rejects_invalid_packages(self):
        empty = self.root / 'empty.docx'
        empty.write_bytes(b'')
        fake = self.root / 'fake.docx'
        fake.write_bytes(b'%PDF-1.7')
        truncated = self.root / 'truncated.docx'
        truncated.write_bytes(self.final.read_bytes()[:-40])
        damaged = _rewrite_package(self.final, self.root / 'broken.docx', {'word/document.xml': b'<bad>'})
        missing = _rewrite_package(self.final, self.root / 'missing.docx', {'word/document.xml': None})
        media = _rewrite_package(self.final, self.root / 'missing-image.docx', {'word/media/image1.png': None})
        empty_media = _rewrite_package(self.final, self.root / 'empty-image.docx', {'word/media/image1.png': b''})
        with ZipFile(self.final) as archive:
            xml = archive.read('word/document.xml').replace(b'r:embed="rId9"', b'r:embed="rIdMissing"')
        broken_ref = _rewrite_package(self.final, self.root / 'image-ref.docx', {'word/document.xml': xml})
        for path in (empty, fake, truncated, damaged, missing, media, empty_media, broken_ref):
            with self.subTest(path=path.name), self.assertRaises(AssertionError):
                self.validate(path)

    def test_keep_revisions_omitted_and_false_use_final_text(self):
        for config in (_FINAL, {**_FINAL, 'keepRevisions': False}):
            with self.subTest(config=config):
                actual = json.dumps({'文件路径': str(self.final)})
                self.assertIn('符合预期', self.structure(actual, json.dumps(config)))
                with self.assertRaisesRegex(AssertionError, '定稿仍有修订标记'):
                    self.structure(self.retained, config)

    def test_final_text_rejects_missing_insertion_and_retained_deletion(self):
        for filename, amount, error in (
            ('missing-insertion.docx', '定稿总价丢失', '定稿插入文本'),
            ('old-amount.docx', f'{_INSERTED}；{_DELETED}', '仍包含第1项删除文本'),
        ):
            with self.subTest(filename=filename), self.assertRaisesRegex(AssertionError, error):
                self.structure(self.sample(filename, amount=amount), _FINAL)

    def test_final_text_rejects_remaining_comments_and_header_revisions(self):
        with ZipFile(self.retained) as archive:
            root = etree.fromstring(archive.read('word/document.xml'))
        for node in list(root.iter(qn('w:ins'), qn('w:del'))):
            parent = node.getparent()
            if node.tag == qn('w:ins'):
                for child in list(node):
                    node.addprevious(child)
            parent.remove(node)
        comment_only = _rewrite_package(self.retained, self.root / 'comment-only.docx', {
            'word/document.xml': etree.tostring(root),
        })
        with self.assertRaisesRegex(AssertionError, '仍有批注'):
            self.structure(comment_only, _FINAL)
        with self.assertRaisesRegex(AssertionError, '仍有修订'):
            self.structure(self.sample('header.docx', header_revision=True), _FINAL)

    def test_keep_revisions_true_requires_matching_revisions_and_comment_anchor(self):
        self.assertIn('符合预期', self.structure(self.retained, _RETAINED))
        for path, error in (
            (self.final, '修订内容'),
            (self.sample('bad-insert.docx', retained=True, amount='错误金额'), '修订内容.*ins'),
            (self.sample('bad-delete.docx', retained=True, deleted='错误草案'), '修订内容.*del'),
            (self.sample('bad-note.docx', retained=True, note='不同的批注'), '批注内容'),
            (self.sample('bad-anchor.docx', retained=True, anchor_inserted=False), '锚定文本'),
        ):
            with self.subTest(path=path.name), self.assertRaisesRegex(AssertionError, error):
                self.structure(path, _RETAINED)

    def test_native_body_order_and_cells(self):
        with self.assertRaisesRegex(AssertionError, '正文标记'):
            self.structure(self.sample('table-only.docx', body=False), _FINAL)
        with self.assertRaisesRegex(AssertionError, '正文标记'):
            self.structure(self.final, {**_FINAL, 'body_markers': _MARKERS[::-1]})
        with self.assertRaisesRegex(AssertionError, '表1第2行第2列内容不符'):
            self.structure(self.sample('wrong-cell.docx', cell='990 元'), _FINAL)
        with self.assertRaisesRegex(AssertionError, '表1第2行第3列不存在'):
            self.structure(self.final, {**_FINAL, 'cells': [{**_CELLS[0], 'column': 3}]})

    def test_invalid_expectations_are_rejected(self):
        for config in ({'keepRevisions': 'false'}, {'keepRevisions': True}, {'unknown': ''}):
            with self.subTest(config=config), self.assertRaises(ValueError):
                self.structure(self.final, config)
