# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 测试数据方法元信息输出
# @Time   : 2026-05-21
# @Author : 毛鹏
import json
import unittest

from mangotools.data_processor import DataProcessor
from mangotools.decorator import get_data_method_info


class TestDataMethod(unittest.TestCase):

    def test_print_data_method_info(self):
        data = get_data_method_info()
        print(json.dumps({
            "class": DataProcessor.__name__,
            "data": data,
        }, ensure_ascii=False, indent=2))
        self.assertGreater(len(data), 0)


if __name__ == '__main__':
    unittest.main()
