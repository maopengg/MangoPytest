# -*- coding: utf-8 -*-

import functools
from typing import Type, Callable, Any

from mangoautomation.models import MethodModel

func_info: list[dict] = []
__func_key_set: set[tuple[str, str]] = set()


def _func_info_add(_type, class_name, name, func, parameter, sort):
    func_key = (_type, func.__name__)
    if func_key in __func_key_set:
        return
    __func_key_set.add(func_key)
    class_dict = next((item for item in func_info if item.get("value") == _type), None)
    if not class_dict:
        new_entry = {
            "label": _type,
            "value": _type,
            "children": [],
        }
        func_info.append(new_entry)
        class_dict = new_entry
    found_dict = next((item for item in class_dict["children"] if item.get("value") == class_name), None)
    if not found_dict:
        new_entry = {
            "label": class_name,
            "value": class_name,
            "children": [],
        }
        class_dict["children"].append(new_entry)
        found_dict = new_entry
    found_dict["children"].append({
        "value": func.__name__,
        "label": name,
        "parameter": [i.model_dump() for i in parameter] if parameter else None,
        "sort": sort,
    })


def async_method_callback(_type, class_name, name, sort=-1, parameter: list[MethodModel] | None = None):
    def decorator(func):
        _func_info_add(_type, class_name, name, func, parameter, sort)

        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            return await func(*args, **kwargs)

        return wrapper

    return decorator


def sync_method_callback(_type, class_name, name, sort=-1, parameter: list[MethodModel] | None = None):
    def decorator(func):
        _func_info_add(_type, class_name, name, func, parameter, sort)

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator


def inject_to_class(target_class: Type[Any]):
    """装饰器工厂，用于将函数注入到指定类中"""

    def decorator(func: Callable) -> Callable:
        """实际装饰器"""
        setattr(target_class, func.__name__, func)

        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            return await func(*args, **kwargs)

        return wrapper

    return decorator
