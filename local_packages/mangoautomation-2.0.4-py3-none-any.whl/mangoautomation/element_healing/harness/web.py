# -*- coding: utf-8 -*-
import asyncio
import logging
import time

from ..agent.web import OpenAICompatibleModelClient, WebLocatorAgent
from ..candidates import CandidateRegistry, DomProximityCandidateSource, DomTextCandidateSource
from ..candidates.base import deduplicate
from ..context import HealingContextBuilder, target_texts
from ..locator import LocatorFactory
from ..memory import NullEventSink, NullMemoryProvider
from ..models import HealingContext, HealingStatus, HealingTrigger, LocatorCandidate
from ..observability import CandidateSummary, HealingMetrics, TraceRecorder
from ..policy import (
    CANDIDATE_TIMEOUT_SECONDS,
    MAX_REJECT_REASONS,
    HealingPolicy,
    StaticRuntimeConfig,
)
from ..verification import (
    AsyncCandidateVerifier,
    SemanticVerifier,
    SyncCandidateVerifier,
    is_visible_sync,
    read_text_async,
    read_text_sync,
)
from .async_web import AsyncWebHealingRunner
from .sync_web import SyncWebHealingRunner

log = logging.getLogger(__name__)


class WebElementHealingHarness:
    CACHE_TTL = 60

    def __init__(self,
                 test_env: int | None = None,
                 memory_provider=None,
                 event_sink=None,
                 model_client=None,
                 runtime_config=None,
                 logger=None):
        self.test_env = test_env
        self.memory_provider = memory_provider or NullMemoryProvider()
        self.event_sink = event_sink or NullEventSink()
        self.runtime_config = runtime_config or StaticRuntimeConfig(enabled=True, mode=2)
        self.log = logger or log
        self.agent = WebLocatorAgent(model_client) if model_client else None
        self.metrics = HealingMetrics()
        self._ai_info_cache: dict[tuple[int, int | None], tuple[float, dict]] = {}
        self._last_attempts: dict[int, dict] = {}
        self._pending_events: dict[int, tuple[str, dict]] = {}
        self._async_verifier = AsyncCandidateVerifier()
        self._sync_verifier = SyncCandidateVerifier()
        self._async_runner = AsyncWebHealingRunner()
        self._sync_runner = SyncWebHealingRunner()

    @classmethod
    def standalone(cls, *, api_key=None, base_url=None, model=None, timeout=None, mode=2,
                   semantic_strength=0, logger=None):
        model_client = None
        if api_key and base_url and model:
            model_client = OpenAICompatibleModelClient(api_key, base_url, model, timeout)
        return cls(
            model_client=model_client,
            runtime_config=StaticRuntimeConfig(
                enabled=True,
                mode=mode,
                semantic_strength_value=semantic_strength,
            ),
            logger=logger,
        )

    def set_test_env(self, test_env: int | None):
        self.test_env = test_env
        return self

    def locator_enabled(self) -> bool:
        return bool(self.runtime_config.locator_enabled())

    def _heal_mode(self) -> int:
        try:
            mode = int(self.runtime_config.locator_mode())
        except (TypeError, ValueError):
            mode = 1
        return mode if mode in (1, 2, 3) else 1

    def _semantic_strength(self) -> int:
        callback = getattr(self.runtime_config, 'semantic_strength', None)
        if not callable(callback):
            return 0
        try:
            value = int(callback())
        except (TypeError, ValueError):
            value = 0
        return max(0, min(value, 100))

    def _with_semantic_strength(self, find_params: dict | None) -> dict:
        value = dict(find_params or {})
        value['_semantic_strength'] = self._semantic_strength()
        return value

    def allow_temporary_heal(self, element_model=None) -> bool:
        return self.locator_enabled() and HealingPolicy(self._heal_mode()).allow_temporary_heal()

    async def locate_async(self, page, element_model, failed_locator, failed_expression, find_params,
                           error=None, speculative: bool = False):
        if not page or page.is_closed() or not self.locator_enabled():
            return None
        return await self._async_runner.run(
            self, page, element_model, failed_expression or [], find_params or {}, error,
            emit_events=not speculative,
        )

    def locate_sync(self, page, element_model, failed_locator, failed_expression, find_params, error=None):
        if not page or page.is_closed() or not self.locator_enabled():
            return None
        return self._sync_runner.run(
            self, page, element_model, failed_expression or [], find_params or {}, error,
        )

    async def _verify_async(self, page, element_model, candidates, find_params, results, rejects,
                            start_index, deadline: float | None = None):
        find_params = self._with_semantic_strength(find_params)
        for offset, candidate in enumerate(candidates):
            remaining = self._remaining(deadline)
            if remaining is not None and remaining <= 0:
                self._append_budget_reject(rejects, 'deterministic healing budget exhausted')
                return None
            timeout = min(CANDIDATE_TIMEOUT_SECONDS, remaining) if remaining is not None else CANDIDATE_TIMEOUT_SECONDS
            try:
                selected, row = await asyncio.wait_for(
                    self._async_verifier.verify(
                        page,
                        element_model,
                        candidate,
                        find_params,
                        start_index + offset,
                        actionability_timeout_ms=max(100, min(1200, int(timeout * 1000))),
                    ),
                    timeout=max(0.1, timeout),
                )
            except asyncio.TimeoutError:
                selected = None
                row = self._timeout_row(candidate, start_index + offset)
            results.append(row)
            if row.get('reject_reason'):
                self._append_reject(
                    rejects, f"{row.get('source')}:{row.get('loc')} {row['reject_reason']}"
                )
            if selected:
                decision = HealingPolicy(self._heal_mode()).decide(selected.verification)
                self._annotate_decision(selected, decision)
                if decision.status != HealingStatus.SUGGESTED:
                    return selected
        return None

    def _verify_sync(self, page, element_model, candidates, find_params, results, rejects,
                     start_index, deadline: float | None = None):
        find_params = self._with_semantic_strength(find_params)
        for offset, candidate in enumerate(candidates):
            remaining = self._remaining(deadline)
            if remaining is not None and remaining <= 0:
                self._append_budget_reject(rejects, 'deterministic healing budget exhausted')
                return None
            selected, row = self._sync_verifier.verify(
                page,
                element_model,
                candidate,
                find_params,
                start_index + offset,
                actionability_timeout_ms=max(
                    100,
                    min(1200, int((remaining or CANDIDATE_TIMEOUT_SECONDS) * 1000)),
                ),
            )
            if deadline is not None and time.perf_counter() > deadline:
                selected = None
                row['verified'] = False
                row['reject_code'] = 'budget_exhausted'
                row['reject_reason'] = 'deterministic healing budget exhausted'
            results.append(row)
            if row.get('reject_reason'):
                self._append_reject(
                    rejects, f"{row.get('source')}:{row.get('loc')} {row['reject_reason']}"
                )
            if selected:
                decision = HealingPolicy(self._heal_mode()).decide(selected.verification)
                self._annotate_decision(selected, decision)
                if decision.status != HealingStatus.SUGGESTED:
                    return selected
        return None

    @staticmethod
    def _remaining(deadline: float | None) -> float | None:
        return None if deadline is None else deadline - time.perf_counter()

    @staticmethod
    def _timeout_row(candidate, candidate_index: int) -> dict:
        row = candidate.to_runtime_dict()
        row.update({
            'candidate_index': candidate_index,
            'verified': False,
            'count': 0,
            'reject_code': 'candidate_timeout',
            'reject_reason': f'candidate validation exceeded {CANDIDATE_TIMEOUT_SECONDS:g}s',
            'duration_ms': int(CANDIDATE_TIMEOUT_SECONDS * 1000),
        })
        return row

    @staticmethod
    def _append_reject(rejects: list, reason: str) -> None:
        if len(rejects) < MAX_REJECT_REASONS:
            rejects.append(reason)

    @classmethod
    def _append_budget_reject(cls, rejects: list, reason: str) -> None:
        if reason not in rejects:
            cls._append_reject(rejects, reason)

    async def _finish_async(self, selected, context, recorder, candidates, results, rejects,
                            emit_event: bool = True):
        mode = self._heal_mode()
        decision = HealingPolicy(mode).decide(selected.verification)
        self._annotate_decision(selected, decision)
        trace = recorder.finish(candidates, results, rejects, decision, agent=self.agent)
        metadata = TraceRecorder.runtime_metadata(
            selected, candidates, results, rejects, mode, context, trace, decision,
        )
        self._last_attempts[context.element_id] = metadata
        self.metrics.increment('verified')
        await self._publish_or_defer_async(
            context.element_id, 'healing_trace', trace.model_dump(mode='json'), emit_event,
        )
        if decision.status == HealingStatus.SUGGESTED:
            return None
        return self._runtime_result(selected, metadata)

    def _finish_sync(self, selected, context, recorder, candidates, results, rejects):
        mode = self._heal_mode()
        decision = HealingPolicy(mode).decide(selected.verification)
        self._annotate_decision(selected, decision)
        trace = recorder.finish(candidates, results, rejects, decision, agent=self.agent)
        metadata = TraceRecorder.runtime_metadata(
            selected, candidates, results, rejects, mode, context, trace, decision,
        )
        self._last_attempts[context.element_id] = metadata
        self.metrics.increment('verified')
        self._emit_sync('healing_trace', trace.model_dump(mode='json'))
        if decision.status == HealingStatus.SUGGESTED:
            return None
        return self._runtime_result(selected, metadata)

    @staticmethod
    def _annotate_decision(selected, decision) -> None:
        selected.runtime_row.update({
            'decision_status': decision.status.value,
            'adopted': decision.status in (HealingStatus.TEMPORARY_HEAL, HealingStatus.AUTO_APPLY),
            'decision_reasons': list(decision.reasons or []),
        })

    async def _exhausted_async(self, context, recorder, candidates, results, rejects,
                               emit_event: bool = True):
        decision = HealingPolicy(self._heal_mode()).decide(None)
        trace = recorder.finish(candidates, results, rejects, decision, agent=self.agent)
        metadata = TraceRecorder.exhausted_metadata(candidates, results, rejects, context, trace)
        self._last_attempts[context.element_id] = metadata
        self.metrics.increment('exhausted')
        await self._publish_or_defer_async(
            context.element_id, 'healing_trace', trace.model_dump(mode='json'), emit_event,
        )
        return None

    def _exhausted_sync(self, context, recorder, candidates, results, rejects):
        decision = HealingPolicy(self._heal_mode()).decide(None)
        trace = recorder.finish(candidates, results, rejects, decision, agent=self.agent)
        metadata = TraceRecorder.exhausted_metadata(candidates, results, rejects, context, trace)
        self._last_attempts[context.element_id] = metadata
        self.metrics.increment('exhausted')
        self._emit_sync('healing_trace', trace.model_dump(mode='json'))
        return None

    @staticmethod
    def _runtime_result(selected, metadata):
        candidate = selected.verification.candidate
        frame_index = candidate.metadata.get('snapshot_frame_index', 0)
        return {
            'locator': selected.locator,
            'count': selected.count,
            'text': selected.text,
            'exp': candidate.exp,
            'loc': candidate.loc,
            'sub': candidate.sub,
            'is_iframe': 1 if int(frame_index or 0) > 0 else 0,
            'metadata': metadata,
        }

    async def _get_ai_info(self, element_id: int):
        cached = self._get_cached_ai_info(element_id)
        if cached:
            return cached
        try:
            value = await self.memory_provider.load_async(element_id, self.test_env)
        except Exception as error:
            log.warning(f'[元素自愈] 历史记忆读取失败，继续使用当前页面候选：{error}')
            value = {}
        return self._cache_memory(element_id, value)

    def _cache_memory(self, element_id: int, value: dict):
        value = value if isinstance(value, dict) else {}
        self._ai_info_cache[(element_id, self.test_env)] = (time.time(), value)
        return value

    def _get_cached_ai_info(self, element_id: int):
        cached = self._ai_info_cache.get((element_id, self.test_env))
        if not cached or time.time() - cached[0] > self.CACHE_TTL:
            return {}
        return cached[1] if isinstance(cached[1], dict) else {}

    async def _emit_async(self, event, payload):
        try:
            await self.event_sink.emit_async(event, payload)
        except Exception as error:
            log.debug(f'[元素自愈] EventSink failed without affecting execution: {error}')

    async def _publish_or_defer_async(self, element_id: int, event: str, payload: dict,
                                      emit_event: bool) -> None:
        if emit_event:
            await self._emit_async(event, payload)
            return
        self._pending_events[element_id] = (event, payload)

    async def commit_attempt_async(self, element_id: int | None) -> None:
        if element_id is None:
            return
        pending = self._pending_events.pop(element_id, None)
        if pending:
            await self._emit_async(*pending)

    def _emit_sync(self, event, payload):
        try:
            self.event_sink.emit_sync(event, payload)
        except Exception as error:
            log.debug(f'[元素自愈] EventSink failed without affecting execution: {error}')

    def get_last_attempt(self, element_id: int):
        return self._last_attempts.get(element_id) or {}

    def fixed_locator_semantic_reject_reason(self, element_model, element_text, loc):
        return SemanticVerifier.fixed_reject_reason(element_model, element_text, loc)

    @staticmethod
    def create_locator(page, candidate):
        return LocatorFactory.create(page, candidate)

    async def revalidate_async(self, page, element_model, runtime_result: dict, find_params: dict):
        candidate, candidate_index = self._runtime_candidate(runtime_result)
        if candidate is None:
            return None
        selected, row = await self._async_verifier.verify(
            page, element_model, candidate, find_params or {}, candidate_index,
        )
        return self._revalidated_runtime_result(runtime_result, selected, row)

    def revalidate_sync(self, page, element_model, runtime_result: dict, find_params: dict):
        candidate, candidate_index = self._runtime_candidate(runtime_result)
        if candidate is None:
            return None
        selected, row = self._sync_verifier.verify(
            page, element_model, candidate, find_params or {}, candidate_index,
        )
        return self._revalidated_runtime_result(runtime_result, selected, row)

    def discard_attempt(self, element_id: int | None) -> None:
        if element_id is not None:
            self._last_attempts.pop(element_id, None)
            self._pending_events.pop(element_id, None)

    def _runtime_candidate(self, runtime_result: dict):
        metadata = runtime_result.get('metadata') or {}
        rows = metadata.get('candidates') or []
        candidate_index = metadata.get('candidate_index')
        selected_row = next(
            (row for row in rows if row.get('candidate_index') == candidate_index),
            None,
        )
        if selected_row is None:
            selected_row = next((row for row in rows if row.get('verified')), None)
        if selected_row is None:
            selected_row = {
                'source': metadata.get('used_source') or 'background_heal',
                'exp': runtime_result.get('exp'),
                'loc': runtime_result.get('loc'),
                'sub': runtime_result.get('sub'),
                'final_score': metadata.get('final_score') or 0,
                'accessibility_snapshot_id': metadata.get('accessibility_snapshot_id'),
                'target_ref': metadata.get('snapshot_ref'),
                'snapshot_frame_index': metadata.get('snapshot_frame_index'),
                'snapshot_frame_url': metadata.get('snapshot_frame_url'),
                'durable_locator_strategy': metadata.get('durable_locator_strategy'),
            }
        try:
            parsed_index = int(candidate_index or 0)
        except (TypeError, ValueError):
            parsed_index = 0
        return self._to_candidate(selected_row), parsed_index

    def _revalidated_runtime_result(self, runtime_result: dict, selected, row: dict):
        if not selected:
            return None
        decision = HealingPolicy(self._heal_mode()).decide(selected.verification)
        if decision.status == HealingStatus.SUGGESTED:
            return None
        metadata = dict(runtime_result.get('metadata') or {})
        metadata.update({
            'background_revalidated': True,
            'final_score': selected.verification.final_score,
            'auto_apply_eligible': selected.verification.auto_apply_eligible,
            'selected_exp': selected.verification.candidate.exp,
            'selected_loc': selected.verification.candidate.loc,
            'selected_sub': selected.verification.candidate.sub,
            'revalidation': row,
        })
        return self._runtime_result(selected, metadata)

    async def _build_dom_proximity_candidates(self, page, element_model, failed_expression):
        values = await CandidateRegistry.current_page_async(
            page, target_texts(element_model), failed_expression,
        )
        return [item.to_runtime_dict() for item in values]

    def _build_dom_proximity_candidates_sync(self, page, element_model, failed_expression):
        values = CandidateRegistry.current_page_sync(
            page, target_texts(element_model), failed_expression,
        )
        return [item.to_runtime_dict() for item in values]

    @staticmethod
    def _normalize_dom_candidates(rows, failed_expression):
        values = deduplicate(DomProximityCandidateSource.normalize(rows), failed_expression)
        return [item.to_runtime_dict() for item in values]

    @staticmethod
    def _trigger_context(error, failed_expression, find_params):
        error_text = getattr(error, 'msg', None) or getattr(error, 'message', None) or str(error or '')
        return {
            'error': str(error_text).strip()[:500],
            'failed_expression': list(failed_expression or [])[-10:],
            'ope_key': (find_params or {}).get('ope_key'),
            'origin_loc': (find_params or {}).get('loc'),
            'origin_exp': (find_params or {}).get('exp'),
            'origin_sub': (find_params or {}).get('sub'),
        }

    async def _verify_candidates_async(self, page, element_id, element_model, candidates,
                                       candidate_results, reject_reasons, heal_mode,
                                       start_index=0, total_count=None, find_params=None,
                                       trigger_context=None):
        typed = [self._to_candidate(item) for item in candidates]
        selected = await self._verify_async(
            page, element_model, typed, find_params or {}, candidate_results, reject_reasons, start_index,
        )
        if not selected:
            return None
        context = await HealingContextBuilder.build_async(
            page, element_model, [], find_params or {}, None, self.test_env,
        )
        recorder = TraceRecorder(context)
        decision = HealingPolicy(heal_mode).decide(selected.verification)
        trace = recorder.finish(typed, candidate_results, reject_reasons, decision, agent=self.agent)
        metadata = TraceRecorder.runtime_metadata(
            selected, typed, candidate_results, reject_reasons, heal_mode, context, trace, decision,
        )
        if total_count is not None:
            metadata['candidate_count'] = total_count
            metadata['candidate_summary']['total'] = total_count
        self._last_attempts[element_id] = metadata
        if decision.status == HealingStatus.SUGGESTED:
            return None
        return self._runtime_result(selected, metadata)

    @staticmethod
    def _to_candidate(row):
        if isinstance(row, LocatorCandidate):
            return row
        known = {
            'matched_label', 'candidate_text', 'distance', 'raw', 'raw_expression',
            'agent_schema_validated', 'agent_schema_version', 'snapshot_ref_resolved',
            'snapshot_matcher_validated', 'snapshot_selection_strategy',
            'accessibility_snapshot_id', 'target_ref', 'snapshot_frame_index', 'snapshot_frame_url',
            'snapshot_node_role', 'snapshot_node_name', 'snapshot_node_text',
            'snapshot_node_label', 'snapshot_node_nearby_text', 'snapshot_node_path',
            'snapshot_parent_name', 'snapshot_parent_text', 'snapshot_parent_label',
            'snapshot_parent_nearby_text', 'durable_locator_strategy',
        }
        return LocatorCandidate(
            source=row.get('source') or 'unknown',
            initial_score=row.get('score') or row.get('final_score') or 0,
            exp=row.get('exp'),
            loc=row.get('loc'),
            sub=row.get('sub'),
            reason=row.get('reason') or '',
            snapshot_id=row.get('snapshot_id'),
            heal_record_id=row.get('heal_record_id'),
            generated_by_ai=bool(row.get('used_ai')),
            metadata={key: row.get(key) for key in known if row.get(key) is not None},
        )

    _read_text_async = staticmethod(read_text_async)
    _read_text_sync = staticmethod(read_text_sync)
    _is_visible_sync = staticmethod(is_visible_sync)
    _candidate_summary = staticmethod(CandidateSummary.build)
    _playwright_text_sub_score = staticmethod(DomTextCandidateSource.score)
    _target_texts = staticmethod(target_texts)


WebElementLocatorEngine = WebElementHealingHarness
