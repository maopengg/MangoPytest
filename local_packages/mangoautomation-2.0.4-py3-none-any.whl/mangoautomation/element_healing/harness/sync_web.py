# -*- coding: utf-8 -*-
import time

from ..candidates import AccessibilityAgentCandidateSource, CandidateRegistry
from ..context import HealingContextBuilder
from ..models import FailedLocator
from ..observability import TraceRecorder
from ..policy import (
    DETERMINISTIC_BUDGET_SECONDS,
    MAX_AGENT_CANDIDATES,
    MAX_CANDIDATES,
    MAX_HISTORICAL_CANDIDATES,
    TOTAL_HEALING_BUDGET_SECONDS,
    AgentCircuitBreaker,
)
from ..snapshot import SnapshotRefResolver


class SyncWebHealingRunner:
    def run(self, harness, page, element_model, failed_expression, find_params, error=None):
        if harness.agent:
            harness.agent.reset_attempt()
        started = time.perf_counter()
        deterministic_deadline = started + DETERMINISTIC_BUDGET_SECONDS
        total_deadline = started + TOTAL_HEALING_BUDGET_SECONDS
        context = HealingContextBuilder.build_sync(
            page, element_model, failed_expression, find_params, error, harness.test_env,
        )
        recorder = TraceRecorder(context)
        memory_started = time.perf_counter()
        try:
            memory = harness._get_cached_ai_info(context.element_id)
            if not memory:
                memory = harness.memory_provider.load_sync(context.element_id, harness.test_env)
                harness._cache_memory(context.element_id, memory)
            recorder.stage('memory', memory_started)
        except Exception as memory_error:
            memory = {}
            recorder.stage('memory', memory_started, error=str(memory_error))

        all_candidates = []
        results = []
        rejects = []

        historical_started = time.perf_counter()
        reserve_for_agent = MAX_AGENT_CANDIDATES if harness.agent and harness.agent.available else 0
        deterministic_capacity = MAX_CANDIDATES - reserve_for_agent
        historical = CandidateRegistry.historical(
            memory, element_model, failed_expression,
        )[:min(MAX_HISTORICAL_CANDIDATES, deterministic_capacity)]
        all_candidates.extend(historical)
        recorder.stage('historical_candidates', historical_started, len(historical))
        selected = harness._verify_sync(
            page, element_model, historical, find_params, results, rejects, 0,
            deadline=deterministic_deadline,
        )
        if selected:
            return harness._finish_sync(selected, context, recorder, all_candidates, results, rejects)

        dom_started = time.perf_counter()
        dom_capacity = max(0, deterministic_capacity - len(historical))
        dom = []
        dom_error = None
        if dom_capacity and time.perf_counter() < deterministic_deadline:
            dom = CandidateRegistry.current_page_sync(
                page, context.expected_semantics.target_texts, failed_expression,
            )[:dom_capacity]
            if time.perf_counter() > deterministic_deadline:
                dom = []
                dom_error = 'deterministic candidate generation budget exhausted'
                harness._append_budget_reject(rejects, dom_error)
        elif time.perf_counter() >= deterministic_deadline:
            dom_error = 'deterministic healing budget exhausted'
            harness._append_budget_reject(rejects, dom_error)
        all_candidates.extend(dom)
        recorder.stage('current_page_candidates', dom_started, len(dom), error=dom_error)
        selected = harness._verify_sync(
            page, element_model, dom, find_params, results, rejects, len(historical),
            deadline=deterministic_deadline,
        )
        if selected:
            return harness._finish_sync(selected, context, recorder, all_candidates, results, rejects)

        agent_context = context.model_copy(deep=True)
        known_failed = {item.loc for item in agent_context.failed_locators}
        for row in results:
            loc = row.get('loc')
            if loc and not row.get('verified') and loc not in known_failed:
                agent_context.failed_locators.append(FailedLocator(loc=loc))
                known_failed.add(loc)
        agent_started = time.perf_counter()
        agent_candidates = []
        agent_error = None
        agent_available = bool(harness.agent and harness.agent.available)
        breaker_status = AgentCircuitBreaker.status(context.element_id, context.page_url)
        recorder.trace.agent_circuit_breaker = breaker_status.to_dict()
        agent_allowed = agent_available and breaker_status.allowed
        recorder.trace.agent_called = agent_allowed
        if agent_available and not agent_allowed:
            agent_error = 'agent circuit breaker cooldown active'
            log_method = harness.log.debug if breaker_status.configuration_error else harness.log.warning
            log_method(
                f'[元素自愈Agent熔断] 跳过模型调用，元素ID={context.element_id}，'
                f'页面={context.page_url}，连续失败={breaker_status.failure_count}/'
                f'{breaker_status.threshold}，冷却剩余='
                f'{breaker_status.cooldown_remaining_seconds:.1f}s，'
                f'最近失败={breaker_status.last_error or "-"}'
            )
        elif agent_allowed and time.perf_counter() < total_deadline:
            if breaker_status.recovery_probe:
                harness.log.info(
                    f'[元素自愈Agent熔断] 冷却结束，开始恢复探测，'
                    f'元素ID={context.element_id}，页面={context.page_url}，'
                    f'此前连续失败={breaker_status.failure_count}，'
                    f'最近失败={breaker_status.last_error or "-"}'
                )
            try:
                agent_candidates = AccessibilityAgentCandidateSource(harness.agent).build_sync(
                    page, agent_context, memory,
                )
                agent_error = getattr(harness.agent, 'last_error', None)
                if not agent_error and not agent_candidates:
                    agent_error = 'agent returned no valid candidates'
            except Exception as agent_exception:
                agent_error = str(agent_exception)
            if time.perf_counter() > total_deadline:
                agent_candidates = []
                agent_error = 'total healing budget exhausted during agent call'
            if agent_error or not agent_candidates:
                breaker_status = AgentCircuitBreaker.failure(
                    context.element_id, context.page_url, error=agent_error,
                    configuration_error=AgentCircuitBreaker.is_configuration_error(agent_error),
                )
                recorder.trace.agent_circuit_breaker = breaker_status.to_dict()
                message = (
                    f'元素ID={context.element_id}，页面={context.page_url}，'
                    f'连续失败={breaker_status.failure_count}/{breaker_status.threshold}，'
                    f'是否熔断={not breaker_status.allowed}，'
                    f'冷却={breaker_status.cooldown_remaining_seconds:.1f}s，'
                    f'原因={agent_error or "-"}'
                )
                harness.log.warning(f'[元素自愈Agent失败] {message}')
            else:
                recovered = AgentCircuitBreaker.success(context.element_id, context.page_url)
                recorder.trace.agent_circuit_breaker = recovered.to_dict()
                harness.log.info(
                    f'[元素自愈Agent成功] 元素ID={context.element_id}，'
                    f'页面={context.page_url}，候选数={len(agent_candidates)}，'
                    f'已清除失败计数={recovered.failure_count}'
                )
        elif agent_allowed:
            agent_error = 'total healing budget exhausted before agent call'
        agent_capacity = max(0, MAX_CANDIDATES - len(all_candidates))
        agent_candidates = agent_candidates[:agent_capacity]
        all_candidates.extend(agent_candidates)
        recorder.stage('agent_candidates', agent_started, len(agent_candidates), error=agent_error)
        selected = harness._verify_sync(
            page, element_model, agent_candidates, find_params, results, rejects,
            len(historical) + len(dom),
            deadline=total_deadline,
        )
        if selected:
            result = harness._finish_sync(selected, context, recorder, all_candidates, results, rejects)
            if result is None and harness.agent and harness.agent.last_snapshot_id:
                SnapshotRefResolver.clear_sync(page, harness.agent.last_snapshot_id)
            return result
        result = harness._exhausted_sync(context, recorder, all_candidates, results, rejects)
        if harness.agent and harness.agent.last_snapshot_id:
            SnapshotRefResolver.clear_sync(page, harness.agent.last_snapshot_id)
        return result
