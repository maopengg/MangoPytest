# -*- coding: utf-8 -*-
import time


class MemoryCache:
    def __init__(self, ttl: int = 60):
        self.ttl = ttl
        self._values: dict[tuple[int, int | None], tuple[float, dict]] = {}

    def get(self, element_id: int, test_env: int | None = None) -> dict | None:
        key = (element_id, test_env)
        cached = self._values.get(key)
        if not cached or time.time() - cached[0] > self.ttl:
            self._values.pop(key, None)
            return None
        return cached[1]

    def set(self, element_id: int, test_env: int | None, value: dict) -> dict:
        value = value if isinstance(value, dict) else {}
        self._values[(element_id, test_env)] = (time.time(), value)
        return value

    def clear(self) -> None:
        self._values.clear()

