# -*- coding: utf-8 -*-
from copy import deepcopy


class InMemoryProvider:
    def __init__(self, initial: dict | None = None):
        self._values: dict[tuple[int, int | None], dict] = {}
        for key, value in (initial or {}).items():
            if isinstance(key, tuple):
                self._values[key] = deepcopy(value)
            else:
                self._values[(int(key), None)] = deepcopy(value)

    def put(self, element_id: int, value: dict, test_env: int | None = None) -> None:
        self._values[(element_id, test_env)] = deepcopy(value if isinstance(value, dict) else {})

    async def load_async(self, element_id: int, test_env: int | None = None) -> dict:
        return self.load_sync(element_id, test_env)

    def load_sync(self, element_id: int, test_env: int | None = None) -> dict:
        value = self._values.get((element_id, test_env))
        if value is None:
            value = self._values.get((element_id, None), {})
        return deepcopy(value)


class InMemoryEventSink:
    def __init__(self):
        self.events: list[tuple[str, dict]] = []

    async def emit_async(self, event: str, payload: dict) -> None:
        self.events.append((event, deepcopy(payload)))

    def emit_sync(self, event: str, payload: dict) -> None:
        self.events.append((event, deepcopy(payload)))

