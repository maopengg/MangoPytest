# -*- coding: utf-8 -*-


class NullMemoryProvider:
    async def load_async(self, element_id: int, test_env: int | None = None) -> dict:
        return {}

    def load_sync(self, element_id: int, test_env: int | None = None) -> dict:
        return {}


class NullEventSink:
    async def emit_async(self, event: str, payload: dict) -> None:
        return None

    def emit_sync(self, event: str, payload: dict) -> None:
        return None

