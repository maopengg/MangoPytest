# -*- coding: utf-8 -*-
import ast

from .supported_methods import ALLOWED_CHAIN_METHODS, ALLOWED_LOCATOR_METHODS


class LocatorExpressionParser:
    @classmethod
    def validate(cls, expression: str) -> None:
        expression = str(expression or '').strip()
        if expression.startswith('page.'):
            expression = expression[5:]
        try:
            tree = ast.parse(expression, mode='eval')
        except SyntaxError:
            raise ValueError('locator表达式语法错误') from None
        cls._validate_node(tree.body)

    @classmethod
    def evaluate(cls, page, expression: str):
        expression = str(expression or '').strip()
        if expression.startswith('page.'):
            expression = expression[5:]
        tree = ast.parse(expression, mode='eval')
        return cls._evaluate_node(page, tree.body)

    @classmethod
    def _validate_node(cls, node):
        if not isinstance(node, ast.Call):
            raise ValueError('不支持的locator表达式')
        if isinstance(node.func, ast.Attribute):
            cls._validate_node(node.func.value)
            method = node.func.attr
            if method not in ALLOWED_CHAIN_METHODS:
                raise ValueError(f'不支持的locator链式方法：{method}')
            cls._literal_call_args(node)
            return
        if isinstance(node.func, ast.Name):
            method = node.func.id
            if method not in ALLOWED_LOCATOR_METHODS:
                raise ValueError(f'不支持的locator方法：{method}')
            cls._literal_call_args(node)
            return
        raise ValueError('locator根表达式必须是方法调用')

    @classmethod
    def _evaluate_node(cls, current, node):
        if not isinstance(node, ast.Call):
            raise ValueError('不支持的locator表达式')
        if isinstance(node.func, ast.Attribute):
            parent = cls._evaluate_node(current, node.func.value)
            method = node.func.attr
            if method not in ALLOWED_CHAIN_METHODS:
                raise ValueError(f'不支持的locator链式方法：{method}')
            args, kwargs = cls._literal_call_args(node)
            return getattr(parent, method)(*args, **kwargs)
        if isinstance(node.func, ast.Name):
            method = node.func.id
            if method not in ALLOWED_LOCATOR_METHODS:
                raise ValueError(f'不支持的locator方法：{method}')
            args, kwargs = cls._literal_call_args(node)
            return getattr(current, method)(*args, **kwargs)
        raise ValueError('locator根表达式必须是方法调用')

    @staticmethod
    def _literal_call_args(node: ast.Call):
        args = [ast.literal_eval(arg) for arg in node.args]
        kwargs = {}
        for keyword in node.keywords:
            if keyword.arg is None:
                raise ValueError('locator表达式不支持展开参数')
            kwargs[keyword.arg] = ast.literal_eval(keyword.value)
        return args, kwargs
