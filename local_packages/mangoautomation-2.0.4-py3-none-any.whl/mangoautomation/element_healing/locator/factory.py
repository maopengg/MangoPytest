# -*- coding: utf-8 -*-
import logging

from mangoautomation.enums import ElementExpEnum

from ..snapshot import SnapshotRefResolver
from .expression_parser import LocatorExpressionParser

log = logging.getLogger(__name__)


class LocatorFactory:
    @classmethod
    def create(cls, page, candidate):
        if SnapshotRefResolver.supports(candidate):
            return SnapshotRefResolver.resolve(page, candidate)
        return cls.create_persistent(page, candidate)

    @classmethod
    def create_persistent(cls, page, candidate):
        candidate = candidate.to_runtime_dict() if hasattr(candidate, 'to_runtime_dict') else candidate
        exp = candidate.get('exp')
        loc = candidate.get('loc')
        if exp == ElementExpEnum.XPATH.value:
            return page.locator(f'xpath={loc}')
        if exp == ElementExpEnum.CSS.value:
            return page.locator(loc)
        if exp == ElementExpEnum.TEXT.value:
            return page.get_by_text(loc, exact=True)
        if exp == ElementExpEnum.PLACEHOLDER.value:
            return page.get_by_placeholder(loc)
        if exp == ElementExpEnum.LOCATOR.value:
            try:
                return LocatorExpressionParser.evaluate(page, str(loc))
            except Exception as error:
                log.debug(f'[元素自愈] locator表达式解析失败，降级为CSS locator: {loc}，错误：{error}')
                return page.locator(str(loc))
        return page.locator(str(loc))
