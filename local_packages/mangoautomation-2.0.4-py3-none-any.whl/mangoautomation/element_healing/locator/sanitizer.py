# -*- coding: utf-8 -*-
import re


def clean(value) -> str:
    if value is None:
        return ''
    return str(value).strip()


def css_escape(value: str) -> str:
    return str(value).replace('\\', '\\\\').replace('"', '\\"')


def short_error(error: Exception, limit: int = 240) -> str:
    message = getattr(error, 'message', None) or str(error)
    return re.sub(r'\s+', ' ', message).strip()[:limit]


def limit_text(value, limit: int = 120) -> str:
    value = clean(value)
    if len(value) <= limit:
        return value
    return value[:limit - 3] + '...'

