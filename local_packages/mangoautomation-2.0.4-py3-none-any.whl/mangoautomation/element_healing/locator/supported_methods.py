ALLOWED_LOCATOR_METHODS = {
    'locator',
    'get_by_role',
    'get_by_text',
    'get_by_placeholder',
    'get_by_label',
    'get_by_test_id',
    'get_by_title',
    'get_by_alt_text',
}

ALLOWED_CHAIN_METHODS = {'locator'}

