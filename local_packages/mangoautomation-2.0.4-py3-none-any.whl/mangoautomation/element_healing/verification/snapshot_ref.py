# -*- coding: utf-8 -*-
from ..locator import LocatorFactory
from ..snapshot import SNAPSHOT_REF_ATTRIBUTE, SnapshotRefResolver


class SnapshotRefVerifier:
    @classmethod
    async def verify_durable_async(cls, page, candidate) -> tuple[int | None, str | None]:
        if not SnapshotRefResolver.supports(candidate):
            return None, None
        try:
            locator = LocatorFactory.create_persistent(
                SnapshotRefResolver.scope(page, candidate), candidate,
            )
            count = await locator.count()
            error = await cls._compare_async(locator, count, candidate)
            return count, error
        except Exception as error:
            return None, f'generated durable locator validation failed: {error}'

    @classmethod
    def verify_durable_sync(cls, page, candidate) -> tuple[int | None, str | None]:
        if not SnapshotRefResolver.supports(candidate):
            return None, None
        try:
            locator = LocatorFactory.create_persistent(
                SnapshotRefResolver.scope(page, candidate), candidate,
            )
            count = locator.count()
            error = cls._compare_sync(locator, count, candidate)
            return count, error
        except Exception as error:
            return None, f'generated durable locator validation failed: {error}'

    @classmethod
    async def _compare_async(cls, locator, count: int, candidate) -> str | None:
        error = cls._count_error(count, candidate)
        if error:
            return error
        selected = locator.nth(candidate.sub - 1) if candidate.sub else locator.first
        marker = await selected.get_attribute(SNAPSHOT_REF_ATTRIBUTE)
        return cls._marker_error(marker, candidate)

    @classmethod
    def _compare_sync(cls, locator, count: int, candidate) -> str | None:
        error = cls._count_error(count, candidate)
        if error:
            return error
        selected = locator.nth(candidate.sub - 1) if candidate.sub else locator.first
        marker = selected.get_attribute(SNAPSHOT_REF_ATTRIBUTE)
        return cls._marker_error(marker, candidate)

    @staticmethod
    def _count_error(count: int, candidate) -> str | None:
        if count < 1:
            return 'generated durable locator count=0'
        if candidate.sub and candidate.sub > count:
            return f'generated durable locator sub={candidate.sub} exceeds count={count}'
        return None

    @staticmethod
    def _marker_error(marker, candidate) -> str | None:
        expected = SnapshotRefResolver.marker(
            candidate.metadata['accessibility_snapshot_id'], candidate.metadata['target_ref'],
        )
        if marker != expected:
            return 'generated durable locator does not resolve to selected snapshot ref'
        return None

    @staticmethod
    def select(locator, candidate):
        return SnapshotRefResolver.select(locator, candidate)
