# -*- coding: utf-8 -*-
import json


SEMANTIC_STATE_SCRIPT = r"""
el => {
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim().slice(0, 240);
  const textOf = node => normalize(node && (node.innerText || node.textContent));
  const labels = [];
  const pushLabel = value => {
    value = normalize(value);
    if (value && value.length <= 160 && !labels.includes(value)) labels.push(value);
  };

  if (el.labels) Array.from(el.labels).forEach(label => pushLabel(textOf(label)));
  const labelledBy = normalize(el.getAttribute('aria-labelledby'));
  if (labelledBy) {
    labelledBy.split(/\s+/).forEach(id => pushLabel(textOf(document.getElementById(id))));
  }
  if (el.id) {
    try {
      const explicit = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (explicit) pushLabel(textOf(explicit));
    } catch (error) {}
  }

  const formScopeSelector = [
    '.form-item', '.form-field', '.form-row', '.byte-form-item',
    '.ud__form-item', '.semi-form-field', '.arco-form-item', '.ant-form-item', '.el-form-item'
  ].join(',');
  let formScope = el.closest(formScopeSelector);
  if (!formScope) {
    let ancestor = el.parentElement;
    for (let depth = 0; ancestor && depth < 7; depth += 1, ancestor = ancestor.parentElement) {
      const className = String(ancestor.className || '');
      const looksLikeItem = /form[-_]?item|formItem|form[-_]?field/i.test(className);
      const looksLikeInner = /control|wrapper|content|children|input|label/i.test(className);
      if (looksLikeItem && !looksLikeInner) {
        formScope = ancestor;
        break;
      }
    }
  }
  if (formScope) {
    Array.from(formScope.querySelectorAll([
      'label', '.byte-form-label-item', '[class*="form-label"]', '[class*="FormLabel"]',
      '[class*="label-item"]', '[class*="Label"]'
    ].join(','))).slice(0, 6).forEach(label => pushLabel(textOf(label)));
    Array.from(formScope.children).slice(0, 8).forEach(child => {
      if (child === el || child.contains(el)) return;
      const childTag = String(child.tagName || '').toLowerCase();
      if (!['input', 'textarea', 'select', 'button'].includes(childTag)) pushLabel(textOf(child));
    });
  }

  const tag = String(el.tagName || '').toLowerCase();
  const role = normalize(el.getAttribute('role')).toLowerCase();
  const type = normalize(el.getAttribute('type')).toLowerCase();
  const cursor = window.getComputedStyle(el).cursor;
  const editable = !el.disabled && (
    tag === 'textarea' || tag === 'select' ||
    (tag === 'input' && !['button', 'submit', 'reset', 'checkbox', 'radio', 'file', 'hidden'].includes(type)) ||
    el.isContentEditable || role === 'textbox'
  );
  const directInteractive = !el.disabled && (
    ['button', 'a', 'input', 'textarea', 'select', 'option', 'label'].includes(tag) ||
    ['button', 'link', 'combobox', 'textbox', 'checkbox', 'radio', 'switch', 'option', 'menuitem', 'treeitem', 'listbox'].includes(role) ||
    el.hasAttribute('aria-haspopup') || el.hasAttribute('contenteditable') ||
    (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1')
  );
  // 控件容器 class 启发式：Arco/Element/Ant/Semi 等 UI 库的 select/cascader 触发器是 div 容器，
  // 无 role 且 cursor 常为 default，但承载点击展开行为，与候选生成端 dom_proximity 判定保持一致
  const controlContainerClass = /(^|[\s_-])(select|picker|selector|selection|trigger|cascader|combobox|input-wrapper|dropdown)([\s_-]|$)/i.test(String(el.className || ''));
  const interactive = directInteractive || (!el.disabled && (cursor === 'pointer' || controlContainerClass));
  return {
    tag,
    role,
    type,
    text: textOf(el),
    aria_label: normalize(el.getAttribute('aria-label')),
    name: normalize(el.getAttribute('name')),
    title: normalize(el.getAttribute('title')),
    placeholder: normalize(el.getAttribute('placeholder')),
    test_id: normalize(
      el.getAttribute('data-testid') || el.getAttribute('data-test-id') ||
      el.getAttribute('data-test') || el.getAttribute('data-cy') || el.getAttribute('data-qa')
    ),
    label_texts: labels,
    editable,
    interactive,
    direct_interactive: directInteractive
  };
}
"""


async def read_text_async(locator) -> str | None:
    methods = (
        locator.inner_text,
        locator.text_content,
        locator.input_value,
        lambda: locator.get_attribute('value'),
    )
    for method in methods:
        try:
            value = await method()
            if value is not None and str(value).strip():
                return str(value)
        except Exception:
            continue
    return None


def read_text_sync(locator) -> str | None:
    methods = (
        locator.inner_text,
        locator.text_content,
        locator.input_value,
        lambda: locator.get_attribute('value'),
    )
    for method in methods:
        try:
            value = method()
            if value is not None and str(value).strip():
                return str(value)
        except Exception:
            continue
    return None


async def is_visible_async(locator) -> bool:
    try:
        return await locator.is_visible()
    except Exception:
        return False


def is_visible_sync(locator) -> bool:
    try:
        return locator.is_visible()
    except Exception:
        return False


async def read_semantic_state_async(locator) -> dict:
    try:
        value = await locator.evaluate(SEMANTIC_STATE_SCRIPT)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def read_semantic_state_sync(locator) -> dict:
    try:
        value = locator.evaluate(SEMANTIC_STATE_SCRIPT)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def semantic_state_signature(state: dict | None) -> str:
    state = state or {}
    stable = {
        key: state.get(key)
        for key in ('tag', 'role', 'type', 'aria_label', 'name', 'title', 'placeholder', 'test_id', 'label_texts')
    }
    return json.dumps(stable, ensure_ascii=False, sort_keys=True)
