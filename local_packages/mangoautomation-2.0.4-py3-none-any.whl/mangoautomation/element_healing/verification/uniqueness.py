# -*- coding: utf-8 -*-


def uniqueness_reject_reason(count: int, sub: int | None) -> tuple[str | None, str | None]:
    if count < 1:
        return 'count_zero', 'count=0'
    if count > 1 and not sub:
        return 'ambiguous', f'ambiguous count={count}'
    return None, None

