# -*- coding: utf-8 -*-


class CandidateScorer:
    @staticmethod
    def final_score(candidate, *, visible: bool, semantic_score: float, stability_score: float,
                    actionable: bool, operation_compatible: bool) -> float:
        if not visible or not actionable or not operation_compatible:
            return 0
        initial_score = float(getattr(candidate, 'initial_score', 0) or 0)
        score = initial_score * 0.35 + semantic_score * 0.40 + stability_score * 0.25
        return round(max(0, min(100, score)), 2)

    @staticmethod
    def stability_score(candidate) -> float:
        loc = str(getattr(candidate, 'loc', '') or '').lower()
        source = str(getattr(candidate, 'source', '') or '')
        score = 65.0
        if 'unique_visible_text' in source:
            score = 65.0
        elif 'get_by_test_id(' in loc or any(key in loc for key in ('data-testid', 'data-test-id', 'data-cy', 'data-qa')):
            score = 100.0
        elif any(key in loc for key in ('get_by_role(', 'get_by_label(', 'get_by_placeholder(')):
            score = 92.0
        elif 'get_by_title(' in loc or 'get_by_alt_text(' in loc:
            score = 88.0
        elif 'get_by_text(' in loc:
            score = 85.0
        elif 'normalize-space' in loc or 'label_relative_xpath' in source:
            score = 82.0
        elif loc.startswith('/html/body/') or 'nth-of-type' in loc:
            score = 45.0
        elif any(key in loc for key in ('[class*=', 'contains(@class', 'locator(".', "locator('.")):
            score = 60.0
        metadata = getattr(candidate, 'metadata', None) or {}
        if metadata.get('snapshot_matcher_validated'):
            score = max(score, 90.0)
        if getattr(candidate, 'sub', None):
            score -= 10
        return max(0, min(100, score))

    @staticmethod
    def verified_read_score(score: float, *, semantic_evidence: list[str], count: int,
                            consecutive_passes: int, stable_context: bool,
                            durable_count: int | None, has_subscript: bool,
                            find_params: dict | None) -> float:
        """Promote a strongly verified Agent read target to temporary-use grade.

        Dynamic values such as an applicant name do not contain their field label. The
        Agent's resolved Snapshot ref, uniqueness and repeat validation are sufficient
        for a side-effect-free read, but never for click/edit/upload operations.
        """
        from ..policy.operation_rules import is_read_operation
        from ..policy.thresholds import TEMPORARY_HEAL_SCORE

        trusted_agent_read = 'trusted_agent_read_target' in (semantic_evidence or [])
        durable_locator_resolved = durable_count in (None, 1) or (
            has_subscript and isinstance(durable_count, int) and durable_count > 0
        )
        if (
                trusted_agent_read and is_read_operation(find_params) and count == 1 and
                consecutive_passes >= 2 and stable_context and durable_locator_resolved):
            return max(float(score or 0), float(TEMPORARY_HEAL_SCORE))
        return float(score or 0)
