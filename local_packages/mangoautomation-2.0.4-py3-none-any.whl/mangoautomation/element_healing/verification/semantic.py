# -*- coding: utf-8 -*-
import re
from difflib import SequenceMatcher

from ..context import semantic_required_texts, target_texts
from ..locator import clean
from ..models import CandidateSource
from ..policy.operation_rules import is_read_operation, semantic_strength


class SemanticVerifier:
    GENERIC_TARGETS = {
        '元素', '按钮', '输入框', '文本框', '搜索框', '下拉框', '选择框',
        '复选框', '单选框', '文本', '结果', '链接', '图片', '表格', '文件上传',
    }
    TRUSTED_MEMORY_SOURCES = {
        CandidateSource.APPLIED_HEAL_RECORD.value,
        CandidateSource.LATEST_SNAPSHOT_LOCATOR.value,
        CandidateSource.HISTORY_SNAPSHOT_LOCATOR.value,
        CandidateSource.BASELINE_SEMANTIC.value,
    }

    @classmethod
    def fixed_reject_reason(cls, element_model, element_text, loc):
        # Runtime variables intentionally make the visible target differ between cases.
        # The resolved locator and actionability checks are stronger evidence here than
        # the reusable platform element name.
        if cls._has_dynamic_locator(element_model) or cls._has_dynamic_semantics(element_model):
            return None
        targets = semantic_required_texts(element_model) or [
            item for item in target_texts(element_model)
            if len(clean(item)) >= 3 and not clean(item).startswith('查找元素')
        ]
        targets = [item for item in targets if clean(item) not in cls.GENERIC_TARGETS]
        if not targets:
            return None
        current_text = clean(element_text)
        current_loc = clean(loc)
        # Icon-only controls often have no visible text. A unique, actionable fixed
        # locator is not a semantic mismatch when there is no runtime text evidence
        # to contradict the configured target name.
        if not current_text:
            return None
        haystack = f'{current_text} {current_loc}'
        if any(target and target in haystack for target in targets):
            return None
        if cls._locator_literal_matches_text(current_loc, current_text):
            return None
        strongest = max(targets, key=len)
        return f'fixed locator semantic mismatch: expected target "{strongest}", actual "{current_text or current_loc}"'

    @classmethod
    def _locator_literal_matches_text(cls, loc: str, element_text: str) -> bool:
        if not loc or not element_text:
            return False
        literals = [
            next(item for item in match if item)
            for match in re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"|\'([^\'\\]*(?:\\.[^\'\\]*)*)\'', loc)
        ]
        actual_variants = cls._variants(element_text)
        return any(
            cls._match_score(cls._variants(literal), actual_variants) >= 80
            for literal in literals
        )

    @staticmethod
    def _has_dynamic_locator(element_model) -> bool:
        for item in getattr(element_model, 'elements', None) or []:
            if '${{' in str(getattr(item, 'loc', '') or ''):
                return True
        return False

    @staticmethod
    def _has_dynamic_semantics(element_model) -> bool:
        values = [getattr(element_model, 'name', None)]
        values.extend(getattr(item, 'prompt', None) for item in getattr(element_model, 'elements', None) or [])
        return any(
            marker in clean(value)
            for value in values
            if value
            for marker in ('全局变量', '变量元素', '动态元素', '参数化元素')
        )

    @classmethod
    def candidate_evaluation(cls, element_model, semantic_state: dict | None, candidate=None,
                             find_params: dict | None = None):
        memory_evidence = cls._trusted_memory_evidence(
            candidate, semantic_state or {}, find_params,
        )
        if memory_evidence:
            return 100.0, memory_evidence, None
        targets = [
            item for item in semantic_required_texts(element_model)
            if clean(item) not in cls.GENERIC_TARGETS
        ]
        if not targets:
            return 100.0, ['semantic_not_required'], None
        state = semantic_state or {}
        values = cls._actual_values(state, candidate)
        best_score = 0.0
        evidence = []
        for target in targets:
            target_variants = cls._variants(target)
            for field, value in values:
                value_variants = cls._variants(value)
                score = cls._match_score(target_variants, value_variants)
                if score > best_score:
                    best_score = score
                    evidence = [field]
                elif score == best_score and score > 0 and field not in evidence:
                    evidence.append(field)
        if best_score >= 80:
            return best_score, evidence, None
        read_evidence = cls._trusted_agent_read_evidence(
            candidate, state, find_params, best_score,
        )
        if read_evidence:
            return 90.0, read_evidence, None
        strongest = max(targets, key=len)
        actual = ' '.join(clean(value) for _, value in values if clean(value))[:120]
        return best_score, evidence, (
            f'candidate semantic mismatch: expected target "{strongest}", actual "{actual}"'
        )

    @classmethod
    def candidate_reject_reason(cls, element_model, candidate, element_text, find_params=None,
                                semantic_state: dict | None = None):
        state = dict(semantic_state or {})
        if element_text and not state.get('text'):
            state['text'] = element_text
        _, _, error = cls.candidate_evaluation(element_model, state, candidate, find_params)
        return error

    @classmethod
    def _trusted_agent_read_evidence(cls, candidate, state: dict,
                                     find_params: dict | None,
                                     semantic_score: float) -> list[str]:
        """Allow a validated Agent selection to return dynamic text for read operations.

        A value such as a contract title does not contain the configured semantic label
        "合同名称". The snapshot ref still proves which live DOM node the Agent selected;
        durable-locator verification later proves that the generated locator reaches the
        same node. This exception must never relax click/edit operations.
        """
        if candidate is None or not is_read_operation(find_params):
            return []
        source = getattr(candidate, 'source', '')
        source = getattr(source, 'value', source)
        metadata = getattr(candidate, 'metadata', None) or {}
        if str(source) != CandidateSource.ACCESSIBILITY_AGENT.value:
            return []
        if not metadata.get('snapshot_ref_resolved'):
            return []
        if not (metadata.get('agent_schema_validated') or metadata.get('snapshot_matcher_validated')):
            return []
        if not any(clean(state.get(key)) for key in ('text', 'name', 'title', 'aria_label')):
            return []
        if semantic_score < semantic_strength(find_params):
            return []
        return ['trusted_agent_read_target']

    @classmethod
    def _trusted_memory_evidence(cls, candidate, state: dict,
                                 find_params: dict | None = None) -> list[str]:
        if candidate is None:
            return []
        source = getattr(candidate, 'source', '')
        source = getattr(source, 'value', source)
        if str(source) not in cls.TRUSTED_MEMORY_SOURCES:
            return []
        loc = clean(getattr(candidate, 'loc', ''))
        if is_read_operation(find_params) and cls._is_dynamic_text_locator(candidate, loc):
            return []
        values = cls._actual_values(state, candidate)
        if any(cls._locator_literal_matches_text(loc, value) for _, value in values):
            return ['trusted_memory_locator']

        semantic_kind = clean((getattr(candidate, 'metadata', None) or {}).get('semantic_kind'))
        field_by_kind = {'placeholder': 'placeholder', 'text': 'text'}
        field = field_by_kind.get(semantic_kind)
        if not field:
            return []
        actual = clean(state.get(field))
        if cls._match_score(cls._variants(loc), cls._variants(actual)) >= 80:
            return [f'trusted_memory_{field}']
        return []

    @staticmethod
    def _is_dynamic_text_locator(candidate, loc: str) -> bool:
        exp = getattr(candidate, 'exp', None)
        return bool(
            exp == 3 or 'get_by_text(' in loc or
            (exp == 0 and ('normalize-space' in loc or 'text()' in loc))
        )

    @staticmethod
    def _actual_values(state: dict, candidate=None) -> list[tuple[str, str]]:
        values = []
        for key in ('text', 'aria_label', 'name', 'title', 'placeholder', 'test_id'):
            value = clean(state.get(key))
            if value:
                values.append((key, value))
        for value in state.get('label_texts') or []:
            value = clean(value)
            if value:
                values.append(('label_text', value))
        values.extend(SemanticVerifier._trusted_snapshot_context(candidate))
        return values

    @staticmethod
    def _trusted_snapshot_context(candidate) -> list[tuple[str, str]]:
        if candidate is None:
            return []
        source = getattr(candidate, 'source', '')
        source = getattr(source, 'value', source)
        metadata = getattr(candidate, 'metadata', None) or {}
        if str(source) != CandidateSource.ACCESSIBILITY_AGENT.value:
            return []
        trusted_selection = (
            metadata.get('agent_schema_validated') or
            metadata.get('snapshot_matcher_validated')
        )
        if not trusted_selection or not metadata.get('snapshot_ref_resolved'):
            return []
        values = []
        for key in (
                'snapshot_node_name', 'snapshot_node_text', 'snapshot_node_label',
                'snapshot_node_nearby_text', 'snapshot_parent_name', 'snapshot_parent_text',
                'snapshot_parent_label', 'snapshot_parent_nearby_text'):
            value = clean(metadata.get(key))
            if value:
                values.append((key, value))
        path = metadata.get('snapshot_node_path') or []
        if isinstance(path, list):
            value = clean(' '.join(str(item) for item in path if item))
            if value:
                values.append(('snapshot_node_path', value))
        return values

    @staticmethod
    def _variants(value: str) -> list[str]:
        value = clean(value).lower()
        if not value:
            return []
        variants = [value]
        stripped = re.sub(r'^(请|请先)?(输入|选择|填写|搜索|点击|上传|添加|创建)', '', value).strip('：: *')
        if stripped and stripped not in variants:
            variants.append(stripped)
        return variants

    @staticmethod
    def _match_score(targets: list[str], values: list[str]) -> float:
        best = 0.0
        for target in targets:
            for value in values:
                if target == value:
                    return 100.0
                if len(target) >= 2 and (target in value or value in target):
                    best = max(best, 85.0)
                if min(len(target), len(value)) >= 3:
                    best = max(best, SequenceMatcher(None, target, value).ratio() * 80)
        return best
