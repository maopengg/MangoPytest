# -*- coding: utf-8 -*-
from dataclasses import dataclass
from typing import Any

from ..models import VerificationResult


@dataclass
class VerifiedLocator:
    locator: Any
    count: int
    text: str | None
    verification: VerificationResult
    runtime_row: dict

