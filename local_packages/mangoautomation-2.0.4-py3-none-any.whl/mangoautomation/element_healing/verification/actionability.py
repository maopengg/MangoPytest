# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..locator import short_error
from ..policy.operation_rules import CLICK_ACTION_KEYS, EDITABLE_ACTION_KEYS, is_click_operation, operation_key


TEXT_CLICK_INTERACTIVE_SCRIPT = r"""
        el => {
          const visible = node => {
            if (!node || node.nodeType !== Node.ELEMENT_NODE) return false;
            const style = window.getComputedStyle(node);
            if (style.visibility === 'hidden' || style.display === 'none' || Number(style.opacity) === 0) return false;
            const rect = node.getBoundingClientRect();
            return rect.width > 1 && rect.height > 1;
          };
          const hasSignal = node => {
            if (!node || !visible(node)) return false;
            const tag = String(node.tagName || '').toLowerCase();
            const role = String(node.getAttribute('role') || '').toLowerCase();
            const cls = String(node.className || '').toLowerCase();
            const cursor = window.getComputedStyle(node).cursor;
            return ['button', 'a', 'input', 'textarea', 'select', 'option'].includes(tag) ||
              ['button', 'link', 'combobox', 'option', 'menuitem', 'treeitem', 'checkbox', 'radio', 'switch'].includes(role) ||
              node.hasAttribute('aria-haspopup') ||
              (node.hasAttribute('tabindex') && node.getAttribute('tabindex') !== '-1') ||
              cursor === 'pointer' ||
              /option|menuitem|menu-item|button|select|picker|selector|selection|trigger|dropdown|tree|checkbox|radio|switch|cascader|combobox|input-wrapper/.test(cls);
          };
          const isSemanticControl = node => {
            if (!node || !visible(node)) return false;
            const tag = String(node.tagName || '').toLowerCase();
            const role = String(node.getAttribute('role') || '').toLowerCase();
            return ['button', 'a', 'input', 'textarea', 'select', 'option'].includes(tag) ||
              ['button', 'link', 'combobox', 'option', 'menuitem', 'treeitem', 'checkbox', 'radio', 'switch'].includes(role) ||
              node.hasAttribute('aria-haspopup') ||
              (node.hasAttribute('tabindex') && node.getAttribute('tabindex') !== '-1');
          };
          const isLabelWithNearbyControl = node => {
            if (!node || !visible(node) || isSemanticControl(node)) return false;
            const tag = String(node.tagName || '').toLowerCase();
            if (!['label', 'span', 'div', 'p', 'dt', 'th'].includes(tag)) return false;
            const labelRect = node.getBoundingClientRect();
            let scope = node.parentElement;
            for (let depth = 0; scope && depth < 4; depth += 1, scope = scope.parentElement) {
              const controls = Array.from(scope.querySelectorAll(
                'input, textarea, select, button, [role="button"], [role="combobox"], [role="textbox"], ' +
                '[role="checkbox"], [role="radio"], [role="switch"], [aria-haspopup], ' +
                '[tabindex]:not([tabindex="-1"]), [class*="select"], [class*="selector"], ' +
                '[class*="selection"], [class*="trigger"], [class*="dropdown"], [class*="cascader"]'
              ));
              for (const control of controls) {
                if (control === node || node.contains(control) || !visible(control)) continue;
                const rect = control.getBoundingClientRect();
                const centerDelta = Math.abs((rect.top + rect.height / 2) - (labelRect.top + labelRect.height / 2));
                const sameRow = rect.left >= labelRect.right - 12 && centerDelta <= 28;
                const nearbyBelow = rect.top >= labelRect.bottom - 8 && rect.top - labelRect.bottom <= 120;
                if ((sameRow || nearbyBelow) && hasSignal(control)) return true;
              }
            }
            return false;
          };
          if (isLabelWithNearbyControl(el)) return false;
          let node = el;
          for (let depth = 0; node && depth < 3; depth += 1, node = node.parentElement) {
            if (hasSignal(node)) return true;
          }
          return false;
        }
        """


class ActionabilityVerifier:
    @classmethod
    async def reject_reason_async(cls, locator, candidate, find_params, timeout_ms: int = 1200):
        text_error = await cls._text_candidate_reject_async(locator, candidate, find_params)
        if text_error:
            return text_error
        key = operation_key(find_params)
        if key in CLICK_ACTION_KEYS:
            try:
                await locator.click(trial=True, timeout=max(100, int(timeout_ms)))
                return None
            except Exception as error:
                return f'actionability click trial failed: {short_error(error)}'
        if key in EDITABLE_ACTION_KEYS:
            try:
                if not await locator.is_enabled():
                    return 'actionability editable check failed: element is disabled'
                if not await locator.is_editable():
                    return 'actionability editable check failed: element is not editable'
                return None
            except Exception as error:
                return f'actionability editable check failed: {short_error(error)}'
        return None

    @classmethod
    def reject_reason_sync(cls, locator, candidate, find_params, timeout_ms: int = 1200):
        text_error = cls._text_candidate_reject_sync(locator, candidate, find_params)
        if text_error:
            return text_error
        key = operation_key(find_params)
        if key in CLICK_ACTION_KEYS:
            try:
                locator.click(trial=True, timeout=max(100, int(timeout_ms)))
                return None
            except Exception as error:
                return f'actionability click trial failed: {short_error(error)}'
        if key in EDITABLE_ACTION_KEYS:
            try:
                if not locator.is_enabled():
                    return 'actionability editable check failed: element is disabled'
                if not locator.is_editable():
                    return 'actionability editable check failed: element is not editable'
                return None
            except Exception as error:
                return f'actionability editable check failed: {short_error(error)}'
        return None

    @classmethod
    async def _text_candidate_reject_async(cls, locator, candidate, find_params):
        if not is_click_operation(find_params) or not cls._is_text_candidate(candidate):
            return None
        try:
            interactive = await locator.evaluate(TEXT_CLICK_INTERACTIVE_SCRIPT)
        except Exception as error:
            return f'text click candidate check failed: {short_error(error)}'
        if not interactive:
            return 'text click candidate rejected: text node has no interactive signal'
        return None

    @classmethod
    def _text_candidate_reject_sync(cls, locator, candidate, find_params):
        if not is_click_operation(find_params) or not cls._is_text_candidate(candidate):
            return None
        try:
            interactive = locator.evaluate(TEXT_CLICK_INTERACTIVE_SCRIPT)
        except Exception as error:
            return f'text click candidate check failed: {short_error(error)}'
        if not interactive:
            return 'text click candidate rejected: text node has no interactive signal'
        return None

    @staticmethod
    def _is_text_candidate(candidate):
        row = candidate.to_runtime_dict() if hasattr(candidate, 'to_runtime_dict') else candidate
        if row.get('source') in ('unique_visible_text', 'playwright_text_sub'):
            return True
        if row.get('exp') == ElementExpEnum.TEXT.value:
            return True
        return str(row.get('loc') or '').strip().startswith('get_by_text(')
