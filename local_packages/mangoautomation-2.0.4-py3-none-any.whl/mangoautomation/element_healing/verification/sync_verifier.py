# -*- coding: utf-8 -*-
import time

from ..locator import LocatorFactory
from ..models import VerificationResult
from ..policy import (
    AUTO_APPLY_CONSECUTIVE_PASSES,
    AUTO_APPLY_SCORE,
    AUTO_APPLY_SEMANTIC_SCORE,
    AUTO_APPLY_STABILITY_SCORE,
)
from ..policy.operation_rules import (
    auto_apply_operation_compatibility_reason,
    dynamic_read_locator_reason,
    needs_actionability_check,
    operation_compatibility_reason,
)
from .actionability import ActionabilityVerifier
from .scorer import CandidateScorer
from .semantic import SemanticVerifier
from .snapshot_ref import SnapshotRefVerifier
from .state import is_visible_sync, read_semantic_state_sync, read_text_sync, semantic_state_signature
from .uniqueness import uniqueness_reject_reason
from .verifier import VerifiedLocator


class SyncCandidateVerifier:
    def verify(self, page, element_model, candidate, find_params, candidate_index: int = 0,
               actionability_timeout_ms: int = 1200):
        started = time.perf_counter()
        row = candidate.to_runtime_dict()
        row.update({'candidate_index': candidate_index, 'verified': False, 'count': 0})
        try:
            locator = LocatorFactory.create(page, candidate)
            count = locator.count()
            row['count'] = count
            code, reason = uniqueness_reject_reason(count, candidate.sub)
            if reason:
                return None, self._reject(row, code, reason, started)
            selected = SnapshotRefVerifier.select(locator, candidate)
            visible = is_visible_sync(selected)
            if not visible:
                return None, self._reject(row, 'not_visible', 'selected not visible', started)
            semantic_state = read_semantic_state_sync(selected)
            operation_error = operation_compatibility_reason(semantic_state, find_params)
            if operation_error:
                return None, self._reject(row, 'operation_mismatch', operation_error, started)
            actionability_error = ActionabilityVerifier.reject_reason_sync(
                selected, candidate, find_params, actionability_timeout_ms,
            )
            if actionability_error:
                row['actionability_checked'] = True
                return None, self._reject(row, 'actionability_failed', actionability_error, started)
            text = read_text_sync(selected)
            if text and not semantic_state.get('text'):
                semantic_state['text'] = text
            semantic_score, semantic_evidence, semantic_error = SemanticVerifier.candidate_evaluation(
                element_model, semantic_state, candidate, find_params,
            )
            if semantic_error:
                return None, self._reject(row, 'semantic_mismatch', semantic_error, started)
            durable_count, durable_error = SnapshotRefVerifier.verify_durable_sync(page, candidate)
            if durable_error:
                row['durable_locator_count'] = durable_count
                return None, self._reject(
                    row, 'snapshot_ref_durable_mismatch', durable_error, started,
                )
            stability_score = CandidateScorer.stability_score(candidate)
            auto_apply_operation_error = auto_apply_operation_compatibility_reason(
                semantic_state, find_params,
            ) or dynamic_read_locator_reason(candidate, find_params)
            consecutive_passes, stable_context, repeat_error = self._repeat_validation(
                locator, candidate, element_model, find_params, count, semantic_state,
                actionability_timeout_ms,
            )
            score = CandidateScorer.final_score(
                candidate,
                visible=True,
                semantic_score=semantic_score,
                stability_score=stability_score,
                actionable=True,
                operation_compatible=True,
            )
            score = CandidateScorer.verified_read_score(
                score,
                semantic_evidence=semantic_evidence,
                count=count,
                consecutive_passes=consecutive_passes,
                stable_context=stable_context,
                durable_count=durable_count,
                has_subscript=bool(candidate.sub),
                find_params=find_params,
            )
            auto_apply_eligible = bool(
                count == 1 and semantic_state and semantic_score >= AUTO_APPLY_SEMANTIC_SCORE and
                'semantic_not_required' not in semantic_evidence and
                stability_score >= AUTO_APPLY_STABILITY_SCORE and
                not auto_apply_operation_error and
                durable_count in (None, 1) and
                int(candidate.metadata.get('snapshot_frame_index', 0) or 0) == 0 and
                consecutive_passes >= AUTO_APPLY_CONSECUTIVE_PASSES and stable_context and
                score >= AUTO_APPLY_SCORE
            )
            durable_auto_apply_error = None
            if durable_count not in (None, 1):
                durable_auto_apply_error = f'generated durable locator is not unique: count={durable_count}'
            elif int(candidate.metadata.get('snapshot_frame_index', 0) or 0) != 0:
                durable_auto_apply_error = 'snapshot ref belongs to iframe and cannot be auto-applied'
            duration = self._elapsed(started)
            result = VerificationResult(
                candidate=candidate,
                valid=True,
                count=count,
                visible=True,
                text=text,
                attributes={
                    key: semantic_state.get(key) for key in ('tag', 'role', 'type')
                    if semantic_state.get(key) is not None
                },
                semantic_score=semantic_score,
                stability_score=stability_score,
                operation_compatible=True,
                auto_apply_operation_compatible=not auto_apply_operation_error,
                consecutive_passes=consecutive_passes,
                stable_context=stable_context,
                auto_apply_eligible=auto_apply_eligible,
                final_score=score,
                duration_ms=duration,
            )
            row.update({
                'verified': True,
                'element_text': text,
                'semantic_score': semantic_score,
                'semantic_evidence': semantic_evidence,
                'stability_score': stability_score,
                'operation_compatible': True,
                'auto_apply_operation_compatible': not auto_apply_operation_error,
                'consecutive_passes': consecutive_passes,
                'stable_context': stable_context,
                'auto_apply_eligible': auto_apply_eligible,
                'auto_apply_reject_reason': (
                    (auto_apply_operation_error or durable_auto_apply_error or repeat_error)
                    if not auto_apply_eligible else None
                ),
                'durable_locator_count': durable_count,
                'final_score': score,
                'actionability_checked': needs_actionability_check(find_params),
                'duration_ms': duration,
            })
            return VerifiedLocator(selected, count, text, result, row), row
        except Exception as error:
            return None, self._reject(row, 'locator_error', str(error), started)

    @staticmethod
    def _repeat_validation(locator, candidate, element_model, find_params, expected_count,
                           first_state, actionability_timeout_ms):
        try:
            second_count = locator.count()
            if second_count != expected_count:
                return 1, False, 'candidate count changed during consecutive validation'
            selected = SnapshotRefVerifier.select(locator, candidate)
            if not is_visible_sync(selected):
                return 1, False, 'candidate became invisible during consecutive validation'
            second_state = read_semantic_state_sync(selected)
            operation_error = operation_compatibility_reason(second_state, find_params)
            if operation_error:
                return 1, False, operation_error
            actionability_error = ActionabilityVerifier.reject_reason_sync(
                selected, candidate, find_params, min(actionability_timeout_ms, 800),
            )
            if actionability_error:
                return 1, False, actionability_error
            _, _, semantic_error = SemanticVerifier.candidate_evaluation(
                element_model, second_state, candidate, find_params,
            )
            if semantic_error:
                return 1, False, semantic_error
            stable_context = bool(first_state and second_state) and (
                semantic_state_signature(first_state) == semantic_state_signature(second_state)
            )
            return 2, stable_context, None if stable_context else 'candidate semantic context changed'
        except Exception as error:
            return 1, False, f'consecutive validation failed: {error}'

    @staticmethod
    def _reject(row, code, reason, started):
        row['reject_code'] = code
        row['reject_reason'] = reason
        row['duration_ms'] = SyncCandidateVerifier._elapsed(started)
        return row

    @staticmethod
    def _elapsed(started):
        return max(0, int((time.perf_counter() - started) * 1000))
