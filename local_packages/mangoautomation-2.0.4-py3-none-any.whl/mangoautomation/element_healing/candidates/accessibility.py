# -*- coding: utf-8 -*-


class AccessibilityAgentCandidateSource:
    def __init__(self, agent=None):
        self.agent = agent

    async def build_async(self, page, context, memory: dict):
        if not self.agent:
            return []
        return await self.agent.propose_async(page, context, memory)

    def build_sync(self, page, context, memory: dict):
        if not self.agent:
            return []
        return self.agent.propose_sync(page, context, memory)

