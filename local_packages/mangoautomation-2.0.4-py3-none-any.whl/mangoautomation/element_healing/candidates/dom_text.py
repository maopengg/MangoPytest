# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..models import CandidateSource, LocatorCandidate


class DomTextCandidateSource:
    @classmethod
    async def build_async(cls, page, targets: list[str]) -> list[LocatorCandidate]:
        result = []
        for target in targets:
            try:
                locator = page.get_by_text(target, exact=True)
                count = await locator.count()
            except Exception:
                continue
            if count < 1 or count > 5:
                continue
            for index in range(count):
                try:
                    if not await locator.nth(index).is_visible():
                        continue
                except Exception:
                    continue
                result.append(cls._candidate(target, count, index))
        return result

    @classmethod
    def build_sync(cls, page, targets: list[str]) -> list[LocatorCandidate]:
        result = []
        for target in targets:
            try:
                locator = page.get_by_text(target, exact=True)
                count = locator.count()
            except Exception:
                continue
            if count < 1 or count > 5:
                continue
            for index in range(count):
                try:
                    if not locator.nth(index).is_visible():
                        continue
                except Exception:
                    continue
                result.append(cls._candidate(target, count, index))
        return result

    @classmethod
    def _candidate(cls, target, count, index):
        score = cls.score(target, count, index)
        return LocatorCandidate(
            source=CandidateSource.DOM_TEXT,
            initial_score=score,
            exp=ElementExpEnum.TEXT.value,
            loc=target,
            sub=index + 1,
            reason='按Playwright文本匹配顺序选择下标，少量短文本首个可见候选可自动写回'
            if score >= 85 else '按Playwright文本匹配顺序选择下标',
            metadata={'matched_label': target},
        )

    @staticmethod
    def score(target: str, count: int, index: int):
        target = str(target or '').strip()
        if count == 1:
            return 84
        if 2 <= count <= 5 and index == 0 and 2 <= len(target) <= 12:
            return 86
        return 76
