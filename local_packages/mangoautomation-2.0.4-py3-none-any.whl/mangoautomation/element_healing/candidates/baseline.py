# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..locator import clean, css_escape
from ..models import CandidateSource, LocatorCandidate


class BaselineCandidateSource:
    @classmethod
    def build(cls, memory: dict) -> list[LocatorCandidate]:
        candidates = []
        latest = memory.get('latest_snapshot') or {}
        if latest:
            candidates.extend(cls._snapshot_candidates(latest, 90, CandidateSource.LATEST_SNAPSHOT_LOCATOR))
        for snapshot in memory.get('snapshots') or []:
            if latest and snapshot.get('id') == latest.get('id'):
                continue
            candidates.extend(cls._snapshot_candidates(snapshot, 70, CandidateSource.HISTORY_SNAPSHOT_LOCATOR))
        return candidates

    @classmethod
    def _snapshot_candidates(cls, snapshot: dict, score: int, source) -> list[LocatorCandidate]:
        result = []
        if snapshot.get('loc'):
            result.append(LocatorCandidate(
                source=source,
                initial_score=score,
                exp=snapshot.get('exp') if snapshot.get('exp') is not None else ElementExpEnum.LOCATOR.value,
                loc=snapshot['loc'],
                sub=snapshot.get('sub'),
                snapshot_id=snapshot.get('id'),
            ))
        result.extend(cls._semantic_candidates(snapshot, score - 10))
        return result

    @staticmethod
    def _semantic_candidates(snapshot: dict, score: int) -> list[LocatorCandidate]:
        result = []
        role = clean(snapshot.get('element_role'))
        name = clean(snapshot.get('element_name')) or clean(snapshot.get('element_text'))
        placeholder = clean(snapshot.get('element_placeholder'))
        text = clean(snapshot.get('element_text'))
        attrs = snapshot.get('element_attributes') or {}
        metadata = {'snapshot_id': snapshot.get('id')}
        if role and name:
            result.append(LocatorCandidate(
                source=CandidateSource.BASELINE_SEMANTIC,
                initial_score=score + 3,
                exp=ElementExpEnum.LOCATOR.value,
                loc=f'get_by_role({role!r}, name={name!r})',
                snapshot_id=snapshot.get('id'),
                metadata={**metadata, 'semantic_kind': 'role_name'},
            ))
        if placeholder:
            result.append(LocatorCandidate(
                source=CandidateSource.BASELINE_SEMANTIC,
                initial_score=score + 2,
                exp=ElementExpEnum.PLACEHOLDER.value,
                loc=placeholder,
                snapshot_id=snapshot.get('id'),
                metadata={**metadata, 'semantic_kind': 'placeholder'},
            ))
        if text:
            result.append(LocatorCandidate(
                source=CandidateSource.BASELINE_SEMANTIC,
                initial_score=score + 1,
                exp=ElementExpEnum.TEXT.value,
                loc=text[:120],
                snapshot_id=snapshot.get('id'),
                metadata={**metadata, 'semantic_kind': 'text'},
            ))
        for name in ('data-testid', 'data-test', 'data-cy', 'aria-label', 'title'):
            value = clean(attrs.get(name))
            if value:
                result.append(LocatorCandidate(
                    source=CandidateSource.BASELINE_SEMANTIC,
                    initial_score=score,
                    exp=ElementExpEnum.CSS.value,
                    loc=f'[{name}="{css_escape(value)}"]',
                    snapshot_id=snapshot.get('id'),
                    metadata={**metadata, 'semantic_kind': f'attribute:{name}'},
                ))
        return result

