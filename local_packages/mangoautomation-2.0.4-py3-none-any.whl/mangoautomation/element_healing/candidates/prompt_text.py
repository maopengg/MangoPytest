# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..models import CandidateSource, LocatorCandidate


class PromptTextCandidateSource:
    @staticmethod
    def build(element_model) -> list[LocatorCandidate]:
        result = []
        for locator in getattr(element_model, 'elements', None) or []:
            prompt = getattr(locator, 'prompt', None)
            if prompt:
                result.append(LocatorCandidate(
                    source=CandidateSource.PROMPT_TEXT,
                    initial_score=40,
                    exp=ElementExpEnum.TEXT.value,
                    loc=str(prompt),
                ))
        return result

