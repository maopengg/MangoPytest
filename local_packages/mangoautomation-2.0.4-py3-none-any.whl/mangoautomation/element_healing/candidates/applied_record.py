# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..models import CandidateSource, LocatorCandidate


class AppliedRecordCandidateSource:
    @staticmethod
    def _generated_by_ai(record: dict) -> bool:
        selected_loc = record.get('selected_loc')
        for candidate in record.get('candidates') or []:
            if candidate.get('loc') == selected_loc:
                return bool(candidate.get('used_ai') or candidate.get('generated_by_ai'))
        locator_engine = (record.get('ai_prompt_summary') or {}).get('locator_engine') or {}
        return bool(locator_engine.get('used_ai'))

    @staticmethod
    def build(memory: dict) -> list[LocatorCandidate]:
        candidates = []
        for record in memory.get('heal_records') or memory.get('records') or []:
            if not record.get('applied') or not record.get('selected_loc'):
                continue
            candidates.append(LocatorCandidate(
                source=CandidateSource.APPLIED_HEAL_RECORD,
                initial_score=100,
                exp=record.get('selected_exp') or ElementExpEnum.LOCATOR.value,
                loc=record['selected_loc'],
                sub=record.get('selected_sub'),
                heal_record_id=record.get('id'),
                generated_by_ai=AppliedRecordCandidateSource._generated_by_ai(record),
            ))
        return candidates
