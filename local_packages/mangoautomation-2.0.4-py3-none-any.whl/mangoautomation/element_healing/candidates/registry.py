# -*- coding: utf-8 -*-
from .applied_record import AppliedRecordCandidateSource
from .baseline import BaselineCandidateSource
from .base import deduplicate
from .dom_label import DomLabelCandidateSource
from .dom_proximity import DomProximityCandidateSource
from .dom_role import DomRoleCandidateSource
from .dom_text import DomTextCandidateSource
from .prompt_text import PromptTextCandidateSource
from ..policy.thresholds import MAX_DOM_CANDIDATES


class CandidateRegistry:
    @staticmethod
    def historical(memory: dict, element_model, failed_expression: list[str]):
        candidates = []
        candidates.extend(AppliedRecordCandidateSource.build(memory))
        candidates.extend(BaselineCandidateSource.build(memory))
        candidates.extend(PromptTextCandidateSource.build(element_model))
        return deduplicate(candidates, failed_expression)

    @staticmethod
    async def current_page_async(page, targets: list[str], failed_expression: list[str]):
        candidates = []
        candidates.extend(await DomProximityCandidateSource.build_async(page, targets))
        candidates.extend(await DomLabelCandidateSource.build_async(page, targets))
        candidates.extend(await DomRoleCandidateSource.build_async(page, targets))
        candidates.extend(await DomTextCandidateSource.build_async(page, targets))
        candidates = deduplicate(candidates, failed_expression)
        return sorted(candidates, key=DomProximityCandidateSource.sort_key, reverse=True)[:MAX_DOM_CANDIDATES]

    @staticmethod
    def current_page_sync(page, targets: list[str], failed_expression: list[str]):
        candidates = []
        candidates.extend(DomProximityCandidateSource.build_sync(page, targets))
        candidates.extend(DomLabelCandidateSource.build_sync(page, targets))
        candidates.extend(DomRoleCandidateSource.build_sync(page, targets))
        candidates.extend(DomTextCandidateSource.build_sync(page, targets))
        candidates = deduplicate(candidates, failed_expression)
        return sorted(candidates, key=DomProximityCandidateSource.sort_key, reverse=True)[:MAX_DOM_CANDIDATES]
