# -*- coding: utf-8 -*-
from typing import Any

from mangoautomation.enums import ElementExpEnum

from ..locator import clean
from ..models import LocatorCandidate


def normalize_exp(exp) -> int:
    if isinstance(exp, int):
        return exp
    value = str(exp or 'locator').lower()
    mapping = {
        'xpath': ElementExpEnum.XPATH.value,
        'css': ElementExpEnum.CSS.value,
        'text': ElementExpEnum.TEXT.value,
        'placeholder': ElementExpEnum.PLACEHOLDER.value,
    }
    return mapping.get(value, ElementExpEnum.LOCATOR.value)


def optional_int(value) -> int | None:
    try:
        value = int(value)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def candidate_key(candidate: LocatorCandidate | dict) -> tuple[Any, Any, Any]:
    if isinstance(candidate, LocatorCandidate):
        return candidate.exp, candidate.loc, candidate.sub
    return candidate.get('exp'), candidate.get('loc'), candidate.get('sub')


def deduplicate(candidates: list[LocatorCandidate], failed_expression: list[str] | None = None) -> list[LocatorCandidate]:
    failed = set(failed_expression or [])
    seen = set()
    result = []
    for candidate in candidates:
        loc = clean(candidate.loc)
        if not loc or loc in failed or f'locator({loc!r})' in failed:
            continue
        key = candidate_key(candidate)
        if key in seen:
            continue
        seen.add(key)
        result.append(candidate)
    return result

