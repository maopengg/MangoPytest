from .accessibility import AccessibilityAgentCandidateSource
from .applied_record import AppliedRecordCandidateSource
from .baseline import BaselineCandidateSource
from .dom_label import DomLabelCandidateSource
from .dom_proximity import DomProximityCandidateSource
from .dom_role import DomRoleCandidateSource
from .dom_text import DomTextCandidateSource
from .prompt_text import PromptTextCandidateSource
from .registry import CandidateRegistry

__all__ = [
    'AccessibilityAgentCandidateSource',
    'AppliedRecordCandidateSource',
    'BaselineCandidateSource',
    'CandidateRegistry',
    'DomLabelCandidateSource',
    'DomProximityCandidateSource',
    'DomRoleCandidateSource',
    'DomTextCandidateSource',
    'PromptTextCandidateSource',
]

