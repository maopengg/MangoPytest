# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..models import CandidateSource, LocatorCandidate
from ..verification.state import read_text_async, read_text_sync


class DomLabelCandidateSource:
    @staticmethod
    async def build_async(page, targets: list[str]) -> list[LocatorCandidate]:
        result = []
        for target in targets:
            try:
                locator = page.get_by_label(target, exact=True)
                count = await locator.count()
            except Exception:
                continue
            if count < 1 or count > 5:
                continue
            for index in range(count):
                item = locator.nth(index)
                try:
                    if not await item.is_visible():
                        continue
                except Exception:
                    continue
                result.append(DomLabelCandidateSource._candidate(target, count, index, await read_text_async(item)))
        return result

    @staticmethod
    def build_sync(page, targets: list[str]) -> list[LocatorCandidate]:
        result = []
        for target in targets:
            try:
                locator = page.get_by_label(target, exact=True)
                count = locator.count()
            except Exception:
                continue
            if count < 1 or count > 5:
                continue
            for index in range(count):
                item = locator.nth(index)
                try:
                    if not item.is_visible():
                        continue
                except Exception:
                    continue
                result.append(DomLabelCandidateSource._candidate(target, count, index, read_text_sync(item)))
        return result

    @staticmethod
    def _candidate(target: str, count: int, index: int, text: str | None):
        return LocatorCandidate(
            source=CandidateSource.DOM_LABEL,
            initial_score=99 if count == 1 else 90,
            exp=ElementExpEnum.LOCATOR.value,
            loc=f'get_by_label({target!r}, exact=True)',
            sub=index + 1 if count > 1 else None,
            reason='Playwright get_by_label 语义定位命中',
            metadata={'matched_label': target, 'candidate_text': text},
        )
