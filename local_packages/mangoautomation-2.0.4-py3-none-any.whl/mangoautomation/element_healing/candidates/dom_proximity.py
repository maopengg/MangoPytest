# -*- coding: utf-8 -*-
from ..locator import clean
from ..models import LocatorCandidate
from .base import normalize_exp, optional_int


DOM_PROXIMITY_SCRIPT = r"""
        (targetTexts) => {
          const normalize = (value) => String(value || '').replace(/\s+/g, ' ').trim();
          const visible = (el) => {
            if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
            const style = window.getComputedStyle(el);
            if (style.visibility === 'hidden' || style.display === 'none' || Number(style.opacity) === 0) return false;
            const rect = el.getBoundingClientRect();
            return rect.width > 1 && rect.height > 1;
          };
          const textOf = (el) => normalize(
            el.innerText || el.textContent || el.getAttribute('aria-label') ||
            el.getAttribute('placeholder') || el.getAttribute('title') || ''
          );
          const interactiveSelectors = [
            'input', 'textarea', 'select', 'button', '[role="button"]', '[role="combobox"]',
            '[role="textbox"]', '[role="checkbox"]', '[role="radio"]', '[role="option"]',
            '[role="menuitem"]', '[role="treeitem"]', '[aria-haspopup]',
            '[contenteditable="true"]', '[tabindex]:not([tabindex="-1"])',
            '.ud__select', '.ud__select__selector', '.ud__select__trigger',
            '.ud__input', '.semi-select', '.arco-select', '.ant-select',
            '.el-select', '.select', '.cascader', '.tree-select', '.option', '.dropdown-item',
            '[class*="select"]', '[class*="selector"]', '[class*="selection"]',
            '[class*="picker"]', '[class*="trigger"]', '[class*="dropdown"]',
            '[class*="cascader"]', '[class*="combobox"]', '[class*="input-wrapper"]'
          ].join(',');
          const componentContainerSelectors = [
            '[role="combobox"]', '[role="button"]', '[aria-haspopup]',
            '.ud__select', '.ud__select__selector', '.ud__select__trigger',
            '.semi-select', '.arco-select', '.ant-select', '.el-select',
            '[class*="select"]', '[class*="selector"]', '[class*="selection"]',
	            '[class*="picker"]', '[class*="trigger"]', '[class*="dropdown"]',
	            '[class*="cascader"]', '[class*="combobox"]'
	          ].join(',');
	          const formItemSelectors = [
	            '.form-item', '.form-field', '.form-row',
	            '.ud__form-item', '.ud__form-field', '.ud__form-row',
	            '.semi-form-field', '.arco-form-item', '.ant-form-item', '.el-form-item',
	            '[class*="form-item"]', '[class*="formItem"]', '[class*="form-field"]'
	          ].join(',');
	          const nearestFormItem = (el) => {
	            if (!el || !el.closest) return null;
	            let scope = el.closest(formItemSelectors);
	            if (scope === el) {
	              scope = el.parentElement && el.parentElement.closest ? el.parentElement.closest(formItemSelectors) : null;
	            }
	            return scope;
	          };
	          const isInteractive = (el) => {
            if (!el || !visible(el)) return false;
            const tag = el.tagName.toLowerCase();
            const role = normalize(el.getAttribute('role')).toLowerCase();
            const cls = normalize(el.className).toLowerCase();
            const cursor = window.getComputedStyle(el).cursor;
            const hasInteractiveSignal = ['input', 'textarea', 'select', 'button'].includes(tag) ||
              ['button', 'combobox', 'textbox', 'checkbox', 'radio', 'switch', 'option', 'menuitem', 'treeitem'].includes(role) ||
              el.hasAttribute('aria-haspopup') || el.hasAttribute('contenteditable') ||
              (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1') ||
              cursor === 'pointer';
            const broadSelectContainer = /(^|\s|_|-)select($|\s|_|-)/.test(cls) &&
              !hasInteractiveSignal &&
              !!el.querySelector('[aria-haspopup], [role="combobox"], [tabindex]:not([tabindex="-1"]), [class*="selector"], [class*="selection"], [class*="trigger"]');
            if (broadSelectContainer) return false;
            return ['input', 'textarea', 'select', 'button'].includes(tag) ||
              ['button', 'combobox', 'textbox', 'checkbox', 'radio', 'switch', 'option', 'menuitem', 'treeitem'].includes(role) ||
              el.hasAttribute('aria-haspopup') || el.hasAttribute('contenteditable') ||
              (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1') ||
              cursor === 'pointer' ||
              /select|picker|trigger|combobox|dropdown|cascader|tree|checkbox|radio|input/.test(cls);
          };
          const preferredInteractiveTarget = (el, label) => {
            if (!el || !visible(el)) return el;
            const role = normalize(el.getAttribute('role')).toLowerCase();
            if (['option', 'menuitem', 'treeitem', 'checkbox', 'radio', 'switch'].includes(role)) return el;
            const tag = el.tagName.toLowerCase();
            if (['button', 'select', 'textarea'].includes(tag)) return el;
	            const formItemScope = nearestFormItem(label);
	            const labelScope = formItemScope || (label && label.closest ? label.closest('[role="dialog"], [aria-modal="true"], .modal, .drawer') : null);
            let node = el;
            while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.body) {
              if (node !== el && !visible(node)) break;
              if (node.matches && node.matches(componentContainerSelectors) && visible(node)) {
                if (!labelScope || labelScope.contains(node) || node.contains(el)) return node;
              }
              if (labelScope && node === labelScope) break;
              node = node.parentElement;
            }
            return el;
          };
          const cssEscape = (value) => {
            if (window.CSS && window.CSS.escape) return window.CSS.escape(value);
            return String(value).replace(/["\\]/g, '\\$&');
          };
          const selectorCount = (selector) => {
            try {
              return document.querySelectorAll(selector).length;
            } catch (error) {
              return 0;
            }
          };
          const xpathLiteral = (value) => {
            value = String(value || '');
            if (!value.includes("'")) return `'${value}'`;
            if (!value.includes('"')) return `"${value}"`;
            return `concat('${value.split("'").join("', \"'\", '")}')`;
          };
          const elementXPath = (el) => {
            const segments = [];
            let node = el;
            while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.body) {
              const tag = node.tagName.toLowerCase();
              const parent = node.parentElement;
              if (!parent) break;
              if (node.id) {
                segments.unshift(`*[@id=${xpathLiteral(node.id)}]`);
                break;
              }
              const same = Array.from(parent.children).filter((item) => item.tagName === node.tagName);
              const index = same.indexOf(node) + 1;
              segments.unshift(`${tag}[${index}]`);
              node = parent;
            }
            return segments.length ? `/html/body/${segments.join('/')}` : '';
          };
          const interactiveXPathCondition = [
            'self::input', 'self::textarea', 'self::select', 'self::button',
            '@role="button"', '@role="combobox"', '@role="textbox"',
            '@role="checkbox"', '@role="radio"', '@role="switch"',
            '@role="option"', '@role="menuitem"', '@role="treeitem"',
            '@aria-haspopup', '@contenteditable="true"',
            '@tabindex and not(@tabindex="-1")',
            'contains(@class, "select")', 'contains(@class, "picker")',
            'contains(@class, "selector")', 'contains(@class, "selection")',
            'contains(@class, "trigger")', 'contains(@class, "combobox")',
            'contains(@class, "dropdown")', 'contains(@class, "cascader")',
            'contains(@class, "tree")', 'contains(@class, "checkbox")',
            'contains(@class, "radio")', 'contains(@class, "input")',
            'contains(@class, "option")', 'contains(@class, "dropdown-item")'
          ].join(' or ');
          const labelXPath = (label) => {
            const labelText = textOf(label);
            if (!labelText) return '';
            const labelTags = 'label, span, div, p, dt, th';
            const sameLabels = Array.from(document.querySelectorAll(labelTags))
              .filter(visible)
              .filter((item) => textOf(item) === labelText);
            const index = sameLabels.indexOf(label) + 1;
            if (index < 1) return '';
            const nodeCondition = [
              'self::label', 'self::span', 'self::div', 'self::p', 'self::dt', 'self::th'
            ].join(' or ');
            return `(.//*[${nodeCondition}][normalize-space(.)=${xpathLiteral(labelText)}])[${index}]`;
          };
          const nodesByXPath = (xpath) => {
            try {
              const snapshot = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
              return Array.from({ length: snapshot.snapshotLength }, (_, index) => snapshot.snapshotItem(index));
            } catch (error) {
              return [];
            }
          };
          const activeScopeSelectors = [
            '[role="dialog"]', '[aria-modal="true"]', '.ud__modal', '.ud__drawer', '.ud__popover',
            '.semi-modal', '.semi-drawer', '.semi-popover', '.arco-modal', '.arco-drawer', '.arco-trigger-popup',
            '.ant-modal', '.ant-drawer', '.ant-popover', '.el-dialog', '.el-drawer',
            '.modal', '.drawer', '.popover'
          ].join(',');
          const scopePriority = (el) => {
            const scope = el && el.closest ? el.closest(activeScopeSelectors) : null;
            if (!scope || !visible(scope)) return 0;
            const rect = scope.getBoundingClientRect();
            const area = rect.width * rect.height;
            if (area <= 0) return 0;
            return Math.min(8, 4 + Math.round(Math.min(area, 400000) / 100000));
          };
          const relativeControlXPath = (label, el) => {
            const base = labelXPath(label);
            if (!base) return '';
            const baseXpath = `${base}/following::*[${interactiveXPathCondition}]`;
            const nodes = nodesByXPath(baseXpath);
            const index = nodes.indexOf(el);
            return index >= 0 ? `(${baseXpath})[${index + 1}]` : '';
          };
          const uniqueSelector = (el) => {
            if (el.id) {
              const selector = `#${cssEscape(el.id)}`;
              if (selectorCount(selector) === 1) {
                return { exp: 'css', loc: selector, source: 'dom_stable_attr', scoreBoost: 2 };
              }
            }
            for (const name of ['data-testid', 'data-test-id', 'data-test', 'data-cy', 'data-qa']) {
              const value = el.getAttribute(name);
              if (!value) continue;
              const selector = `${el.tagName.toLowerCase()}[${name}="${String(value).replace(/"/g, '\\"')}"]`;
              if (selectorCount(selector) === 1) {
                return { exp: 'css', loc: selector, source: 'dom_stable_attr', scoreBoost: 6 };
              }
            }
            for (const name of ['aria-labelledby', 'aria-controls', 'name', 'aria-label', 'placeholder', 'title']) {
              const value = el.getAttribute(name);
              if (!value) continue;
              const selector = `${el.tagName.toLowerCase()}[${name}="${String(value).replace(/"/g, '\\"')}"]`;
              if (selectorCount(selector) === 1) {
                return { exp: 'css', loc: selector, source: 'dom_stable_attr', scoreBoost: 4 };
              }
            }
            const path = [];
            let node = el;
            while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.body) {
              const tag = node.tagName.toLowerCase();
              const parent = node.parentElement;
              if (!parent) break;
              const same = Array.from(parent.children).filter((item) => item.tagName === node.tagName);
              const index = same.indexOf(node) + 1;
              path.unshift(`${tag}:nth-of-type(${index})`);
              node = parent;
            }
            if (path.length) {
              const selector = `body > ${path.join(' > ')}`;
              if (selectorCount(selector) === 1) {
                return { exp: 'xpath', loc: elementXPath(el), source: 'dom_proximity_xpath' };
              }
            }
            return null;
          };
          const candidateScore = (labelRect, el, relation) => {
            const rect = el.getBoundingClientRect();
            const centerDelta = Math.abs((rect.top + rect.height / 2) - (labelRect.top + labelRect.height / 2));
	            let score = relation === 'label-for' ? 94 :
	              relation === 'same-form-item-control' ? 90 :
	              relation === 'same-form-item' ? 88 : relation === 'same-row' ? 86 : 80;
            if (centerDelta <= 14) score += 4;
            if (el.getAttribute('role') || el.getAttribute('aria-label') || el.getAttribute('placeholder')) score += 3;
            if (window.getComputedStyle(el).cursor === 'pointer') score += 2;
            return Math.min(94, score);
          };
          const collectAroundLabel = (label) => {
            const labelRect = label.getBoundingClientRect();
            const results = [];
            const push = (el, relation) => {
              el = preferredInteractiveTarget(el, label);
              if (!isInteractive(el) || el === label) return;
              const selector = uniqueSelector(el);
              if (!selector || !selector.loc) return;
              const rect = el.getBoundingClientRect();
              const centerDelta = Math.abs((rect.top + rect.height / 2) - (labelRect.top + labelRect.height / 2));
              const sameRow = rect.left >= labelRect.left - 20 &&
                rect.top < labelRect.bottom + 28 && rect.bottom > labelRect.top - 28 &&
                centerDelta <= 24;
	              const rightSide = rect.left >= labelRect.right - 12 &&
	                centerDelta <= 24;
	              const nearbyBelow = rect.top >= labelRect.bottom - 8 && rect.top - labelRect.bottom <= 120;
	              const sameFormControl = relation === 'same-form-item-control' &&
	                rect.left >= labelRect.left - 24 &&
	                rect.top >= labelRect.top - 80 &&
	                rect.top - labelRect.bottom <= 260;
	              if (!sameRow && !rightSide && !nearbyBelow && !sameFormControl) return;
              const scopeBoost = Math.max(scopePriority(label), scopePriority(el));
              const score = Math.min(99, candidateScore(labelRect, el, relation) + scopeBoost);
              const relativeXPath = (
                selector.source !== 'dom_stable_attr' && !['ancestor', 'label-for'].includes(relation)
              ) ? relativeControlXPath(label, el) : '';
              if (relativeXPath) {
                results.push({
                  source: 'label_relative_xpath',
                  exp: 'xpath',
                  loc: relativeXPath,
                  score: Math.min(96, score + 2),
                  reason: `${relation} matched by label text relative xpath${scopeBoost ? ' in active scope' : ''}`,
                  matched_label: textOf(label),
                  candidate_text: textOf(el),
                  distance: Math.abs(rect.left - labelRect.right) + Math.abs(rect.top - labelRect.top)
                });
              }
              results.push({
                source: selector.source,
                exp: selector.exp,
                loc: selector.loc,
                score: selector.source === 'dom_proximity_xpath'
                  ? Math.min(92, score + (selector.scoreBoost || 0))
                  : relation === 'label-for' && selector.source === 'dom_stable_attr'
                    ? Math.min(98, score + (selector.scoreBoost || 0))
                  : Math.min(99, score + (selector.scoreBoost || 0)),
                reason: `${relation} matched by label proximity${scopeBoost ? ' in active scope' : ''}`,
                matched_label: textOf(label),
                candidate_text: textOf(el),
                distance: Math.abs(rect.left - labelRect.right) + Math.abs(rect.top - labelRect.top)
              });
            };
            const labelFor = label.getAttribute('for');
	            if (labelFor) {
	              const control = document.getElementById(labelFor);
	              if (control) push(control, 'label-for');
	            }
	            const formItem = nearestFormItem(label);
	            if (formItem && visible(formItem)) {
	              formItem.querySelectorAll(interactiveSelectors).forEach((el) => push(el, 'same-form-item-control'));
	            }
	            let parent = label.parentElement;
            for (let depth = 0; parent && depth < 5; depth += 1, parent = parent.parentElement) {
              const relation = depth <= 2 ? 'same-form-item' : 'ancestor';
              parent.querySelectorAll(interactiveSelectors).forEach((el) => push(el, relation));
            }
            document.querySelectorAll(interactiveSelectors).forEach((el) => push(el, 'same-row'));
            return results;
          };
          const targets = (targetTexts || []).map(normalize).filter(Boolean);
          const isLabelLikeText = (text, target) => {
            if (!text || !target) return false;
            const occurrences = text.split(target).length - 1;
            if (occurrences > 1) return false;
            if (text === target) return true;
            if (target.includes(text) && text.length >= 4) return true;
            return text.includes(target) && text.length <= target.length + 6;
          };
          const hasExactLabelChild = (el, text) => {
            if (!el || !text || !['DIV', 'P', 'DT', 'TH'].includes(el.tagName)) return false;
            return Array.from(el.querySelectorAll('label, span, div, p, dt, th, [role="option"], [role="menuitem"], [role="treeitem"]'))
              .some((child) => child !== el && visible(child) && textOf(child) === text);
          };
          const hasAnyTargetLabelChild = (el, targets) => {
            if (!el || !['DIV', 'P', 'DT', 'TH'].includes(el.tagName)) return false;
            return Array.from(el.querySelectorAll('label, span, div, p, dt, th'))
              .some((child) => child !== el && visible(child) && targets.includes(textOf(child)));
          };
          const isSemanticControl = (el) => {
            if (!el || !visible(el)) return false;
            const tag = el.tagName.toLowerCase();
            const role = normalize(el.getAttribute('role')).toLowerCase();
            return ['input', 'textarea', 'select', 'button', 'a'].includes(tag) ||
              ['button', 'link', 'combobox', 'textbox', 'checkbox', 'radio', 'switch', 'option', 'menuitem', 'treeitem'].includes(role) ||
              el.hasAttribute('aria-haspopup') || el.hasAttribute('contenteditable') ||
              (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1');
          };
          const isTableHeaderText = (el) => {
            if (!el || !visible(el)) return false;
            const tag = el.tagName.toLowerCase();
            if (tag === 'th') return true;
            const tableHeaderScope = el.closest('thead, [role="columnheader"], .ud__table-header, .arco-table-th, .ant-table-thead');
            return !!tableHeaderScope;
          };
          const collectPortalOptions = (targets) => {
            const rows = [];
            const selectors = [
              '[role="option"]', '[role="menuitem"]', '[role="treeitem"]',
              '.option', '.dropdown-item', '.select-option', '.cascader-menu-item',
              '.ud__select-option', '.ud__dropdown-menu-item', '.ud__tree-node',
              '.semi-select-option', '.arco-select-option', '.ant-select-item-option',
              '.el-select-dropdown__item'
            ].join(',');
            document.querySelectorAll(selectors).forEach((el) => {
              if (!isInteractive(el)) return;
              const text = textOf(el);
              const target = targets.find((item) => text === item);
              if (!target) return;
              const xpath = elementXPath(el);
              if (!xpath) return;
              rows.push({
                source: 'portal_text_option',
                exp: 'xpath',
                loc: xpath,
                score: 88,
                reason: 'portal option matched by exact visible text',
                matched_label: target,
                candidate_text: text,
                distance: 9999
              });
            });
            return rows;
          };
          const collectPopupTextOptions = (targets) => {
            const rows = [];
            const popupSelectors = [
              '[role="listbox"]', '[role="tree"]', '[role="menu"]',
              '.ud__trigger-popup', '.ud__select-dropdown', '.ud__dropdown',
              '.ud__tree', '.semi-portal', '.semi-select-option-list',
              '.arco-trigger-popup', '.arco-select-dropdown', '.arco-cascader-popup',
              '.ant-select-dropdown', '.ant-cascader-dropdown', '.el-select-dropdown',
              '.dropdown-menu', '.select-dropdown', '.cascader-dropdown'
            ].join(',');
            const optionLikeSelectors = [
              '[role="option"]', '[role="menuitem"]', '[role="treeitem"]',
              'li', 'button', 'label',
              '.option', '.dropdown-item', '.select-option', '.cascader-menu-item',
              '.ud__select-option', '.ud__dropdown-menu-item', '.ud__tree-node',
              '.ud__checkbox', '.semi-select-option', '.arco-select-option',
              '.ant-select-item-option', '.el-select-dropdown__item'
            ].join(',');
            document.querySelectorAll(popupSelectors).forEach((scope) => {
              if (!visible(scope)) return;
              Array.from(scope.querySelectorAll('span, div, label, li, button')).forEach((textEl) => {
                if (!visible(textEl) || hasExactLabelChild(textEl, textOf(textEl))) return;
                const text = textOf(textEl);
                const target = targets.find((item) => text === item);
                if (!target) return;
                const option = textEl.closest(optionLikeSelectors) || textEl;
                if (!option || !visible(option)) return;
                const xpath = elementXPath(option);
                if (!xpath) return;
                rows.push({
                  source: 'popup_text_option',
                  exp: 'xpath',
                  loc: xpath,
                  score: 87,
                  reason: 'popup option matched by exact visible text',
                  matched_label: target,
                  candidate_text: textOf(option) || text,
                  distance: 9998
                });
              });
            });
            return rows;
          };
          const commonActionTexts = new Set([
            '确定', '确认', '取消', '提交', '保存', '删除', '新增', '编辑',
            '查询', '搜索', '重置', '关闭', '返回', '下一步', '上一步',
            '完成', '选择', '全选'
          ]);
          const safeUniqueTextTarget = (target) => {
            target = normalize(target);
            if (!target || commonActionTexts.has(target)) return false;
            return target.length >= 4;
          };
          const collectUniqueVisibleText = (targets) => {
            const rows = [];
            targets = targets.filter(safeUniqueTextTarget);
            if (!targets.length) return rows;
            const nodes = Array.from(document.querySelectorAll('button, a, li, div, span, p, td, th'))
              .filter(visible)
              .filter((el) => !hasExactLabelChild(el, textOf(el)))
              .map((el) => ({ el, text: textOf(el) }))
              .filter(({ text }) => safeUniqueTextTarget(text) && text.length <= 160);
            for (const target of targets) {
              const matched = nodes.filter(({ text }) => text === target || target.includes(text));
              if (matched.length !== 1) continue;
              const el = matched[0].el;
              const text = matched[0].text;
              const exact = text === target;
              rows.push({
                source: 'unique_visible_text',
                exp: 'text',
                loc: text,
                score: exact ? 85 : 83,
                reason: exact
                  ? 'unique visible text matched exactly'
                  : 'unique visible text is contained in the configured element name',
                matched_label: target,
                candidate_text: text,
                distance: 10000
              });
            }
            return rows;
          };
          const labels = Array.from(document.querySelectorAll('label, span, div, p, dt, th'))
            .filter(visible)
            .filter((el) => !isSemanticControl(el))
            .filter((el) => !isTableHeaderText(el))
            .map((el) => ({ el, text: textOf(el) }))
            .filter(({ text }) => text && text.length <= 80)
            .filter(({ el, text }) => !hasExactLabelChild(el, text))
            .filter(({ el }) => !hasAnyTargetLabelChild(el, targets))
            .filter(({ text }) => targets.some((target) => isLabelLikeText(text, target)))
            .sort((a, b) => scopePriority(b.el) - scopePriority(a.el));
          const rows = [];
          const seen = new Set();
          for (const { el } of labels.slice(0, 20)) {
            for (const row of collectAroundLabel(el)) {
              const key = `${row.exp || 'css'}:${row.loc}:`;
              if (seen.has(key)) continue;
              seen.add(key);
              rows.push(row);
            }
          }
          for (const row of collectPortalOptions(targets)) {
            const key = `${row.exp || 'css'}:${row.loc}:`;
            if (seen.has(key)) continue;
            seen.add(key);
            rows.push(row);
          }
          for (const row of collectPopupTextOptions(targets)) {
            const key = `${row.exp || 'css'}:${row.loc}:`;
            if (seen.has(key)) continue;
            seen.add(key);
            rows.push(row);
          }
          for (const row of collectUniqueVisibleText(targets)) {
            const key = `${row.exp || 'css'}:${row.loc}:`;
            if (seen.has(key)) continue;
            seen.add(key);
            rows.push(row);
          }
          return rows.sort((a, b) => b.score - a.score || a.distance - b.distance).slice(0, 8);
        }
        """


class DomProximityCandidateSource:
    @classmethod
    async def build_async(cls, page, targets: list[str]) -> list[LocatorCandidate]:
        try:
            rows = await page.evaluate(DOM_PROXIMITY_SCRIPT, targets)
        except Exception:
            return []
        return cls.normalize(rows)

    @classmethod
    def build_sync(cls, page, targets: list[str]) -> list[LocatorCandidate]:
        try:
            rows = page.evaluate(DOM_PROXIMITY_SCRIPT, targets)
        except Exception:
            return []
        return cls.normalize(rows)

    @classmethod
    def normalize(cls, rows: list[dict] | None) -> list[LocatorCandidate]:
        result = []
        for row in rows or []:
            loc = clean(row.get('loc'))
            if not loc:
                continue
            score = row.get('score') or 80
            try:
                score = int(score)
            except (TypeError, ValueError):
                score = 80
            source = row.get('source') or 'dom_proximity'
            candidate_text = clean(row.get('candidate_text'))
            matched_label = clean(row.get('matched_label'))
            if source == 'dom_proximity' and matched_label:
                if matched_label not in candidate_text and matched_label not in loc:
                    score = min(score, 70)
            if source == 'dom_proximity' and loc.startswith('body >'):
                score = min(score, 78)
            result.append(LocatorCandidate(
                source=source,
                initial_score=max(0, min(100, score)),
                exp=normalize_exp(row.get('exp')),
                loc=loc,
                sub=optional_int(row.get('sub')),
                reason=row.get('reason') or '',
                metadata={
                    'matched_label': row.get('matched_label'),
                    'candidate_text': candidate_text,
                    'distance': row.get('distance'),
                },
            ))
        return sorted(result, key=cls.sort_key, reverse=True)[:12]

    @staticmethod
    def sort_key(candidate: LocatorCandidate):
        priority = {
            'playwright_label': 100,
            'playwright_role': 95,
            'dom_stable_attr': 90,
            'label_relative_xpath': 80,
            'dom_proximity': 70,
            'dom_proximity_xpath': 60,
            'portal_text_option': 55,
            'popup_text_option': 54,
            'unique_visible_text': 52,
            'playwright_text_sub': 50,
        }
        source = candidate.source.value if hasattr(candidate.source, 'value') else str(candidate.source)
        return candidate.initial_score, priority.get(source, 0)
