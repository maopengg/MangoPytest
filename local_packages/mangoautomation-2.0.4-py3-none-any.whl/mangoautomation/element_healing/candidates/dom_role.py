# -*- coding: utf-8 -*-
from mangoautomation.enums import ElementExpEnum

from ..models import CandidateSource, LocatorCandidate
from ..verification.state import read_text_async, read_text_sync


ROLES = ('combobox', 'button', 'textbox', 'checkbox', 'radio', 'switch', 'menuitem', 'option', 'treeitem')


class DomRoleCandidateSource:
    @classmethod
    async def build_async(cls, page, targets: list[str]) -> list[LocatorCandidate]:
        rows = []
        for target in targets:
            for role in ROLES:
                rows.extend(await cls._for_async(page, role, target, True))
                rows.extend(await cls._for_async(page, role, target, False))
        return rows

    @classmethod
    def build_sync(cls, page, targets: list[str]) -> list[LocatorCandidate]:
        rows = []
        for target in targets:
            for role in ROLES:
                rows.extend(cls._for_sync(page, role, target, True))
                rows.extend(cls._for_sync(page, role, target, False))
        return rows

    @classmethod
    async def _for_async(cls, page, role, target, exact):
        try:
            locator = page.get_by_role(role, name=target, exact=exact)
            count = await locator.count()
        except Exception:
            return []
        if count < 1 or count > 5:
            return []
        result = []
        for index in range(count):
            item = locator.nth(index)
            try:
                if not await item.is_visible():
                    continue
            except Exception:
                continue
            result.append(cls._candidate(role, target, exact, count, index, await read_text_async(item)))
        return result

    @classmethod
    def _for_sync(cls, page, role, target, exact):
        try:
            locator = page.get_by_role(role, name=target, exact=exact)
            count = locator.count()
        except Exception:
            return []
        if count < 1 or count > 5:
            return []
        result = []
        for index in range(count):
            item = locator.nth(index)
            try:
                if not item.is_visible():
                    continue
            except Exception:
                continue
            result.append(cls._candidate(role, target, exact, count, index, read_text_sync(item)))
        return result

    @staticmethod
    def _candidate(role, target, exact, count, index, text):
        exact_arg = ', exact=True' if exact else ''
        return LocatorCandidate(
            source=CandidateSource.DOM_ROLE,
            initial_score=DomRoleCandidateSource.score(role, count, exact),
            exp=ElementExpEnum.LOCATOR.value,
            loc=f'get_by_role({role!r}, name={target!r}{exact_arg})',
            sub=index + 1 if count > 1 else None,
            reason=f"Playwright get_by_role({role}) {'精确' if exact else '模糊'}语义定位命中",
            metadata={'matched_label': target, 'candidate_text': text},
        )

    @staticmethod
    def score(role: str, count: int, exact: bool):
        if count != 1:
            return 91 if exact else 82
        if not exact:
            return 98 if role in ('combobox', 'button', 'menuitem') else 86
        if role in ('combobox', 'button', 'menuitem', 'option', 'treeitem'):
            return 100
        return 95
