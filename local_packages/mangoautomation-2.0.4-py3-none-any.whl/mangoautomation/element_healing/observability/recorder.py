# -*- coding: utf-8 -*-
import time

from ..models import HealingTrace, TraceStage
from .summary import CandidateSummary


class TraceRecorder:
    def __init__(self, context):
        self.context = context
        self.started = time.perf_counter()
        self.trace = HealingTrace(
            trace_id=context.trace_id,
            element_id=context.element_id,
            trigger=context.trigger.value,
        )

    def stage(self, name: str, started: float, candidate_count: int = 0, error: str | None = None):
        self.trace.stages.append(TraceStage(
            name=name,
            duration_ms=max(0, int((time.perf_counter() - started) * 1000)),
            candidate_count=candidate_count,
            error=str(error)[:300] if error else None,
        ))

    def finish(self, candidates, results, reject_reasons, decision, *, agent=None):
        self.trace.duration_ms = max(0, int((time.perf_counter() - self.started) * 1000))
        self.trace.candidates = list(results or [])
        self.trace.reject_reasons = list(reject_reasons or [])[:10]
        self.trace.decision = decision
        if agent and getattr(agent, 'available', False):
            self.trace.agent_called = self.trace.agent_called or any(
                (row.get('used_ai') or row.get('source') == 'ai_accessibility')
                for row in results or []
            )
            client = getattr(agent, 'model_client', None)
            self.trace.model = getattr(client, 'model_name', None)
            self.trace.prompt_version = getattr(agent, 'prompt_version', None)
            self.trace.schema_version = getattr(agent, 'schema_version', None)
        return self.trace

    @staticmethod
    def runtime_metadata(selected, candidates, results, reject_reasons, mode, context, trace, decision=None):
        candidate = selected.verification.candidate
        row = candidate.to_runtime_dict()
        selected_index = selected.runtime_row.get('candidate_index')
        return {
            'trace_id': context.trace_id,
            'used_source': row.get('source'),
            'used_ai': row.get('used_ai', False),
            'temporary_heal_used': bool(
                decision and decision.status.value in ('temporary_heal', 'auto_apply')
            ),
            'auto_apply_eligible': selected.verification.auto_apply_eligible,
            'candidate_count': len(candidates),
            'candidate_index': selected_index,
            'final_score': selected.verification.final_score,
            'selected_exp': candidate.exp,
            'selected_loc': candidate.loc,
            'selected_sub': candidate.sub,
            'accessibility_snapshot_id': row.get('accessibility_snapshot_id'),
            'snapshot_ref': row.get('target_ref'),
            'snapshot_frame_index': row.get('snapshot_frame_index'),
            'snapshot_frame_url': row.get('snapshot_frame_url'),
            'durable_locator_strategy': row.get('durable_locator_strategy'),
            'baseline_snapshot_id': candidate.snapshot_id,
            'heal_record_id': candidate.heal_record_id,
            'reject_reasons': list(reject_reasons)[:10],
            'candidates': results,
            'candidate_summary': CandidateSummary.build(candidates, results, reject_reasons),
            'trigger': {
                'type': context.trigger.value,
                'error': context.trigger_error,
                'failed_expression': [item.loc for item in context.failed_locators][-10:],
                'ope_key': context.operation_key,
                'origin_exp': context.origin_exp,
                'origin_loc': context.origin_loc,
                'origin_sub': context.origin_sub,
            },
            'trace': trace.model_dump(mode='json'),
        }

    @staticmethod
    def exhausted_metadata(candidates, results, reject_reasons, context, trace):
        return {
            'trace_id': context.trace_id,
            'used_source': 'candidate_exhausted',
            'used_ai': trace.agent_called,
            'temporary_heal_used': False,
            'candidate_count': len(candidates),
            'final_score': 0,
            'reject_reasons': list(reject_reasons)[:10],
            'candidates': results,
            'candidate_summary': CandidateSummary.build(candidates, results, reject_reasons),
            'trigger': {
                'type': context.trigger.value,
                'error': context.trigger_error,
                'failed_expression': [item.loc for item in context.failed_locators][-10:],
                'ope_key': context.operation_key,
                'origin_exp': context.origin_exp,
                'origin_loc': context.origin_loc,
                'origin_sub': context.origin_sub,
            },
            'trace': trace.model_dump(mode='json'),
        }
