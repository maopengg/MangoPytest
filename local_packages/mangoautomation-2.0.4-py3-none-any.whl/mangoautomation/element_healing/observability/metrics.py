# -*- coding: utf-8 -*-
from collections import Counter


class HealingMetrics:
    def __init__(self):
        self.counters = Counter()

    def increment(self, name: str, value: int = 1) -> None:
        self.counters[name] += value

    def snapshot(self) -> dict:
        return dict(self.counters)

