# -*- coding: utf-8 -*-
from ..locator import clean, limit_text


class CandidateSummary:
    @classmethod
    def build(cls, candidates=None, results=None, reject_reasons=None, total_count=None):
        candidates = candidates or []
        results = results or []
        summary = {
            'total': len(candidates) if total_count is None else total_count,
            'checked': len(results),
            'verified': 0,
            'by_source': {},
            'top_rejections': [],
        }
        for candidate in candidates:
            row = candidate.to_runtime_dict() if hasattr(candidate, 'to_runtime_dict') else candidate
            source = clean(row.get('source')) or 'unknown'
            summary['by_source'].setdefault(
                source, {'total': 0, 'checked': 0, 'verified': 0, 'rejected': 0, 'reasons': {}},
            )['total'] += 1
        for row in results:
            source = clean(row.get('source')) or 'unknown'
            source_summary = summary['by_source'].setdefault(
                source, {'total': 0, 'checked': 0, 'verified': 0, 'rejected': 0, 'reasons': {}},
            )
            source_summary['checked'] += 1
            source_summary['total'] = max(source_summary['total'], source_summary['checked'])
            if row.get('verified'):
                summary['verified'] += 1
                source_summary['verified'] += 1
                continue
            reason = cls.reject_bucket(row.get('reject_reason'))
            source_summary['rejected'] += 1
            source_summary['reasons'][reason] = source_summary['reasons'].get(reason, 0) + 1
            if len(summary['top_rejections']) < 8:
                summary['top_rejections'].append({
                    'source': source,
                    'exp': row.get('exp'),
                    'loc': limit_text(row.get('loc'), 180),
                    'sub': row.get('sub'),
                    'count': row.get('count'),
                    'reason': limit_text(row.get('reject_reason') or reason, 180),
                    'score': row.get('score') or row.get('final_score'),
                })
        if reject_reasons and not summary['top_rejections']:
            summary['top_rejections'] = [
                {'reason': limit_text(reason, 180)} for reason in list(reject_reasons)[:8]
            ]
        return summary

    @staticmethod
    def reject_bucket(reason):
        reason = clean(reason)
        if not reason:
            return 'unknown'
        if reason.startswith('count=0'):
            return 'count=0'
        if reason.startswith('ambiguous count='):
            return 'ambiguous'
        if reason == 'selected not visible':
            return 'not_visible'
        if 'text click candidate rejected' in reason:
            return 'text_not_interactive'
        if 'actionability' in reason:
            return 'actionability_failed'
        if 'semantic mismatch' in reason:
            return 'semantic_mismatch'
        if 'Timeout' in reason:
            return 'timeout'
        return limit_text(reason, 80)

