# -*- coding: utf-8 -*-
import hashlib
import json


def build_dom_digest(snapshot: dict) -> str:
    payload = json.dumps(snapshot or {}, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()

