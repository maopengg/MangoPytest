# -*- coding: utf-8 -*-
import re

from ..locator.sanitizer import clean


def first_prompt(element_model) -> str | None:
    for item in getattr(element_model, 'elements', None) or []:
        prompt = getattr(item, 'prompt', None)
        if prompt:
            return str(prompt)
    return None


def split_target_text(value: str) -> list[str]:
    value = clean(value)
    if not value:
        return []
    parts = [value]
    parts.extend(item for item in re.split(r'[-_/|｜>：:\s]+', value) if item)
    if len(value) > 12:
        suffix = re.sub(r'^(创建|新增|编辑|选择|输入|点击|打开|填写)', '', parts[-1] if parts else value)
        if suffix:
            parts.append(suffix)
    result = []
    for item in parts:
        item = item.strip('：: *\n\t')
        if len(item) < 2 or item in result:
            continue
        result.append(item)
    return sorted(result, key=len)


def target_texts(element_model, limit: int = 8) -> list[str]:
    values = []
    for source in (getattr(element_model, 'name', None), first_prompt(element_model)):
        for item in split_target_text(source):
            if item not in values:
                values.append(item)
    return values[:limit]


def semantic_required_texts(element_model, limit: int = 4) -> list[str]:
    values = []
    for source in (getattr(element_model, 'name', None), first_prompt(element_model)):
        value = clean(source)
        if not value:
            continue
        value = re.sub(r'^查找元素[：:\s]*', '', value).strip()
        value = semantic_core_text(value)
        parts = [item for item in re.split(r'[-_/|｜>：:\s]+', value) if len(item.strip()) >= 2]
        item = (parts[-1] if parts else value).strip('：: *\n\t')
        if len(item) >= 2 and item not in values:
            values.append(item)
    return values[:limit]


def semantic_core_text(value: str) -> str:
    value = clean(value)
    if not value:
        return ''
    value = re.sub(
        r'^(?:请)?(?:在)?(?:当前)?(?:页面|左侧|右侧|上方|下方|列表|表格|弹窗|抽屉|半屏窗口)'
        r'(?:中|内|上)?',
        '',
        value,
    )
    value = re.sub(
        r'^(?:查找|找到|寻找|找|获取|读取|定位|识别|选择|点击|输入|填写|打开|拿到|提取)',
        '',
        value,
    )
    value = re.sub(r'^(?:一个|一下|到|出|该|对应的|对应)', '', value)
    value = re.sub(r'^(?:(?:左侧|右侧|当前|选中|第一个|第一条)的?)+', '', value)
    if '的' in value:
        suffix = value.rsplit('的', 1)[-1].strip()
        if len(suffix) >= 2:
            value = suffix
    return value.strip('：: *\n\t')
