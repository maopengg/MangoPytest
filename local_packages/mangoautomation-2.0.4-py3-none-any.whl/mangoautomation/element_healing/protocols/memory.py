# -*- coding: utf-8 -*-
from typing import Protocol


class MemoryProvider(Protocol):
    async def load_async(self, element_id: int, test_env: int | None = None) -> dict:
        ...

    def load_sync(self, element_id: int, test_env: int | None = None) -> dict:
        ...


class RuntimeConfigProvider(Protocol):
    def locator_enabled(self) -> bool:
        ...

    def locator_mode(self) -> int:
        ...

    def semantic_strength(self) -> int:
        ...
