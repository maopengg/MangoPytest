# -*- coding: utf-8 -*-
from typing import Protocol


class ModelClient(Protocol):
    model_name: str | None

    async def complete_async(self, messages: list[dict], *, max_tokens: int, temperature: float,
                             response_format: dict | None = None) -> str:
        ...

    def complete_sync(self, messages: list[dict], *, max_tokens: int, temperature: float,
                      response_format: dict | None = None) -> str:
        ...
