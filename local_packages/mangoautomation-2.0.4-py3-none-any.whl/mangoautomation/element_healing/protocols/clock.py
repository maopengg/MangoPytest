# -*- coding: utf-8 -*-
import time


class SystemClock:
    @staticmethod
    def monotonic() -> float:
        return time.perf_counter()

    @staticmethod
    def epoch() -> float:
        return time.time()

