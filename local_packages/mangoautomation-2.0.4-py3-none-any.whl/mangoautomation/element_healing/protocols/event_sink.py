# -*- coding: utf-8 -*-
from typing import Protocol


class EventSink(Protocol):
    async def emit_async(self, event: str, payload: dict) -> None:
        ...

    def emit_sync(self, event: str, payload: dict) -> None:
        ...

