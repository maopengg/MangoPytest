# -*- coding: utf-8 -*-
import re

from mangoautomation.enums import ElementExpEnum

from .models import AccessibilitySnapshotNode, DurableLocatorSpec


class DurableLocatorGenerator:
    DYNAMIC_ID_PATTERN = re.compile(
        r'(?:^|[-_])[0-9a-f]{8,}(?:[-_]|$)|\d{8,}|^[0-9]+$', re.I,
    )

    @classmethod
    def build(cls, node: AccessibilitySnapshotNode,
              nodes: list[AccessibilitySnapshotNode]) -> DurableLocatorSpec | None:
        values = cls.build_all(node, nodes, limit=1)
        return values[0] if values else None

    @classmethod
    def build_all(cls, node: AccessibilitySnapshotNode,
                  nodes: list[AccessibilitySnapshotNode], limit: int = 5) -> list[DurableLocatorSpec]:
        result = []
        seen = set()
        for strategy, exp, loc, key in cls._strategies(node):
            matches = [item for item in nodes if item.frame_index == node.frame_index and key(item)]
            if not matches:
                continue
            sub = None
            if len(matches) > 1:
                sub = next((index + 1 for index, item in enumerate(matches) if item.ref == node.ref), None)
                if not sub:
                    continue
            candidate_key = (exp, loc, sub)
            if candidate_key in seen:
                continue
            seen.add(candidate_key)
            result.append(DurableLocatorSpec(
                exp=exp,
                loc=loc,
                sub=sub,
                strategy=strategy,
            ))
            if len(result) >= limit:
                break
        return result

    @classmethod
    def _strategies(cls, node: AccessibilitySnapshotNode):
        role = cls._clean(node.role)
        name = cls._clean(node.name)
        label = cls._clean(node.label)
        placeholder = cls._clean(node.placeholder)
        title = cls._clean(node.title)
        alt = cls._clean(node.alt)
        text = cls._clean(node.text)
        tag = cls._clean(node.tag).lower()
        attributes = node.attributes or {}
        testid = cls._clean(attributes.get('testid'))
        element_id = cls._clean(attributes.get('id'))
        element_name = cls._clean(attributes.get('name'))

        if role and role != 'generic' and name:
            yield (
                'role_name',
                ElementExpEnum.LOCATOR.value,
                f'get_by_role({role!r}, name={name!r}, exact=True)',
                lambda item, role=role, name=name: item.role == role and item.name == name,
            )
        if label:
            yield (
                'label', ElementExpEnum.LOCATOR.value, f'get_by_label({label!r}, exact=True)',
                lambda item, label=label: item.label == label,
            )
        if placeholder:
            yield (
                'placeholder', ElementExpEnum.LOCATOR.value,
                f'get_by_placeholder({placeholder!r}, exact=True)',
                lambda item, placeholder=placeholder: item.placeholder == placeholder,
            )
        if testid:
            yield (
                'test_id', ElementExpEnum.LOCATOR.value, f'get_by_test_id({testid!r})',
                lambda item, testid=testid: (item.attributes or {}).get('testid') == testid,
            )
        if title:
            yield (
                'title', ElementExpEnum.LOCATOR.value, f'get_by_title({title!r}, exact=True)',
                lambda item, title=title: item.title == title,
            )
        if alt:
            yield (
                'alt_text', ElementExpEnum.LOCATOR.value, f'get_by_alt_text({alt!r}, exact=True)',
                lambda item, alt=alt: item.alt == alt,
            )
        if text:
            yield (
                'text', ElementExpEnum.LOCATOR.value, f'get_by_text({text!r}, exact=True)',
                lambda item, text=text: item.text == text,
            )
            if tag:
                xpath = f'//{tag}[normalize-space(.)={cls._xpath_literal(text)}]'
                yield (
                    'xpath_text', ElementExpEnum.XPATH.value, xpath,
                    lambda item, tag=tag, text=text: item.tag == tag and item.text == text,
                )
        if element_id and not cls.DYNAMIC_ID_PATTERN.search(element_id):
            selector = cls._attribute_selector('id', element_id)
            yield (
                'stable_id', ElementExpEnum.LOCATOR.value, f'locator({selector!r})',
                lambda item, element_id=element_id: (item.attributes or {}).get('id') == element_id,
            )
        if tag and element_name:
            selector = f'{tag}{cls._attribute_selector("name", element_name)}'
            yield (
                'name_attribute', ElementExpEnum.LOCATOR.value, f'locator({selector!r})',
                lambda item, tag=tag, element_name=element_name: (
                    item.tag == tag and (item.attributes or {}).get('name') == element_name
                ),
            )
        if role and role != 'generic':
            yield (
                'role', ElementExpEnum.LOCATOR.value, f'get_by_role({role!r})',
                lambda item, role=role: item.role == role,
            )
        if tag:
            yield (
                'tag', ElementExpEnum.LOCATOR.value, f'locator({tag!r})',
                lambda item, tag=tag: item.tag == tag,
            )

    @staticmethod
    def _attribute_selector(name: str, value: str) -> str:
        escaped = value.replace('\\', '\\\\').replace('"', '\\"')
        return f'[{name}="{escaped}"]'

    @staticmethod
    def _xpath_literal(value: str) -> str:
        if "'" not in value:
            return f"'{value}'"
        if '"' not in value:
            return f'"{value}"'
        parts = value.split("'")
        values = []
        for index, part in enumerate(parts):
            if part:
                values.append(f"'{part}'")
            if index < len(parts) - 1:
                values.append('"\'"')
        return f'concat({", ".join(values)})'

    @staticmethod
    def _clean(value) -> str:
        return ' '.join(str(value or '').split()).strip()[:500]
