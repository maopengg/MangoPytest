# -*- coding: utf-8 -*-

SNAPSHOT_REF_ATTRIBUTE = 'data-mango-healing-ref'


ACCESSIBILITY_SNAPSHOT_SCRIPT = r"""(options) => {
  const snapshotId = String(options.snapshot_id || '');
  const startIndex = Number(options.start_index || 1);
  const limit = Math.max(1, Number(options.limit || 200));
  const markerAttribute = 'data-mango-healing-ref';

  document.querySelectorAll(`[${markerAttribute}]`).forEach((element) => {
    element.removeAttribute(markerAttribute);
  });

  const compact = (value, maxLength = 240) => String(value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);

  const isVisible = (element) => {
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return Boolean(
      style && style.visibility !== 'hidden' && style.display !== 'none' &&
      Number(style.opacity || 1) !== 0 && rect.width > 0 && rect.height > 0
    );
  };

  const roleOf = (element) => {
    const explicitRole = compact(element.getAttribute('role'), 60).split(' ')[0];
    if (explicitRole) return explicitRole;
    const tag = element.tagName.toLowerCase();
    const type = compact(element.getAttribute('type'), 30).toLowerCase();
    const roles = {
      a: element.hasAttribute('href') ? 'link' : 'generic',
      button: 'button', textarea: 'textbox', select: 'combobox', option: 'option',
      nav: 'navigation', main: 'main', header: 'banner', footer: 'contentinfo',
      form: 'form', table: 'table', tr: 'row', td: 'cell', th: 'columnheader',
      ul: 'list', ol: 'list', li: 'listitem', img: 'img', dialog: 'dialog',
      summary: 'button', progress: 'progressbar', meter: 'meter', label: 'label'
    };
    if (tag === 'input') {
      if (type === 'checkbox') return 'checkbox';
      if (type === 'radio') return 'radio';
      if (type === 'range') return 'slider';
      if (type === 'number') return 'spinbutton';
      if (['button', 'submit', 'reset', 'image', 'file'].includes(type)) return 'button';
      return 'textbox';
    }
    if (/^h[1-6]$/.test(tag)) return 'heading';
    return roles[tag] || 'generic';
  };

  const labelTextOf = (element) => {
    if (element.labels && element.labels.length) {
      return compact(Array.from(element.labels).map((label) => label.innerText || '').join(' '));
    }
    const id = element.getAttribute('id');
    if (id) {
      const escapedId = window.CSS && CSS.escape ? CSS.escape(id) : id.replace(/["\\]/g, '\\$&');
      const label = document.querySelector(`label[for="${escapedId}"]`);
      if (label) return compact(label.innerText || '');
    }
    return '';
  };

  const nameOf = (element) => {
    const ariaLabel = compact(element.getAttribute('aria-label'));
    if (ariaLabel) return ariaLabel;
    const labelledBy = compact(element.getAttribute('aria-labelledby'));
    if (labelledBy) {
      const text = compact(labelledBy.split(/\s+/).map((id) => {
        const target = document.getElementById(id);
        return target ? target.innerText || target.textContent || '' : '';
      }).join(' '));
      if (text) return text;
    }
    const labelText = labelTextOf(element);
    if (labelText) return labelText;
    for (const attribute of ['alt', 'placeholder', 'title']) {
      const value = compact(element.getAttribute(attribute));
      if (value) return value;
    }
    return compact(element.innerText || element.textContent || '');
  };

  const isInteractive = (element, role) => {
    const tag = element.tagName.toLowerCase();
    const cursor = window.getComputedStyle(element).cursor;
    return Boolean(
      ['button', 'a', 'input', 'textarea', 'select', 'option', 'summary'].includes(tag) ||
      element.isContentEditable || element.tabIndex >= 0 || element.hasAttribute('onclick') ||
      cursor === 'pointer' ||
      ['button', 'link', 'textbox', 'combobox', 'checkbox', 'radio', 'slider',
       'spinbutton', 'menuitem', 'option', 'switch', 'tab', 'treeitem'].includes(role)
    );
  };

  const hasSelectionSignal = (element) => {
    const className = compact(element.getAttribute('class'), 300).toLowerCase();
    return Boolean(
      element.getAttribute('aria-selected') === 'true' || element.hasAttribute('aria-current') ||
      /(^|[\s_-])(active|selected|current)([\s_-]|$)/.test(className)
    );
  };

  const isMeaningfulLeafText = (element) => {
    const directText = compact(
      Array.from(element.childNodes)
        .filter((node) => node.nodeType === Node.TEXT_NODE)
        .map((node) => node.textContent || '')
        .join(' '),
      180,
    );
    if (directText.length >= 2 && directText.length <= 180) return true;
    if (Array.from(element.children).some(isVisible)) return false;
    const text = compact(element.innerText || element.textContent || '', 180);
    return text.length >= 2 && text.length <= 180;
  };

  const isSemantic = (element, role, interactive) => {
    const tag = element.tagName.toLowerCase();
    return Boolean(
      interactive || role !== 'generic' || element.hasAttribute('aria-label') ||
      element.hasAttribute('aria-labelledby') ||
      ['label', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'img'].includes(tag) ||
      element.hasAttribute('data-testid') || element.hasAttribute('data-test-id') ||
      element.hasAttribute('data-cy') || element.hasAttribute('data-qa') ||
      hasSelectionSignal(element) ||
      isMeaningfulLeafText(element)
    );
  };

  const pathOf = (element) => {
    const path = [];
    let current = element;
    while (current && current !== document.documentElement && path.length < 6) {
      const role = roleOf(current);
      const name = nameOf(current);
      path.unshift(name ? `${role}:${compact(name, 50)}` : current.tagName.toLowerCase());
      current = current.parentElement;
    }
    return path;
  };

  const nearbyTextOf = (element) => {
    const container = element.closest(
      'label,fieldset,[role="group"],[role="dialog"],[class*="form-item"],'+
      '[class*="form_item"],[class*="field"],[class*="control"]'
    );
    if (!container || container === element) return '';
    return compact(container.innerText || container.textContent || '', 320);
  };

  const attributeValue = (element, names) => {
    for (const name of names) {
      const value = compact(element.getAttribute(name), 180);
      if (value) return value;
    }
    return '';
  };

  const allElements = Array.from(document.querySelectorAll('*'));
  const included = [];
  for (const element of allElements) {
    if (included.length >= limit || !isVisible(element)) continue;
    const role = roleOf(element);
    const interactive = isInteractive(element, role);
    if (!isSemantic(element, role, interactive)) continue;
    included.push({ element, role, interactive });
  }

  const refByElement = new Map();
  included.forEach((item, offset) => {
    const ref = `e${startIndex + offset}`;
    refByElement.set(item.element, ref);
    item.element.setAttribute(markerAttribute, `${snapshotId}:${ref}`);
  });

  const nodes = included.map((item, order) => {
    const element = item.element;
    const ref = refByElement.get(element);
    let parent = element.parentElement;
    while (parent && !refByElement.has(parent)) parent = parent.parentElement;
    const rect = element.getBoundingClientRect();
    const tag = element.tagName.toLowerCase();
    const checked = 'checked' in element ? Boolean(element.checked) : null;
    const selectedSignal = hasSelectionSignal(element);
    const selected = 'selected' in element ? Boolean(element.selected) : (selectedSignal || null);
    const ariaExpanded = element.getAttribute('aria-expanded');
    const level = /^h[1-6]$/.test(tag) ? Number(tag.slice(1)) : null;
    return {
      ref,
      parent_ref: parent ? refByElement.get(parent) : null,
      order,
      role: item.role,
      name: compact(nameOf(element)),
      text: compact(element.innerText || element.textContent || ''),
      label: compact(labelTextOf(element)),
      placeholder: compact(element.getAttribute('placeholder')),
      title: compact(element.getAttribute('title')),
      alt: compact(element.getAttribute('alt')),
      tag,
      visible: true,
      disabled: Boolean(element.disabled || element.getAttribute('aria-disabled') === 'true'),
      editable: Boolean(element.isContentEditable || ['input', 'textarea', 'select'].includes(tag)),
      interactive: item.interactive,
      checked,
      selected,
      expanded: ariaExpanded === null ? null : ariaExpanded === 'true',
      required: Boolean(element.required || element.getAttribute('aria-required') === 'true'),
      level,
      attributes: {
        id: compact(element.getAttribute('id'), 180),
        name: compact(element.getAttribute('name'), 180),
        type: compact(element.getAttribute('type'), 80),
        testid: attributeValue(element, ['data-testid', 'data-test-id', 'data-cy', 'data-qa']),
        aria_label: compact(element.getAttribute('aria-label'), 240)
      },
      rect: {
        x: Number(rect.x.toFixed(2)), y: Number(rect.y.toFixed(2)),
        width: Number(rect.width.toFixed(2)), height: Number(rect.height.toFixed(2))
      },
      path: pathOf(element),
      nearby_text: nearbyTextOf(element)
    };
  });

  return { nodes, next_index: startIndex + nodes.length };
}"""
