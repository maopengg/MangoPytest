# -*- coding: utf-8 -*-
import re

from .scripts import SNAPSHOT_REF_ATTRIBUTE


class SnapshotRefResolver:
    REF_PATTERN = re.compile(r'^e[1-9]\d*$')

    @classmethod
    def supports(cls, candidate) -> bool:
        metadata = getattr(candidate, 'metadata', {}) or {}
        return bool(
            metadata.get('accessibility_snapshot_id') and
            cls.REF_PATTERN.fullmatch(str(metadata.get('target_ref') or ''))
        )

    @classmethod
    def resolve(cls, page, candidate):
        metadata = getattr(candidate, 'metadata', {}) or {}
        scope = cls.scope(page, candidate)
        return scope.locator(cls.selector(
            metadata['accessibility_snapshot_id'], metadata['target_ref'],
        ))

    @classmethod
    def scope(cls, page, candidate):
        metadata = getattr(candidate, 'metadata', {}) or {}
        frame_index = metadata.get('snapshot_frame_index', 0)
        try:
            frame_index = int(frame_index)
        except (TypeError, ValueError):
            frame_index = 0
        frames = getattr(page, 'frames', None)
        if isinstance(frames, (list, tuple)) and 0 <= frame_index < len(frames):
            return frames[frame_index]
        return page

    @classmethod
    def selector(cls, snapshot_id: str, target_ref: str) -> str:
        marker = cls.marker(snapshot_id, target_ref)
        return f'[{SNAPSHOT_REF_ATTRIBUTE}="{marker}"]'

    @staticmethod
    def marker(snapshot_id: str, target_ref: str) -> str:
        return f'{snapshot_id}:{target_ref}'

    @classmethod
    def select(cls, locator, candidate):
        if cls.supports(candidate):
            return locator.first
        return locator.nth(candidate.sub - 1) if candidate.sub else locator.first

    @classmethod
    async def clear_async(cls, page, snapshot_id: str | None = None) -> None:
        for frame in cls._frames(page):
            try:
                await frame.evaluate(cls._cleanup_script(), snapshot_id)
            except Exception:
                continue

    @classmethod
    def clear_sync(cls, page, snapshot_id: str | None = None) -> None:
        for frame in cls._frames(page):
            try:
                frame.evaluate(cls._cleanup_script(), snapshot_id)
            except Exception:
                continue

    @staticmethod
    def _frames(page) -> list:
        frames = getattr(page, 'frames', None)
        return list(frames) if isinstance(frames, (list, tuple)) and frames else [page]

    @staticmethod
    def _cleanup_script() -> str:
        return """(snapshotId) => {
          document.querySelectorAll('[data-mango-healing-ref]').forEach((element) => {
            const value = element.getAttribute('data-mango-healing-ref') || '';
            if (!snapshotId || value.startsWith(`${snapshotId}:`)) {
              element.removeAttribute('data-mango-healing-ref');
            }
          });
        }"""
