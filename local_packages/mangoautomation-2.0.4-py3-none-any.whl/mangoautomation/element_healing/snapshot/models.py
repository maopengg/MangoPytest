# -*- coding: utf-8 -*-
from pydantic import BaseModel, ConfigDict, Field


class SnapshotRect(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)

    x: float
    y: float
    width: float = Field(ge=0)
    height: float = Field(ge=0)


class AccessibilitySnapshotNode(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)

    ref: str = Field(pattern=r'^e[1-9]\d*$')
    frame_index: int = Field(ge=0)
    frame_url: str = ''
    parent_ref: str | None = None
    order: int = Field(ge=0)
    role: str = 'generic'
    name: str = ''
    text: str = ''
    label: str = ''
    placeholder: str = ''
    title: str = ''
    alt: str = ''
    tag: str = ''
    visible: bool = True
    disabled: bool = False
    editable: bool = False
    interactive: bool = False
    checked: bool | None = None
    selected: bool | None = None
    expanded: bool | None = None
    required: bool = False
    level: int | None = None
    attributes: dict[str, str] = Field(default_factory=dict)
    rect: SnapshotRect | None = None
    path: list[str] = Field(default_factory=list)
    nearby_text: str = ''


class AccessibilitySnapshot(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)

    snapshot_id: str = Field(min_length=8, max_length=64, pattern=r'^[a-zA-Z0-9_-]+$')
    page_url: str = ''
    created_at_ms: int = Field(ge=0)
    nodes: list[AccessibilitySnapshotNode] = Field(default_factory=list)
    tree: str = ''
    errors: list[str] = Field(default_factory=list)

    def node_by_ref(self, target_ref: str) -> AccessibilitySnapshotNode | None:
        return next((node for node in self.nodes if node.ref == target_ref), None)

    def prompt_nodes(self, limit: int = 160) -> list[dict]:
        fields = (
            'ref', 'parent_ref', 'frame_index', 'role', 'name', 'text', 'label', 'placeholder',
            'title', 'alt', 'tag', 'disabled', 'editable', 'interactive',
            'checked', 'selected', 'expanded', 'required', 'attributes', 'path', 'nearby_text',
        )
        return [
            {
                key: getattr(node, key)
                for key in fields
                if getattr(node, key) not in ('', None, [], False)
            }
            for node in self.nodes[:limit]
        ]


class DurableLocatorSpec(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)

    exp: int
    loc: str = Field(min_length=1, max_length=1000)
    sub: int | None = Field(default=None, ge=1)
    strategy: str = Field(min_length=1, max_length=80)
