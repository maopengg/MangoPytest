# -*- coding: utf-8 -*-
import time
from uuid import uuid4

from pydantic import ValidationError

from ..baseline import sanitize_json_value
from ..baseline.sanitizer import sanitize_attributes, sanitize_url
from .models import AccessibilitySnapshot, AccessibilitySnapshotNode
from .renderer import AccessibilitySnapshotRenderer
from .scripts import ACCESSIBILITY_SNAPSHOT_SCRIPT


class AccessibilitySnapshotBuilder:
    DEFAULT_LIMIT = 200

    @classmethod
    async def build_async(cls, page, limit: int = DEFAULT_LIMIT) -> AccessibilitySnapshot:
        snapshot_id = uuid4().hex[:16]
        nodes = []
        errors = []
        next_index = 1
        for frame_index, frame in enumerate(cls._frames(page)):
            remaining = max(0, int(limit) - len(nodes))
            if not remaining:
                break
            try:
                raw = await frame.evaluate(ACCESSIBILITY_SNAPSHOT_SCRIPT, {
                    'snapshot_id': snapshot_id,
                    'start_index': next_index,
                    'limit': remaining,
                })
                frame_nodes, next_index = cls._normalize_frame_result(
                    raw, frame_index, cls._url(frame), next_index, errors,
                )
                nodes.extend(frame_nodes)
            except Exception as error:
                errors.append(f'frame[{frame_index}] {str(error)[:300]}')
        return cls._build_snapshot(snapshot_id, cls._url(page), nodes, errors)

    @classmethod
    def build_sync(cls, page, limit: int = DEFAULT_LIMIT) -> AccessibilitySnapshot:
        snapshot_id = uuid4().hex[:16]
        nodes = []
        errors = []
        next_index = 1
        for frame_index, frame in enumerate(cls._frames(page)):
            remaining = max(0, int(limit) - len(nodes))
            if not remaining:
                break
            try:
                raw = frame.evaluate(ACCESSIBILITY_SNAPSHOT_SCRIPT, {
                    'snapshot_id': snapshot_id,
                    'start_index': next_index,
                    'limit': remaining,
                })
                frame_nodes, next_index = cls._normalize_frame_result(
                    raw, frame_index, cls._url(frame), next_index, errors,
                )
                nodes.extend(frame_nodes)
            except Exception as error:
                errors.append(f'frame[{frame_index}] {str(error)[:300]}')
        return cls._build_snapshot(snapshot_id, cls._url(page), nodes, errors)

    @staticmethod
    def _frames(page) -> list:
        frames = getattr(page, 'frames', None)
        return list(frames) if isinstance(frames, (list, tuple)) and frames else [page]

    @staticmethod
    def _url(target) -> str:
        value = getattr(target, 'url', '')
        return sanitize_url(value if isinstance(value, str) else '')

    @classmethod
    def _normalize_frame_result(cls, raw, frame_index: int, frame_url: str,
                                next_index: int, errors: list[str]):
        if not isinstance(raw, dict):
            return [], next_index
        result = []
        for row in raw.get('nodes') or []:
            if not isinstance(row, dict):
                continue
            value = sanitize_json_value(row)
            value['frame_index'] = frame_index
            value['frame_url'] = frame_url
            value['attributes'] = {
                str(key): str(item or '')
                for key, item in sanitize_attributes(value.get('attributes')).items()
            }
            try:
                result.append(AccessibilitySnapshotNode.model_validate(value, strict=True))
            except ValidationError as error:
                errors.append(f'frame[{frame_index}] invalid node: {str(error)[:300]}')
        raw_next = raw.get('next_index')
        try:
            parsed_next = int(raw_next)
        except (TypeError, ValueError):
            parsed_next = next_index + len(result)
        return result, max(parsed_next, next_index + len(result))

    @staticmethod
    def _build_snapshot(snapshot_id: str, page_url: str,
                        nodes: list[AccessibilitySnapshotNode], errors: list[str]):
        return AccessibilitySnapshot(
            snapshot_id=snapshot_id,
            page_url=page_url,
            created_at_ms=int(time.time() * 1000),
            nodes=nodes,
            tree=AccessibilitySnapshotRenderer.render(nodes),
            errors=errors[:10],
        )
