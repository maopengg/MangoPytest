# -*- coding: utf-8 -*-
from .models import AccessibilitySnapshotNode


class AccessibilitySnapshotRenderer:
    @classmethod
    def render(cls, nodes: list[AccessibilitySnapshotNode]) -> str:
        lines = []
        node_map = {node.ref: node for node in nodes}
        current_frame = None
        for node in nodes:
            if current_frame != node.frame_index:
                current_frame = node.frame_index
                frame_label = 'main frame' if current_frame == 0 else f'frame {current_frame}'
                lines.append(f'frame "{frame_label}" url="{cls._compact(node.frame_url, 180)}"')
            depth = cls._depth(node, node_map)
            lines.append(f'{"  " * (depth + 1)}- {cls._line(node)}')
        return '\n'.join(lines)

    @classmethod
    def _line(cls, node: AccessibilitySnapshotNode) -> str:
        name = cls._compact(node.name, 180)
        value = f'{node.role} "{name}"' if name else node.role
        value += f' [ref={node.ref}]'
        states = []
        if node.disabled:
            states.append('disabled')
        if node.editable:
            states.append('editable')
        if node.checked is not None:
            states.append(f'checked={str(node.checked).lower()}')
        if node.selected is not None:
            states.append(f'selected={str(node.selected).lower()}')
        if node.expanded is not None:
            states.append(f'expanded={str(node.expanded).lower()}')
        if node.required:
            states.append('required')
        if node.level:
            states.append(f'level={node.level}')
        if states:
            value += f' [{" ".join(states)}]'
        text = cls._compact(node.text, 180)
        if text and text != name:
            value += f': {text}'
        return value

    @staticmethod
    def _depth(node: AccessibilitySnapshotNode, node_map: dict[str, AccessibilitySnapshotNode]) -> int:
        depth = 0
        parent_ref = node.parent_ref
        seen = set()
        while parent_ref and parent_ref in node_map and parent_ref not in seen and depth < 12:
            seen.add(parent_ref)
            depth += 1
            parent_ref = node_map[parent_ref].parent_ref
        return depth

    @staticmethod
    def _compact(value, max_length: int) -> str:
        return ' '.join(str(value or '').split()).replace('"', '\\"')[:max_length]
