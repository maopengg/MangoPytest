# -*- coding: utf-8 -*-
import threading
import time
from dataclasses import dataclass

from .thresholds import AGENT_COOLDOWN_SECONDS, AGENT_FAILURE_THRESHOLD


@dataclass(frozen=True)
class AgentCircuitBreakerStatus:
    allowed: bool
    failure_count: int = 0
    threshold: int = AGENT_FAILURE_THRESHOLD
    cooldown_seconds: float = AGENT_COOLDOWN_SECONDS
    cooldown_remaining_seconds: float = 0.0
    last_error: str | None = None
    recovery_probe: bool = False
    configuration_error: bool = False

    def to_dict(self) -> dict:
        return {
            'allowed': self.allowed,
            'failure_count': self.failure_count,
            'threshold': self.threshold,
            'cooldown_seconds': self.cooldown_seconds,
            'cooldown_remaining_seconds': round(self.cooldown_remaining_seconds, 3),
            'last_error': self.last_error,
            'recovery_probe': self.recovery_probe,
            'configuration_error': self.configuration_error,
        }


@dataclass
class _FailureState:
    count: int
    last_failure: float
    last_error: str | None = None


class AgentCircuitBreaker:
    """Short-lived process-local protection for repeatedly failing Agent calls."""

    _lock = threading.Lock()
    _failures: dict[tuple[int | None, str], _FailureState] = {}
    _configuration_failure: _FailureState | None = None

    @classmethod
    def allow(cls, element_id: int | None, page_url: str | None, now: float | None = None) -> bool:
        return cls.status(element_id, page_url, now=now).allowed

    @classmethod
    def status(cls, element_id: int | None, page_url: str | None,
               now: float | None = None) -> AgentCircuitBreakerStatus:
        key = cls._key(element_id, page_url)
        now = time.monotonic() if now is None else now
        with cls._lock:
            configuration_failure = cls._configuration_failure
            if configuration_failure is not None:
                elapsed = max(0.0, now - configuration_failure.last_failure)
                if elapsed < AGENT_COOLDOWN_SECONDS:
                    return AgentCircuitBreakerStatus(
                        allowed=False,
                        failure_count=configuration_failure.count,
                        cooldown_remaining_seconds=max(0.0, AGENT_COOLDOWN_SECONDS - elapsed),
                        last_error=configuration_failure.last_error,
                        configuration_error=True,
                    )
                cls._configuration_failure = None
            state = cls._failures.get(key)
            if state is None:
                return AgentCircuitBreakerStatus(allowed=True)
            if state.count < AGENT_FAILURE_THRESHOLD:
                return AgentCircuitBreakerStatus(
                    allowed=True,
                    failure_count=state.count,
                    last_error=state.last_error,
                )
            elapsed = max(0.0, now - state.last_failure)
            if elapsed >= AGENT_COOLDOWN_SECONDS:
                cls._failures.pop(key, None)
                return AgentCircuitBreakerStatus(
                    allowed=True,
                    failure_count=state.count,
                    last_error=state.last_error,
                    recovery_probe=True,
                )
            return AgentCircuitBreakerStatus(
                allowed=False,
                failure_count=state.count,
                cooldown_remaining_seconds=max(0.0, AGENT_COOLDOWN_SECONDS - elapsed),
                last_error=state.last_error,
            )

    @classmethod
    def success(cls, element_id: int | None, page_url: str | None) -> AgentCircuitBreakerStatus:
        with cls._lock:
            cls._configuration_failure = None
            state = cls._failures.pop(cls._key(element_id, page_url), None)
        return AgentCircuitBreakerStatus(
            allowed=True,
            failure_count=state.count if state else 0,
            last_error=state.last_error if state else None,
        )

    @classmethod
    def failure(cls, element_id: int | None, page_url: str | None, error: str | None = None,
                now: float | None = None, configuration_error: bool = False) -> AgentCircuitBreakerStatus:
        key = cls._key(element_id, page_url)
        now = time.monotonic() if now is None else now
        with cls._lock:
            if configuration_error:
                state = _FailureState(
                    count=AGENT_FAILURE_THRESHOLD,
                    last_failure=now,
                    last_error=str(error)[:500] if error else None,
                )
                cls._configuration_failure = state
                return AgentCircuitBreakerStatus(
                    allowed=False,
                    failure_count=state.count,
                    cooldown_remaining_seconds=AGENT_COOLDOWN_SECONDS,
                    last_error=state.last_error,
                    configuration_error=True,
                )
            previous = cls._failures.get(key)
            state = _FailureState(
                count=(previous.count if previous else 0) + 1,
                last_failure=now,
                last_error=str(error)[:500] if error else None,
            )
            cls._failures[key] = state
        return AgentCircuitBreakerStatus(
            allowed=state.count < AGENT_FAILURE_THRESHOLD,
            failure_count=state.count,
            cooldown_remaining_seconds=(
                AGENT_COOLDOWN_SECONDS if state.count >= AGENT_FAILURE_THRESHOLD else 0.0
            ),
            last_error=state.last_error,
        )

    @classmethod
    def reset(cls) -> None:
        with cls._lock:
            cls._failures.clear()
            cls._configuration_failure = None

    @staticmethod
    def is_configuration_error(error: str | None) -> bool:
        message = str(error or '').lower()
        return any(marker in message for marker in (
            'authentication fails', 'authentication_error', 'invalid api key',
            'api key is invalid', 'error code: 401', 'status code: 401', 'unauthorized',
        ))

    @staticmethod
    def _key(element_id: int | None, page_url: str | None) -> tuple[int | None, str]:
        return element_id, str(page_url or '').split('#', 1)[0]
