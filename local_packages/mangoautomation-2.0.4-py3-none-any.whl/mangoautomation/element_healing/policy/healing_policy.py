# -*- coding: utf-8 -*-
from dataclasses import dataclass

from ..models import HealingDecision, HealingStatus, VerificationResult
from .thresholds import AUTO_APPLY_SCORE, TEMPORARY_HEAL_SCORE


@dataclass(frozen=True)
class StaticRuntimeConfig:
    enabled: bool = True
    mode: int = 2
    semantic_strength_value: int = 0

    def locator_enabled(self) -> bool:
        return self.enabled

    def locator_mode(self) -> int:
        return self.mode if self.mode in (1, 2, 3) else 1

    def semantic_strength(self) -> int:
        try:
            value = int(self.semantic_strength_value)
        except (TypeError, ValueError):
            value = 0
        return max(0, min(value, 100))


class HealingPolicy:
    def __init__(self, mode: int = 2, auto_apply_score: int = AUTO_APPLY_SCORE):
        self.mode = mode if mode in (1, 2, 3) else 1
        self.auto_apply_score = auto_apply_score

    def allow_temporary_heal(self) -> bool:
        return self.mode in (2, 3)

    def decide(self, result: VerificationResult | None) -> HealingDecision:
        if result is None or not result.valid:
            return HealingDecision(status=HealingStatus.REJECTED, reasons=['no verified candidate'])
        if self.mode == 1:
            return HealingDecision(
                status=HealingStatus.SUGGESTED,
                selected=result,
                should_save_record=True,
                reasons=['current mode only produces suggestions'],
            )
        if result.final_score < TEMPORARY_HEAL_SCORE:
            return HealingDecision(
                status=HealingStatus.SUGGESTED,
                selected=result,
                should_save_record=True,
                reasons=[
                    f'candidate score {result.final_score} is below temporary-heal threshold '
                    f'{TEMPORARY_HEAL_SCORE}'
                ],
            )
        status = HealingStatus.TEMPORARY_HEAL
        reasons = []
        if self.mode == 3 and result.final_score >= self.auto_apply_score and result.auto_apply_eligible:
            status = HealingStatus.AUTO_APPLY
        elif self.mode == 3:
            reasons.append('candidate passed temporary use but did not satisfy strict auto-apply gates')
        return HealingDecision(
            status=status,
            selected=result,
            should_retry_operation=True,
            should_save_record=True,
            should_refresh_baseline=True,
            reasons=reasons,
        )
