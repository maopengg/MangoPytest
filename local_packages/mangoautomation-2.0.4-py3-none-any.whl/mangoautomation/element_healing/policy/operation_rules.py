CLICK_ACTION_KEYS = {
    'w_click', 'w_force_click', 'w_dblclick', 'w_many_click', 'w_right_click', 'w_time_click',
    'w_check', 'w_uncheck', 'w_set_checked', 'w_tap',
}

EDITABLE_ACTION_KEYS = {
    'w_input', 'w_clear_input', 'w_clear', 'w_type', 'w_press_sequentially',
}

CHECK_ACTION_KEYS = {'w_check', 'w_uncheck', 'w_set_checked'}
SELECT_ACTION_KEYS = {'w_select_option'}
UPLOAD_ACTION_KEYS = {'w_upload_files'}
READ_ACTION_KEYS = {
    'w_get_text', 'w_get_texts', 'w_get_attribute', 'w_get_input_value', 'w_get_inner_html',
}


def operation_key(find_params: dict | None) -> str:
    return str((find_params or {}).get('ope_key') or '').strip()


def semantic_strength(find_params: dict | None) -> int:
    value = (find_params or {}).get('_semantic_strength', 0)
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = 0
    return max(0, min(value, 100))


def is_click_operation(find_params: dict | None) -> bool:
    return operation_key(find_params) in CLICK_ACTION_KEYS


def is_read_operation(find_params: dict | None) -> bool:
    return operation_key(find_params) in READ_ACTION_KEYS


def dynamic_read_locator_reason(candidate, find_params: dict | None) -> str | None:
    if not is_read_operation(find_params):
        return None
    strategy = str((getattr(candidate, 'metadata', None) or {}).get('durable_locator_strategy') or '')
    if strategy in {'text', 'xpath_text'}:
        return 'dynamic text locator is valid for this run but cannot be auto-applied'
    return None


def needs_actionability_check(find_params: dict | None) -> bool:
    key = operation_key(find_params)
    return key in CLICK_ACTION_KEYS or key in EDITABLE_ACTION_KEYS or key in UPLOAD_ACTION_KEYS


def operation_compatibility_reason(semantic_state: dict | None, find_params: dict | None) -> str | None:
    state = semantic_state or {}
    if not state:
        return None
    key = operation_key(find_params)
    tag = str(state.get('tag') or '').lower()
    role = str(state.get('role') or '').lower()
    element_type = str(state.get('type') or '').lower()

    if key in EDITABLE_ACTION_KEYS and state.get('editable') is False:
        return f'operation {key} requires an editable element, actual tag={tag or "-"}, role={role or "-"}'
    if key in CHECK_ACTION_KEYS and not (
        role in {'checkbox', 'radio', 'switch'} or
        (tag == 'input' and element_type in {'checkbox', 'radio'})
    ):
        return f'operation {key} requires checkbox/radio/switch, actual tag={tag or "-"}, role={role or "-"}'
    if key in SELECT_ACTION_KEYS and not (tag == 'select' or role in {'combobox', 'listbox'}):
        return f'operation {key} requires select/combobox, actual tag={tag or "-"}, role={role or "-"}'
    if key in UPLOAD_ACTION_KEYS and not (
        (tag == 'input' and element_type == 'file') or state.get('interactive')
    ):
        return f'operation {key} requires file input or interactive file chooser trigger'
    if key in CLICK_ACTION_KEYS and state.get('interactive') is False:
        return f'operation {key} requires an interactive element, actual tag={tag or "-"}, role={role or "-"}'
    return None


def auto_apply_operation_compatibility_reason(semantic_state: dict | None,
                                              find_params: dict | None) -> str | None:
    reason = operation_compatibility_reason(semantic_state, find_params)
    if reason:
        return reason
    state = semantic_state or {}
    key = operation_key(find_params)
    if key in CLICK_ACTION_KEYS and not state.get('direct_interactive'):
        return f'auto apply for {key} requires a direct interactive signal'
    if key in UPLOAD_ACTION_KEYS and not (
        (str(state.get('tag') or '').lower() == 'input' and
         str(state.get('type') or '').lower() == 'file') or
        state.get('direct_interactive')
    ):
        return f'auto apply for {key} requires file input or a direct interactive trigger'
    return None
