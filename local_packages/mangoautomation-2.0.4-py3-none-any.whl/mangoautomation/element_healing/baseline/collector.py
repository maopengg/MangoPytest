# -*- coding: utf-8 -*-
import asyncio

from .fingerprint import fingerprint
from .sanitizer import sanitize_snapshot


ELEMENT_SNAPSHOT_SCRIPT = """(el) => {
  const sensitiveName = /password|passwd|pwd|token|secret|authorization|cookie|session|api[-_]?key|access[-_]?key/i;
  const transientName = /^(data-mango-healing-ref)$/i;
  const safeHtml = (node, limit) => {
    if (!node) return '';
    const clone = node.cloneNode(true);
    const nodes = [clone, ...Array.from(clone.querySelectorAll('*'))];
    for (const item of nodes) {
      for (const attr of Array.from(item.attributes || [])) {
        if (sensitiveName.test(attr.name) || transientName.test(attr.name) || attr.name.toLowerCase() === 'value') {
          item.removeAttribute(attr.name);
        }
      }
      const tag = String(item.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') {
        item.removeAttribute('value');
        if (tag === 'textarea') item.textContent = '';
      }
    }
    return String(clone.outerHTML || '').slice(0, limit);
  };
  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  const attrs = {};
  for (const attr of Array.from(el.attributes || [])) {
    if (sensitiveName.test(attr.name) || transientName.test(attr.name) || attr.name.toLowerCase() === 'value') continue;
    if (/^(id|class|name|type|role|title|placeholder|aria-|data-)/.test(attr.name)) {
      attrs[attr.name] = String(attr.value).slice(0, 500);
    }
  }
  const parent = el.parentElement;
  const siblings = parent ? Array.from(parent.children).slice(0, 12).map((item) => safeHtml(item, 1000)).join('\\n').slice(0, 8000) : '';
  const localPath = [];
  let node = el;
  while (node && node !== document.body && localPath.length < 5) {
    localPath.unshift({
      tag: String(node.tagName || '').toLowerCase(),
      role: node.getAttribute('role') || '',
      name: node.getAttribute('aria-label') || node.getAttribute('name') || '',
      text: (node.innerText || '').trim().slice(0, 160)
    });
    node = node.parentElement;
  }
  return {
    page_url: `${window.location.origin}${window.location.pathname}`,
    page_title: document.title,
    element_tag: el.tagName.toLowerCase(),
    element_role: el.getAttribute('role') || '',
    element_type: el.getAttribute('type') || '',
    element_name: el.getAttribute('aria-label') || el.getAttribute('name') || '',
    element_placeholder: el.getAttribute('placeholder') || '',
    element_value: '',
    element_attributes: attrs,
    element_rect: {x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height)},
    element_css: {
      display: style.display, visibility: style.visibility, color: style.color,
      backgroundColor: style.backgroundColor, fontSize: style.fontSize, zIndex: style.zIndex
    },
    outer_html: safeHtml(el, 8000),
    parent_html: safeHtml(parent, 12000),
    nearby_html: siblings,
    page_dom_digest: {tag: el.tagName.toLowerCase(), text: (el.innerText || '').trim().slice(0, 500)},
    accessibility_digest: {nodes: localPath}
  };
}"""


class BaselineCollector:
    @classmethod
    async def freeze_async(cls, page, locator, timeout_seconds: float = 0.8) -> dict | None:
        try:
            snapshot = await asyncio.wait_for(
                locator.evaluate(ELEMENT_SNAPSHOT_SCRIPT),
                timeout=timeout_seconds,
            )
        except Exception:
            return None
        return cls._finalize(snapshot)

    @classmethod
    def freeze_sync(cls, page, locator) -> dict | None:
        try:
            snapshot = locator.evaluate(ELEMENT_SNAPSHOT_SCRIPT)
        except Exception:
            return None
        return cls._finalize(snapshot)

    @staticmethod
    def _finalize(snapshot: dict | None) -> dict:
        snapshot = sanitize_snapshot(snapshot)
        snapshot['html_hash'] = fingerprint(
            snapshot.get('outer_html'), snapshot.get('parent_html'), snapshot.get('nearby_html'),
        )
        return snapshot
