# -*- coding: utf-8 -*-
import hashlib


def fingerprint(*values) -> str:
    raw = '|'.join(str(value or '') for value in values)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

