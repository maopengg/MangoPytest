# -*- coding: utf-8 -*-
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

SENSITIVE_ATTRIBUTE_PATTERN = re.compile(
    r'(password|passwd|pwd|token|secret|authorization|cookie|session|api[-_]?key|access[-_]?key)',
    re.I,
)
SENSITIVE_ASSIGNMENT_PATTERN = re.compile(
    r'(?i)((?:password|passwd|pwd|token|secret|authorization|cookie|session|api[-_]?key|access[-_]?key)'
    r'\s*[=:]\s*)([^\s"\'<>;&]+)',
)
BEARER_PATTERN = re.compile(r'(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}')
JWT_PATTERN = re.compile(r'\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b')
EMAIL_PATTERN = re.compile(r'(?<![\w.-])[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}(?![\w.-])')
PHONE_PATTERN = re.compile(r'(?<!\d)(?:\+?86[- ]?)?1[3-9]\d{9}(?!\d)')
LONG_NUMBER_PATTERN = re.compile(r'(?<!\d)\d{12,19}(?!\d)')
VALUE_ATTRIBUTE_PATTERN = re.compile(r'(?i)(\svalue\s*=\s*)(["\']).*?\2', re.S)
TEXTAREA_PATTERN = re.compile(r'(?is)(<textarea\b[^>]*>).*?(</textarea>)')


def sanitize_attributes(attributes: dict | None) -> dict:
    result = {}
    for key, value in (attributes or {}).items():
        if SENSITIVE_ATTRIBUTE_PATTERN.search(str(key)):
            continue
        result[str(key)[:80]] = redact_sensitive_text(value, 500)
    return result


def redact_sensitive_text(value, max_length: int | None = None) -> str:
    text = str(value or '')
    text = BEARER_PATTERN.sub(r'\1 [REDACTED]', text)
    text = JWT_PATTERN.sub('[REDACTED_JWT]', text)
    text = SENSITIVE_ASSIGNMENT_PATTERN.sub(r'\1[REDACTED]', text)
    text = EMAIL_PATTERN.sub('[REDACTED_EMAIL]', text)
    text = PHONE_PATTERN.sub('[REDACTED_PHONE]', text)
    text = LONG_NUMBER_PATTERN.sub('[REDACTED_NUMBER]', text)
    return text if max_length is None else text[:max_length]


def sanitize_html(value, max_length: int) -> str:
    text = redact_sensitive_text(value)
    text = VALUE_ATTRIBUTE_PATTERN.sub(r'\1\2[REDACTED]\2', text)
    text = TEXTAREA_PATTERN.sub(r'\1[REDACTED]\2', text)
    return text[:max_length]


def sanitize_url(value) -> str:
    value = str(value or '')
    try:
        parts = urlsplit(value)
        query = []
        for key, item in parse_qsl(parts.query, keep_blank_values=True):
            query.append((key, '[REDACTED]' if SENSITIVE_ATTRIBUTE_PATTERN.search(key) else redact_sensitive_text(item, 200)))
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), ''))
    except Exception:
        return redact_sensitive_text(value, 2000)


def sanitize_json_value(value, depth: int = 0):
    if depth > 8:
        return '[TRUNCATED]'
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            key_text = str(key)[:120]
            result[key_text] = '[REDACTED]' if SENSITIVE_ATTRIBUTE_PATTERN.search(key_text) else sanitize_json_value(item, depth + 1)
        return result
    if isinstance(value, list):
        return [sanitize_json_value(item, depth + 1) for item in value[:200]]
    if isinstance(value, tuple):
        return [sanitize_json_value(item, depth + 1) for item in value[:200]]
    if isinstance(value, str):
        return redact_sensitive_text(value, 2000)
    return value


def sanitize_snapshot(snapshot: dict | None) -> dict:
    snapshot = dict(snapshot or {})
    snapshot['element_attributes'] = sanitize_attributes(snapshot.get('element_attributes'))
    snapshot['element_value'] = ''
    snapshot['page_url'] = sanitize_url(snapshot.get('page_url'))
    for key in ('page_title', 'element_name', 'element_placeholder'):
        snapshot[key] = redact_sensitive_text(snapshot.get(key), 512)
    snapshot['outer_html'] = sanitize_html(snapshot.get('outer_html'), 8000)
    snapshot['parent_html'] = sanitize_html(snapshot.get('parent_html'), 12000)
    snapshot['nearby_html'] = sanitize_html(snapshot.get('nearby_html'), 12000)
    for key in ('page_dom_digest', 'accessibility_digest'):
        snapshot[key] = sanitize_json_value(snapshot.get(key) or {})
    return snapshot
