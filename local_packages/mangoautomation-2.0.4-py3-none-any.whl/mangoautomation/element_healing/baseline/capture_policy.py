# -*- coding: utf-8 -*-


class BaselineCapturePolicy:
    @staticmethod
    def should_capture(element_model, locator_metadata: dict | None = None) -> bool:
        return bool(
            getattr(element_model, 'collect_snapshot', False) or
            (locator_metadata or {}).get('temporary_heal_used')
        )

