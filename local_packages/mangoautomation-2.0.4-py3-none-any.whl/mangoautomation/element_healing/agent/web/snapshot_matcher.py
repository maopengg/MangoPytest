# -*- coding: utf-8 -*-
from ...context.sanitizer import semantic_core_text
from ...policy import MAX_AGENT_CANDIDATES
from .response_schema import WebLocatorCandidatePayload


class AccessibilitySnapshotMatcher:
    """Resolve explicit label/value structures without depending on model output."""

    @classmethod
    def match(cls, context, snapshot, *, label_value_only: bool = False) -> list[WebLocatorCandidatePayload]:
        targets = cls._targets(context)
        if not targets:
            return []
        children = {}
        for node in snapshot.nodes:
            if node.parent_ref:
                children.setdefault(node.parent_ref, []).append(node)

        scored = {}
        for node in snapshot.nodes:
            own_values = cls._values(node)
            own_score = cls._semantic_score(targets, own_values)
            if own_score and not label_value_only:
                cls._add(scored, node.ref, own_score, 'snapshot node matches target semantics')

            if not cls._starts_with_target(targets, own_values):
                continue
            for child in children.get(node.ref, []):
                child_values = cls._values(child)
                if not child_values or cls._semantic_score(targets, child_values):
                    continue
                if not cls._is_value_node(child):
                    continue
                cls._add(
                    scored,
                    child.ref,
                    min(98, max(92, own_score + 5)),
                    f'value node adjacent to target label {node.ref}',
                )

        if not label_value_only:
            cls._match_selected_card_applicant(scored, context, snapshot, children)
            cls._match_selected_card_title(scored, context, snapshot, children)

        order_by_ref = {node.ref: node.order for node in snapshot.nodes}
        rows = sorted(
            scored.values(),
            key=lambda item: (-item[0], order_by_ref.get(item[1], 10 ** 9)),
        )
        return [
            WebLocatorCandidatePayload(
                source='ai_accessibility',
                target_ref=ref,
                reason=reason,
                confidence=score,
            )
            for score, ref, reason in rows[:MAX_AGENT_CANDIDATES]
        ]

    @staticmethod
    def _targets(context) -> list[str]:
        raw_values = [getattr(context, 'element_name', None), getattr(context, 'prompt', None)]
        semantics = getattr(context, 'expected_semantics', None)
        raw_values.extend(getattr(semantics, 'target_texts', None) or [])
        result = []
        for value in raw_values:
            target = semantic_core_text(str(value or ''))
            if len(target) >= 2 and target not in result:
                result.append(target)
        return result

    @staticmethod
    def _values(node) -> list[str]:
        values = []
        for value in (
                node.name, node.text, node.label, node.placeholder,
                node.title, node.alt, node.nearby_text):
            value = ' '.join(str(value or '').split()).strip()
            if value and value not in values:
                values.append(value)
        return values

    @staticmethod
    def _semantic_score(targets: list[str], values: list[str]) -> int:
        score = 0
        for target in targets:
            for value in values:
                if value == target:
                    return 93
                if value.startswith(f'{target}：') or value.startswith(f'{target}:'):
                    score = max(score, 91)
                elif target in value and len(value) <= len(target) + 24:
                    score = max(score, 86)
        return score

    @staticmethod
    def _starts_with_target(targets: list[str], values: list[str]) -> bool:
        return any(
            value == target or value.startswith(f'{target}：') or value.startswith(f'{target}:')
            for target in targets
            for value in values
        )

    @staticmethod
    def _is_value_node(node) -> bool:
        value = ' '.join(str(node.text or node.name or '').split()).strip()
        if not value or len(value) > 180:
            return False
        return not any(child in value for child in ('请输入', '请选择'))

    @classmethod
    def _match_selected_card_title(cls, scored: dict, context, snapshot, children: dict) -> None:
        if not cls._is_selected_card_title_request(context):
            return
        node_by_ref = {node.ref: node for node in snapshot.nodes}
        root_refs = cls._selected_card_roots(snapshot, node_by_ref)
        if not root_refs:
            return
        title_nodes = []
        for node in snapshot.nodes:
            if not cls._has_selected_ancestor(node, root_refs, node_by_ref):
                continue
            value = ' '.join(str(node.text or node.name or '').split()).strip()
            if not cls._is_card_title_value(value, bool(children.get(node.ref))):
                continue
            title_nodes.append(node)
        if title_nodes:
            node = min(title_nodes, key=lambda item: item.order)
            role_bonus = 3 if node.role == 'heading' else 0
            cls._add(scored, node.ref, min(96, 91 + role_bonus),
                     'title text inside the currently selected card')

    @classmethod
    def _match_selected_card_applicant(cls, scored: dict, context, snapshot, children: dict) -> None:
        if not cls._is_selected_card_applicant_request(context):
            return
        node_by_ref = {node.ref: node for node in snapshot.nodes}
        root_refs = cls._selected_card_roots(snapshot, node_by_ref)
        if not root_refs:
            return
        descendants = [
            node for node in snapshot.nodes
            if cls._has_selected_ancestor(node, root_refs, node_by_ref)
        ]
        markers = [
            node for node in descendants
            if '流程类型' in ' '.join(str(node.text or node.name or '').split())
        ]
        if not markers:
            return
        marker = min(markers, key=lambda item: len(' '.join(str(item.text or item.name or '').split())))
        marker_value = ' '.join(str(marker.text or marker.name or '').split()).strip(' ：:')
        leaf_nodes = [
            node for node in descendants
            if node.order > marker.order and not children.get(node.ref)
        ]
        distinct_nodes = []
        seen_values = set()
        for node in sorted(leaf_nodes, key=lambda item: item.order):
            value = ' '.join(str(node.text or node.name or '').split()).strip()
            if not value or value in seen_values or cls._is_card_metadata_value(value):
                continue
            seen_values.add(value)
            distinct_nodes.append(node)
        if marker_value == '流程类型' and distinct_nodes:
            distinct_nodes = distinct_nodes[1:]
        if distinct_nodes:
            cls._add(
                scored,
                distinct_nodes[0].ref,
                94,
                'applicant value after flow type inside the currently selected card',
            )

    @classmethod
    def _selected_card_roots(cls, snapshot, node_by_ref: dict) -> set[str]:
        selected_refs = {node.ref for node in snapshot.nodes if node.selected is True}
        card_refs = cls._task_card_refs(snapshot, node_by_ref)
        return selected_refs | set(card_refs[:1])

    @classmethod
    def _task_card_refs(cls, snapshot, node_by_ref: dict) -> list[str]:
        matches = []
        for node in snapshot.nodes:
            text = ' '.join(str(node.text or node.name or '').split()).strip()
            if '合同编号' not in text or '流程类型' not in text:
                continue
            if cls._has_task_card_ancestor(node, node_by_ref):
                continue
            matches.append((node.order, node.ref))
        return [ref for _, ref in sorted(matches)]

    @staticmethod
    def _has_task_card_ancestor(node, node_by_ref: dict) -> bool:
        parent_ref = node.parent_ref
        visited = set()
        while parent_ref and parent_ref not in visited:
            visited.add(parent_ref)
            parent = node_by_ref.get(parent_ref)
            if not parent:
                return False
            text = ' '.join(str(parent.text or parent.name or '').split()).strip()
            if '合同编号' in text and '流程类型' in text:
                return True
            parent_ref = parent.parent_ref
        return False

    @staticmethod
    def _is_selected_card_title_request(context) -> bool:
        operation_key = str(getattr(context, 'operation_key', '') or '')
        if operation_key and operation_key not in {'w_get_text', 'w_get_texts'}:
            return False
        text = ' '.join(str(value or '') for value in (
            getattr(context, 'element_name', None), getattr(context, 'prompt', None),
        )).lower()
        if any(word in text for word in ('申请人', '用户名称', '人员名称', '姓名')):
            return False
        return any(word in text for word in ('卡片', '左侧', '选中', '当前')) and any(
            word in text for word in ('title', '标题', '名称')
        )

    @staticmethod
    def _is_selected_card_applicant_request(context) -> bool:
        operation_key = str(getattr(context, 'operation_key', '') or '')
        if operation_key and operation_key not in {'w_get_text', 'w_get_texts'}:
            return False
        text = ' '.join(str(value or '') for value in (
            getattr(context, 'element_name', None), getattr(context, 'prompt', None),
        ))
        return any(word in text for word in ('申请人', '用户名称', '人员名称', '姓名')) and any(
            word in text for word in ('卡片', '左侧', '选中', '当前', '流程类型')
        )

    @staticmethod
    def _has_selected_ancestor(node, selected_refs: set[str], node_by_ref: dict) -> bool:
        parent_ref = node.parent_ref
        visited = set()
        while parent_ref and parent_ref not in visited:
            if parent_ref in selected_refs:
                return True
            visited.add(parent_ref)
            parent = node_by_ref.get(parent_ref)
            parent_ref = parent.parent_ref if parent else None
        return False

    @staticmethod
    def _is_card_title_value(value: str, has_children: bool) -> bool:
        if not value or len(value) > 120 or has_children:
            return False
        excluded = ('合同编号', '流程类型', '节点：', '节点:', '申请人', '提交于')
        return not any(word in value for word in excluded)

    @staticmethod
    def _is_card_metadata_value(value: str) -> bool:
        return any(word in value for word in (
            '合同编号', '节点：', '节点:', '流程类型', '天前到达', '小时前到达',
            '分钟前到达', '测试组验证',
        ))

    @staticmethod
    def _add(scored: dict, ref: str, score: int, reason: str) -> None:
        current = scored.get(ref)
        row = (score, ref, reason)
        if current is None or score > current[0]:
            scored[ref] = row
