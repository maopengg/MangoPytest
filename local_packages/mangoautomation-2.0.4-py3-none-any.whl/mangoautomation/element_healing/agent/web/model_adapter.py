# -*- coding: utf-8 -*-
from openai import AsyncOpenAI, DefaultAsyncHttpxClient, DefaultHttpxClient, OpenAI

from ...policy.thresholds import AGENT_TIMEOUT_SECONDS


class OpenAICompatibleModelClient:
    def __init__(self, api_key: str, base_url: str, model: str, timeout: int | None = None):
        self.model_name = model
        try:
            configured_timeout = float(timeout) if timeout else AGENT_TIMEOUT_SECONDS
        except (TypeError, ValueError):
            configured_timeout = AGENT_TIMEOUT_SECONDS
        self.timeout_seconds = max(1.0, min(configured_timeout, AGENT_TIMEOUT_SECONDS))
        kwargs = {'api_key': api_key, 'base_url': base_url, 'timeout': self.timeout_seconds}
        self.client = OpenAI(
            **kwargs,
            http_client=DefaultHttpxClient(trust_env=False, timeout=self.timeout_seconds),
        )
        self.async_client = AsyncOpenAI(
            **kwargs,
            http_client=DefaultAsyncHttpxClient(trust_env=False, timeout=self.timeout_seconds),
        )
        self._response_format_mode = 'json_schema'

    async def complete_async(self, messages: list[dict], *, max_tokens: int, temperature: float,
                             response_format: dict | None = None) -> str:
        kwargs = self._completion_kwargs(messages, max_tokens, temperature, response_format)
        try:
            response = await self.async_client.chat.completions.create(**kwargs)
        except Exception as error:
            if not self._can_fallback_to_json_object(error, response_format):
                raise
            self._response_format_mode = 'json_object'
            kwargs['response_format'] = {'type': 'json_object'}
            response = await self.async_client.chat.completions.create(**kwargs)
        return response.choices[0].message.content if response.choices else ''

    def complete_sync(self, messages: list[dict], *, max_tokens: int, temperature: float,
                      response_format: dict | None = None) -> str:
        kwargs = self._completion_kwargs(messages, max_tokens, temperature, response_format)
        try:
            response = self.client.chat.completions.create(**kwargs)
        except Exception as error:
            if not self._can_fallback_to_json_object(error, response_format):
                raise
            self._response_format_mode = 'json_object'
            kwargs['response_format'] = {'type': 'json_object'}
            response = self.client.chat.completions.create(**kwargs)
        return response.choices[0].message.content if response.choices else ''

    def _completion_kwargs(self, messages: list[dict], max_tokens: int, temperature: float,
                           response_format: dict | None) -> dict:
        kwargs = {
            'model': self.model_name,
            'messages': messages,
            'temperature': temperature,
            'max_tokens': max_tokens,
        }
        if response_format:
            kwargs['response_format'] = (
                {'type': 'json_object'}
                if self._response_format_mode == 'json_object'
                else response_format
            )
        return kwargs

    def _can_fallback_to_json_object(self, error: Exception, response_format: dict | None) -> bool:
        if not response_format or self._response_format_mode != 'json_schema':
            return False
        if getattr(error, 'status_code', None) not in (400, 404, 422):
            return False
        message = str(error).lower()
        return any(value in message for value in (
            'response_format', 'json_schema', 'json schema', 'structured output',
        ))
