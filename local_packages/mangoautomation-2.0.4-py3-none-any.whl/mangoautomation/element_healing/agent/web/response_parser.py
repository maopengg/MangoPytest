# -*- coding: utf-8 -*-
from pydantic import ValidationError

from .response_schema import WebLocatorAgentResponse, WebLocatorCandidatePayload


class AgentResponseSchemaError(ValueError):
    pass


class AgentResponseParser:
    @staticmethod
    def parse(content: str) -> list[WebLocatorCandidatePayload]:
        content = str(content or '').strip()
        try:
            value = WebLocatorAgentResponse.model_validate_json(content)
        except ValidationError as error:
            details = []
            for item in error.errors(include_input=False)[:5]:
                location = '.'.join(str(value) for value in item.get('loc') or ()) or 'response'
                details.append(f'{location}:{item.get("type", "invalid")}')
            summary = ', '.join(details) or 'invalid response'
            raise AgentResponseSchemaError(f'Agent响应不符合Schema：{summary}') from None
        return value.candidates
