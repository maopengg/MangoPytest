# -*- coding: utf-8 -*-
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


SCHEMA_VERSION = 'snapshot-ref-v3'
RESPONSE_SCHEMA_NAME = 'web_snapshot_ref_candidates'


class WebLocatorCandidatePayload(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)

    source: Literal['ai_accessibility']
    target_ref: str = Field(pattern=r'^e[1-9]\d*$')
    reason: str = Field(min_length=1, max_length=300)
    confidence: int = Field(ge=0, le=100)


class WebLocatorAgentResponse(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)

    schema_version: Literal[SCHEMA_VERSION]
    candidates: list[WebLocatorCandidatePayload] = Field(max_length=5)

    @classmethod
    def openai_response_format(cls) -> dict:
        return {
            'type': 'json_schema',
            'json_schema': {
                'name': RESPONSE_SCHEMA_NAME,
                'strict': True,
                'schema': cls.model_json_schema(),
            },
        }
