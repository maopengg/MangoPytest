# -*- coding: utf-8 -*-
import json

from ...baseline import sanitize_json_value
from .response_schema import SCHEMA_VERSION, WebLocatorAgentResponse

PROMPT_VERSION = 'web-snapshot-ref-v3'


class WebLocatorPrompt:
    @staticmethod
    def build(context, memory: dict, snapshot) -> str:
        snapshots = memory.get('snapshots') or []
        snapshot_summary = [{
            'role': item.get('element_role'),
            'name': item.get('element_name'),
            'text': item.get('element_text'),
            'placeholder': item.get('element_placeholder'),
            'attributes': item.get('element_attributes'),
        } for item in snapshots[:3]]
        payload = {
            'task': 'Select exact target element refs from the current accessibility snapshot',
            'prompt_version': PROMPT_VERSION,
            'schema_version': SCHEMA_VERSION,
            'target': {
                'name': context.element_name,
                'category': context.category,
                'prompt': context.prompt,
                'target_texts': context.expected_semantics.target_texts,
                'operation_key': context.operation_key,
            },
            'failed_locators': [item.loc for item in context.failed_locators][-10:],
            'baseline_snapshots': snapshot_summary,
            'accessibility_snapshot': {
                'snapshot_id': snapshot.snapshot_id,
                'page_url': snapshot.page_url,
                'tree': snapshot.tree,
                'nodes': snapshot.prompt_nodes(160),
            },
            'output_contract': WebLocatorAgentResponse.model_json_schema(),
            'rules': [
                'Return target_ref values that exist verbatim in accessibility_snapshot',
                'Never invent a ref and never return a locator expression',
                'Use role, accessible name, label, nearby_text, path, and operation_key together',
                'Descriptions such as left-side current name refer to the selected/current card; use '
                'selected state and nearby card structure instead of requiring literal prompt text',
                'For custom controls select the actual interactive node near its visible label',
                'For input operations select the editable control, never a descriptive label',
                'For click operations prefer the direct control; a unique visible text node is allowed '
                'only when its node or clickable ancestor represents the requested target',
                'If no snapshot node is sufficiently supported, return an empty candidates list',
                'Return exactly one JSON object matching output_contract without markdown or explanation',
            ],
        }
        return json.dumps(sanitize_json_value(payload), ensure_ascii=False)
