# -*- coding: utf-8 -*-
from ...snapshot import AccessibilitySnapshotBuilder


class WebAgentContextBuilder:
    @staticmethod
    async def build_async(page, limit: int = 160):
        return await AccessibilitySnapshotBuilder.build_async(page, limit)

    @staticmethod
    def build_sync(page, limit: int = 160):
        return AccessibilitySnapshotBuilder.build_sync(page, limit)
