# -*- coding: utf-8 -*-
from ...candidates.base import deduplicate
from ...models import CandidateSource, LocatorCandidate
from ...policy import MAX_AGENT_CANDIDATES
from ...snapshot import DurableLocatorGenerator
from .response_schema import SCHEMA_VERSION, WebLocatorCandidatePayload


class AgentCandidateNormalizer:
    @classmethod
    def normalize(cls, rows: list[WebLocatorCandidatePayload],
                  snapshot, failed_locators: list[str], *, generated_by_ai: bool = True,
                  selection_strategy: str = 'model') -> list[LocatorCandidate]:
        result = []
        for row in rows[:MAX_AGENT_CANDIDATES]:
            if not isinstance(row, WebLocatorCandidatePayload):
                raise TypeError('Agent候选必须先通过响应Schema校验')
            node = snapshot.node_by_ref(row.target_ref)
            if not node:
                continue
            parent = snapshot.node_by_ref(node.parent_ref) if node.parent_ref else None
            durable_values = DurableLocatorGenerator.build_all(
                node, snapshot.nodes, MAX_AGENT_CANDIDATES - len(result),
            )
            for index, durable in enumerate(durable_values):
                result.append(LocatorCandidate(
                    source=CandidateSource.ACCESSIBILITY_AGENT,
                    initial_score=max(0, row.confidence - index * 3),
                    exp=durable.exp,
                    loc=durable.loc,
                    sub=durable.sub,
                    reason=row.reason,
                    generated_by_ai=generated_by_ai,
                    metadata={
                        'agent_schema_validated': generated_by_ai,
                        'snapshot_matcher_validated': not generated_by_ai,
                        'snapshot_selection_strategy': selection_strategy,
                        'agent_schema_version': SCHEMA_VERSION,
                        'snapshot_ref_resolved': True,
                        'accessibility_snapshot_id': snapshot.snapshot_id,
                        'target_ref': node.ref,
                        'snapshot_frame_index': node.frame_index,
                        'snapshot_frame_url': node.frame_url,
                        'snapshot_node_role': node.role,
                        'snapshot_node_name': node.name,
                        'snapshot_node_text': node.text,
                        'snapshot_node_label': node.label,
                        'snapshot_node_nearby_text': node.nearby_text,
                        'snapshot_node_path': node.path,
                        'snapshot_parent_name': parent.name if parent else '',
                        'snapshot_parent_text': parent.text if parent else '',
                        'snapshot_parent_label': parent.label if parent else '',
                        'snapshot_parent_nearby_text': parent.nearby_text if parent else '',
                        'durable_locator_strategy': durable.strategy,
                    },
                ))
                if len(result) >= MAX_AGENT_CANDIDATES:
                    break
            if len(result) >= MAX_AGENT_CANDIDATES:
                break
        return deduplicate(result, failed_locators)
