# -*- coding: utf-8 -*-
from pydantic import BaseModel, Field

from .enums import HealingTrigger


class FailedLocator(BaseModel):
    exp: int | None = None
    loc: str
    sub: int | None = None


class ElementSemantics(BaseModel):
    target_texts: list[str] = Field(default_factory=list)
    role: str | None = None
    accessible_name: str | None = None
    placeholder: str | None = None


class HealingContext(BaseModel):
    trace_id: str
    element_id: int | None = None
    element_name: str | None = None
    category: str | None = None
    prompt: str | None = None
    test_env: int | None = None
    operation_key: str | None = None
    operation_type: int | None = None
    origin_exp: int | None = None
    origin_loc: str | None = None
    origin_sub: int | None = None
    page_url: str | None = None
    page_title: str | None = None
    failed_locators: list[FailedLocator] = Field(default_factory=list)
    trigger: HealingTrigger = HealingTrigger.LOCATOR_EXCEPTION
    trigger_error: str | None = None
    expected_semantics: ElementSemantics = Field(default_factory=ElementSemantics)
