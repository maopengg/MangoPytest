# -*- coding: utf-8 -*-
from uuid import uuid4

from pydantic import BaseModel, Field

from .enums import CandidateSource


class LocatorCandidate(BaseModel):
    candidate_id: str = Field(default_factory=lambda: uuid4().hex)
    source: CandidateSource | str
    exp: int
    loc: str
    sub: int | None = None
    reason: str = ''
    initial_score: float = 0
    snapshot_id: int | None = None
    heal_record_id: int | None = None
    generated_by_ai: bool = False
    metadata: dict = Field(default_factory=dict)

    def to_runtime_dict(self) -> dict:
        source = self.source.value if isinstance(self.source, CandidateSource) else str(self.source)
        return {
            'candidate_id': self.candidate_id,
            'source': source,
            'score': self.initial_score,
            'exp': self.exp,
            'loc': self.loc,
            'sub': self.sub,
            'reason': self.reason,
            'snapshot_id': self.snapshot_id,
            'heal_record_id': self.heal_record_id,
            'used_ai': self.generated_by_ai,
            **self.metadata,
        }

