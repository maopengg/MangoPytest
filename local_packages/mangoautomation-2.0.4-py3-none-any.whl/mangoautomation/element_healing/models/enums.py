# -*- coding: utf-8 -*-
from enum import Enum


class HealingTrigger(str, Enum):
    LOCATOR_EXCEPTION = 'locator_exception'
    ZERO_MATCH = 'zero_match'
    AMBIGUOUS_MATCH = 'ambiguous_match'
    SEMANTIC_MISMATCH = 'semantic_mismatch'
    NOT_ACTIONABLE = 'not_actionable'
    RECOVERABLE_OPERATION_ERROR = 'recoverable_operation_error'


class CandidateSource(str, Enum):
    APPLIED_HEAL_RECORD = 'applied_heal_record'
    LATEST_SNAPSHOT_LOCATOR = 'latest_snapshot_locator'
    HISTORY_SNAPSHOT_LOCATOR = 'history_snapshot_locator'
    BASELINE_SEMANTIC = 'baseline_semantic'
    DOM_LABEL = 'playwright_label'
    DOM_ROLE = 'playwright_role'
    DOM_TEXT = 'playwright_text_sub'
    DOM_PROXIMITY = 'dom_proximity'
    PROMPT_TEXT = 'prompt_text_candidate'
    ACCESSIBILITY_AGENT = 'ai_accessibility'


class HealingStatus(str, Enum):
    NOT_TRIGGERED = 'not_triggered'
    REJECTED = 'rejected'
    SUGGESTED = 'suggested'
    TEMPORARY_HEAL = 'temporary_heal'
    AUTO_APPLY = 'auto_apply'

