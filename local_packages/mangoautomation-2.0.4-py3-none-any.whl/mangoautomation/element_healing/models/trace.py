# -*- coding: utf-8 -*-
from datetime import datetime

from pydantic import BaseModel, Field

from .decision import HealingDecision


class TraceStage(BaseModel):
    name: str
    duration_ms: int = 0
    candidate_count: int = 0
    error: str | None = None


class HealingTrace(BaseModel):
    trace_id: str
    element_id: int | None = None
    trigger: str
    started_at: datetime = Field(default_factory=datetime.now)
    duration_ms: int = 0
    stages: list[TraceStage] = Field(default_factory=list)
    candidates: list[dict] = Field(default_factory=list)
    reject_reasons: list[str] = Field(default_factory=list)
    agent_called: bool = False
    agent_circuit_breaker: dict = Field(default_factory=dict)
    model: str | None = None
    prompt_version: str | None = None
    schema_version: str | None = None
    decision: HealingDecision | None = None
