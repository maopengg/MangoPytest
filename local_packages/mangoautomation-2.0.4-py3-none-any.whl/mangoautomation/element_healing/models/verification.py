# -*- coding: utf-8 -*-
from pydantic import BaseModel, Field

from .candidate import LocatorCandidate


class VerificationResult(BaseModel):
    candidate: LocatorCandidate
    valid: bool
    count: int = 0
    visible: bool | None = None
    enabled: bool | None = None
    editable: bool | None = None
    text: str | None = None
    attributes: dict = Field(default_factory=dict)
    bounding_box: dict | None = None
    semantic_score: float = 0
    stability_score: float = 0
    operation_compatible: bool = False
    auto_apply_operation_compatible: bool = False
    consecutive_passes: int = 0
    stable_context: bool = False
    auto_apply_eligible: bool = False
    final_score: float = 0
    reject_code: str | None = None
    reject_reason: str | None = None
    duration_ms: int = 0
