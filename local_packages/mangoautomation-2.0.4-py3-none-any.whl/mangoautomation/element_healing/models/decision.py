# -*- coding: utf-8 -*-
from pydantic import BaseModel, Field

from .enums import HealingStatus
from .verification import VerificationResult


class HealingDecision(BaseModel):
    status: HealingStatus
    selected: VerificationResult | None = None
    should_retry_operation: bool = False
    should_save_record: bool = False
    should_refresh_baseline: bool = False
    reasons: list[str] = Field(default_factory=list)

