# -*- coding: utf-8 -*-
from typing import Any

from pydantic import BaseModel


class MethodModel(BaseModel):
    f: str
    n: str | None = None
    p: str | None = None
    d: bool = False
    v: Any = None
    value_type: str | None = None
    input_type: str | None = None
