# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-05-28 18:40
# @Author : 毛鹏

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

from mangoautomation.enums import ElementOperationEnum
from mangoautomation.models._base_model import MethodModel
from mangotools.database import DatabaseConnectionConfig


class ExtraAllowModel(BaseModel):
    model_config = ConfigDict(extra='allow')


class Position(BaseModel):
    x: int
    y: int


class Connector(BaseModel):
    node_id: str
    position: str


class UINode(BaseModel):
    id: str
    position: Position
    type: int
    label: str
    config: dict


class UIEdge(BaseModel):
    id: str
    source: Connector
    target: Connector


class FlowData(BaseModel):
    nodes: list[UINode]
    edges: list[UIEdge]


class EnvironmentConfigModel(BaseModel):
    id: int
    test_object_value: str
    db_c_status: bool
    db_rud_status: bool
    mysql_config: DatabaseConnectionConfig | None = None
    database_connections: list[dict] = []


class ElementListModel(BaseModel):
    exp: int
    loc: str
    sub: int | None = None
    is_iframe: int | None = None
    prompt: str | None = None
    slot: int | None = None
    is_placeholder: bool = False


class ElementModel(BaseModel):
    id: int
    element_id: int | None = None
    type: ElementOperationEnum
    name: str | None
    category: str | None = None
    ai_heal_status: int = 0
    collect_snapshot: bool = False
    elements: list[ElementListModel] = []
    sleep: int | None
    ope_key: str | None
    ope_value: list[MethodModel] = []
    sql_execute: list[dict] | None = None
    custom: list[dict] | None = None
    condition_value: dict | None = None
    func: str | None = None


class ElementListResultModel(BaseModel):
    loc: str | None = None
    exp: int | None = None
    ele_quantity: int = 0
    element_text: str | None = None
    text_snippets: list[str] = []
    visible: bool | None = None
    enabled: bool | None = None
    editable: bool | None = None
    bounding_box: dict | None = None
    locate_duration_ms: int | None = None
    sub: int | None = None
    is_iframe: int | None


class ElementResultModel(BaseModel):
    _baseline_snapshot: dict = PrivateAttr(default_factory=dict)

    id: int
    name: str | None = None
    sleep: int | None = None

    type: int
    ope_key: str | None = None
    ope_value: list[MethodModel] | None = None
    sql_execute: list[dict] | None = None
    custom: list[dict] | None = None
    condition_value: dict | None = None
    ass_msg: str | None = None
    test_time: str | None = None
    stop_time: str | None = None
    duration_ms: int | None = None
    page_url: str | None = None
    page_title: str | None = None
    viewport: dict | None = None

    elements: list[ElementListResultModel] = []
    status: int = 0
    error_message: str | None = None
    picture_path: str | None = None
    picture_name: str | None = None
    locator_engine: dict = {}

    next_node_id: int | None = None


class UiPublicModel(BaseModel):
    type: int
    key: str
    value: str
    datasource_alias: int | None = None
    db_type: int | None = None
    mysql_config: DatabaseConnectionConfig | None = None


class RecordingModel(BaseModel):
    url_list: list[dict]


class StepsDataModel(BaseModel):
    type: int
    ope_key: str | None = None
    page_step_details_id: int
    page_step_details_data: list | None = None
    page_step_details_name: str | None = None
    condition_value: dict | None = None


class UiFlowRuntimeNode(BaseModel):
    id: int
    type: int | None = None
    children: list['UiFlowRuntimeNode'] = Field(default_factory=list)


class UiStepControlModel(BaseModel):
    close_after_execution: bool = False
    before_wait_seconds: int = Field(default=0, ge=0, le=3600)
    after_wait_seconds: int = Field(default=0, ge=0, le=3600)
    close_live_after_execution: bool = True


class UiCaseFrontCustomItem(BaseModel):
    key: str = ''
    value: Any = ''
    test_envs: list[int] | None = Field(default_factory=list)


class UiCaseFrontSqlItem(BaseModel):
    sql: Any = ''
    key_list: str | list[str] | None = ''
    datasource_alias: int | None = None
    test_envs: list[int] = Field(default_factory=list)


class UiCasePosteriorSqlItem(BaseModel):
    sql: Any = ''
    datasource_alias: int | None = None
    test_envs: list[int] = Field(default_factory=list)


class UiAuthCookieModel(BaseModel):
    name: str
    value: str
    domain: str | None = None
    path: str = '/'
    expires: int | float | None = None
    httpOnly: bool = False
    secure: bool = False
    sameSite: str | None = None


class UiAuthStorageItem(BaseModel):
    origin: str
    key: str
    value: str = ''


class UiAuthStorageStateOrigin(ExtraAllowModel):
    origin: str
    localStorage: list[dict] = []


class UiAuthStorageState(ExtraAllowModel):
    cookies: list[UiAuthCookieModel] = Field(default_factory=list)
    origins: list[UiAuthStorageStateOrigin] = Field(default_factory=list)


class PageStepsModel(BaseModel):
    id: int
    name: str
    project_product: int
    project_product_name: str
    module_name: str
    test_env: int | None = None
    type: int
    url: str
    switch_step_open_url: bool
    error_retry: int | None = None
    element_list: list[ElementModel] | ElementModel = []
    environment_config: EnvironmentConfigModel
    public_data_list: list[UiPublicModel] = []
    flow_data: UiFlowRuntimeNode | None = None
    step_control: UiStepControlModel = Field(default_factory=UiStepControlModel)
    is_auth_step: bool = False


class UiAuthCacheModel(BaseModel):
    cookies: list[UiAuthCookieModel] = Field(default_factory=list)
    local_storage: list[UiAuthStorageItem] = Field(default_factory=list)
    session_storage: list[UiAuthStorageItem] = Field(default_factory=list)
    headers: dict[str, str] = Field(default_factory=dict)
    storage_state: UiAuthStorageState | None = None


class CasePageStepsModel(PageStepsModel):
    execution_id: str | None = None
    case_steps_id: int | None = None
    case_data: list[StepsDataModel] = []


class DebugPageStepsModel(PageStepsModel):
    send_user: str | None = None
    ui_auth_cache: UiAuthCacheModel | None = None
    workspace_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None


class UiElementCheckModel(DebugPageStepsModel):
    check_id: str
    send_user: str
    check_mode: str = 'normal'


class UiElementCheckResultModel(BaseModel):
    workspace_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    check_id: str
    check_mode: str = 'normal'
    element_id: int
    element_name: str
    test_env: int | None = None
    status: int = 0
    check_status: str = 'invalid'
    error_message: str | None = None
    page_url: str | None = None
    page_title: str | None = None
    duration_ms: int | None = None
    checked_time: str | None = None
    locator_groups: list[dict] = Field(default_factory=list)
    selected_result: ElementResultModel | None = None
    expected_event_result: dict = Field(default_factory=dict)
    baseline: dict = Field(default_factory=dict)


class UiAutoAuthModel(BaseModel):
    config_id: int
    url: str | None = None
    origin: str | None = None
    cookie_domains: list[str] = []
    local_storage_keys: list[str] = []
    session_storage_keys: list[str] = []
    headers: dict = {}
    timeout: int = 300
    send_user: str | None = None


class CaseModel(BaseModel):
    execution_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    send_user: str
    test_suite_details: int | None
    test_suite_id: int | None
    id: int
    name: str
    project_product: int
    project_product_name: str
    module_name: str
    test_env: int
    case_people: str
    front_custom: list[UiCaseFrontCustomItem]
    front_sql: list[UiCaseFrontSqlItem]
    posterior_sql: list[UiCasePosteriorSqlItem]
    parametrize: list[dict] | list
    data_factory_cache_data: dict = {}
    data_factory_execution_ids: list[int] = []
    data_factory_auto_cleanup_execution_ids: list[int] = []
    gray_config_ids: list[int] = []
    gray_execution_log_ids: list[int] = []
    ui_auth_cache: UiAuthCacheModel | None = None
    steps: list[CasePageStepsModel]


class PageStepsResultModel(BaseModel):
    execution_id: str | None = None
    progress_sequence: int = 0
    workspace_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    id: int
    name: str
    type: int
    project_product_id: int
    project_product_name: str
    test_env: int | None = None
    case_step_details_id: int | None = None
    test_time: str | None = None
    stop_time: str | None = None

    cache_data: dict
    data_factory_cache_data: dict = {}
    test_object: str
    is_auth_step: bool = False
    is_final: bool = False

    status: int
    error_message: str | None = None
    element_result_list: list[ElementResultModel] | Any = []


class UiCaseResultModel(BaseModel):
    execution_id: str | None = None
    slot_id: str | None = None
    executor_connection_id: str | None = None
    id: int
    name: str
    project_product_id: int
    project_product_name: str
    module_name: str
    test_env: int
    status: int
    test_time: str | None = None
    stop_time: str | None = None
    error_message: str | None = None
    video_path: str | None = None
    data_factory_cache_data: dict = {}
    data_factory_execution_ids: list[int] = []
    data_factory_auto_cleanup_execution_ids: list[int] = []
    gray_config_ids: list[int] = []
    gray_execution_log_ids: list[int] = []
    steps: list[PageStepsResultModel] = []
