# -*- coding: utf-8 -*-
from dataclasses import dataclass


@dataclass(frozen=True)
class ElementRetryPolicy:
    """UI element retry timing shared by sync and async drivers."""

    # 4010 表示浏览器上下文已经不存在。继续重试定位无法恢复设备，只会让
    # 每个定位组按重试窗口反复打印“Web设备未初始化”。应立即交给上层重建浏览器。
    non_retryable_error_codes = frozenset({4010, 4015, 4048, 4051, 4054, 4056})

    fixed_retry_seconds: float = 25
    healing_fixed_retry_seconds: float = 15
    healing_start_seconds: float = 5
    minimum_locator_attempts: int = 2
    retry_interval_seconds: float = 0.5

    def should_start_healing(self, elapsed: float, attempt_counts: list[int]) -> bool:
        return (
            elapsed >= self.healing_start_seconds
            and bool(attempt_counts)
            and all(count >= self.minimum_locator_attempts for count in attempt_counts)
        )

    def should_retry(self, error: Exception) -> bool:
        """Only transient element failures should consume the retry window."""
        return getattr(error, 'code', None) not in self.non_retryable_error_codes


DEFAULT_ELEMENT_RETRY_POLICY = ElementRetryPolicy()
