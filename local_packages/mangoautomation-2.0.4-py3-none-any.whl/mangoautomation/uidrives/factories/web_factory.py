# -*- coding: utf-8 -*-
from mangoautomation.uidrives.runtime import AsyncWebRuntime, SyncWebRuntime


class WebDriverFactory:
    @staticmethod
    def create_async_runtime(**kwargs) -> AsyncWebRuntime:
        return AsyncWebRuntime(**kwargs)

    @staticmethod
    def create_sync_runtime(**kwargs) -> SyncWebRuntime:
        return SyncWebRuntime(**kwargs)
