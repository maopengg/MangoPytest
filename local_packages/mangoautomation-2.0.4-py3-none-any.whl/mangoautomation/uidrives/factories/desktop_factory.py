# -*- coding: utf-8 -*-
from mangoautomation.uidrives.runtime import DesktopRuntime


class WindowsDriverFactory:
    @staticmethod
    def create_runtime(win_path: str, win_title: str, log=None) -> DesktopRuntime:
        return DesktopRuntime(win_path, win_title, log=log)
