# -*- coding: utf-8 -*-
from mangoautomation.uidrives.runtime import AndroidRuntime


class AndroidDriverFactory:
    @staticmethod
    def create_runtime(equipment: str) -> AndroidRuntime:
        return AndroidRuntime(equipment)
