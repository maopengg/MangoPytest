# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2026-06-04 12:00
# @Author : 毛鹏
import ctypes
import os
import platform
import shutil
import string
from pathlib import Path

from mangoautomation.enums import BrowserTypeEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0055


WINDOWS_BROWSER_FILES = {
    BrowserTypeEnum.CHROMIUM.value: 'chrome.exe',
    BrowserTypeEnum.EDGE.value: 'msedge.exe',
    BrowserTypeEnum.FIREFOX.value: 'firefox.exe',
}

MACOS_BROWSER_APPS = {
    BrowserTypeEnum.CHROMIUM.value: [
        ('Google Chrome.app', 'Google Chrome'),
        ('Google Chrome for Testing.app', 'Google Chrome for Testing'),
        ('Chromium.app', 'Chromium'),
    ],
    BrowserTypeEnum.EDGE.value: [
        ('Microsoft Edge.app', 'Microsoft Edge'),
    ],
    BrowserTypeEnum.FIREFOX.value: [
        ('Firefox.app', 'firefox'),
    ],
}

LINUX_BROWSER_BINARIES = {
    BrowserTypeEnum.CHROMIUM.value: [
        'google-chrome',
        'google-chrome-stable',
        'chromium',
        'chromium-browser',
    ],
    BrowserTypeEnum.EDGE.value: [
        'microsoft-edge',
        'microsoft-edge-stable',
    ],
    BrowserTypeEnum.FIREFOX.value: [
        'firefox',
    ],
}


def find_browser_path(web_type: int, log=None) -> str | None:
    _debug(log, '[路径搜索] 开始自动搜索浏览器可执行文件')
    system = platform.system()
    if system == 'Windows':
        browser_path = _search_windows_browser_path(web_type, log)
    elif system == 'Darwin':
        browser_path = _search_macos_browser_path(web_type, log)
    elif system == 'Linux':
        browser_path = _search_linux_browser_path(web_type, log)
    else:
        browser_path = None

    if browser_path:
        _debug(log, f'[路径搜索] 找到浏览器: {browser_path}')
        return browser_path

    _debug(log, '[路径搜索] 未找到系统浏览器，将使用Playwright默认浏览器')
    return None


def search_browser_path(web_type: int, log=None) -> str:
    browser_path = find_browser_path(web_type, log)
    if browser_path:
        return browser_path
    _error(log, '[路径搜索失败] 未找到浏览器可执行文件')
    raise MangoAutomationError(*ERROR_MSG_0055)


def _search_windows_browser_path(web_type: int, log=None) -> str | None:
    target_file = WINDOWS_BROWSER_FILES.get(web_type)
    _debug(log, f'[路径搜索] 目标文件: {target_file}')
    if not target_file:
        return None

    drives = []
    for letter in string.ascii_uppercase:
        drive = f'{letter}:\\'
        if ctypes.windll.kernel32.GetDriveTypeW(drive) == 3:
            drives.append(drive)

    _debug(log, f'[路径搜索] 检测到可用磁盘: {drives}')
    for drive in drives:
        for root, dirs, files in os.walk(drive):
            if target_file in files:
                return os.path.join(root, target_file)
    return None


def _search_macos_browser_path(web_type: int, log=None) -> str | None:
    candidates = _macos_browser_candidates(web_type)
    _debug(log, f'[路径搜索] macOS候选路径: {candidates}')
    for browser_path in candidates:
        if os.path.exists(browser_path):
            return browser_path
    return None


def _macos_browser_candidates(web_type: int) -> list[str]:
    application_dirs = [Path('/Applications'), Path.home() / 'Applications']
    candidates: list[str] = []
    for app_name, executable_name in MACOS_BROWSER_APPS.get(web_type, []):
        for application_dir in application_dirs:
            candidates.append(str(application_dir / app_name / 'Contents' / 'MacOS' / executable_name))
    return candidates


def _search_linux_browser_path(web_type: int, log=None) -> str | None:
    candidates = LINUX_BROWSER_BINARIES.get(web_type, [])
    _debug(log, f'[路径搜索] Linux候选命令: {candidates}')
    for binary in candidates:
        browser_path = shutil.which(binary)
        if browser_path:
            return browser_path
    return None


def _debug(log, message: str):
    if log:
        log.debug(message)


def _error(log, message: str):
    if log:
        log.error(message)
