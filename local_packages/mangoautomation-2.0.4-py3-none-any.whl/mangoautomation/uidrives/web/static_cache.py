# -*- coding: utf-8 -*-
import hashlib
import json
import mimetypes
import os
import time
from pathlib import Path
from typing import Optional


class StaticResourceCache:
    CACHE_RESOURCE_TYPES = {'script', 'stylesheet', 'font', 'image', 'media'}
    MAX_FILE_SIZE = 50 * 1024 * 1024
    DEFAULT_TTL = 24 * 60 * 60
    META_SUFFIX = '.json'
    BODY_SUFFIX = '.body'

    def __init__(self, cache_path: Optional[str], log=None):
        self.cache_path = Path(cache_path).expanduser() if cache_path else None
        self.log = log
        if self.cache_path:
            self.cache_path.mkdir(parents=True, exist_ok=True)

    @property
    def enabled(self):
        return self.cache_path is not None

    def can_cache_request(self, request):
        if not self.enabled:
            return False
        if request.method.upper() != 'GET':
            return False
        if request.resource_type not in self.CACHE_RESOURCE_TYPES:
            return False
        return request.url.startswith(('http://', 'https://'))

    def cache_files(self, request):
        accept_encoding = request.headers.get('accept-encoding', '')
        cache_key = hashlib.sha256(f'{request.url}|{accept_encoding}'.encode('utf-8')).hexdigest()
        return self.cache_path / f'{cache_key}{self.META_SUFFIX}', self.cache_path / f'{cache_key}{self.BODY_SUFFIX}'

    def read(self, request):
        meta_file, body_file = self.cache_files(request)
        if not meta_file.exists() or not body_file.exists():
            return None
        try:
            meta = json.loads(meta_file.read_text(encoding='utf-8'))
            expires_at = meta.get('expires_at') or 0
            if expires_at and expires_at < time.time():
                self.delete_files(meta_file, body_file)
                return None
            body = body_file.read_bytes()
            headers = meta.get('headers') or {}
            content_type = headers.get('content-type') or mimetypes.guess_type(request.url)[0]
            if content_type:
                headers['content-type'] = content_type
            return {
                'status': meta.get('status') or 200,
                'headers': headers,
                'body': body,
            }
        except Exception as error:
            if self.log:
                self.log.debug(f'[静态资源缓存] 读取缓存失败，已忽略，url={request.url}，详情：{error}')
            self.delete_files(meta_file, body_file)
            return None

    def write(self, request, status, headers, body):
        if status != 200:
            return
        if not body or len(body) > self.MAX_FILE_SIZE:
            return
        cache_control = headers.get('cache-control', '')
        if 'no-store' in cache_control.lower():
            return
        meta_file, body_file = self.cache_files(request)
        expires_at = time.time() + self._ttl(cache_control)
        safe_headers = self._safe_headers(headers)
        meta = {
            'url': request.url,
            'status': status,
            'headers': safe_headers,
            'expires_at': expires_at,
            'created_at': time.time(),
            'size': len(body),
        }
        try:
            tmp_body_file = body_file.with_suffix(f'{body_file.suffix}.tmp')
            tmp_meta_file = meta_file.with_suffix(f'{meta_file.suffix}.tmp')
            tmp_body_file.write_bytes(body)
            tmp_meta_file.write_text(json.dumps(meta, ensure_ascii=False), encoding='utf-8')
            os.replace(tmp_body_file, body_file)
            os.replace(tmp_meta_file, meta_file)
        except Exception as error:
            if self.log:
                self.log.debug(f'[静态资源缓存] 写入缓存失败，已忽略，url={request.url}，详情：{error}')

    def delete_files(self, meta_file, body_file):
        for file in (meta_file, body_file):
            try:
                if file.exists():
                    file.unlink()
            except Exception:
                pass

    def _ttl(self, cache_control):
        for item in cache_control.split(','):
            item = item.strip().lower()
            if item.startswith('max-age='):
                try:
                    return max(0, int(item.split('=', 1)[1]))
                except ValueError:
                    return self.DEFAULT_TTL
        return self.DEFAULT_TTL

    @staticmethod
    def _safe_headers(headers):
        blocked_headers = {
            'content-encoding',
            'content-length',
            'transfer-encoding',
            'connection',
            'keep-alive',
            'proxy-authenticate',
            'proxy-authorization',
            'te',
            'trailer',
            'upgrade',
        }
        return {
            str(key).lower(): str(value)
            for key, value in (headers or {}).items()
            if str(key).lower() not in blocked_headers
        }
