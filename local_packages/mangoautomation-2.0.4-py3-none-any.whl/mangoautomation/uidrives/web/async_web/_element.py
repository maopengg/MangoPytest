# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-04-26 22:22
# @Author : 毛鹏
import asyncio
import json
import os
import re

import time
from playwright.async_api import Error

from mangoautomation.tools import async_method_callback
from mangoautomation.models import MethodModel
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0024, ERROR_MSG_0056, ERROR_MSG_0053
from mangoautomation.tools import Meta
from mangoautomation.uidrives.web.press_key import validate_press_key
from ..highlight import WebElementHighlighter


class AsyncWebElement(metaclass=Meta):
    """元素操作"""

    def __init__(self, base_data):
        self.base_data = base_data

    @staticmethod
    def _parse_json_value(value):
        if not isinstance(value, str):
            return value
        text = value.strip()
        if not text:
            return value
        if text[0] in '[{':
            return json.loads(text)
        return value

    @staticmethod
    def _parse_bool(value):
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {'1', 'true', 'yes', 'y', 'on', '是', '启用', '选中'}
        return bool(value)

    @classmethod
    def _normalize_upload_files(cls, file_path):
        if isinstance(file_path, dict):
            return (
                    file_path.get('local_path') or
                    file_path.get('file_path') or
                    file_path.get('path') or
                    file_path.get('download_url') or
                    file_path.get('file_name') or
                    file_path.get('name')
            )
        if isinstance(file_path, list):
            return [cls._normalize_upload_files(item) for item in file_path]
        return file_path

    @async_method_callback('web', '元素操作', '元素单击', 0, [MethodModel(f='locating')])
    async def w_click(self, locating):
        """元素单击"""
        await locating.first.click()

    @async_method_callback('web', '元素操作', '元素双击', 1, [MethodModel(f='locating')])
    async def w_dblclick(self, locating):
        """元素双击"""
        await locating.first.dblclick()

    @async_method_callback('web', '元素操作', '强制单击', 2, [MethodModel(f='locating')])
    async def w_force_click(self, locating):
        """强制单击"""
        await locating.first.click(force=True)

    @async_method_callback('web', '元素操作', 'JS事件单击', 9, [MethodModel(f='locating')])
    async def w_js_click(self, locating):
        """JS事件单击"""
        await locating.first.dispatch_event('click')

    @async_method_callback('web', '元素操作', '元素输入', 3, [
        MethodModel(f='locating'),
        MethodModel(n='输入内容', f='input_value', p='请输入输入内容', d=True)])
    async def w_input(self, locating, input_value):
        """元素输入"""
        await locating.first.fill(str(input_value))

    @async_method_callback('web', '元素操作', '鼠标悬停', 4, [MethodModel(f='locating')])
    async def w_hover(self, locating):
        """鼠标悬停"""
        await locating.first.hover()
        await asyncio.sleep(1)

    @async_method_callback('web', '元素操作', '获取元素文本', 5, [
        MethodModel(f='locating'),
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入获取元素文本后存储的key', d=True)])
    async def w_get_text(self, locating, set_cache_key=None):
        """获取元素文本"""
        if await locating.count() < 1:
            raise MangoAutomationError(*ERROR_MSG_0053)
        methods = [
            ("inner_text", lambda: locating.first.inner_text(timeout=500)),
            ("text_content", lambda: locating.first.text_content(timeout=500)),
            ("input_value", lambda: locating.first.input_value(timeout=500)),
            ("value", lambda: locating.first.get_attribute("value", timeout=500)),
            ("aria-label", lambda: locating.first.get_attribute("aria-label", timeout=500)),
            ("placeholder", lambda: locating.first.get_attribute("placeholder", timeout=500)),
            ("title", lambda: locating.first.get_attribute("title", timeout=500)),
            ("evaluate", lambda: locating.first.evaluate("el => el.value")),
        ]
        for method_name, method in methods:
            try:
                value = await method()
                if value is not None and str(value).strip() and set_cache_key:
                    self.base_data.test_data.set_cache(key=set_cache_key, value=value)
                    return value
                elif value is not None and str(value).strip():
                    return value
            except Exception:
                continue
        return None

    @async_method_callback('web', '元素操作', '元素清空再输入', 6, [
        MethodModel(f='locating'),
        MethodModel(n='输入文本', f='input_value', p='请输入输入内容', d=True)])
    async def w_clear_input(self, locating, input_value):
        """元素清空再输入"""
        await locating.first.clear()
        await locating.first.fill(str(input_value))

    @async_method_callback('web', '元素操作', '多元素循环单击', 7, [MethodModel(f='locating')])
    async def w_many_click(self, locating):
        """多元素循环单击"""
        await asyncio.sleep(1)
        elements = await locating.all()
        for element in elements:
            await element.click()
            await asyncio.sleep(0.2)

    @async_method_callback('web', '元素操作', '上传文件', 8, [
        MethodModel(f='locating'),
        MethodModel(n='文件名称', f='file_path', p='请输入文件路径，参照帮助文档', d=True)])
    async def w_upload_files(self, locating, file_path):
        """上传文件：定位到 input[type=file] 时直接设置文件，否则点击元素并处理文件选择器"""
        file_path = self._normalize_upload_files(file_path)
        first = locating.first
        direct_input = await self._find_file_input(first)
        if direct_input:
            await direct_input.set_input_files(file_path)
            await self._assert_upload_no_page_error()
            return
        try:
            async with self.base_data.page.expect_file_chooser() as fc_info:
                await first.click()
            file_chooser = await fc_info.value
            await file_chooser.set_files(file_path)
            await self._assert_upload_no_page_error()
        except Error:
            raise MangoAutomationError(*ERROR_MSG_0024)

    async def _assert_upload_no_page_error(self):
        await self.base_data.page.wait_for_timeout(800)
        try:
            text = await self.base_data.page.locator('body').inner_text(timeout=1000)
        except Error:
            return
        error_keywords = (
            'Request failed with status code',
            '服务器错误',
            '上传失败',
            '上传文件失败',
        )
        if not any(keyword in text for keyword in error_keywords):
            return
        trace_match = re.search(r'Trace ID\s*([0-9a-fA-F-]{16,})', text)
        trace_text = f'，Trace ID：{trace_match.group(1)}' if trace_match else ''
        status_match = re.search(r'Request failed with status code\s*(\d+)', text)
        status_text = f'，HTTP状态码：{status_match.group(1)}' if status_match else ''
        raise MangoAutomationError(4024, f'上传文件后页面提示业务上传失败{status_text}{trace_text}')

    async def _find_file_input(self, locating):
        try:
            tag_name = await locating.evaluate("el => (el && el.tagName ? el.tagName.toLowerCase() : '')")
            input_type = await locating.evaluate("el => (el && el.getAttribute ? (el.getAttribute('type') || '').toLowerCase() : '')")
            if tag_name == 'input' and input_type == 'file':
                return locating
        except Error:
            pass
        try:
            child_input = locating.locator('input[type="file"]').first
            if await child_input.count() > 0:
                return child_input
        except Error:
            pass
        try:
            page_input = self.base_data.page.locator('input[type="file"]').first
            if await page_input.count() > 0:
                return page_input
        except Error:
            pass
        return None

    @async_method_callback('web', '元素操作', '下载文件', 10, [
        MethodModel(f='locating'),
        MethodModel(n='存储key值', f='file_key', p='请输入文件存储路径的key，后续通过key获取文件保存的绝对路径',
                    d=True)])
    async def w_download(self, locating, file_key):
        """下载文件"""
        async with self.base_data.page.expect_download() as download_info:
            await locating.first.click()
        download = await download_info.value
        file_name = download.suggested_filename
        save_path = os.path.abspath(os.path.join(self.base_data.download_path, file_name))
        await download.save_as(save_path)
        self.base_data.test_data.set_cache(file_key, save_path)

    @async_method_callback('web', '元素操作', '滚动到元素位置', 20, [
        MethodModel(f='locating')])
    async def w_scroll_to_element(self, locating):
        """滚动到元素位置"""
        await locating.first.scroll_into_view_if_needed()

    @async_method_callback('web', '元素操作', '元素右键点击', 21, [MethodModel(f='locating')])
    async def w_right_click(self, locating):
        """元素右键点击"""
        await locating.first.click(button='right')

    @async_method_callback('web', '元素操作', '循环点击N秒', 22, [
        MethodModel(f='locating'),
        MethodModel(n='点击时间', f='n', p='请输入循环点击的时间', d=True)])
    async def w_time_click(self, locating, n):
        """循环点击N秒"""
        try:
            n = int(n)
        except ValueError:
            raise MangoAutomationError(*ERROR_MSG_0056)
        s = time.time()
        while True:
            await locating.first.click()
            if time.time() - s > n:
                return

    @async_method_callback('web', '元素操作', '往上拖动N个像素', 23, [
        MethodModel(f='locating'),
        MethodModel(n='像素大小', f='n', p='请输入向上像素', d=True)])
    async def w_drag_up_pixel(self, locating, n):
        """往上拖动N个像素"""
        try:
            n = int(n)
        except ValueError:
            raise MangoAutomationError(*ERROR_MSG_0056)

        box = await locating.first.bounding_box()

        if box:
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
            await self.base_data.page.mouse.down()
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2 - n)
            await self.base_data.page.mouse.up()

    @async_method_callback('web', '元素操作', '往下拖动N个像素', 24, [
        MethodModel(f='locating'),
        MethodModel(n='像素大小', f='n', p='请输入向下像素', d=True)])
    async def w_drag_down_pixel(self, locating, n):
        """往下拖动N个像素"""
        try:
            n = int(n)
        except ValueError:
            raise MangoAutomationError(*ERROR_MSG_0056)

        box = await locating.first.bounding_box()

        if box:
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
            await self.base_data.page.mouse.down()
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2 + n)
            await self.base_data.page.mouse.up()

    @async_method_callback('web', '元素操作', '往左拖动N个像素', 25, [
        MethodModel(f='locating'),
        MethodModel(n='像素大小', f='n', p='请输入向左像素', d=True)])
    async def w_drag_left_pixel(self, locating, n):
        """往左拖动N个像素"""
        try:
            n = int(n)
        except ValueError:
            raise MangoAutomationError(*ERROR_MSG_0056)

        box = await locating.first.bounding_box()

        if box:
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
            await self.base_data.page.mouse.down()
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2 - n, box['y'] + box['height'] / 2)
            await self.base_data.page.mouse.up()

    @async_method_callback('web', '元素操作', '往右拖动N个像素', 26, [
        MethodModel(f='locating'),
        MethodModel(n='像素大小', f='n', p='请输入向右像素', d=True)])
    async def w_drag_right_pixel(self, locating, n):
        """往右拖动N个像素"""
        try:
            n = int(n)
        except ValueError:
            raise MangoAutomationError(*ERROR_MSG_0056)
        box = await locating.first.bounding_box()

        if box:
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
            await self.base_data.page.mouse.down()
            await self.base_data.page.mouse.move(box['x'] + box['width'] / 2 + n, box['y'] + box['height'] / 2)
            await self.base_data.page.mouse.up()

    @async_method_callback('web', '元素操作', '元素截图', 27, [
        MethodModel(f='locating'),
        MethodModel(n='保存路径', f='path', p='请输入截图名称', d=True)])
    async def w_ele_screenshot(self, locating, path):
        """元素截图"""
        await locating.first.screenshot(path=str(os.path.join(self.base_data.download_path, path)))

    @async_method_callback('web', '元素操作', '拖动A元素到达B', 28, [
        MethodModel(f='locating1'),
        MethodModel(f='locating2')])
    async def w_drag_to(self, locating1, locating2):
        """拖动A元素到达B"""
        await locating1.first.drag_to(locating2.first)

    @async_method_callback('web', '元素操作', '清空输入框', 29, [MethodModel(f='locating')])
    async def w_clear(self, locating):
        """清空输入框"""
        await locating.first.clear()

    @async_method_callback('web', '元素操作', '逐字输入', 30, [
        MethodModel(f='locating'),
        MethodModel(n='输入文本', f='text', p='请输入逐字输入的内容', d=True)])
    async def w_type(self, locating, text):
        """逐字输入"""
        await locating.first.type(str(text))

    @async_method_callback('web', '元素操作', '逐字输入并触发键盘事件', 31, [
        MethodModel(f='locating'),
        MethodModel(n='输入文本', f='text', p='请输入逐字输入的内容', d=True)])
    async def w_press_sequentially(self, locating, text):
        """逐字输入并触发键盘事件"""
        await locating.first.press_sequentially(str(text))

    @async_method_callback('web', '元素操作', '元素按键', 32, [
        MethodModel(f='locating'),
        MethodModel(n='按键值', f='key', p='请输入按键值，例如 Enter、Tab、Escape', d=True)])
    async def w_press(self, locating, key):
        """元素按键"""
        await locating.first.press(validate_press_key(key))

    @async_method_callback('web', '元素操作', '元素聚焦', 33, [MethodModel(f='locating')])
    async def w_focus(self, locating):
        """元素聚焦"""
        await locating.first.focus()

    @async_method_callback('web', '元素操作', '元素失焦', 34, [MethodModel(f='locating')])
    async def w_blur(self, locating):
        """元素失焦"""
        await locating.first.blur()

    @async_method_callback('web', '元素操作', '勾选复选框或单选框', 35, [MethodModel(f='locating')])
    async def w_check(self, locating):
        """勾选复选框或单选框"""
        await locating.first.check()

    @async_method_callback('web', '元素操作', '取消勾选复选框', 36, [MethodModel(f='locating')])
    async def w_uncheck(self, locating):
        """取消勾选复选框"""
        await locating.first.uncheck()

    @async_method_callback('web', '元素操作', '设置选中状态', 37, [
        MethodModel(f='locating'),
        MethodModel(n='是否选中', f='checked', p='请输入 true/false', d=True)])
    async def w_set_checked(self, locating, checked):
        """设置选中状态"""
        await locating.first.set_checked(self._parse_bool(checked))

    @async_method_callback('web', '元素操作', '选择下拉选项', 38, [
        MethodModel(f='locating'),
        MethodModel(n='选项值', f='values', p='请输入选项值，支持字符串、数组或对象JSON', d=True)])
    async def w_select_option(self, locating, values):
        """选择下拉选项"""
        await locating.first.select_option(self._parse_json_value(values))

    @async_method_callback('web', '元素操作', '选中文本', 39, [MethodModel(f='locating')])
    async def w_select_text(self, locating):
        """选中文本"""
        await locating.first.select_text()

    @async_method_callback('web', '元素操作', '触摸点击', 40, [MethodModel(f='locating')])
    async def w_tap(self, locating):
        """触摸点击"""
        await locating.first.tap()

    @async_method_callback('web', '元素操作', '派发元素事件', 41, [
        MethodModel(f='locating'),
        MethodModel(n='事件名称', f='event_type', p='请输入事件名称，例如 input、change、click', d=True),
        MethodModel(n='事件初始化JSON', f='event_init', p='可选，输入事件初始化JSON')])
    async def w_dispatch_event(self, locating, event_type, event_init=None):
        """派发元素事件"""
        await locating.first.dispatch_event(str(event_type), self._parse_json_value(event_init) if event_init else None)

    @async_method_callback('web', '元素操作', '获取元素属性', 42, [
        MethodModel(f='locating'),
        MethodModel(n='属性名', f='name', p='请输入属性名称', d=True),
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    async def w_get_attribute(self, locating, name, set_cache_key):
        """获取元素属性"""
        value = await locating.first.get_attribute(str(name))
        self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @async_method_callback('web', '元素操作', '获取输入框值', 43, [
        MethodModel(f='locating'),
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    async def w_get_input_value(self, locating, set_cache_key):
        """获取输入框值"""
        value = await locating.first.input_value()
        self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @async_method_callback('web', '元素操作', '获取元素HTML', 44, [
        MethodModel(f='locating'),
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    async def w_get_inner_html(self, locating, set_cache_key):
        """获取元素HTML"""
        value = await locating.first.inner_html()
        self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @async_method_callback('web', '元素操作', '获取多个元素文本', 45, [
        MethodModel(f='locating'),
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    async def w_get_texts(self, locating, set_cache_key):
        """获取多个元素文本"""
        values = await locating.all_text_contents()
        self.base_data.test_data.set_cache(key=set_cache_key, value=values)
        return values

    @async_method_callback('web', '元素操作', '等待元素状态', 46, [
        MethodModel(f='locating'),
        MethodModel(n='状态', f='state', p='请输入 attached、detached、visible、hidden', d=True),
        MethodModel(n='超时时间毫秒', f='timeout', p='可选，默认30000')])
    async def w_wait_for_element_state(self, locating, state, timeout=30000):
        """等待元素状态"""
        await locating.first.wait_for(state=str(state), timeout=int(timeout or 30000))

    @async_method_callback('web', '元素操作', '高亮元素', 47, [MethodModel(f='locating')])
    async def w_highlight(self, locating):
        """高亮元素"""
        element_results = getattr(self.element_result_model, 'elements', None) or []
        element_result = element_results[-1] if element_results else None
        expression = WebElementHighlighter.format_expression(
            getattr(element_result, 'loc', None) or getattr(self.element_model, 'name', None),
            getattr(element_result, 'sub', None),
        )
        await WebElementHighlighter.highlight_async(locating, expression)
