# -*- coding: utf-8 -*-
from typing import Any

from mangoautomation.enums import BrowserTypeEnum


CHROMIUM_COMPATIBILITY_ARGS = (
    "--disable-blink-features=AutomationControlled",
)

# 在 Context 创建后、任何业务页面脚本执行前安装。仅修正 Playwright 明确暴露的
# webdriver 标记，不伪造 UA、系统版本或硬件信息，避免产生彼此矛盾的浏览器指纹。
AUTOMATION_COMPATIBILITY_INIT_SCRIPT = """
(() => {
  const navigatorPrototype = Object.getPrototypeOf(navigator);
  const descriptor = Object.getOwnPropertyDescriptor(navigatorPrototype, 'webdriver');
  if (!descriptor || descriptor.configurable) {
    Object.defineProperty(navigatorPrototype, 'webdriver', {
      configurable: true,
      enumerable: true,
      get: () => undefined,
    });
  }
})();
""".strip()


def apply_browser_compatibility_launch_args(web_type: int, launch_args: dict[str, Any]) -> dict[str, Any]:
    """Return launch options shared by case, debug and live browser sessions."""
    result = dict(launch_args)
    if web_type not in (BrowserTypeEnum.CHROMIUM.value, BrowserTypeEnum.EDGE.value):
        return result
    args = list(result.get("args") or [])
    for argument in CHROMIUM_COMPATIBILITY_ARGS:
        if argument not in args:
            args.append(argument)
    result["args"] = args
    return result
