# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: w_press 元素按键值合法性校验，非法按键在 press 前直接报错，避免等待超时/Unknown key
# @Author : 毛鹏

from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0063

# 取自 playwright driver usKeyboardLayout.js 的全部 code 名称 + aliases
_PLAYWRIGHT_KEY_NAMES = {
    'AltGraph', 'AltLeft', 'AltRight', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowUp',
    'Backquote', 'Backslash', 'Backspace', 'BracketLeft', 'BracketRight', 'CapsLock',
    'Comma', 'ContextMenu', 'ControlLeft', 'ControlRight', 'Delete', 'Digit0', 'Digit1',
    'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6', 'Digit7', 'Digit8', 'Digit9',
    'End', 'Enter', 'Equal', 'Escape', 'F1', 'F10', 'F11', 'F12', 'F2', 'F3', 'F4',
    'F5', 'F6', 'F7', 'F8', 'F9', 'Home', 'Insert', 'KeyA', 'KeyB', 'KeyC', 'KeyD',
    'KeyE', 'KeyF', 'KeyG', 'KeyH', 'KeyI', 'KeyJ', 'KeyK', 'KeyL', 'KeyM', 'KeyN',
    'KeyO', 'KeyP', 'KeyQ', 'KeyR', 'KeyS', 'KeyT', 'KeyU', 'KeyV', 'KeyW', 'KeyX',
    'KeyY', 'KeyZ', 'MetaLeft', 'MetaRight', 'Minus', 'NumLock', 'Numpad0', 'Numpad1',
    'Numpad2', 'Numpad3', 'Numpad4', 'Numpad5', 'Numpad6', 'Numpad7', 'Numpad8',
    'Numpad9', 'NumpadAdd', 'NumpadDecimal', 'NumpadDivide', 'NumpadEnter',
    'NumpadMultiply', 'NumpadSubtract', 'PageDown', 'PageUp', 'Pause', 'Period',
    'PrintScreen', 'Quote', 'ScrollLock', 'Semicolon', 'ShiftLeft', 'ShiftRight',
    'Slash', 'Space', 'Tab',
    # 修饰键别名（press 单独按键或组合键前缀均可）
    'Shift', 'Control', 'Alt', 'Meta', 'ControlOrMeta',
}

# 组合键中允许作为前缀的修饰键
_PLAYWRIGHT_MODIFIERS = {
    'Shift', 'Control', 'Alt', 'Meta', 'ControlOrMeta',
    'ShiftLeft', 'ControlLeft', 'AltLeft', 'MetaLeft',
    'ShiftRight', 'ControlRight', 'AltRight', 'MetaRight',
}

# 键盘布局中允许的单字符（可打印 ASCII）之外的特殊字符
_EXTRA_SINGLE_CHARS = {'\n', '\r'}


def _is_valid_single_char(key: str) -> bool:
    if key in _EXTRA_SINGLE_CHARS:
        return True
    return len(key) == 1 and 32 <= ord(key) <= 126


def _is_valid_key_name(key: str) -> bool:
    return key in _PLAYWRIGHT_KEY_NAMES or _is_valid_single_char(key)


def _split_combination(key: str) -> list[str]:
    """与 playwright Keyboard.press 的拆分逻辑保持一致，支持 Control+A、Control++ 这类写法。"""
    tokens = []
    building = ''
    for char in key:
        if char == '+' and building:
            tokens.append(building)
            building = ''
        else:
            building += char
    tokens.append(building)
    return tokens


def validate_press_key(key) -> str:
    """校验 w_press 的按键值，非法时直接抛出明确业务错误，避免走 Playwright press 后超时。

    合法形式：单个按键（Enter、Tab、Escape、ArrowDown、a、1）或组合键（Control+A、Shift+Tab）。
    """
    key = str(key)
    if key in _EXTRA_SINGLE_CHARS:
        return key
    key = key.strip()
    if not key:
        raise MangoAutomationError(*ERROR_MSG_0063, value=('空值',))
    tokens = _split_combination(key)
    for token in tokens[:-1]:
        if token not in _PLAYWRIGHT_MODIFIERS:
            raise MangoAutomationError(*ERROR_MSG_0063, value=(key,))
    if not _is_valid_key_name(tokens[-1]):
        raise MangoAutomationError(*ERROR_MSG_0063, value=(key,))
    return key
