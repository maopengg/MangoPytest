# -*- coding: utf-8 -*-
from typing import Any


HIGHLIGHT_SCRIPT = """(elements, options) => {
    const ownerDocument = elements[0]?.ownerDocument;
    if (!ownerDocument) return 0;

    const ownerWindow = ownerDocument.defaultView || window;
    const cleanupKey = '__mangoElementHighlightCleanup';
    if (typeof ownerWindow[cleanupKey] === 'function') {
        ownerWindow[cleanupKey]();
    }
    ownerDocument
        .querySelectorAll('[data-mango-element-highlight]')
        .forEach((item) => item.remove());

    const initialUrl = ownerWindow.location.href;
    let animationFrame = null;
    let active = true;
    const overlays = elements.map((element, index) => {
        const overlay = ownerDocument.createElement('div');
        overlay.dataset.mangoElementHighlight = 'true';
        Object.assign(overlay.style, {
            position: 'absolute',
            border: `3px solid ${options.color}`,
            boxSizing: 'border-box',
            zIndex: '2147483647',
            pointerEvents: 'none',
        });

        const tag = ownerDocument.createElement('div');
        tag.textContent = elements.length > 1
            ? `${index + 1}. ${options.label}`
            : options.label;
        Object.assign(tag.style, {
            position: 'absolute',
            left: '0',
            bottom: 'calc(100% + 6px)',
            maxWidth: '520px',
            padding: '6px 10px',
            borderRadius: '4px',
            background: '#1d2129',
            color: '#ffffff',
            font: '13px/20px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.24)',
        });
        overlay.appendChild(tag);
        ownerDocument.body.appendChild(overlay);
        return {element, overlay};
    });

    const cleanup = () => {
        if (!active) return;
        active = false;
        if (animationFrame !== null) {
            ownerWindow.cancelAnimationFrame(animationFrame);
        }
        overlays.forEach(({overlay}) => overlay.remove());
        if (ownerWindow[cleanupKey] === cleanup) {
            delete ownerWindow[cleanupKey];
        }
    };
    ownerWindow[cleanupKey] = cleanup;

    const render = () => {
        if (!active) return;
        if (ownerWindow.location.href !== initialUrl) {
            cleanup();
            return;
        }

        let visibleCount = 0;
        overlays.forEach(({element, overlay}) => {
            const rect = element.getBoundingClientRect();
            const style = ownerWindow.getComputedStyle(element);
            const visible = element.isConnected
                && style.display !== 'none'
                && style.visibility !== 'hidden'
                && rect.width > 0
                && rect.height > 0;
            if (!visible) {
                overlay.remove();
                return;
            }
            visibleCount += 1;
            Object.assign(overlay.style, {
                left: `${rect.left + ownerWindow.scrollX}px`,
                top: `${rect.top + ownerWindow.scrollY}px`,
                width: `${rect.width}px`,
                height: `${rect.height}px`,
            });
        });

        if (visibleCount === 0) {
            cleanup();
            return;
        }
        animationFrame = ownerWindow.requestAnimationFrame(render);
    };
    render();
    return elements.length;
}"""

CLEAR_CONTEXT_HIGHLIGHT_SCRIPT = """() => {
    const cleanupKey = '__mangoElementHighlightCleanup';
    if (typeof window[cleanupKey] === 'function') {
        window[cleanupKey]();
    }
    document
        .querySelectorAll('[data-mango-element-highlight]')
        .forEach((item) => item.remove());
    return true;
}"""

CLEAR_LOCATOR_HIGHLIGHT_SCRIPT = """(elements) => {
    const ownerDocument = elements[0]?.ownerDocument;
    if (!ownerDocument) return false;
    const ownerWindow = ownerDocument.defaultView || window;
    const cleanupKey = '__mangoElementHighlightCleanup';
    if (typeof ownerWindow[cleanupKey] === 'function') {
        ownerWindow[cleanupKey]();
    }
    ownerDocument
        .querySelectorAll('[data-mango-element-highlight]')
        .forEach((item) => item.remove());
    return true;
}"""


class WebElementHighlighter:
    """平台 WEB 元素高亮器，不依赖底层驱动提供的提示文案。"""

    DEFAULT_COLOR = '#f53f3f'

    @staticmethod
    def format_expression(expression: str | None, sub: int | None = None) -> str:
        label = str(expression or '已定位元素')
        if sub:
            return f'{label}.nth({int(sub) - 1})'
        return label

    @classmethod
    def options(cls, expression: str | None, color: str | None = None) -> dict[str, str]:
        return {
            'label': str(expression or '已定位元素'),
            'color': color or cls.DEFAULT_COLOR,
        }

    @classmethod
    async def highlight_async(
            cls,
            locator: Any,
            expression: str | None,
            color: str | None = None,
    ) -> int:
        targets = locator if isinstance(locator, list) else [locator]
        highlighted = 0
        for target in targets:
            if target is not None:
                highlighted += await target.evaluate_all(
                    HIGHLIGHT_SCRIPT,
                    cls.options(expression, color),
                ) or 0
        return highlighted

    @classmethod
    def highlight(
            cls,
            locator: Any,
            expression: str | None,
            color: str | None = None,
    ) -> int:
        targets = locator if isinstance(locator, list) else [locator]
        highlighted = 0
        for target in targets:
            if target is not None:
                highlighted += target.evaluate_all(
                    HIGHLIGHT_SCRIPT,
                    cls.options(expression, color),
                ) or 0
        return highlighted

    @classmethod
    async def clear_async(cls, targets: Any) -> int:
        target_list = targets if isinstance(targets, list) else [targets]
        cleared = 0
        for target in target_list:
            if target is None:
                continue
            if callable(getattr(target, 'evaluate_all', None)):
                result = await target.evaluate_all(CLEAR_LOCATOR_HIGHLIGHT_SCRIPT)
            elif callable(getattr(target, 'evaluate', None)):
                result = await target.evaluate(CLEAR_CONTEXT_HIGHLIGHT_SCRIPT)
            else:
                continue
            cleared += 1 if result is not False else 0
        return cleared

    @classmethod
    def clear(cls, targets: Any) -> int:
        target_list = targets if isinstance(targets, list) else [targets]
        cleared = 0
        for target in target_list:
            if target is None:
                continue
            if callable(getattr(target, 'evaluate_all', None)):
                result = target.evaluate_all(CLEAR_LOCATOR_HIGHLIGHT_SCRIPT)
            elif callable(getattr(target, 'evaluate', None)):
                result = target.evaluate(CLEAR_CONTEXT_HIGHLIGHT_SCRIPT)
            else:
                continue
            cleared += 1 if result is not False else 0
        return cleared
