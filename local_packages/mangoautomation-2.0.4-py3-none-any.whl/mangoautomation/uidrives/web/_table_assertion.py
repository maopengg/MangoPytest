# -*- coding: utf-8 -*-
import json
import re


def normalize_text(value) -> str:
    return re.sub(r'\s+', ' ', str(value or '')).strip()


def parse_expected_fields(value) -> dict[str, str]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as error:
            raise ValueError(f'表格字段配置不是有效对象：{error}') from error
    if not isinstance(value, dict) or not value:
        raise ValueError('请至少配置一个表格字段和值')
    result = {}
    for field, expected in value.items():
        field_name = normalize_text(field)
        if not field_name:
            raise ValueError('表格字段名不能为空')
        result[field_name] = normalize_text(expected)
    return result


def build_table_rows(headers, cell_rows) -> list[dict[str, str]]:
    normalized_headers = [normalize_text(header) for header in headers]
    if not normalized_headers or any(not header for header in normalized_headers):
        raise ValueError('未识别到完整表头，请确认定位器指向包含表头的 table 元素')
    duplicates = sorted({header for header in normalized_headers if normalized_headers.count(header) > 1})
    if duplicates:
        raise ValueError(f'表头存在重名字段：{",".join(duplicates)}')
    return [
        {
            header: normalize_text(cells[index]) if index < len(cells) else ''
            for index, header in enumerate(normalized_headers)
        }
        for cells in cell_rows
    ]


def assert_table_rows(headers, cell_rows, expected, comparison: str) -> str:
    expected_fields = parse_expected_fields(expected)
    headers = [normalize_text(header) for header in headers]
    rows = build_table_rows(headers, cell_rows)
    missing_fields = [field for field in expected_fields if field not in headers]
    if missing_fields:
        raise AssertionError(
            f'表格缺少字段：{",".join(missing_fields)}；实际表头：{",".join(headers)}'
        )

    def matches(row):
        if comparison == 'contains':
            return all(value in row[field] for field, value in expected_fields.items())
        return all(row[field] == value for field, value in expected_fields.items())

    matched = [index + 1 for index, row in enumerate(rows) if matches(row)]
    matched_rows = '、'.join(str(index) for index in matched)
    conditions = '，'.join(f'{field}={value}' for field, value in expected_fields.items())
    if comparison == 'not_equal':
        if matched:
            raise AssertionError(f'表格第{matched_rows}行出现了不应存在的匹配数据：{conditions}')
        return f'表格不存在字段值完全匹配的行：{conditions}'
    if not matched:
        mode = '包含' if comparison == 'contains' else '等于'
        raise AssertionError(f'表格中没有找到字段值{mode}的行：{conditions}，共检查{len(rows)}行')
    mode = '包含' if comparison == 'contains' else '等于'
    return f'表格第{matched[0]}行字段值{mode}预期：{conditions}'
