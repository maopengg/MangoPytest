import time
from typing import Any

from mangoautomation.element_healing.baseline import BaselineCollector
from mangoautomation.uidrives.web.highlight import WebElementHighlighter

from .scanner import PageElementScanner


class WebElementInspector:
    """与平台协议无关的 Playwright 页面元素扫描、采集和定位验证能力。"""

    PICK_SCRIPT = r"""
    ([x, y]) => {
      let target = document.elementFromPoint(x, y);
      if (!target) return null;
      let shadowDepth = 0;
      while (target?.shadowRoot?.elementFromPoint) {
        const inner = target.shadowRoot.elementFromPoint(x, y);
        if (!inner || inner === target) break;
        target = inner;
        shadowDepth += 1;
      }
      const clean = (value, limit = 240) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
      const literal = (value) => JSON.stringify(String(value || ''));
      const tag = target.tagName.toLowerCase();
      const inputType = clean(target.getAttribute('type'), 40).toLowerCase();
      const sensitive = tag === 'input' && inputType === 'password';
      const text = clean(target.innerText || target.textContent);
      const associatedLabel = target.labels?.length
        ? clean(Array.from(target.labels).map((item) => item.textContent || '').join(' '))
        : clean(target.closest('label')?.textContent);
      const label = clean(target.getAttribute('aria-label') || associatedLabel || target.getAttribute('title'));
      const placeholder = clean(target.getAttribute('placeholder'));
      const implicitRole = () => {
        const explicit = clean(target.getAttribute('role'), 80).split(/\s+/)[0];
        if (explicit) return explicit;
        if (tag === 'button') return 'button';
        if (tag === 'a' && target.hasAttribute('href')) return 'link';
        if (tag === 'textarea') return 'textbox';
        if (tag === 'select') return target.multiple ? 'listbox' : 'combobox';
        if (tag === 'input') {
          if (inputType === 'checkbox') return 'checkbox';
          if (inputType === 'radio') return 'radio';
          if (['button', 'submit', 'reset', 'image'].includes(inputType)) return 'button';
          if (inputType !== 'hidden') return 'textbox';
        }
        return '';
      };
      const cssPath = (node) => {
        const parts = [];
        let current = node;
        while (current && parts.length < 12) {
          let segment = current.tagName.toLowerCase();
          if (current.id) segment = `[id=${literal(current.id)}]`;
          else {
            const testAttr = ['data-testid', 'data-test', 'data-qa'].find((name) => current.hasAttribute(name));
            if (testAttr) segment = `[${testAttr}=${literal(current.getAttribute(testAttr))}]`;
            else if (current.parentElement) {
              const siblings = Array.from(current.parentElement.children).filter((item) => item.tagName === current.tagName);
              if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(current) + 1})`;
            }
          }
          parts.unshift(segment);
          if (current.id || ['data-testid', 'data-test', 'data-qa'].some((name) => current.hasAttribute(name))) break;
          if (current.parentElement) current = current.parentElement;
          else current = current.getRootNode?.()?.host || null;
        }
        return parts.join(' ');
      };
      const xpath = (node) => {
        if (shadowDepth) return '';
        if (node.id) return `//*[@id=${literal(node.id)}]`;
        const parts = [];
        while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.body) {
          let index = 1;
          let sibling = node.previousElementSibling;
          while (sibling) {
            if (sibling.tagName === node.tagName) index += 1;
            sibling = sibling.previousElementSibling;
          }
          parts.unshift(`${node.tagName.toLowerCase()}[${index}]`);
          node = node.parentElement;
        }
        return `/html/body/${parts.join('/')}`;
      };
      const rect = target.getBoundingClientRect();
      const role = implicitRole();
      const accessibleName = clean(label || target.getAttribute('alt') || placeholder || text);
      return {
        tag,
        role,
        text: sensitive ? '' : text,
        label,
        accessible_name: accessibleName,
        placeholder,
        id: clean(target.id, 160),
        class_name: clean(typeof target.className === 'string' ? target.className : '', 300),
        input_type: inputType,
        sensitive_value_masked: sensitive,
        shadow_depth: shadowDepth,
        attributes: Object.fromEntries(
          ['data-testid', 'data-test', 'data-qa', 'name']
            .map((name) => [name, target.getAttribute(name)])
            .filter(([, value]) => value)
        ),
        css_path: cssPath(target),
        xpath: xpath(target),
        bounding_box: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      };
    }
    """

    TARGET_SCRIPT = r"""
    target => {
      const clean = (value, limit = 240) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
      const literal = (value) => JSON.stringify(String(value || ''));
      const tag = target.tagName.toLowerCase();
      const inputType = clean(target.getAttribute('type'), 40).toLowerCase();
      const text = inputType === 'password' ? '' : clean(target.innerText || target.textContent || target.value);
      const associatedLabel = target.labels?.length
        ? clean(Array.from(target.labels).map((item) => item.textContent || '').join(' '))
        : clean(target.closest('label')?.textContent);
      const label = clean(target.getAttribute('aria-label') || associatedLabel || target.getAttribute('title'));
      const placeholder = clean(target.getAttribute('placeholder'));
      const explicitRole = clean(target.getAttribute('role'), 80).split(/\s+/)[0];
      const role = explicitRole || (
        tag === 'button' ? 'button' :
        tag === 'a' && target.hasAttribute('href') ? 'link' :
        tag === 'textarea' ? 'textbox' :
        tag === 'select' ? (target.multiple ? 'listbox' : 'combobox') :
        tag === 'input' && inputType === 'checkbox' ? 'checkbox' :
        tag === 'input' && inputType === 'radio' ? 'radio' :
        tag === 'input' && inputType !== 'hidden' ? 'textbox' : ''
      );
      const cssPath = (node) => {
        const parts = [];
        let current = node;
        while (current && parts.length < 12) {
          let segment = current.tagName.toLowerCase();
          if (current.id) segment = `[id=${literal(current.id)}]`;
          else {
            const stableAttr = ['data-testid', 'data-test', 'data-qa', 'name'].find((name) => current.hasAttribute(name));
            if (stableAttr) segment = `${segment}[${stableAttr}=${literal(current.getAttribute(stableAttr))}]`;
            else if (current.parentElement) {
              const siblings = Array.from(current.parentElement.children).filter((item) => item.tagName === current.tagName);
              if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(current) + 1})`;
            }
          }
          parts.unshift(segment);
          if (current.id || ['data-testid', 'data-test', 'data-qa'].some((name) => current.hasAttribute(name))) break;
          current = current.parentElement;
        }
        return parts.join(' ');
      };
      const xpath = (node) => {
        if (node.id) return `//*[@id=${literal(node.id)}]`;
        const parts = [];
        while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.body) {
          let index = 1;
          let sibling = node.previousElementSibling;
          while (sibling) {
            if (sibling.tagName === node.tagName) index += 1;
            sibling = sibling.previousElementSibling;
          }
          parts.unshift(`${node.tagName.toLowerCase()}[${index}]`);
          node = node.parentElement;
        }
        return `/html/body/${parts.join('/')}`;
      };
      return {
        tag,
        role,
        text,
        label,
        accessible_name: clean(label || target.getAttribute('alt') || placeholder || text),
        placeholder,
        id: clean(target.id, 160),
        input_type: inputType,
        attributes: Object.fromEntries(
          ['data-testid', 'data-test', 'data-qa', 'name']
            .map((name) => [name, target.getAttribute(name)])
            .filter(([, value]) => value)
        ),
        css_path: cssPath(target),
        xpath: xpath(target),
      };
    }
    """

    def __init__(self, scanner: PageElementScanner | None = None):
        self.scanner = scanner or PageElementScanner()

    async def scan(self, page: Any, mode: str = "quick", region: dict | None = None) -> dict:
        return await self.scanner.scan(page, mode, region)

    async def pick(self, page: Any, x: float, y: float) -> dict:
        started_at = time.perf_counter()
        target_frame, local_x, local_y, frame_box = await self.frame_at_point(page, x, y)
        item = await target_frame.evaluate(self.PICK_SCRIPT, [local_x, local_y])
        if not item:
            raise RuntimeError("当前位置没有可采集元素")
        frame_prefix = await self.scanner._frame_locator_prefix(target_frame, page)
        item.update({
            "frame_index": page.frames.index(target_frame),
            "frame_url": target_frame.url,
            "frame_depth": frame_prefix.count("frame_locator("),
            "frame_locator_prefix": frame_prefix,
        })
        if frame_box:
            item["bounding_box"]["x"] += frame_box["x"]
            item["bounding_box"]["y"] += frame_box["y"]
        item["locators"] = self.scanner._apply_frame_locator_prefix(
            self.scanner.locator_suggestions(item),
            frame_prefix,
        )
        validation = await self.validate(page, item["locators"], highlight=True)
        item["locators"] = validation["locators"] or item["locators"]
        item["baseline_snapshot"] = await self.collect_baseline(page, item)
        item["inspection_duration_ms"] = int((time.perf_counter() - started_at) * 1000)
        item["validation"] = validation
        return item

    async def suggest_from_locator(self, locator: Any, limit: int = 7) -> list[dict]:
        """基于已确认的真实 DOM 节点生成定位器候选，不重新猜测目标元素。"""
        item = await locator.evaluate(self.TARGET_SCRIPT)
        if not isinstance(item, dict):
            return []
        return self.scanner.locator_suggestions(item)[:max(1, int(limit))]

    async def validate(
        self,
        page: Any,
        locators: list[dict],
        *,
        highlight: bool = False,
        baseline_item: dict | None = None,
    ) -> dict:
        started_at = time.perf_counter()
        candidates = [
            dict(locator)
            for locator in (locators or [])
            if isinstance(locator, dict) and locator.get("loc") and locator.get("exp") is not None
        ]
        if not candidates:
            raise RuntimeError("没有可检测的定位器")
        groups = []
        selected = None
        reject_reasons = []
        for group_index, locator_item in enumerate(candidates, start=1):
            group = await self._validate_group(page, locator_item, group_index)
            groups.append(group)
            if group["status"] == "invalid":
                reject_reasons.append(group["error_message"] or f"{locator_item['loc']} 定位无效")
            if selected is None and group.get("visible"):
                selected = group
        if selected is not None and highlight:
            try:
                locator = self.playwright_locator(page, selected["exp"], selected["loc"])
                selected["highlighted_count"] = await WebElementHighlighter.highlight_async(
                    locator,
                    selected["loc"],
                )
                selected["highlighted"] = selected["highlighted_count"] > 0
            except Exception as error:
                selected["highlight_error"] = str(error)
        baseline_snapshot = {}
        if selected is not None and baseline_item is not None:
            baseline_payload = dict(baseline_item)
            baseline_payload["locators"] = [{
                "exp": selected["exp"],
                "loc": selected["loc"],
                "sub": selected.get("sub"),
            }]
            baseline_snapshot = await self.collect_baseline(page, baseline_payload)
        return {
            "status": bool(selected),
            "selected_group": selected.get("group") if selected else None,
            "selected": selected,
            "locator_groups": groups,
            "locators": candidates,
            "reject_reasons": reject_reasons,
            "baseline_snapshot": baseline_snapshot,
            "duration_ms": int((time.perf_counter() - started_at) * 1000),
        }

    async def _validate_group(self, page: Any, locator_item: dict, group_index: int) -> dict:
        started_at = time.perf_counter()
        result = {
            "group": group_index,
            "exp": locator_item.get("exp"),
            "loc": locator_item.get("loc"),
            "sub": locator_item.get("sub"),
            "status": "invalid",
            "count": 0,
            "visible": None,
            "enabled": None,
            "editable": None,
            "element_text": "",
            "bounding_box": None,
            "highlighted": False,
            "highlighted_count": 0,
            "error_message": "",
        }
        try:
            locator = self.playwright_locator(page, result["exp"], result["loc"])
            count = await locator.count()
            result["count"] = count
            if count < 1:
                result["error_message"] = f"{result['loc']} 匹配 0"
                return result
            first = locator.first
            result["bounding_box"] = await first.bounding_box()
            result["element_text"] = await self._element_text(first)
            result["visible"] = await self._optional_call(first, "is_visible", bool(result["bounding_box"]))
            result["enabled"] = await self._optional_call(first, "is_enabled")
            result["editable"] = await self._optional_call(first, "is_editable")
            result["status"] = (
                "valid" if result["visible"] and count == 1
                else "risk" if result["visible"]
                else "invalid"
            )
            if not result["visible"]:
                result["error_message"] = f"{result['loc']} 元素不可见"
        except Exception as error:
            result["error_message"] = f"{result['loc']} 检测异常：{error}"
        finally:
            result["duration_ms"] = int((time.perf_counter() - started_at) * 1000)
        return result

    async def collect_baseline(self, page: Any, item: dict) -> dict:
        for locator in item.get("locators") or []:
            loc = locator.get("loc")
            exp = locator.get("exp")
            if not loc:
                continue
            try:
                playwright_locator = self.playwright_locator(page, exp, loc)
                snapshot = await BaselineCollector.freeze_async(
                    page,
                    playwright_locator.first,
                    timeout_seconds=0.6,
                )
                if not snapshot:
                    continue
                snapshot.update({
                    "source": 2,
                    "status": 1,
                    "url": page.url,
                    "title": await page.title(),
                    "exp": exp,
                    "loc": loc,
                    "sub": locator.get("sub"),
                    "match_count": await playwright_locator.count(),
                    "element_text": snapshot.get("element_text")
                    or item.get("text")
                    or item.get("label")
                    or item.get("placeholder"),
                })
                return snapshot
            except Exception:
                continue
        return {}

    async def frame_at_point(self, page: Any, x: float, y: float):
        selected_frame = page.main_frame
        selected_box = None
        selected_depth = 0
        for frame in page.frames:
            if frame is page.main_frame or frame.is_detached():
                continue
            try:
                box = await (await frame.frame_element()).bounding_box()
            except Exception:
                continue
            if not box or not (
                box["x"] <= x <= box["x"] + box["width"]
                and box["y"] <= y <= box["y"] + box["height"]
            ):
                continue
            depth = 0
            current = frame
            while current is not None and current is not page.main_frame:
                depth += 1
                current = current.parent_frame
            if depth >= selected_depth:
                selected_frame = frame
                selected_box = box
                selected_depth = depth
        if selected_box:
            return selected_frame, x - selected_box["x"], y - selected_box["y"], selected_box
        return selected_frame, x, y, None

    @staticmethod
    def playwright_locator(page: Any, exp: Any, loc: str):
        return PageElementScanner.playwright_locator(page, exp, loc)

    @staticmethod
    async def _element_text(locator: Any) -> str:
        try:
            return (await locator.inner_text()).strip()
        except Exception:
            try:
                return ((await locator.text_content()) or "").strip()
            except Exception:
                return ""

    @staticmethod
    async def _optional_call(target: Any, method: str, default=None):
        try:
            return await getattr(target, method)()
        except Exception:
            return default
