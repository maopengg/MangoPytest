import asyncio
import json
import logging
import time


logger = logging.getLogger(__name__)


class PageElementScanner:
    SCAN_MODES = {"quick", "deep", "region"}
    MAX_RESULTS = 200
    MAX_FRAME_CANDIDATES = 600
    MAX_VALIDATION_CONCURRENCY = 8

    DISCOVERY_SCRIPT = r"""
    async (scanRoot, { mode, maxCandidates }) => {
      const ownerDocument = scanRoot.ownerDocument || document;
      const ownerWindow = ownerDocument.defaultView || window;
      const candidateSelector = [
        'button', 'a[href]', 'input:not([type="hidden"])', 'textarea', 'select', 'option',
        '[role]', '[placeholder]', '[aria-label]', '[data-testid]', '[data-test]', '[data-qa]',
        '[contenteditable="true"]', '[tabindex]', '[onclick]'
      ].join(',');
      const results = new Map();
      const scanStats = { visited: 0, candidates: 0, sensitive_values_masked: 0, shadow_roots: 0 };

      const clean = (value, limit = 240) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
      const implicitRole = (target) => {
        const explicit = clean(target.getAttribute('role'), 80).split(/\s+/)[0];
        if (explicit) return explicit;
        const tag = target.tagName.toLowerCase();
        const type = clean(target.getAttribute('type'), 40).toLowerCase();
        if (tag === 'button') return 'button';
        if (tag === 'a' && target.hasAttribute('href')) return 'link';
        if (tag === 'textarea') return 'textbox';
        if (tag === 'select') return target.multiple ? 'listbox' : 'combobox';
        if (tag === 'option') return 'option';
        if (tag === 'input') {
          if (type === 'checkbox') return 'checkbox';
          if (type === 'radio') return 'radio';
          if (['button', 'submit', 'reset', 'image'].includes(type)) return 'button';
          if (type === 'range') return 'slider';
          if (type === 'number') return 'spinbutton';
          if (type !== 'hidden') return 'textbox';
        }
        return '';
      };
      const labelText = (target) => {
        const labelledBy = clean(target.getAttribute('aria-labelledby'), 300);
        if (labelledBy) {
          const value = labelledBy
            .split(/\s+/)
            .map((id) => clean(ownerDocument.getElementById(id)?.textContent))
            .filter(Boolean)
            .join(' ');
          if (value) return clean(value);
        }
        if (target.labels?.length) {
          const value = Array.from(target.labels).map((item) => clean(item.textContent)).filter(Boolean).join(' ');
          if (value) return clean(value);
        }
        const wrapped = target.closest('label');
        return clean(wrapped?.textContent);
      };
      const accessibleName = (target, text) => clean(
        target.getAttribute('aria-label') ||
        labelText(target) ||
        target.getAttribute('alt') ||
        target.getAttribute('title') ||
        target.getAttribute('placeholder') ||
        text
      );
      const selectorLiteral = (value) => JSON.stringify(String(value || ''));
      const cssSegment = (target) => {
        if (target.id) return `[id=${selectorLiteral(target.id)}]`;
        for (const name of ['data-testid', 'data-test', 'data-qa']) {
          const value = target.getAttribute(name);
          if (value) return `[${name}=${selectorLiteral(value)}]`;
        }
        let segment = target.tagName.toLowerCase();
        const name = target.getAttribute('name');
        if (name) segment += `[name=${selectorLiteral(name)}]`;
        const parent = target.parentElement;
        if (parent) {
          const siblings = Array.from(parent.children).filter((item) => item.tagName === target.tagName);
          if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(target) + 1})`;
        }
        return segment;
      };
      const cssPath = (target) => {
        const parts = [];
        let current = target;
        let guard = 0;
        while (current && guard < 12) {
          parts.unshift(cssSegment(current));
          if (current.id || current.hasAttribute('data-testid') || current.hasAttribute('data-test') || current.hasAttribute('data-qa')) break;
          if (current.parentElement) current = current.parentElement;
          else {
            const root = current.getRootNode?.();
            current = root?.host || null;
          }
          guard += 1;
        }
        return parts.join(' ');
      };
      const xpath = (target, shadowDepth) => {
        if (shadowDepth > 0) return '';
        if (target.id) return `//*[@id=${selectorLiteral(target.id)}]`;
        const parts = [];
        let current = target;
        while (current && current.nodeType === ownerWindow.Node.ELEMENT_NODE && current !== ownerDocument.body) {
          let index = 1;
          let sibling = current.previousElementSibling;
          while (sibling) {
            if (sibling.tagName === current.tagName) index += 1;
            sibling = sibling.previousElementSibling;
          }
          parts.unshift(`${current.tagName.toLowerCase()}[${index}]`);
          current = current.parentElement;
        }
        return `/html/body/${parts.join('/')}`;
      };
      const isCandidate = (target, style) => {
        if (target.matches(candidateSelector)) return true;
        if (typeof target.onclick === 'function') return true;
        return style.cursor === 'pointer';
      };
      const inspect = (target, shadowDepth) => {
        scanStats.visited += 1;
        if (scanStats.visited > 30000) return;
        const style = getComputedStyle(target);
        if (!isCandidate(target, style)) return;
        const rect = target.getBoundingClientRect();
        const visible = !!(
          rect.width > 0 && rect.height > 0 &&
          style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0
        );
        if (!visible) return;
        const tag = target.tagName.toLowerCase();
        const inputType = clean(target.getAttribute('type'), 40).toLowerCase();
        const sensitive = tag === 'input' && inputType === 'password';
        if (sensitive) scanStats.sensitive_values_masked += 1;
        const text = ['input', 'textarea', 'select', 'option'].includes(tag)
          ? clean(target.innerText || target.textContent)
          : clean(target.innerText || target.textContent);
        const label = clean(target.getAttribute('aria-label') || labelText(target) || target.getAttribute('title'));
        const placeholder = clean(target.getAttribute('placeholder'));
        const name = accessibleName(target, text);
        const id = clean(target.id, 160);
        if (!(text || label || placeholder || id || name || target.hasAttribute('data-testid') || target.hasAttribute('data-test') || target.hasAttribute('data-qa'))) return;
        const inViewport = rect.bottom > 0 && rect.right > 0 && rect.top < ownerWindow.innerHeight && rect.left < ownerWindow.innerWidth;
        let covered = false;
        if (inViewport) {
          const x = Math.max(0, Math.min(ownerWindow.innerWidth - 1, rect.left + Math.min(rect.width / 2, 8)));
          const y = Math.max(0, Math.min(ownerWindow.innerHeight - 1, rect.top + Math.min(rect.height / 2, 8)));
          const root = target.getRootNode?.();
          const hit = root?.elementFromPoint?.(x, y) || ownerDocument.elementFromPoint(x, y);
          covered = !!(hit && hit !== target && !target.contains(hit) && !hit.contains(target));
        }
        const role = implicitRole(target);
        const attributes = {};
        for (const attrName of ['name', 'data-testid', 'data-test', 'data-qa', 'aria-label', 'title', 'placeholder', 'alt']) {
          const value = clean(target.getAttribute(attrName));
          if (value) attributes[attrName] = value;
        }
        const reasons = [];
        if (role) reasons.push(`语义角色:${role}`);
        if (target.hasAttribute('onclick') || typeof target.onclick === 'function') reasons.push('点击事件');
        if (target.hasAttribute('tabindex')) reasons.push('可聚焦');
        if (target.isContentEditable) reasons.push('可编辑');
        if (style.cursor === 'pointer') reasons.push('指针样式');
        const path = cssPath(target);
        const item = {
          tag,
          role,
          text: sensitive ? '' : text,
          label,
          accessible_name: name,
          placeholder,
          id,
          class_name: clean(typeof target.className === 'string' ? target.className : '', 300),
          input_type: inputType,
          sensitive_value_masked: sensitive,
          attributes,
          visible: true,
          in_viewport: inViewport,
          covered,
          enabled: !target.disabled && target.getAttribute('aria-disabled') !== 'true',
          editable: !!(target.isContentEditable || tag === 'textarea' || (tag === 'input' && !['button', 'submit', 'reset', 'checkbox', 'radio', 'file'].includes(inputType))),
          shadow_depth: shadowDepth,
          css_path: path,
          xpath: xpath(target, shadowDepth),
          interactive_reasons: reasons,
          bounding_box: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
        };
        let scanScore = role ? 35 : 10;
        if (attributes['data-testid'] || attributes['data-test'] || attributes['data-qa']) scanScore += 45;
        if (id) scanScore += 35;
        if (name) scanScore += 20;
        if (inViewport) scanScore += 8;
        if (!covered) scanScore += 5;
        if (sensitive) scanScore -= 5;
        item.scan_score = scanScore;
        item.fingerprint = `${tag}|${id}|${name}|${path}|${shadowDepth}`;
        const previous = results.get(item.fingerprint);
        if (!previous || item.scan_score > previous.scan_score) results.set(item.fingerprint, item);
      };
      const walkRoot = (root, shadowDepth = 0) => {
        const walker = ownerDocument.createTreeWalker(root, ownerWindow.NodeFilter.SHOW_ELEMENT);
        let target = walker.nextNode();
        while (target) {
          inspect(target, shadowDepth);
          if (target.shadowRoot) {
            scanStats.shadow_roots += 1;
            walkRoot(target.shadowRoot, shadowDepth + 1);
          }
          target = walker.nextNode();
        }
      };
      const collect = () => {
        scanStats.visited = 0;
        walkRoot(scanRoot, 0);
      };
      collect();
      if (mode === 'deep') {
        const all = Array.from(scanRoot.querySelectorAll('*')).slice(0, 5000);
        const rootScroller = scanRoot === ownerDocument.documentElement
          ? ownerDocument.scrollingElement
          : scanRoot;
        const scrolling = [rootScroller, ...all.filter((target) => {
          const style = getComputedStyle(target);
          return target.scrollHeight > target.clientHeight + 80 && /(auto|scroll)/.test(style.overflowY);
        })].filter(Boolean).slice(0, 6);
        for (const target of scrolling) {
          const originalTop = target.scrollTop;
          const maxTop = Math.max(0, target.scrollHeight - target.clientHeight);
          if (!maxTop) continue;
          try {
            for (const ratio of [0, 0.5, 1]) {
              target.scrollTop = Math.round(maxTop * ratio);
              await new Promise((resolve) => setTimeout(resolve, 70));
              collect();
            }
          } finally {
            target.scrollTop = originalTop;
          }
        }
      }
      const elements = Array.from(results.values())
        .sort((left, right) => right.scan_score - left.scan_score)
        .slice(0, maxCandidates);
      scanStats.candidates = elements.length;
      return { elements, stats: scanStats };
    }
    """

    async def scan(self, page, mode: str = "quick", region: dict | None = None) -> dict:
        mode = str(mode or "quick").lower()
        if mode not in self.SCAN_MODES:
            raise RuntimeError("页面元素扫描模式无效")
        if mode == "region" and not isinstance(region, dict):
            raise RuntimeError("请先通过直播的“选择元素”选中一个扫描区域")
        started_at = time.perf_counter()
        frames = [frame for frame in page.frames if not frame.is_detached()]
        scan_targets = []
        if mode == "region":
            region_locator = None
            for locator_item in region.get("locators") or []:
                try:
                    candidate = self.playwright_locator(
                        page, locator_item.get("exp"), locator_item.get("loc")
                    )
                    if await candidate.count() == 1:
                        region_locator = candidate.first
                        break
                except Exception:
                    continue
            if region_locator is None:
                raise RuntimeError("已选择的区域在当前页面中失效，请重新选择区域")
            scan_targets.append({
                "target": region_locator,
                "frame_index": int(region.get("frame_index") or 0),
                "frame_url": region.get("frame_url") or page.url,
                "frame_locator_prefix": region.get("frame_locator_prefix") or "",
            })
        else:
            for frame_index, frame in enumerate(frames):
                scan_targets.append({
                    "target": frame.locator("html"),
                    "frame_index": frame_index,
                    "frame_url": frame.url,
                    "frame_locator_prefix": await self._frame_locator_prefix(frame, page),
                })
        candidates: list[dict] = []
        totals = {
            "visited": 0,
            "candidates": 0,
            "sensitive_values_masked": 0,
            "shadow_roots": 0,
            "frame_count": len(scan_targets),
            "failed_frame_count": 0,
            "region_selected": mode == "region",
        }
        for scan_target in scan_targets:
            frame_index = scan_target["frame_index"]
            frame_url = scan_target["frame_url"]
            frame_locator_prefix = scan_target["frame_locator_prefix"]
            try:
                payload = await scan_target["target"].evaluate(
                    self.DISCOVERY_SCRIPT,
                    {
                        "mode": "quick" if mode == "region" else mode,
                        "maxCandidates": self.MAX_FRAME_CANDIDATES,
                    },
                )
            except Exception as error:
                totals["failed_frame_count"] += 1
                logger.warning(
                    "页面元素扫描 frame 失败：index=%s, url=%s, error=%s",
                    frame_index,
                    frame_url,
                    error,
                )
                continue
            for key in ("visited", "candidates", "sensitive_values_masked", "shadow_roots"):
                totals[key] += int((payload.get("stats") or {}).get(key) or 0)
            for item in payload.get("elements") or []:
                item.update({
                    "frame_index": frame_index,
                    "frame_url": frame_url,
                    "frame_depth": frame_locator_prefix.count("frame_locator("),
                    "frame_locator_prefix": frame_locator_prefix,
                })
                item["locators"] = self._apply_frame_locator_prefix(
                    self.locator_suggestions(item),
                    frame_locator_prefix,
                )
                candidates.append(item)

        deduplicated: dict[str, dict] = {}
        for item in candidates:
            key = f"{item.get('frame_index')}|{item.get('fingerprint')}"
            previous = deduplicated.get(key)
            if previous is None or item.get("scan_score", 0) > previous.get("scan_score", 0):
                deduplicated[key] = item
        ranked = sorted(
            deduplicated.values(),
            key=lambda item: (
                item.get("scan_score", 0),
                bool(item.get("in_viewport")),
                bool(item.get("accessible_name")),
            ),
            reverse=True,
        )[:self.MAX_RESULTS]

        semaphore = asyncio.Semaphore(self.MAX_VALIDATION_CONCURRENCY)

        async def enrich(item: dict) -> dict:
            async with semaphore:
                return await self._validate_candidate(page, item)

        validated = await asyncio.gather(*(enrich(item) for item in ranked)) if ranked else []
        elements = [item for item in validated if item.get("locators")]
        elements.sort(
            key=lambda item: (
                (item.get("locators") or [{}])[0].get("score", 0),
                item.get("scan_score", 0),
            ),
            reverse=True,
        )
        try:
            page_title = await page.title()
        except Exception:
            page_title = ""
        for item in elements:
            locator = item["locators"][0]
            item["baseline_snapshot"] = {
                "source": 2,
                "status": 1,
                "url": page.url,
                "title": page_title,
                "frame_url": item.get("frame_url") if item.get("frame_depth") else None,
                "exp": locator.get("exp"),
                "loc": locator.get("loc"),
                "sub": locator.get("sub"),
                "match_count": locator.get("match_count") or 0,
                "element_text": item.get("text") or item.get("label") or item.get("placeholder") or "",
                "element_tag": item.get("tag"),
                "element_role": item.get("role"),
                "element_type": item.get("input_type"),
                "element_name": item.get("accessible_name"),
                "element_placeholder": item.get("placeholder"),
                "element_value": "",
                "element_attributes": item.get("attributes") or {},
                "element_rect": item.get("bounding_box") or {},
                "element_css": {},
                "accessibility_digest": {
                    "role": item.get("role"),
                    "name": item.get("accessible_name"),
                },
            }
        totals.update({
            "returned_count": len(elements),
            "rejected_count": len(validated) - len(elements),
            "duration_ms": int((time.perf_counter() - started_at) * 1000),
        })
        return {"elements": elements, "scan_mode": mode, "scan_stats": totals}

    async def _frame_locator_prefix(self, frame, page) -> str:
        if frame is page.main_frame:
            return ""
        selectors = []
        current = frame
        while current is not None and current is not page.main_frame:
            try:
                frame_element = await current.frame_element()
                selector = await frame_element.evaluate(
                    r"""(target) => {
                      const literal = (value) => JSON.stringify(String(value || ''));
                      const segment = (node) => {
                        if (node.id) return `[id=${literal(node.id)}]`;
                        for (const name of ['data-testid', 'data-test', 'data-qa', 'name', 'title']) {
                          const value = node.getAttribute(name);
                          if (value) return `${node.tagName.toLowerCase()}[${name}=${literal(value)}]`;
                        }
                        let value = node.tagName.toLowerCase();
                        const parent = node.parentElement;
                        if (parent) {
                          const siblings = Array.from(parent.children).filter((item) => item.tagName === node.tagName);
                          if (siblings.length > 1) value += `:nth-of-type(${siblings.indexOf(node) + 1})`;
                        }
                        return value;
                      };
                      const parts = [];
                      let current = target;
                      while (current && parts.length < 10) {
                        parts.unshift(segment(current));
                        if (current.id || ['data-testid', 'data-test', 'data-qa'].some((name) => current.hasAttribute(name))) break;
                        current = current.parentElement;
                      }
                      return parts.join(' ');
                    }"""
                )
                if not selector:
                    return ""
                selectors.append(selector)
            except Exception as error:
                logger.warning(
                    "页面元素扫描 iframe 定位链生成失败：url=%s, error=%s",
                    current.url,
                    error,
                )
                return ""
            current = current.parent_frame
        selectors.reverse()
        return ".".join(
            f"frame_locator({json.dumps(selector, ensure_ascii=False)})"
            for selector in selectors
        )

    @staticmethod
    def _apply_frame_locator_prefix(locators: list[dict], prefix: str) -> list[dict]:
        if not prefix:
            return locators
        wrapped = []
        for locator in locators:
            item = dict(locator)
            if int(item.get("exp")) == 2:
                item["loc"] = f"{prefix}.{item['loc']}"
            elif int(item.get("exp")) == 9:
                item["exp"] = 2
                item["loc"] = f"{prefix}.locator({json.dumps(item['loc'], ensure_ascii=False)})"
            else:
                item["exp"] = 2
                xpath_locator = f"xpath={item['loc']}"
                item["loc"] = f"{prefix}.locator({json.dumps(xpath_locator, ensure_ascii=False)})"
            item["source"] = f"{item.get('source')}_frame"
            wrapped.append(item)
        return wrapped

    async def _validate_candidate(self, frame, item: dict) -> dict:
        validations = await asyncio.gather(*(
            self._validate_locator(frame, locator)
            for locator in (item.get("locators") or [])[:5]
        ))
        locators = [locator for locator in validations if locator.get("match_count", 0) > 0]
        locators.sort(key=lambda locator: locator.get("score", 0), reverse=True)
        item["locators"] = locators[:5]
        risks = []
        if item.get("sensitive_value_masked"):
            risks.append("敏感输入值已屏蔽")
        if item.get("covered"):
            risks.append("元素可能被遮挡")
        if not item.get("in_viewport"):
            risks.append("元素当前不在视口内")
        if not locators:
            risks.append("没有验证通过的定位器")
        elif locators[0].get("match_count") != 1:
            risks.append(f"推荐定位器匹配 {locators[0].get('match_count')} 个元素")
        item["risks"] = risks
        item["confidence_score"] = locators[0].get("score", 0) if locators else 0
        return item

    async def _validate_locator(self, frame, locator: dict) -> dict:
        started_at = time.perf_counter()
        result = dict(locator)
        try:
            playwright_locator = self.playwright_locator(frame, locator.get("exp"), locator.get("loc"))
            count = await playwright_locator.count()
            result["match_count"] = count
            result["unique"] = count == 1
            if count:
                first = playwright_locator.first
                for key, method in (
                    ("visible", "is_visible"),
                    ("enabled", "is_enabled"),
                    ("editable", "is_editable"),
                ):
                    try:
                        result[key] = await getattr(first, method)()
                    except Exception:
                        result[key] = None
            base_score = int(locator.get("base_score") or 0)
            result["score"] = max(0, min(100, base_score + (18 if count == 1 else 0) + (6 if result.get("visible") else 0) - (15 if count > 1 else 0)))
            result["verified"] = count > 0
        except Exception as error:
            result.update({
                "match_count": 0,
                "unique": False,
                "verified": False,
                "score": 0,
                "error_message": str(error),
            })
        result["locate_duration_ms"] = int((time.perf_counter() - started_at) * 1000)
        result.pop("base_score", None)
        return result

    @staticmethod
    def playwright_locator(frame, exp, loc: str):
        if int(exp) == 0:
            return frame.locator(f"xpath={loc}")
        if int(exp) == 9:
            return frame.locator(loc)
        return eval(f"frame.{loc}", {"frame": frame})

    @staticmethod
    def locator_suggestions(item: dict) -> list[dict]:
        suggestions: list[dict] = []
        attributes = item.get("attributes") or {}
        role = str(item.get("role") or "").strip()
        name = str(item.get("accessible_name") or item.get("label") or "").strip()
        placeholder = str(item.get("placeholder") or "").strip()
        text = str(item.get("text") or "").strip()
        element_id = str(item.get("id") or "").strip()
        css_path = str(item.get("css_path") or "").strip()
        xpath = str(item.get("xpath") or "").strip()

        def add(exp: int, loc: str, source: str, base_score: int):
            if loc and not any(row["exp"] == exp and row["loc"] == loc for row in suggestions):
                suggestions.append({
                    "exp": exp,
                    "loc": loc,
                    "source": source,
                    "base_score": base_score,
                })

        test_id = attributes.get("data-testid")
        if test_id:
            add(2, f"get_by_test_id({json.dumps(test_id, ensure_ascii=False)})", "testid", 76)
        for attr_name, score in (("data-test", 74), ("data-qa", 72)):
            value = attributes.get(attr_name)
            if value:
                add(9, f"[{attr_name}={json.dumps(value, ensure_ascii=False)}]", attr_name, score)
        if element_id:
            add(0, f"//*[@id={json.dumps(element_id, ensure_ascii=False)}]", "id_xpath", 74)
        if role and name:
            add(
                2,
                f"get_by_role({json.dumps(role, ensure_ascii=False)}, name={json.dumps(name, ensure_ascii=False)}, exact=True)",
                "role",
                68,
            )
        label = str(item.get("label") or "").strip()
        if label:
            add(2, f"get_by_label({json.dumps(label, ensure_ascii=False)}, exact=True)", "label", 66)
        if placeholder:
            add(2, f"get_by_placeholder({json.dumps(placeholder, ensure_ascii=False)}, exact=True)", "placeholder", 60)
        if text and len(text) <= 160:
            add(2, f"get_by_text({json.dumps(text, ensure_ascii=False)}, exact=True)", "text", 52)
        if css_path:
            add(9, css_path, "css_path", 42)
        if xpath:
            add(0, xpath, "xpath", 34)
        return suggestions[:7]
