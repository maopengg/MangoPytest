import time
from typing import Any

from .inspector import WebElementInspector


class WebStepRecorder:
    """与平台协议无关的 Playwright 录制动作执行器。"""

    CLICK_ACTIONS = {"click", "double_click", "right_click"}
    POINTER_ACTIONS = CLICK_ACTIONS | {"drag"}

    def __init__(self, inspector: WebElementInspector | None = None):
        self.inspector = inspector or WebElementInspector()

    async def poll_passive_events(self, page: Any) -> list[dict]:
        events = await page.evaluate(
            """() => {
                if (!window.__mangoRecorder) {
                    const state = { events: [], lastUrl: location.href };
                    const push = (event) => state.events.push({ ...event, at: Date.now(), url: location.href });
                    const captureChange = (event) => {
                        const target = event.target;
                        if (!(target instanceof HTMLElement)) return;
                        const rect = target.getBoundingClientRect();
                        if (target instanceof HTMLSelectElement) {
                            push({ action: 'select', value: target.value, x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 });
                        } else if (target instanceof HTMLInputElement && ['checkbox', 'radio'].includes(target.type)) {
                            push({ action: target.checked ? 'check' : 'uncheck', x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 });
                        }
                    };
                    document.addEventListener('change', captureChange, true);
                    for (const name of ['pushState', 'replaceState']) {
                        const original = history[name].bind(history);
                        history[name] = (...args) => { const result = original(...args); push({ action: 'navigation' }); return result; };
                    }
                    addEventListener('popstate', () => push({ action: 'navigation' }));
                    addEventListener('hashchange', () => push({ action: 'navigation' }));
                    window.__mangoRecorder = state;
                }
                const items = window.__mangoRecorder.events.splice(0, 100);
                if (window.__mangoRecorder.lastUrl !== location.href && !items.some((item) => item.action === 'navigation')) {
                    items.push({ action: 'navigation', url: location.href, at: Date.now() });
                }
                window.__mangoRecorder.lastUrl = location.href;
                return items;
            }"""
        )
        results = []
        for event in events or []:
            element = None
            if event.get("x") is not None and event.get("y") is not None:
                element = await self.inspector.pick(page, float(event["x"]), float(event["y"]))
            results.append({
                **event,
                "element": element,
                "input_value": event.get("value", ""),
                "page": {"page_id": str(id(page)), "title": await page.title(), "url": page.url},
                "passive": True,
            })
        return results

    async def execute(self, page: Any, action: dict) -> dict:
        started_at = time.perf_counter()
        action_type = str(action.get("action") or "")
        element = None
        if action_type in self.POINTER_ACTIONS:
            x, y = await self._coordinates(page, action)
            element = await self.inspector.pick(page, x, y)
        elif action_type in {"input", "key_press"}:
            element = await self._active_element(page)

        if action_type in self.CLICK_ACTIONS:
            button = "right" if action_type == "right_click" else str(action.get("button") or "left")
            await page.mouse.click(
                x,
                y,
                button=button,
                click_count=2 if action_type == "double_click" else 1,
            )
        elif action_type == "input":
            text = str(action.get("text") or "")[:2000]
            await page.keyboard.insert_text(text)
        elif action_type == "key_press":
            await page.keyboard.press(str(action.get("key") or "Enter")[:100])
        elif action_type == "scroll":
            await page.mouse.wheel(
                float(action.get("delta_x") or 0),
                float(action.get("delta_y") or 0),
            )
        elif action_type == "drag":
            to_x, to_y = await self._coordinates(
                page,
                {"x": action.get("to_x"), "y": action.get("to_y")},
            )
            await page.mouse.move(x, y)
            await page.mouse.down(button=str(action.get("button") or "left"))
            await page.mouse.move(to_x, to_y, steps=8)
            await page.mouse.up(button=str(action.get("button") or "left"))
        else:
            raise RuntimeError(f"不支持的录制动作：{action_type or '-'}")

        page_info = {
            "page_id": str(id(page)),
            "title": await page.title(),
            "url": page.url,
        }
        sensitive = bool((element or {}).get("sensitive_value_masked"))
        return {
            "action": action_type,
            "element": element,
            "input_value": "******" if sensitive else str(action.get("text") or ""),
            "sensitive": sensitive,
            "key": action.get("key"),
            "drag_delta_x": round(to_x - x, 2) if action_type == "drag" else None,
            "drag_delta_y": round(to_y - y, 2) if action_type == "drag" else None,
            "page": page_info,
            "duration_ms": int((time.perf_counter() - started_at) * 1000),
        }

    async def _active_element(self, page: Any) -> dict | None:
        box = await page.evaluate(
            """() => {
                const target = document.activeElement;
                if (!target || target === document.body) return null;
                const rect = target.getBoundingClientRect();
                return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
            }"""
        )
        if not box:
            return None
        return await self.inspector.pick(page, float(box["x"]), float(box["y"]))

    @staticmethod
    async def _coordinates(page: Any, action: dict) -> tuple[float, float]:
        viewport = page.viewport_size or await page.evaluate(
            "() => ({ width: window.innerWidth || 1280, height: window.innerHeight || 720 })"
        )
        return (
            max(0.0, min(1.0, float(action.get("x") or 0))) * float(viewport["width"]),
            max(0.0, min(1.0, float(action.get("y") or 0))) * float(viewport["height"]),
        )
