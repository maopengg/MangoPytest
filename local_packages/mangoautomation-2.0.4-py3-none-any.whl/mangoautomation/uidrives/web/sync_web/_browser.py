# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-04-25 22:33
# @Author : 毛鹏
import json
import os.path
import traceback
from urllib.parse import urlparse

import time
from playwright._impl._errors import TimeoutError, Error, TargetClosedError

from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import (
    ERROR_MSG_0010,
    ERROR_MSG_0013,
    ERROR_MSG_0049,
    ERROR_MSG_0058,
    ERROR_MSG_0059,
    ERROR_MSG_0064,
)
from mangoautomation.tools import Meta


class SyncWebBrowser(metaclass=Meta):
    """浏览器操作"""

    def __init__(self, base_data):
        self.base_data = base_data

    @staticmethod
    def _parse_json_value(value):
        if not isinstance(value, str):
            return value
        text = value.strip()
        if not text:
            return value
        if text[0] in '[{':
            return json.loads(text)
        return value

    @staticmethod
    def _parse_permissions(value):
        if isinstance(value, list):
            return value
        if isinstance(value, str):
            text = value.strip()
            if text.startswith('['):
                return json.loads(text)
            return [item.strip() for item in text.split(',') if item.strip()]
        return value

    @sync_method_callback('web', '浏览器操作', '强制等待', 0, [
        MethodModel(n='等待时间', f='_time', p='请输入等待时间', d=True)])
    def w_wait_for_timeout(self, _time):
        """强制等待"""
        time.sleep(int(_time))

    @sync_method_callback('web', '浏览器操作', '打开URL', 1, [
        MethodModel(n='url地址', f='url', p='请输入URL', d=True)])
    def w_goto(self, url):
        """打开URL"""
        try:
            result = urlparse(url)
            if not all([result.scheme, result.netloc]):
                raise MangoAutomationError(*ERROR_MSG_0049)
            self.base_data.page.goto(url, timeout=60000)
            self.base_data.page.wait_for_load_state("domcontentloaded")
        except TimeoutError as error:
            self.base_data.log.debug(f'打开URL失败-2，类型：{type(error)}，失败详情：{error}')
            raise MangoAutomationError(*ERROR_MSG_0013, value=(url,))
        except TargetClosedError as error:
            self.base_data.setup()
            self.base_data.log.debug(f'打开URL失败-2，类型：{type(error)}，失败详情：{error}')
            raise MangoAutomationError(*ERROR_MSG_0010, value=(url,))
        except Error as error:
            self.base_data.log.debug(
                f'打开URL失败-3，类型：{type(error)}，失败详情：{error}，失败明细：{traceback.format_exc()}')
            raise MangoAutomationError(*ERROR_MSG_0058, value=(url,))

    @sync_method_callback('web', '浏览器操作', '整个页面截图', 2, [
        MethodModel(n='保存路径', f='path', p='请输入截图名称', d=True)])
    def w_screenshot(self, path):
        """整个页面截图"""
        page = getattr(self.base_data, 'page', None)
        if page is None:
            raise MangoAutomationError(*ERROR_MSG_0010)
        screenshot_path = os.path.join(self.base_data.screenshot_path, path)
        try:
            try:
                page.screenshot(path=screenshot_path, full_page=True, timeout=10000)
            except TimeoutError as error:
                # 整页截图可能因页面过长或动态资源持续变化而超时，退化为当前视口截图。
                # 截图超时不代表浏览器关闭，不能清空仍然有效的页面上下文。
                self.base_data.log.warning(
                    f'整页截图超时，改用当前视口截图，失败详情：{error}')
                page.screenshot(path=screenshot_path, full_page=False, timeout=10000)
        except TargetClosedError as error:
            self.base_data.log.debug(
                f'截图时浏览器页面已关闭，类型：{type(error)}，失败详情：{error}，失败明细：{traceback.format_exc()}')
            self.base_data.setup()
            raise MangoAutomationError(*ERROR_MSG_0010)
        except (TimeoutError, AttributeError, Error) as error:
            self.base_data.log.warning(
                f'截图失败但浏览器上下文保持不变，类型：{type(error)}，失败详情：{error}')
            raise MangoAutomationError(*ERROR_MSG_0064)

    @sync_method_callback('web', '浏览器操作', '自动接受弹窗', 3)
    def w_accept_dialog(self):
        """自动接受弹窗"""
        self.base_data.page.on("dialog", lambda dialog: dialog.accept())

    @sync_method_callback('web', '浏览器操作', '自动取消弹窗', 4)
    def w_dismiss_dialog(self):
        """自动取消弹窗"""
        self.base_data.page.on("dialog", lambda dialog: dialog.dismiss())

    @sync_method_callback('web', '浏览器操作', '获取cookie', 5)
    def w_get_cookie(self):
        """获取cookie"""
        with open(os.path.join(self.base_data.download_path, 'storage_state.json'), 'w') as file:
            file.write(json.dumps(self.base_data.context.storage_state()))

    @sync_method_callback('web', '浏览器操作', '设置cookie', 6, [
        MethodModel(n='cookie', f='storage_state', p='请输入获取cookie方法中获取的内容', d=True)])
    def w_set_cookie(self, storage_state):
        """设置cookie"""
        if isinstance(storage_state, str):
            storage_state = json.loads(storage_state)
        else:
            raise MangoAutomationError(*ERROR_MSG_0059)
        self.base_data.context.add_cookies(storage_state['cookies'])
        for storage in storage_state.get('origins', []):
            local_storage = storage.get('localStorage', [])
            session_storage = storage.get('sessionStorage', [])
            for item in local_storage:
                self.base_data.context.add_init_script(
                    f"window.localStorage.setItem({json.dumps(item['name'])}, {json.dumps(item['value'])});")
            for item in session_storage:
                self.base_data.context.add_init_script(
                    f"window.sessionStorage.setItem({json.dumps(item['name'])}, {json.dumps(item['value'])});")
        self.base_data.page.reload()

    @sync_method_callback('web', '浏览器操作', '清除所有cookie', 7)
    def w_clear_cookies(self):
        """清除所有cookie"""
        self.base_data.context.clear_cookies()

    @sync_method_callback('web', '浏览器操作', '清除本地存储和会话存储', 8)
    def w_clear_storage(self):
        """清除本地存储和会话存储"""
        self.base_data.page.evaluate("() => localStorage.clear()")
        self.base_data.page.evaluate("() => sessionStorage.clear()")

    @sync_method_callback('web', '浏览器操作', '等待页面加载状态', 20, [
        MethodModel(n='状态', f='state', p='请输入 load、domcontentloaded、networkidle', d=True),
        MethodModel(n='超时时间毫秒', f='timeout', p='可选，默认30000')])
    def w_wait_for_load_state(self, state, timeout=30000):
        """等待页面加载状态"""
        self.base_data.page.wait_for_load_state(str(state), timeout=int(timeout or 30000))

    @sync_method_callback('web', '浏览器操作', '等待URL匹配', 21, [
        MethodModel(n='URL', f='url', p='请输入URL字符串或glob表达式', d=True),
        MethodModel(n='超时时间毫秒', f='timeout', p='可选，默认30000')])
    def w_wait_for_url(self, url, timeout=30000):
        """等待URL匹配"""
        self.base_data.page.wait_for_url(str(url), timeout=int(timeout or 30000))

    @sync_method_callback('web', '浏览器操作', '等待选择器状态', 22, [
        MethodModel(n='选择器', f='selector', p='请输入选择器', d=True),
        MethodModel(n='状态', f='state', p='可选，attached、detached、visible、hidden'),
        MethodModel(n='超时时间毫秒', f='timeout', p='可选，默认30000')])
    def w_wait_for_selector(self, selector, state='visible', timeout=30000):
        """等待选择器状态"""
        self.base_data.page.wait_for_selector(str(selector), state=str(state or 'visible'),
                                              timeout=int(timeout or 30000))

    @sync_method_callback('web', '浏览器操作', '等待JS条件成立', 23, [
        MethodModel(n='JS表达式', f='expression', p='请输入返回真值的JS表达式或函数', d=True),
        MethodModel(n='超时时间毫秒', f='timeout', p='可选，默认30000')])
    def w_wait_for_function(self, expression, timeout=30000):
        """等待JS条件成立"""
        self.base_data.page.wait_for_function(str(expression), timeout=int(timeout or 30000))

    @sync_method_callback('web', '浏览器操作', '设置浏览器视口', 24, [
        MethodModel(n='宽度', f='width', p='请输入视口宽度', d=True),
        MethodModel(n='高度', f='height', p='请输入视口高度', d=True)])
    def w_set_viewport_size(self, width, height):
        """设置浏览器视口"""
        self.base_data.page.set_viewport_size({'width': int(width), 'height': int(height)})

    @sync_method_callback('web', '浏览器操作', '设置额外请求头', 25, [
        MethodModel(n='请求头JSON', f='headers', p='请输入请求头JSON对象', d=True)])
    def w_set_extra_http_headers(self, headers):
        """设置额外请求头"""
        headers = self._parse_json_value(headers)
        if not isinstance(headers, dict):
            raise MangoAutomationError(*ERROR_MSG_0059)
        self.base_data.page.set_extra_http_headers(headers)

    @sync_method_callback('web', '浏览器操作', '注入初始化脚本', 26, [
        MethodModel(n='JS脚本', f='script', p='请输入初始化JS脚本', d=True)])
    def w_add_init_script(self, script):
        """注入初始化脚本"""
        self.base_data.context.add_init_script(str(script))

    @sync_method_callback('web', '浏览器操作', '执行JS脚本', 27, [
        MethodModel(n='JS脚本', f='script', p='请输入JS脚本', d=True),
        MethodModel(n='缓存的key', f='set_cache_key', p='可选，输入缓存key')])
    def w_evaluate(self, script, set_cache_key=None):
        """执行JS脚本"""
        value = self.base_data.page.evaluate(str(script))
        if set_cache_key:
            self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @sync_method_callback('web', '浏览器操作', '获取页面标题', 28, [
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    def w_get_title(self, set_cache_key):
        """获取页面标题"""
        value = self.base_data.page.title()
        self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @sync_method_callback('web', '浏览器操作', '获取当前URL', 29, [
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    def w_get_url(self, set_cache_key):
        """获取当前URL"""
        value = self.base_data.page.url
        self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @sync_method_callback('web', '浏览器操作', '获取页面HTML', 30, [
        MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    def w_content(self, set_cache_key):
        """获取页面HTML"""
        value = self.base_data.page.content()
        self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @sync_method_callback('web', '浏览器操作', '授权浏览器权限', 31, [
        MethodModel(n='权限列表', f='permissions', p='请输入权限列表，支持逗号分隔或JSON数组', d=True)])
    def w_grant_permissions(self, permissions):
        """授权浏览器权限"""
        self.base_data.context.grant_permissions(self._parse_permissions(permissions))

    @sync_method_callback('web', '浏览器操作', '清除浏览器权限', 32)
    def w_clear_permissions(self):
        """清除浏览器权限"""
        self.base_data.context.clear_permissions()
