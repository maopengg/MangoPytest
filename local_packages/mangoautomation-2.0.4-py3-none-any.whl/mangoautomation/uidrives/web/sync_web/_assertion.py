# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-04-26 22:25
# @Author : 毛鹏

import time

from playwright import sync_api

from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0021
from mangoautomation.tools import Meta
from mangoautomation.tools import sync_method_callback
from mangoautomation.models import MethodModel
from .._table_assertion import assert_table_rows, normalize_text


class SyncWebAssertion(metaclass=Meta):
    """元素断言"""

    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('ass_web', '页面内容', '包含文本', 0, [
        MethodModel(n='预期文本', f='expect', p='请输入页面应包含的文本', d=True)])
    def w_page_to_contain_text(self, expect):
        """页面包含文本"""
        body = self.base_data.page.locator('body')
        try:
            sync_api.expect(body).to_contain_text(str(expect))
        except AssertionError as e:
            raise AssertionError(f'页面未包含预期文本：{expect}') from e
        return f'页面包含预期文本：{expect}'

    @sync_method_callback('ass_web', '页面内容', '不包含文本', 1, [
        MethodModel(n='排除文本', f='expect', p='请输入页面不应包含的文本', d=True)])
    def w_page_not_to_contain_text(self, expect):
        """页面不包含文本"""
        body = self.base_data.page.locator('body')
        try:
            sync_api.expect(body).not_to_contain_text(str(expect))
        except AssertionError as e:
            raise AssertionError(f'页面包含了不应出现的文本：{expect}') from e
        return f'页面不包含文本：{expect}'

    @sync_method_callback('ass_web', '页面内容', '文本等于', 2, [
        MethodModel(n='预期文本', f='expect', p='请输入页面完整文本', d=True)])
    def w_page_to_have_text(self, expect):
        """页面文本等于"""
        body = self.base_data.page.locator('body')
        try:
            sync_api.expect(body).to_have_text(str(expect))
        except AssertionError as e:
            raise AssertionError(f'页面文本不等于预期文本：{expect}') from e
        return f'页面文本等于预期文本：{expect}'

    @sync_method_callback('ass_web', '页面内容', '文本不等于', 3, [
        MethodModel(n='排除文本', f='expect', p='请输入页面不应完全等于的文本', d=True)])
    def w_page_not_to_have_text(self, expect):
        """页面文本不等于"""
        body = self.base_data.page.locator('body')
        try:
            sync_api.expect(body).not_to_have_text(str(expect))
        except AssertionError as e:
            raise AssertionError(f'页面文本不应等于：{expect}') from e
        return f'页面文本不等于：{expect}'

    @sync_method_callback('ass_web', '页面内容', '文本出现次数等于', 4, [
        MethodModel(n='目标文本', f='expect', p='请输入需要统计的文本', d=True),
        MethodModel(n='预期次数', f='count', p='请输入预期出现次数', d=True)])
    def w_page_text_count_equal(self, expect, count):
        """页面文本出现次数等于"""
        expected_count = self._normalize_page_text_count(count)
        return self._wait_page_text_count(str(expect), expected_count, 'equal')

    @sync_method_callback('ass_web', '页面内容', '文本出现次数不少于', 5, [
        MethodModel(n='目标文本', f='expect', p='请输入需要统计的文本', d=True),
        MethodModel(n='最少次数', f='count', p='请输入最少出现次数', d=True)])
    def w_page_text_count_at_least(self, expect, count):
        """页面文本出现次数不少于"""
        expected_count = self._normalize_page_text_count(count)
        return self._wait_page_text_count(str(expect), expected_count, 'at_least')

    @sync_method_callback('ass_web', '页面内容', '文本出现次数不多于', 6, [
        MethodModel(n='目标文本', f='expect', p='请输入需要统计的文本', d=True),
        MethodModel(n='最多次数', f='count', p='请输入最多出现次数', d=True)])
    def w_page_text_count_at_most(self, expect, count):
        """页面文本出现次数不多于"""
        expected_count = self._normalize_page_text_count(count)
        return self._wait_page_text_count(str(expect), expected_count, 'at_most')

    @staticmethod
    def _normalize_page_text_count(count):
        expected_count = int(count)
        if expected_count < 0:
            raise ValueError('页面文本出现次数不能小于0')
        return expected_count

    def _wait_page_text_count(self, text, expected_count, comparison):
        if not text:
            raise ValueError('需要统计的页面文本不能为空')
        deadline = time.monotonic() + 5
        actual_count = 0
        while True:
            page_text = self.base_data.page.locator('body').inner_text()
            actual_count = page_text.count(text)
            if (
                (comparison == 'equal' and actual_count == expected_count)
                or (comparison == 'at_least' and actual_count >= expected_count)
                or (comparison == 'at_most' and actual_count <= expected_count)
            ):
                return f'文本【{text}】实际出现{actual_count}次，预期{self._page_text_count_expectation(comparison, expected_count)}'
            if time.monotonic() >= deadline:
                raise AssertionError(
                    f'文本【{text}】实际出现{actual_count}次，'
                    f'预期{self._page_text_count_expectation(comparison, expected_count)}'
                )
            self.base_data.page.wait_for_timeout(100)

    @staticmethod
    def _page_text_count_expectation(comparison, expected_count):
        labels = {
            'equal': f'等于{expected_count}次',
            'at_least': f'不少于{expected_count}次',
            'at_most': f'不多于{expected_count}次',
        }
        return labels[comparison]

    def _table_rows(self, actual):
        if actual is None:
            raise ValueError('请选择需要断言的表格元素')
        table = actual
        count = table.count()
        if count != 1:
            raise ValueError(f'表格元素必须唯一，实际匹配{count}个')
        headers = table.locator('thead th').all_inner_texts()
        body_rows = table.locator('tbody tr')
        if not headers:
            first_row = table.locator('tr').first
            headers = first_row.locator('th, td').all_inner_texts()
            rows = table.locator('tr')
            start = 1
        else:
            rows = body_rows
            start = 0
        cell_rows = [
            rows.nth(index).locator('th, td').all_inner_texts()
            for index in range(start, rows.count())
        ]
        return [normalize_text(header) for header in headers], cell_rows

    def _assert_table(self, actual, expect, comparison):
        headers, rows = self._table_rows(actual)
        return assert_table_rows(headers, rows, expect, comparison)

    @sync_method_callback('ass_web', '表格断言', '存在字段值完全匹配的行', 0, [
        MethodModel(f='actual'),
        MethodModel(n='字段和值', f='expect', p='请添加需要校验的表格字段和值', d=True,
                    v={'字段名': '预期值'}, value_type='object', input_type='key_value'),
    ])
    def w_table_row_values_equal(self, actual, expect):
        """表格存在字段值完全匹配的行"""
        return self._assert_table(actual, expect, 'equal')

    @sync_method_callback('ass_web', '表格断言', '存在字段值包含匹配的行', 1, [
        MethodModel(f='actual'),
        MethodModel(n='字段和值', f='expect', p='请添加需要校验的表格字段和值', d=True,
                    v={'字段名': '预期值'}, value_type='object', input_type='key_value'),
    ])
    def w_table_row_values_contain(self, actual, expect):
        """表格存在字段值包含匹配的行"""
        return self._assert_table(actual, expect, 'contains')

    @sync_method_callback('ass_web', '表格断言', '不存在字段值完全匹配的行', 2, [
        MethodModel(f='actual'),
        MethodModel(n='字段和值', f='expect', p='请添加需要校验的表格字段和值', d=True,
                    v={'字段名': '预期值'}, value_type='object', input_type='key_value'),
    ])
    def w_table_row_values_not_equal(self, actual, expect):
        """表格不存在字段值完全匹配的行"""
        return self._assert_table(actual, expect, 'not_equal')

    @sync_method_callback('ass_web', '元素断言', '元素是几个', 0, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入元素个数', d=True)])
    def w_to_have_count(self, actual, expect):
        """元素是几个"""
        try:
            sync_api.expect(actual).to_have_count(int(expect))
        except AssertionError as e:
            raise AssertionError(f'实际={actual.count()}, 预期={expect}') from e
        return f'实际={actual.count()}, 预期={expect}'

    @sync_method_callback('ass_web', '元素断言', '元素存在', 1, [MethodModel(f='actual')])
    def a_assert_ele_exists(self, actual):
        """元素存在"""
        count = 0 if actual is None else actual.count()
        if count == 0:
            assert False, f'实际={count}, 预期>0'
        return f'实际={count}, 预期>0'

    @sync_method_callback('ass_web', '元素断言', '元素不存在', 2, [MethodModel(f='actual')])
    def a_assert_ele_not_exists(self, actual):
        """等待元素从DOM中消失"""
        if actual is None:
            return '实际=0, 预期=0'
        try:
            sync_api.expect(actual).to_have_count(0)
        except AssertionError as e:
            raise AssertionError(f'实际={actual.count()}, 预期=0') from e
        count = actual.count()
        return f'实际={count}, 预期=0'

    @sync_method_callback('ass_web', '元素断言', '元素存在个数', 2, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入元素存在个数，预期不存在输入0', d=True)])
    def w_to_element_count(self, actual, expect):
        """元素存在个数"""
        expect = int(expect)
        if expect == 0:
            if actual is None:
                return f'实际=0, 预期={expect}'
            try:
                sync_api.expect(actual).to_have_count(0)
            except AssertionError as e:
                raise AssertionError(f'实际={actual.count()}, 预期={expect}') from e
            count = actual.count()
            return f'实际={count}, 预期={expect}'
        else:
            if actual:
                try:
                    sync_api.expect(actual).to_have_count(expect)
                    return f'实际={actual.count()}, 预期={expect}'
                except AssertionError as e:
                    raise AssertionError(f'实际={actual.count()}, 预期={expect}') from e
            else:
                raise MangoAutomationError(*ERROR_MSG_0021)

    @sync_method_callback('ass_web', '元素断言', '元素不包含文本', 3, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入不包含的文本', d=True)])
    def w_not_to_contain_text(self, actual, expect):
        """元素不包含文本"""
        try:
            sync_api.expect(actual).not_to_contain_text(expect)
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期={expect}') from e
        return f'实际={actual}, 预期={expect}'

    @sync_method_callback('ass_web', '元素断言', '元素不为空', 4, [MethodModel(f='actual')])
    def w_not_to_be_empty(self, actual):
        """元素不为空"""
        try:
            sync_api.expect(actual).not_to_be_empty()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=不为空') from e
        return f'实际={actual}, 预期=不为空'

    @sync_method_callback('ass_web', '元素断言', '元素不启用', 5, [MethodModel(f='actual')])
    def w_not_to_be_enabled(self, actual):
        """元素不启用"""
        try:
            sync_api.expect(actual).not_to_be_enabled()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=不启用') from e
        return f'实际={actual}, 预期=不启用'

    @sync_method_callback('ass_web', '元素断言', '元素不聚焦', 6, [MethodModel(f='actual')])
    def w_not_to_be_focused(self, actual):
        """元素不聚焦"""
        try:
            sync_api.expect(actual).not_to_be_focused()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=不聚焦') from e
        return f'实际={actual}, 预期=不聚焦'

    @sync_method_callback('ass_web', '元素断言', '元素不可隐藏', 7, [MethodModel(f='actual')])
    def w_not_to_be_hidden(self, actual):
        """元素不可隐藏"""
        try:
            sync_api.expect(actual).not_to_be_hidden()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=不可隐藏') from e
        return f'实际={actual}, 预期=不可隐藏'

    @sync_method_callback('ass_web', '元素断言', '元素不在视窗中', 8, [MethodModel(f='actual')])
    def w_not_to_be_in_viewport(self, actual):
        """元素不在视窗中"""
        try:
            sync_api.expect(actual).not_to_be_in_viewport()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=不在视窗中') from e
        return f'实际={actual}, 预期=不在视窗中'

    @sync_method_callback('ass_web', '元素断言', '元素不可见', 9, [MethodModel(f='actual')])
    def w_not_to_be_visible(self, actual):
        """元素不可见"""
        try:
            sync_api.expect(actual).not_to_be_visible()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=不可见') from e
        return f'实际={actual}, 预期=不可见'

    @sync_method_callback('ass_web', '元素断言', '元素没有阶级', 10, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入样式', d=True)])
    def w_not_to_have_class(self, actual, expect):
        """元素没有阶级"""
        try:
            sync_api.expect(actual).not_to_have_class(expect)
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=没有阶级') from e
        return f'实际={actual}, 预期=没有阶级'

    @sync_method_callback('ass_web', '元素断言', '复选框已选中', 11, [MethodModel(f='actual')])
    def w_to_be_checked(self, actual):
        """复选框已选中"""
        try:
            sync_api.expect(actual).to_be_checked()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=复选框已选中') from e
        return f'实际={actual}, 预期=复选框已选中'

    @sync_method_callback('ass_web', '元素断言', '元素已禁用', 12, [MethodModel(f='actual')])
    def w_to_be_disabled(self, actual):
        """元素已禁用"""
        try:
            sync_api.expect(actual).to_be_disabled()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=已禁用') from e
        return f'实际={actual}, 预期=已禁用'

    @sync_method_callback('ass_web', '元素断言', '元素已启用', 13, [MethodModel(f='actual')])
    def w_to_be_enabled(self, actual):
        """元素已启用"""
        try:
            sync_api.expect(actual).to_be_enabled()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=已启用') from e
        return f'实际={actual}, 预期=已启用'

    @sync_method_callback('ass_web', '元素断言', '元素可编辑', 14, [MethodModel(f='actual')])
    def w_to_be_editable(self, actual):
        """元素可编辑"""
        try:
            sync_api.expect(actual).to_be_editable()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=可编辑') from e
        return f'实际={actual}, 预期=可编辑'

    @sync_method_callback('ass_web', '元素断言', '元素为空', 15, [MethodModel(f='actual')])
    def w_to_be_empty(self, actual):
        """元素为空"""
        if actual is None:
            assert True, f'实际={actual}, 预期=为空'
            return f'实际={actual}, 预期=为空'

        else:
            try:
                sync_api.expect(actual).to_be_empty()
                return f'实际={actual}, 预期=为空'
            except AssertionError as e:
                raise AssertionError(f'实际={actual}, 预期=为空') from e

    @sync_method_callback('ass_web', '元素断言', '元素可见', 16, [MethodModel(f='actual')])
    def w_to_be_visible(self, actual):
        """元素可见"""
        try:
            sync_api.expect(actual).to_be_visible()
        except AssertionError as e:
            raise AssertionError(f'实际={actual}, 预期=可见') from e
        return f'实际={actual}, 预期=可见'

    # @staticmethod
    # def w_not_to_have_actuals(actual, actuals: list):
    #     """选择已选择选项"""
    #     expect(actual).to_have_actuals(actuals)

    # @staticmethod
    # def w_not_to_have_attribute(locating, name, actual):
    #     """元素不具有属性"""
    #     exp(locating).not_to_have_attribute(name, actual)
    # @staticmethod

    # @staticmethod
    # def w_not_to_have_css(locating, name, actual):
    #     """元素不使用CSS"""
    #     exp(locating).not_to_have_css(name, actual)

    # @staticmethod
    # def w_not_to_have_id(locating, _id):
    #     """元素没有ID"""
    #     exp(locating).not_to_have_id(_id)
    #
    # @staticmethod
    # def w_not_to_have_js_property(locating, name, actual):
    #     """元素不具有js属性"""
    #     exp(locating).not_to_have_js_property(name, actual)
    #
    # @staticmethod
    # def w_not_to_have_text(locating, expected):
    #     """元素没有文本"""
    #     exp(locating).not_to_have_text(expected)

    # @staticmethod
    # def w_not_to_have_actual(locating, actual):
    #     """元素无价值"""
    #     exp(locating).not_to_have_actual(actual)

    #
    # def w_to_be_attached(self, hidden_text):
    #     """待连接"""
    #     exp(self.page.get_by_text(hidden_text)).to_be_attached()

    #
    # def w_to_be_editable(self, hidden_text):
    #     """可编辑"""
    #     locator = self.page.get_by_role("textbox")
    #     exp(locator).to_be_editable()

    # def w_to_be_enabled(self, hidden_text):
    #     """为空"""
    #     locator = self.page.locator("button.submit")
    #     exp(locator).to_be_enabled()

    # def w_to_be_focused(self, hidden_text):
    #     """聚焦"""
    #     locator = self.page.get_by_role("textbox")
    #     exp(locator).to_be_focused()
    #
    # def w_to_be_hidden(self, hidden_text):
    #     """隐藏"""
    #     locator = self.page.locator('.my-element')
    #     exp(locator).to_be_hidden()
    #
    # def w_to_be_in_viewport(self, hidden_text):
    #     """待在视口中"""
    #     locator = self.page.get_by_role("button")
    #     # Make sure at least some part of element intersects viewport.
    #     exp(locator).to_be_in_viewport()
    #     # Make sure element is fully outside of viewport.
    #     exp(locator).not_to_be_in_viewport()
    #     # Make sure that at least half of the element intersects viewport.
    #     exp(locator).to_be_in_viewport(ratio=0.5)
    #

    # def w_to_contain_text(self, hidden_text):
    #     """包含文本"""
    #     locator = self.page.locator('.title')
    #     exp(locator).to_contain_text("substring")
    #     exp(locator).to_contain_text(re.compile(r"\d messages"))
    #
    # def w_to_have_attribute(self, hidden_text):
    #     """具有属性"""
    #     locator = self.page.locator("input")
    #     exp(locator).to_have_attribute("type", "text")
    #
    # def w_to_have_class(self, hidden_text):
    #     """到保存类别"""
    #     locator = self.page.locator("#component")
    #     exp(locator).to_have_class(re.compile(r"selected"))
    #     exp(locator).to_have_class("selected row")
    #
    # def w_to_have_count(self, hidden_text):
    #     """有计数"""
    #     locator = self.page.locator("list > .component")
    #     exp(locator).to_have_count(3)
    #
    # def w_to_have_css(self, hidden_text):
    #     """使用CSS"""
    #     locator = self.page.get_by_role("button")
    #     exp(locator).to_have_css("display", "flex")
    #
    # def w_to_have_id(self, hidden_text):
    #     """到id"""
    #     locator = self.page.get_by_role("textbox")
    #     exp(locator).to_have_id("lastname")
    #
    # def w_to_have_js_property(self, hidden_text):
    #     """拥有js属性"""
    #     locator = self.page.locator(".component")
    #     exp(locator).to_have_js_property("loaded", True)
    #
    # def w_to_have_text(self, hidden_text):
    #     """有文本"""
    #     locator = self.page.locator(".title")
    #     exp(locator).to_have_text(re.compile(r"Welcome, Test User"))
    #     exp(locator).to_have_text(re.compile(r"Welcome, .*"))
    #
    # def w_to_have_actual(self, hidden_text):
    #     """有价值"""
    #     locator = self.page.locator("input[type=number]")
    #     exp(locator).to_have_actual(re.compile(r"[0-9]"))
