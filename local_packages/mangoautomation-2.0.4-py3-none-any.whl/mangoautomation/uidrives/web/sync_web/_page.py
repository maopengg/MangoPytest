# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-04-25 22:33
# @Author : 毛鹏
import time
from playwright.sync_api import Locator

from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback
from mangoautomation.tools import Meta


class SyncWebPage(metaclass=Meta):
    """页面操作"""

    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('web', '页面操作', '切换页签', 0, [
        MethodModel(n='页签下标', f='individual', p='请输入页签下标，从1开始数', d=True)])
    def w_switch_tabs(self, individual):
        """切换页签"""
        pages = self.base_data.context.pages
        self.base_data.log.debug(f'当前总下标个数：{len(pages)}，需要跳转到：{int(individual) - 1} 页')
        pages[int(individual) - 1].bring_to_front()
        self.base_data.page = pages[int(individual) - 1]
        time.sleep(1)

    @sync_method_callback('web', '页面操作', '关闭当前页签', 1)
    def w_close_current_tab(self):
        """关闭当前页签"""
        time.sleep(2)
        pages = self.base_data.context.pages
        pages[-1].close()
        self.base_data.page = pages[0]

    @sync_method_callback('web', '页面操作', '点击并打开新页签', 2, [MethodModel(f='locating')])
    def w_open_new_tab_and_switch(self, locating):
        """点击并打开新页签"""
        with self.base_data.context.expect_page() as new_page_info:
            locating.first.click()
        new_page = new_page_info.value
        new_page.bring_to_front()
        self.base_data.page = new_page
        new_page.wait_for_load_state("domcontentloaded")

    @sync_method_callback('web', '页面操作', '刷新页面', 3)
    def w_refresh(self):
        """刷新页面"""
        self.base_data.page.reload()

    @sync_method_callback('web', '页面操作', '返回上一页', 4)
    def w_go_back(self):
        """返回上一页"""
        self.base_data.page.go_back()

    @sync_method_callback('web', '页面操作', '前进到下一页', 5)
    def w_go_forward(self):
        """前进到下一页"""
        self.base_data.page.go_forward()

    @sync_method_callback('web', '页面操作', '新建页签', 20)
    def w_new_page(self):
        """新建页签"""
        self.base_data.page = self.base_data.context.new_page()
        self.base_data.page.bring_to_front()

    @sync_method_callback('web', '页面操作', '关闭指定页签', 21, [
        MethodModel(n='页签下标', f='individual', p='请输入页签下标，从1开始数', d=True)])
    def w_close_page_by_index(self, individual):
        """关闭指定页签"""
        pages = self.base_data.context.pages
        index = int(individual) - 1
        pages[index].close()
        pages = self.base_data.context.pages
        if pages:
            self.base_data.page = pages[min(index, len(pages) - 1)]
            self.base_data.page.bring_to_front()

    @sync_method_callback('web', '页面操作', '切换到最新页签', 22)
    def w_switch_latest_tab(self):
        """切换到最新页签"""
        pages = self.base_data.context.pages
        self.base_data.page = pages[-1]
        self.base_data.page.bring_to_front()
