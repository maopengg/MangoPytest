# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-04-29 12:11
# @Author : 毛鹏
from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback
from mangoautomation.tools import Meta


class SyncWebDeviceInput(metaclass=Meta):
    """输入设备"""

    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('web', '输入设备', '模拟按下指定的键', 0, [
        MethodModel(n='按键值', f='keyboard', p='请输入键盘名称，首字母大写', d=True)])
    def w_keys(self, keyboard):
        """模拟按下指定的键"""
        self.base_data.page.keyboard.press(str(keyboard))

    @sync_method_callback('web', '输入设备', '鼠标上下滚动像素，负数代表向上', 1, [
        MethodModel(n='y坐标', f='y', p='请输入向上滚动像素', d=True)])
    def w_wheel(self, y):
        """鼠标上下滚动像素，负数代表向上"""
        self.base_data.page.mouse.wheel(0, int(y))

    @sync_method_callback('web', '输入设备', '鼠标点击坐标', 2, [
        MethodModel(n='x坐标', f='x', p='请输入点击的x轴', d=True),
        MethodModel(n='y坐标', f='y', p='请输入点击的y轴', d=True)])
    def w_mouse_click(self, x, y):
        """鼠标点击坐标"""
        self.base_data.page.mouse.click(float(x), float(y))

    def __get_viewport_center(self):
        viewport_size = self.base_data.page.evaluate('''() => {
            return {
                width: window.innerWidth,
                height: window.innerHeight
            }
        }''')
        return viewport_size['width'] / 2, viewport_size['height'] / 2

    @sync_method_callback('web', '输入设备', '鼠标移动到中间', 3)
    def w_mouse_move_center(self):
        """鼠标移动到中间"""
        center_x, center_y = self.__get_viewport_center()
        self.base_data.page.mouse.move(center_x, center_y)

    @sync_method_callback('web', '输入设备', '鼠标移动到中间并点击', 4)
    def w_mouse_click_center(self):
        """鼠标移动到中间并点击"""
        center_x, center_y = self.__get_viewport_center()
        self.base_data.page.mouse.click(center_x, center_y)

    @sync_method_callback('web', '输入设备', '模拟人工输入文字', 5, [
        MethodModel(n='输入文本', f='text', p='请输入键盘输入的内容', d=True)])
    def w_keyboard_type_text(self, text):
        """模拟人工输入文字"""
        self.base_data.page.keyboard.type(str(text))

    @sync_method_callback('web', '输入设备', '直接输入文字', 6, [
        MethodModel(n='输入文本', f='text', p='请输入键盘输入的内容', d=True)])
    def w_keyboard_insert_text(self, text):
        """直接输入文字"""
        self.base_data.page.keyboard.insert_text(str(text))

    @sync_method_callback('web', '输入设备', '删除光标左侧的字符', 7, [
        MethodModel(n='删除个数', f='count', p='请输入要删除字符串的个数', d=True)])
    def w_keyboard_delete_text(self, count):
        """删除光标左侧的字符"""
        for _ in range(0, int(count)):
            self.base_data.page.keyboard.press("Backspace")

    @sync_method_callback('web', '输入设备', '按下键盘按键', 20, [
        MethodModel(n='按键值', f='key', p='请输入按键值，例如 Shift、Control', d=True)])
    def w_keyboard_down(self, key):
        """按下键盘按键"""
        self.base_data.page.keyboard.down(str(key))

    @sync_method_callback('web', '输入设备', '松开键盘按键', 21, [
        MethodModel(n='按键值', f='key', p='请输入按键值，例如 Shift、Control', d=True)])
    def w_keyboard_up(self, key):
        """松开键盘按键"""
        self.base_data.page.keyboard.up(str(key))

    @sync_method_callback('web', '输入设备', '键盘快捷键', 22, [
        MethodModel(n='快捷键', f='shortcut', p='请输入快捷键，例如 Control+A', d=True)])
    def w_keyboard_shortcut(self, shortcut):
        """键盘快捷键"""
        self.base_data.page.keyboard.press(str(shortcut))

    @sync_method_callback('web', '输入设备', '鼠标移动到坐标', 23, [
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def w_mouse_move(self, x, y):
        """鼠标移动到坐标"""
        self.base_data.page.mouse.move(float(x), float(y))

    @sync_method_callback('web', '输入设备', '鼠标按下', 24)
    def w_mouse_down(self):
        """鼠标按下"""
        self.base_data.page.mouse.down()

    @sync_method_callback('web', '输入设备', '鼠标松开', 25)
    def w_mouse_up(self):
        """鼠标松开"""
        self.base_data.page.mouse.up()

    @sync_method_callback('web', '输入设备', '鼠标双击坐标', 26, [
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def w_mouse_dblclick(self, x, y):
        """鼠标双击坐标"""
        self.base_data.page.mouse.dblclick(float(x), float(y))

    @sync_method_callback('web', '输入设备', '鼠标右键点击坐标', 27, [
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def w_mouse_right_click(self, x, y):
        """鼠标右键点击坐标"""
        self.base_data.page.mouse.click(float(x), float(y), button='right')

    @sync_method_callback('web', '输入设备', '鼠标横纵滚动像素', 28, [
        MethodModel(n='横向滚动像素', f='x', p='请输入横向滚动像素', d=True),
        MethodModel(n='纵向滚动像素', f='y', p='请输入纵向滚动像素', d=True)])
    def w_mouse_wheel_xy(self, x, y):
        """鼠标横纵滚动像素"""
        self.base_data.page.mouse.wheel(float(x), float(y))
