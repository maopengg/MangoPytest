# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2024-04-24 10:43
# @Author : 毛鹏
import threading
import traceback
from typing import Optional

import time
from playwright._impl._errors import Error
from playwright.sync_api import sync_playwright, Page, BrowserContext, Browser, Playwright, Request, Route

from mangoautomation.enums import BrowserTypeEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0057, ERROR_MSG_0008, ERROR_MSG_0062, ERROR_MSG_0009
from mangoautomation.uidrives.web.browser_path import find_browser_path, search_browser_path
from mangoautomation.uidrives.web.browser_compatibility import (
    AUTOMATION_COMPATIBILITY_INIT_SCRIPT,
    apply_browser_compatibility_launch_args,
)
from mangoautomation.uidrives.web.static_cache import StaticResourceCache

DEFAULT_WINDOW_WIDTH = 1440
DEFAULT_WINDOW_HEIGHT = 900


class SyncWebNewBrowser:

    def __init__(self,
                 web_type,
                 web_path=None,
                 web_max=False,
                 web_headers=False,
                 web_recording=False,
                 web_h5=None,
                 is_header_intercept=False,
                 web_is_default=False,
                 videos_path=None,
                 static_cache_enabled=False,
                 static_cache_path=None,
                 log=None,
                 **kwargs
                 ):
        self.lock = threading.Lock()
        self.web_type = web_type
        self.web_path = web_path
        self.web_max = web_max
        self.web_headers = web_headers
        self.web_recording = web_recording
        self.web_h5 = web_h5
        self.web_is_default = web_is_default
        self.videos_path = videos_path
        self.is_header_intercept = is_header_intercept
        self.static_cache = StaticResourceCache(static_cache_path if static_cache_enabled else None, log)
        self.log = log
        self.kwargs = kwargs
        self.browser: Optional[None | Browser] = None
        self.playwright: Optional[None | Playwright] = None

    def new_web_page(self, count=0) -> tuple[BrowserContext, Page]:
        if self.browser is None:
            with self.lock:
                if self.browser is None:
                    self.log.debug(f'[浏览器初始化] 开始创建浏览器实例 (类型: {self.web_type})')
                    self.browser = self.new_browser()
                    time.sleep(1)
                    self.log.debug('[浏览器初始化] 浏览器实例创建成功')
        try:
            self.log.debug(f'[页面创建] 开始创建新页面 (重试次数: {count}/3)')
            context = self.new_context()
            page = self.new_page(context)
            self.log.debug('[页面创建] 页面和上下文创建成功')
            return context, page
        except Exception as e:
            self.log.error(f'[页面创建失败] 创建页面失败 (重试: {count}/3)，错误: {str(e)}\n{traceback.format_exc()}')
            self.browser = None
            if count >= 3:
                self.log.error('[页面创建失败] 已达到最大重试次数(3次)，放弃创建')
                raise MangoAutomationError(*ERROR_MSG_0057)
            else:
                self.log.debug(f'[页面创建] 准备第 {count + 1} 次重试')
                return self.new_web_page(count=count + 1)

    def new_browser(self) -> Browser:
        self.log.debug('[Playwright启动] 正在启动Playwright')
        self.playwright = sync_playwright().start()
        
        if self.web_type == BrowserTypeEnum.CHROMIUM.value or self.web_type == BrowserTypeEnum.EDGE.value:
            browser = self.playwright.chromium
            browser_name = 'Chromium/Edge'
        elif self.web_type == BrowserTypeEnum.FIREFOX.value:
            browser = self.playwright.firefox
            browser_name = 'Firefox'
        elif self.web_type == BrowserTypeEnum.WEBKIT.value:
            browser = self.playwright.webkit
            browser_name = 'WebKit'
        else:
            self.log.error(f'[浏览器类型错误] 不支持的浏览器类型: {self.web_type}')
            raise MangoAutomationError(*ERROR_MSG_0008)
        
        self.log.debug(f'[浏览器选择] 已选择浏览器: {browser_name}')
        
        if self.web_is_default:
            try:
                launch_args = apply_browser_compatibility_launch_args(self.web_type, {})
                result = browser.launch(**launch_args)
                return result
            except Error as error:
                self.log.error(f'[浏览器启动失败] 使用默认配置启动失败: {str(error)}\n{traceback.format_exc()}')
                raise MangoAutomationError(*ERROR_MSG_0062)
        else:
            try:
                launch_args = {
                    "headless": self.web_headers,
                }
                browser_path = self.web_path if self.web_path else find_browser_path(self.web_type, self.log)
                if browser_path:
                    launch_args["executable_path"] = browser_path
                if self.web_max:
                    if "args" in launch_args:
                        launch_args["args"].append('--start-maximized')
                    else:
                        launch_args["args"] = ['--start-maximized']
                elif self.web_type in (BrowserTypeEnum.CHROMIUM.value, BrowserTypeEnum.EDGE.value):
                    launch_args["args"] = [
                        f'--window-size={DEFAULT_WINDOW_WIDTH},{DEFAULT_WINDOW_HEIGHT}'
                    ]

                launch_path = browser_path if browser_path else 'Playwright默认浏览器'
                self.log.debug(f'[浏览器启动] 启动参数: headless={self.web_headers}, max={self.web_max}, path={launch_path}')
                launch_args = apply_browser_compatibility_launch_args(self.web_type, launch_args)
                result = browser.launch(**launch_args)
                return result
            except Error as error:
                self.log.error(f'[浏览器启动失败] 启动失败，路径: {self.web_path}，错误: {str(error)}\n{traceback.format_exc()}')
                raise MangoAutomationError(*ERROR_MSG_0009, value=(self.web_path,))

    def new_context(self) -> BrowserContext:
        args_dict = {'ignore_https_errors': True}
        if self.web_is_default:
            args_dict["viewport"] = {"width": 1920, "height": 1080}
            self.log.debug('[上下文配置] 使用默认视口: 1920x1080')
        if self.web_h5:
            args_dict.update(self.playwright.devices[self.web_h5])
            self.log.debug(f'[上下文配置] 使用H5设备模拟: {self.web_h5}')
        if not (self.web_is_default or self.web_h5):
            if self.web_max:
                args_dict["no_viewport"] = True
                self.log.debug('[上下文配置] 浏览器最大化，不限制视口大小')
            else:
                args_dict["viewport"] = {"width": DEFAULT_WINDOW_WIDTH, "height": DEFAULT_WINDOW_HEIGHT}
                self.log.debug(
                    f'[上下文配置] 使用默认横向视口: {DEFAULT_WINDOW_WIDTH}x{DEFAULT_WINDOW_HEIGHT}'
                )
        if self.web_recording and self.videos_path:
            args_dict["record_video_dir"] = self.videos_path
            self.log.debug(f'[上下文配置] 启用视频录制: {self.videos_path}')
        
        timeout = int(self.kwargs.get('set_default_timeout', 3)) * 1000
        self.log.debug(f'[上下文配置] 设置默认超时: {timeout}ms')
        
        context = self.browser.new_context(**args_dict)
        context.add_init_script(script=AUTOMATION_COMPATIBILITY_INIT_SCRIPT)
        context.set_default_timeout(timeout)
        self.log.debug('[上下文配置] 已应用统一浏览器兼容配置')
        return context

    def new_page(self, context: BrowserContext) -> Page:
        try:
            page = context.new_page()
            timeout = int(self.kwargs.get('set_default_timeout', 3)) * 1000
            page.set_default_timeout(timeout)
            self.log.debug(f'[页面配置] 页面超时设置: {timeout}ms')
            
            if self.static_cache.enabled or self.is_header_intercept:
                page.route("**/*", self.route_request)
                if self.static_cache.enabled:
                    self.log.debug(f'[页面配置] 已启用静态资源缓存: {self.static_cache.cache_path}')
                if self.is_header_intercept:
                    self.log.debug('[页面配置] 已启用请求拦截')
            
            return page
        except Error as error:
            self.log.error(f'[页面创建失败] 创建Page对象失败: {str(error)}\n{traceback.format_exc()}')
            raise MangoAutomationError(*ERROR_MSG_0009, value=(self.web_path,))

    def close(self):
        if self.browser:
            self.log.debug('[浏览器关闭] 正在关闭浏览器')
            self.browser.close()
            self.log.debug('[浏览器关闭] 浏览器已关闭')

    def __search_path(self, ):
        return search_browser_path(self.web_type, self.log)

    def route_request(self, route: Route, request: Request):
        if self.static_cache.can_cache_request(request):
            cache_item = self.static_cache.read(request)
            if cache_item:
                route.fulfill(**cache_item)
                return
            response = route.fetch()
            body = response.body()
            self.static_cache.write(request, response.status, response.headers, body)
            route.fulfill(
                status=response.status,
                headers=StaticResourceCache._safe_headers(response.headers),
                body=body,
            )
            return
        if self.is_header_intercept:
            self.wen_intercept_request(route, request)
            return
        route.continue_()

    def wen_intercept_request(self, route: Route, request: Request):
        pass

    def wen_recording_api(self, request: Request, project_product):
        pass
