# -*- coding: utf-8 -*-
from mangoautomation.uidrives.pc.new_windows import NewWindows


class DesktopRuntime:
    def __init__(self, win_path: str, win_title: str, log=None):
        self.win_path = win_path
        self.win_title = win_title
        self.log = log
        self.driver = None

    def connect(self):
        if self.driver is None:
            self.driver = NewWindows(self.win_path, self.win_title)
        return self.driver

    def close(self):
        self.driver = None
