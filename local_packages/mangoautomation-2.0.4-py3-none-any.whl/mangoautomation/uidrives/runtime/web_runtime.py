# -*- coding: utf-8 -*-
from mangoautomation.uidrives.web.async_web import AsyncWebNewBrowser
from mangoautomation.uidrives.web.sync_web import SyncWebNewBrowser


class AsyncWebRuntime:
    def __init__(self, **kwargs):
        self.browser_runtime = AsyncWebNewBrowser(**kwargs)

    @property
    def web_recording(self):
        return self.browser_runtime.web_recording

    @property
    def browser(self):
        return self.browser_runtime.browser

    @browser.setter
    def browser(self, value):
        self.browser_runtime.browser = value

    @property
    def is_header_intercept(self):
        return self.browser_runtime.is_header_intercept

    @is_header_intercept.setter
    def is_header_intercept(self, value):
        self.browser_runtime.is_header_intercept = value

    @property
    def wen_intercept_request(self):
        return self.browser_runtime.wen_intercept_request

    @wen_intercept_request.setter
    def wen_intercept_request(self, value):
        self.browser_runtime.wen_intercept_request = value

    @property
    def wen_recording_api(self):
        return self.browser_runtime.wen_recording_api

    @wen_recording_api.setter
    def wen_recording_api(self, value):
        self.browser_runtime.wen_recording_api = value

    async def new_context_page(self):
        return await self.browser_runtime.new_web_page()

    async def close(self):
        await self.browser_runtime.close()


class SyncWebRuntime:
    def __init__(self, **kwargs):
        self.browser_runtime = SyncWebNewBrowser(**kwargs)

    @property
    def web_recording(self):
        return self.browser_runtime.web_recording

    @property
    def browser(self):
        return self.browser_runtime.browser

    @browser.setter
    def browser(self, value):
        self.browser_runtime.browser = value

    def new_context_page(self):
        return self.browser_runtime.new_web_page()

    def close(self):
        self.browser_runtime.close()
