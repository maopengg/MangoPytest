# -*- coding: utf-8 -*-
from mangoautomation.uidrives.android import NewAndroid


class AndroidRuntime:
    def __init__(self, equipment: str):
        self.equipment = equipment
        self.connector = NewAndroid(equipment)
        self.device = None

    def connect(self):
        if self.device is None:
            self.device = self.connector.new_android()
        return self.device

    def close(self):
        self.connector.close_android()
        self.device = None
