# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-09-09 23:17
# @Author : 毛鹏
import time
from ast import literal_eval

from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0046
from mangoautomation.tools import Meta


class AndroidApplication(metaclass=Meta):
    """应用操作"""

    def __init__(self, base_data):
        self.base_data = base_data

    def is_app_installed(self, package_name) -> bool:
        result = self.base_data.android.shell("pm list packages")
        output = getattr(result, 'output', result)
        return f'package:{package_name}' in str(output)

    @sync_method_callback('android', '应用操作', '启动应用', 0,
                          [MethodModel(n='包名', f='package_name', p='请输入应用名称', d=True)])
    def a_start_app(self, package_name):
        """启动应用"""
        if not package_name:
            raise MangoAutomationError(*ERROR_MSG_0046)
        if not self.is_app_installed(package_name):
            raise MangoAutomationError(*ERROR_MSG_0046)
        self.base_data.android.app_start(package_name)
        time.sleep(4)

    @sync_method_callback('android', '应用操作', '关闭应用', 1, [
        MethodModel(n='包名', f='package_name', p='请输入应用名称', d=True)])
    def a_close_app(self, package_name):
        """关闭应用"""
        if not package_name:
            raise MangoAutomationError(*ERROR_MSG_0046)
        if not self.is_app_installed(package_name):
            raise MangoAutomationError(*ERROR_MSG_0046)

        self.base_data.android.app_stop(package_name)

    @sync_method_callback('android', '应用操作', '清除app数据', 2, [
        MethodModel(n='包名', f='package_name', p='请输入应用名称', d=True)])
    def a_clear_app(self, package_name):
        """清除app数据"""
        if not package_name:
            raise MangoAutomationError(*ERROR_MSG_0046)
        if not self.is_app_installed(package_name):
            raise MangoAutomationError(*ERROR_MSG_0046)

        self.base_data.android.app_clear(package_name)

    @sync_method_callback('android', '应用操作', '停止所有app', 3)
    def a_app_stop_all(self):
        """停止所有app"""
        self.base_data.android.app_stop_all()

    @sync_method_callback('android', '应用操作', '停止除指定app外所有app', 4, [
        MethodModel(n='包名List', f='package_name_list', p='请输入应用名称列表', d=True)])
    def a_app_stop_appoint(self, package_name_list):
        """停止除指定app外所有app"""
        if isinstance(package_name_list, str):
            try:
                package_name_list = literal_eval(package_name_list)
            except (ValueError, SyntaxError):
                package_name_list = [i.strip() for i in package_name_list.split(',') if i.strip()]
        for i in list(package_name_list):
            if not self.is_app_installed(i):
                raise MangoAutomationError(*ERROR_MSG_0046)
        self.base_data.android.app_stop_all(excludes=package_name_list)
