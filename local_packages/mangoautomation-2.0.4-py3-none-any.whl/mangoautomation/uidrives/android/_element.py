# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-09-09 23:17
# @Author : 毛鹏
import os.path

import time
from uiautomator2 import UiObject
from uiautomator2.xpath import XPathSelector

from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0043, ERROR_MSG_0044
from mangoautomation.tools import Meta


class AndroidElement(metaclass=Meta):
    """元素操作"""

    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('android', '元素操作', '元素单击', 0, [
        MethodModel(f='locating')])
    def a_click(self, locating):
        """元素单击"""
        locating.click()

    @sync_method_callback('android', '元素操作', '元素双击', 1, [
        MethodModel(f='locating')])
    def a_double_click(self, locating):
        """元素双击"""
        x, y = locating.center()
        self.base_data.android.double_click(x, y)

    @sync_method_callback('android', '元素操作', '单击输入', 2, [
        MethodModel(n='输入文本', f='locating'), MethodModel(f='text', p='请输入内容', d=True)])
    def a_input(self, locating, text):
        """单击输入"""
        locating.click()
        self.base_data.android.set_fastinput_ime(True)
        time.sleep(1)
        self.base_data.android.send_keys(text)

    @sync_method_callback('android', '元素操作', '设置文本', 3, [
        MethodModel(f='locating'), MethodModel(n='设置文本', f='text', p='请输入内容', d=True)])
    def a_set_text(self, locating, text):
        """设置文本"""
        locating.set_text(text)

    @sync_method_callback('android', '元素操作', '坐标单击', 4, [
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def a_click_coord(self, x, y):
        """坐标单击"""
        self.base_data.android.click(float(x), float(y))

    @sync_method_callback('android', '元素操作', '坐标双击', 5, [
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def a_double_click_coord(self, x, y):
        """坐标双击"""
        self.base_data.android.double_click(float(x), float(y))

    @sync_method_callback('android', '元素操作', '长按元素', 6, [
        MethodModel(f='locating'),
        MethodModel(n='长按时间', f='time_', p='请输入长按时间', d=True)])
    def a_long_click(self, locating, time_):
        """长按元素"""
        locating.long_click(duration=float(time_))

    @sync_method_callback('android', '元素操作', '清空输入框', 7, [MethodModel(f='locating')])
    def a_clear_text(self, locating):
        """清空输入框"""
        locating.clear_text()

    @sync_method_callback('android', '元素操作', '获取元素文本', 8, [
        MethodModel(f='locating'), MethodModel(n='缓存的key', f='set_cache_key', p='请输入元素文本存储的key', d=True)])
    def a_get_text(self, locating, set_cache_key=None):
        """获取元素文本"""
        value = locating.get_text()
        if set_cache_key:
            self.base_data.test_data.set_cache(key=set_cache_key, value=value)
        return value

    @sync_method_callback('android', '元素操作', '元素截图', 9, [
        MethodModel(f='locating'),
        MethodModel(n='截图名称', f='file_name', p='请输入元素截图存储的名称，后续可以通过名称获取', d=True)])
    def a_element_screenshot(self, locating, file_name):
        """元素截图"""
        im = locating.screenshot()
        file_path = os.path.join(self.base_data.screenshot_path, file_name)
        self.base_data.test_data.set_cache(file_name, file_path)
        im.save(file_path)

    @sync_method_callback('android', '元素操作', '元素缩小', 10, [
        MethodModel(f='locating')])
    def a_pinch_in(self, locating):
        """元素缩小"""
        locating.pinch_in()

    @sync_method_callback('android', '元素操作', '元素放大', 11, [
        MethodModel(f='locating')])
    def a_pinch_out(self, locating):
        """元素放大"""
        locating.pinch_out()

    @sync_method_callback('android', '元素操作', '等待元素出现', 12, [
        MethodModel(f='locating'), MethodModel(n='等待时间', f='time_', p='请输入等待元素出现的时间', d=True)])
    def a_wait(self, locating, time_):
        """等待元素出现"""
        if not locating.wait(timeout=float(time_)):
            raise MangoAutomationError(*ERROR_MSG_0043)

    @sync_method_callback('android', '元素操作', '等待元素消失', 13, [
        MethodModel(f='locating'), MethodModel(n='等待时间', f='time_', p='请输入等待元素消失的时间', d=True)])
    def a_wait_gone(self, locating, time_):
        """等待元素消失"""
        if not locating.wait_gone(timeout=float(time_)):
            raise MangoAutomationError(*ERROR_MSG_0044)

    @sync_method_callback('android', '元素操作', '拖动A元素到达B元素上', 14, [
        MethodModel(f='locating'), MethodModel(f='locating2')])
    def a_drag_to_ele(self, locating, locating2):
        """拖动A元素到达B元素上"""
        locating.drag_to(locating2)

    @sync_method_callback('android', '元素操作', '拖动元素到坐标上', 15, [
        MethodModel(f='locating'),
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def a_drag_to_coord(self, locating, x, y):
        """拖动元素到坐标上"""
        locating.drag_to(float(x), float(y))

    @sync_method_callback('android', '元素操作', '元素内向右滑动', 16, [MethodModel(f='locating')])
    def a_swipe_right(self, locating):
        """元素内向右滑动"""
        locating.swipe('right')

    @sync_method_callback('android', '元素操作', '元素内向左滑动', 17, [MethodModel(f='locating')])
    def a_swipe_left(self, locating):
        """元素内向左滑动"""
        locating.swipe('left')

    @sync_method_callback('android', '元素操作', '元素内向上滑动', 18, [MethodModel(f='locating')])
    def a_swipe_up(self, locating):
        """元素内向上滑动"""
        locating.swipe('up')

    @sync_method_callback('android', '元素操作', '元素内向下滑动', 19, [MethodModel(f='locating')])
    def a_swipe_ele(self, locating):
        """元素内向下滑动"""
        locating.swipe('down')

    @sync_method_callback('android', '元素操作', '提取元素坐标', 20, [
        MethodModel(f='locating'),
        MethodModel(n='x坐标', f='x_key', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y_key', p='请输入y坐标', d=True)])
    def a_get_center(self, locating, x_key, y_key):
        """提取元素坐标"""
        x, y = locating.center()
        if x_key and y_key:
            self.base_data.test_data.set_cache(key=x_key, value=x)
            self.base_data.test_data.set_cache(key=y_key, value=y)
        return x, y
