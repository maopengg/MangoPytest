# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023/4/6 13:31
# @Author : 毛鹏
import os.path

from uiautomator2 import Direction

from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback
from mangoautomation.tools import Meta


class AndroidPage(metaclass=Meta):
    """页面操作"""

    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('android', '页面操作', '右滑', 1)
    def a_swipe_right(self):
        """右滑"""
        self.base_data.android.swipe_ext(Direction.HORIZ_FORWARD)

    @sync_method_callback('android', '页面操作', '左滑', 2)
    def a_swipe_left(self):
        """左滑"""
        self.base_data.android.swipe_ext(Direction.HORIZ_BACKWARD)

    @sync_method_callback('android', '页面操作', '上滑', 3)
    def a_swipe_up(self):
        """上滑"""
        self.base_data.android.swipe_ext(Direction.FORWARD)

    @sync_method_callback('android', '页面操作', '下滑', 4)
    def a_swipe_down(self):
        """下滑"""
        self.base_data.android.swipe_ext(Direction.BACKWARD)

    @sync_method_callback('android', '页面操作', '坐标滑动', 5, [
        MethodModel(n='当前x', f='sx', p='请输入sx坐标', d=True),
        MethodModel(n='当前y', f='sy', p='请输入sy坐标', d=True),
        MethodModel(n='目标x', f='ex', p='请输入ex坐标', d=True),
        MethodModel(n='目标y', f='ey', p='请输入ey坐标', d=True)])
    def a_swipe(self, sx, sy, ex, ey):
        """坐标滑动"""
        self.base_data.android.swipe(sx, sy, ex, ey, 0.5)

    @sync_method_callback('android', '页面操作', '坐标拖动', 6, [
        MethodModel(n='当前x', f='sx', p='请输入sx坐标', d=True),
        MethodModel(n='当前y', f='sy', p='请输入sy坐标', d=True),
        MethodModel(n='目标x', f='ex', p='请输入ex坐标', d=True),
        MethodModel(n='目标y', f='ey', p='请输入ey坐标', d=True)])
    def a_drag(self, sx, sy, ex, ey):
        """坐标拖动"""
        self.base_data.android.drag(sx, sy, ex, ey, 0.5)

    @sync_method_callback('android', '页面操作', '打开快速通知', 7)
    def a_open_quick_settings(self):
        """打开快速通知"""
        self.base_data.android.open_quick_settings()

    @sync_method_callback('android', '页面操作', '屏幕截图', 8, [
        MethodModel(n='文件名称', f='file_name', p='请输入截图文件名称', d=True)])
    def a_screenshot(self, file_name):
        """屏幕截图"""
        self.base_data.android.screenshot(filename=os.path.join(self.base_data.screenshot_path, file_name))

    @sync_method_callback('android', '页面操作', '长按屏幕N秒', 9, [
        MethodModel(n='x坐标', f='x', p='请输入按下的x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入按下的x坐标', d=True),
        MethodModel(n='长按时间', f='time_', p='请输入长按时间', d=True)])
    def a_long_click(self, x, y, time_):
        """长按屏幕N秒"""
        self.base_data.android.long_click(x, y, time_)

    @sync_method_callback('android', '页面操作', '设置为natural', 10)
    def a_set_orientation_natural(self):
        """设置为natural"""
        self.base_data.android.set_orientation("natural")

    @sync_method_callback('android', '页面操作', '设置为left', 11)
    def a_set_orientation_left(self):
        """设置为left"""
        self.base_data.android.set_orientation("left")

    @sync_method_callback('android', '页面操作', '设置为right', 12)
    def a_set_orientation_right(self):
        """设置为right"""
        self.base_data.android.set_orientation("right")

    @sync_method_callback('android', '页面操作', '设置为upsidedown', 13)
    def a_set_orientation_upsidedown(self):
        """设置为upsidedown"""
        self.base_data.android.set_orientation("upsidedown")

    @sync_method_callback('android', '页面操作', '冻结旋转', 14)
    def a_freeze_rotation(self):
        """冻结旋转"""
        self.base_data.android.freeze_rotation()

    @sync_method_callback('android', '页面操作', '取消冻结旋转', 15)
    def a_freeze_rotation_false(self):
        """取消冻结旋转"""
        self.base_data.android.freeze_rotation(False)

    @sync_method_callback('android', '页面操作', '获取转储的内容', 16)
    def a_dump_hierarchy(self):
        """获取转储的内容"""
        return self.base_data.android.dump_hierarchy()

    @sync_method_callback('android', '页面操作', '打开通知', 17)
    def a_open_notification(self):
        """打开通知"""
        return self.base_data.android.open_notification()
