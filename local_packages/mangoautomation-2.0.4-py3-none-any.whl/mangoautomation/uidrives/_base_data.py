# -*- coding: utf-8 -*-
from mangoautomation.uidrives.context import AutomationContext, BaseData

__all__ = ["AutomationContext", "BaseData"]
