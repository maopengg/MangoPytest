# -*- coding: utf-8 -*-
import unittest
from unittest.mock import patch

from mangoautomation.element_healing.agent.web.model_adapter import OpenAICompatibleModelClient


class ModelAdapterTest(unittest.TestCase):
    @patch('mangoautomation.element_healing.agent.web.model_adapter.AsyncOpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.OpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultAsyncHttpxClient')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultHttpxClient')
    def test_ai_clients_ignore_environment_proxy(
            self, sync_http_client, async_http_client, sync_openai, async_openai):
        OpenAICompatibleModelClient('key', 'https://ai.example.test/v1', 'model', 20)

        sync_http_client.assert_called_once_with(trust_env=False, timeout=20.0)
        async_http_client.assert_called_once_with(trust_env=False, timeout=20.0)
        self.assertIs(sync_openai.call_args.kwargs['http_client'], sync_http_client.return_value)
        self.assertIs(async_openai.call_args.kwargs['http_client'], async_http_client.return_value)


if __name__ == '__main__':
    unittest.main()
