# -*- coding: utf-8 -*-
import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from mangoautomation.models import MethodModel
from mangoautomation.tools import async_method_callback, sync_method_callback
from mangoautomation.tools._decorator import func_info
from mangoautomation.uidrives.web.async_web import AsyncWebDevice
from mangoautomation.uidrives.web.async_web._assertion import AsyncWebAssertion
from mangoautomation.uidrives.web.async_web._element import AsyncWebElement
from mangoautomation.uidrives.web.sync_web import SyncWebDevice
from mangoautomation.uidrives.web.sync_web._assertion import SyncWebAssertion
from mangoautomation.uidrives.web.sync_web._element import SyncWebElement
from mangoautomation.uidrives.web._table_assertion import assert_table_rows


class TestMethodCallback(unittest.TestCase):

    def test_same_method_name_is_deduplicated_within_type_but_kept_across_types(self):
        def create_method(_type, class_name):
            @sync_method_callback(_type, class_name, '同名方法')
            def shared_scope_method():
                return None

        create_method('scope_a', '同步实现')
        create_method('scope_a', '异步实现')
        create_method('scope_b', '设备实现')

        scope_a_methods = [
            method['value']
            for group in func_info
            if group['value'] == 'scope_a'
            for class_group in group['children']
            for method in class_group['children']
        ]
        scope_b_methods = [
            method['value']
            for group in func_info
            if group['value'] == 'scope_b'
            for class_group in group['children']
            for method in class_group['children']
        ]

        self.assertEqual(scope_a_methods.count('shared_scope_method'), 1)
        self.assertEqual(scope_b_methods.count('shared_scope_method'), 1)

    def test_sync_method_callback_uses_manual_name(self):
        @sync_method_callback('demo', '同步方法', '手动同步名称', 1, [
            MethodModel(f='actual'),
            MethodModel(n='预期值', f='expect', p='请输入预期值', d=True),
        ])
        def demo_sync_method(actual, expect):
            """这个注释不应该作为名称"""
            return f'{actual}-{expect}'

        self.assertEqual(demo_sync_method('实际', '预期'), '实际-预期')

        method_info = self._find_method_info('demo', '同步方法', 'demo_sync_method')
        self.assertEqual(method_info['label'], '手动同步名称')
        self.assertEqual(method_info['sort'], 1)
        self.assertEqual(method_info['parameter'][1]['n'], '预期值')

    def test_async_method_callback_uses_manual_name(self):
        @async_method_callback('demo', '异步方法', '手动异步名称', 2, [
            MethodModel(f='actual'),
        ])
        async def demo_async_method(actual):
            """这个注释不应该作为名称"""
            return f'async-{actual}'

        self.assertEqual(asyncio.run(demo_async_method('实际')), 'async-实际')

        method_info = self._find_method_info('demo', '异步方法', 'demo_async_method')
        self.assertEqual(method_info['label'], '手动异步名称')
        self.assertEqual(method_info['sort'], 2)
        self.assertEqual(method_info['parameter'][0]['f'], 'actual')

    def test_sync_force_click_uses_playwright_force_option(self):
        target = Mock()
        locating = SimpleNamespace(first=target)

        SyncWebElement(None).w_force_click(locating)

        target.click.assert_called_once_with(force=True)
        target.evaluate.assert_not_called()

    def test_sync_js_click_dispatches_click_event(self):
        target = Mock()
        locating = SimpleNamespace(first=target)

        SyncWebElement(None).w_js_click(locating)

        target.click.assert_not_called()
        target.dispatch_event.assert_called_once_with('click')

    def test_async_force_click_uses_playwright_force_option(self):
        target = SimpleNamespace(
            click=AsyncMock(),
            evaluate=AsyncMock(),
            dispatch_event=AsyncMock(),
        )
        locating = SimpleNamespace(first=target)

        asyncio.run(AsyncWebElement(None).w_force_click(locating))

        target.click.assert_awaited_once_with(force=True)
        target.dispatch_event.assert_not_awaited()

    def test_async_js_click_dispatches_click_event(self):
        target = SimpleNamespace(
            click=AsyncMock(),
            evaluate=AsyncMock(),
            dispatch_event=AsyncMock(),
        )
        locating = SimpleNamespace(first=target)

        asyncio.run(AsyncWebElement(None).w_js_click(locating))

        target.click.assert_not_awaited()
        target.dispatch_event.assert_awaited_once_with('click')

    @patch('mangoautomation.uidrives.web.sync_web._assertion.sync_api.expect')
    def test_sync_element_exists_and_not_exists_are_separate_assertions(self, expect_mock):
        assertion = SyncWebAssertion(None)
        exists = SimpleNamespace(count=lambda: 1)
        missing = SimpleNamespace(count=lambda: 0)

        self.assertEqual(assertion.a_assert_ele_exists(exists), '实际=1, 预期>0')
        self.assertEqual(assertion.a_assert_ele_not_exists(missing), '实际=0, 预期=0')
        expect_mock.assert_called_once_with(missing)
        expect_mock.return_value.to_have_count.assert_called_once_with(0)
        with self.assertRaises(AssertionError):
            assertion.a_assert_ele_exists(missing)
        expect_mock.return_value.to_have_count.side_effect = AssertionError
        with self.assertRaises(AssertionError):
            assertion.a_assert_ele_not_exists(exists)

    @patch('mangoautomation.uidrives.web.async_web._assertion.async_api.expect')
    def test_async_element_exists_and_not_exists_are_separate_assertions(self, expect_mock):
        assertion = AsyncWebAssertion(None)
        exists = SimpleNamespace(count=AsyncMock(return_value=1))
        missing = SimpleNamespace(count=AsyncMock(return_value=0))
        playwright_expect = SimpleNamespace(to_have_count=AsyncMock())
        expect_mock.return_value = playwright_expect

        self.assertEqual(asyncio.run(assertion.a_assert_ele_exists(exists)), '实际=1, 预期>0')
        self.assertEqual(asyncio.run(assertion.a_assert_ele_not_exists(missing)), '实际=0, 预期=0')
        expect_mock.assert_called_once_with(missing)
        playwright_expect.to_have_count.assert_awaited_once_with(0)
        with self.assertRaises(AssertionError):
            asyncio.run(assertion.a_assert_ele_exists(missing))
        playwright_expect.to_have_count.side_effect = AssertionError
        with self.assertRaises(AssertionError):
            asyncio.run(assertion.a_assert_ele_not_exists(exists))

    def test_page_text_assertions_do_not_require_element_parameter(self):
        method_info = self._find_method_info(
            'ass_web', '页面内容', 'w_page_text_count_at_least',
        )

        self.assertEqual(method_info['label'], '文本出现次数不少于')
        self.assertEqual(
            [item['f'] for item in method_info['parameter']],
            ['expect', 'count'],
        )

    def test_table_assertion_metadata_uses_key_value_editor(self):
        method_info = self._find_method_info(
            'ass_web', '表格断言', 'w_table_row_values_equal',
        )

        self.assertEqual(method_info['label'], '存在字段值完全匹配的行')
        self.assertEqual(
            [item['f'] for item in method_info['parameter']],
            ['actual', 'expect'],
        )
        self.assertEqual(method_info['parameter'][1]['input_type'], 'key_value')

    def test_table_assertion_only_checks_configured_fields_in_same_row(self):
        headers = ['姓名', '部门', '状态', '备注']
        rows = [
            ['张三', '研发部', '启用', '管理员'],
            ['李四', '测试部', '停用', '普通用户'],
        ]

        result = assert_table_rows(headers, rows, {'姓名': '张三', '状态': '启用'}, 'equal')

        self.assertIn('第1行', result)
        with self.assertRaises(AssertionError):
            assert_table_rows(headers, rows, {'姓名': '张三', '状态': '停用'}, 'equal')

    def test_table_assertion_supports_contains_and_missing_field_message(self):
        headers = ['名称', '说明']
        rows = [['订单服务', '负责订单创建和查询']]

        self.assertIn(
            '第1行',
            assert_table_rows(headers, rows, {'说明': '订单创建'}, 'contains'),
        )
        with self.assertRaisesRegex(AssertionError, '表格缺少字段：状态'):
            assert_table_rows(headers, rows, {'状态': '启用'}, 'equal')

    def test_sync_page_text_count_assertions(self):
        body = SimpleNamespace(inner_text=Mock(return_value='合同列表\n合同详情\n合同'))
        page = SimpleNamespace(
            locator=Mock(return_value=body),
            wait_for_timeout=Mock(),
        )
        assertion = SyncWebAssertion(SimpleNamespace(page=page))

        self.assertIn('实际出现3次', assertion.w_page_text_count_equal('合同', 3))
        self.assertIn('不少于2次', assertion.w_page_text_count_at_least('合同', 2))
        self.assertIn('不多于3次', assertion.w_page_text_count_at_most('合同', 3))
        page.locator.assert_called_with('body')
        page.wait_for_timeout.assert_not_called()

    @patch('mangoautomation.uidrives.web.sync_web._assertion.sync_api.expect')
    def test_sync_page_text_content_assertions(self, expect_mock):
        body = Mock()
        page = SimpleNamespace(locator=Mock(return_value=body))
        assertion = SyncWebAssertion(SimpleNamespace(page=page))

        self.assertIn('页面包含预期文本', assertion.w_page_to_contain_text('合同'))
        self.assertIn('页面不包含文本', assertion.w_page_not_to_contain_text('错误'))
        self.assertIn('页面文本等于预期文本', assertion.w_page_to_have_text('合同'))
        self.assertIn('页面文本不等于', assertion.w_page_not_to_have_text('错误'))
        expect_mock.return_value.to_contain_text.assert_called_once_with('合同')
        expect_mock.return_value.not_to_contain_text.assert_called_once_with('错误')
        expect_mock.return_value.to_have_text.assert_called_once_with('合同')
        expect_mock.return_value.not_to_have_text.assert_called_once_with('错误')

    def test_async_page_text_count_assertions(self):
        body = SimpleNamespace(inner_text=AsyncMock(return_value='合同列表\n合同详情\n合同'))
        page = SimpleNamespace(
            locator=Mock(return_value=body),
            wait_for_timeout=AsyncMock(),
        )
        assertion = AsyncWebAssertion(SimpleNamespace(page=page))

        self.assertIn(
            '实际出现3次',
            asyncio.run(assertion.w_page_text_count_equal('合同', 3)),
        )
        self.assertIn(
            '不少于2次',
            asyncio.run(assertion.w_page_text_count_at_least('合同', 2)),
        )
        self.assertIn(
            '不多于3次',
            asyncio.run(assertion.w_page_text_count_at_most('合同', 3)),
        )
        page.locator.assert_called_with('body')
        page.wait_for_timeout.assert_not_awaited()

    @patch('mangoautomation.uidrives.web.async_web._assertion.async_api.expect')
    def test_async_page_text_content_assertions(self, expect_mock):
        body = Mock()
        page = SimpleNamespace(locator=Mock(return_value=body))
        playwright_expect = SimpleNamespace(
            to_contain_text=AsyncMock(),
            not_to_contain_text=AsyncMock(),
            to_have_text=AsyncMock(),
            not_to_have_text=AsyncMock(),
        )
        expect_mock.return_value = playwright_expect
        assertion = AsyncWebAssertion(SimpleNamespace(page=page))

        self.assertIn(
            '页面包含预期文本',
            asyncio.run(assertion.w_page_to_contain_text('合同')),
        )
        self.assertIn(
            '不包含文本',
            asyncio.run(assertion.w_page_not_to_contain_text('错误')),
        )
        self.assertIn(
            '文本等于预期文本',
            asyncio.run(assertion.w_page_to_have_text('合同')),
        )
        self.assertIn(
            '文本不等于',
            asyncio.run(assertion.w_page_not_to_have_text('错误')),
        )
        playwright_expect.to_contain_text.assert_awaited_once_with('合同')
        playwright_expect.not_to_contain_text.assert_awaited_once_with('错误')
        playwright_expect.to_have_text.assert_awaited_once_with('合同')
        playwright_expect.not_to_have_text.assert_awaited_once_with('错误')

    def test_sync_page_assertion_runner_allows_method_without_actual(self):
        body = SimpleNamespace(inner_text=Mock(return_value='合同合同'))
        page = SimpleNamespace(
            locator=Mock(return_value=body),
            wait_for_timeout=Mock(),
        )
        base_data = SimpleNamespace(page=page, log=Mock())
        result = SyncWebDevice(base_data).web_assertion_element(
            '当前页面',
            'w_page_text_count_at_least',
            {'expect': '合同', 'count': 2},
        )

        self.assertIn('不少于2次', result)

    def test_async_page_assertion_runner_allows_method_without_actual(self):
        body = SimpleNamespace(inner_text=AsyncMock(return_value='合同合同'))
        page = SimpleNamespace(
            locator=Mock(return_value=body),
            wait_for_timeout=AsyncMock(),
        )
        base_data = SimpleNamespace(page=page, log=Mock())
        result = asyncio.run(
            AsyncWebDevice(base_data).web_assertion_element(
                '当前页面',
                'w_page_text_count_at_least',
                {'expect': '合同', 'count': 2},
            )
        )

        self.assertIn('不少于2次', result)

    @staticmethod
    def _find_method_info(_type, class_name, method_name):
        type_info = next(item for item in func_info if item['value'] == _type)
        class_info = next(item for item in type_info['children'] if item['value'] == class_name)
        return next(item for item in class_info['children'] if item['value'] == method_name)


if __name__ == '__main__':
    unittest.main()
