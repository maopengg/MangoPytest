# -*- coding: utf-8 -*-
from mangoautomation.element_healing.models import CandidateSource
from mangoautomation.enums import ElementExpEnum

from .objects import (
    BROKEN_LOCATOR,
    TARGET_LOCATOR,
    ElementHealingScenario,
    ElementObjectFactory,
    StrictAgentModelClient,
    candidate,
)


def _snapshot(snapshot_id: int, *, locator: str | None = TARGET_LOCATOR) -> dict:
    return {
        'id': snapshot_id,
        'exp': ElementExpEnum.LOCATOR.value,
        'loc': locator,
        'sub': None,
        'element_role': 'button',
        'element_name': 'Save',
        'element_text': 'Save',
        'element_attributes': {'data-testid': 'save-button'},
    }


FLOW_SCENARIOS = (
    ElementHealingScenario(
        name='applied repair record wins first',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={'heal_records': [{
            'id': 11,
            'applied': True,
            'selected_exp': ElementExpEnum.LOCATOR.value,
            'selected_loc': TARGET_LOCATOR,
            'selected_sub': None,
            'candidates': [{'loc': TARGET_LOCATOR, 'used_ai': True}],
        }]},
        expected_source=CandidateSource.APPLIED_HEAL_RECORD.value,
    ),
    ElementHealingScenario(
        name='latest baseline locator repairs element',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={'latest_snapshot': _snapshot(21), 'snapshots': [], 'heal_records': []},
        expected_source=CandidateSource.LATEST_SNAPSHOT_LOCATOR.value,
    ),
    ElementHealingScenario(
        name='historical baseline repairs when latest is absent',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={'latest_snapshot': None, 'snapshots': [_snapshot(31)], 'heal_records': []},
        expected_source=CandidateSource.HISTORY_SNAPSHOT_LOCATOR.value,
    ),
    ElementHealingScenario(
        name='baseline semantic fields generate locator',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={'latest_snapshot': _snapshot(41, locator=None), 'snapshots': [], 'heal_records': []},
        expected_source=CandidateSource.BASELINE_SEMANTIC.value,
    ),
    ElementHealingScenario(
        name='invalid applied record falls through to latest baseline',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={
            'heal_records': [{
                'id': 51,
                'applied': True,
                'selected_exp': ElementExpEnum.LOCATOR.value,
                'selected_loc': "get_by_role('button', name='Removed')",
            }],
            'latest_snapshot': _snapshot(52),
            'snapshots': [],
        },
        expected_source=CandidateSource.LATEST_SNAPSHOT_LOCATOR.value,
        expected_reject_code='count_zero',
    ),
    ElementHealingScenario(
        name='current DOM deterministic candidate repairs element',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        dom_candidates=(candidate(CandidateSource.DOM_ROLE, score=92),),
        expected_source=CandidateSource.DOM_ROLE.value,
    ),
    ElementHealingScenario(
        name='accessibility ref Agent is final candidate source',
        element=ElementObjectFactory.button(BROKEN_LOCATOR, prompt='Locate the Save control'),
        model_client=StrictAgentModelClient(),
        expected_source=CandidateSource.ACCESSIBILITY_AGENT.value,
        expected_agent_called=True,
    ),
    ElementHealingScenario(
        name='suggestion mode records candidate but does not replace locator',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={'latest_snapshot': _snapshot(61), 'snapshots': [], 'heal_records': []},
        mode=1,
        expected_source=CandidateSource.LATEST_SNAPSHOT_LOCATOR.value,
        expected_status='suggested',
        expected_result=False,
    ),
    ElementHealingScenario(
        name='high confidence mode marks candidate auto apply',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        memory={'latest_snapshot': _snapshot(71), 'snapshots': [], 'heal_records': []},
        mode=3,
        expected_source=CandidateSource.LATEST_SNAPSHOT_LOCATOR.value,
        expected_status='auto_apply',
    ),
    ElementHealingScenario(
        name='all deterministic candidates exhausted returns original failure',
        element=ElementObjectFactory.button(BROKEN_LOCATOR),
        expected_result=False,
        expected_status='rejected',
    ),
    ElementHealingScenario(
        name='malformed Agent schema cannot bypass Harness validation',
        element=ElementObjectFactory.button(BROKEN_LOCATOR, prompt='Locate the Save control'),
        model_client=StrictAgentModelClient(malformed=True),
        expected_result=False,
        expected_status='rejected',
        expected_agent_called=True,
        expected_reject_code='count_zero',
    ),
    ElementHealingScenario(
        name='unknown snapshot ref cannot become locator',
        element=ElementObjectFactory.button(BROKEN_LOCATOR, prompt='Locate the Save control'),
        model_client=StrictAgentModelClient(unknown_ref=True),
        expected_result=False,
        expected_status='rejected',
        expected_agent_called=True,
        expected_reject_code='count_zero',
    ),
)
