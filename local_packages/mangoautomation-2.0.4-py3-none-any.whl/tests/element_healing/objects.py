# -*- coding: utf-8 -*-
import json
from dataclasses import dataclass, field

from mangoautomation.element_healing.agent.web.response_schema import SCHEMA_VERSION
from mangoautomation.element_healing.models import LocatorCandidate
from mangoautomation.element_healing.snapshot import (
    SNAPSHOT_REF_ATTRIBUTE,
    AccessibilitySnapshot,
    AccessibilitySnapshotNode,
    SnapshotRefResolver,
)
from mangoautomation.enums import ElementExpEnum, ElementOperationEnum
from mangoautomation.models import ElementListModel, ElementModel


TARGET_LOCATOR = "get_by_role('button', name='Save', exact=True)"
BROKEN_LOCATOR = "get_by_role('button', name='Missing', exact=True)"


class ElementObjectFactory:
    """Build production ElementModel objects used by healing-flow scenarios."""

    @staticmethod
    def button(*locators: str, prompt: str | None = None) -> ElementModel:
        return ElementModel(
            id=101,
            element_id=1001,
            type=ElementOperationEnum.OPE,
            name='Save',
            category='Dialog',
            collect_snapshot=False,
            elements=[
                ElementListModel(
                    exp=ElementExpEnum.LOCATOR.value,
                    loc=locator,
                    prompt=prompt,
                )
                for locator in locators
            ],
            sleep=None,
            ope_key='w_click',
            ope_value=[],
        )


class ScenarioLocator:
    def __init__(
            self,
            count: int = 1,
            *,
            text: str = 'Save',
            visible: bool = True,
            enabled: bool = True,
            editable: bool = False,
            role: str = 'button',
            tag: str = 'button',
            attributes: dict | None = None,
            interactive: bool = True,
    ):
        self._count = count
        self._text = text
        self._visible = visible
        self._enabled = enabled
        self._editable = editable
        self._role = role
        self._tag = tag
        self._attributes = attributes or {}
        self._interactive = interactive
        self.first = self

    def count(self):
        return self._count

    def nth(self, index):
        return self

    def is_visible(self):
        return self._visible

    def is_enabled(self):
        return self._enabled

    def is_editable(self):
        return self._editable

    def click(self, **kwargs):
        if not self._interactive:
            raise RuntimeError('element is not clickable')

    def inner_text(self):
        return self._text

    def text_content(self):
        return self._text

    def input_value(self):
        return self._text if self._editable else None

    def get_attribute(self, name):
        return self._attributes.get(name)

    def evaluate(self, script):
        if 'isLabelWithNearbyControl' in script:
            return self._interactive
        return {
            'tag': self._tag,
            'role': self._role,
            'type': 'button' if self._tag == 'button' else 'text',
            'text': self._text,
            'aria_label': self._text,
            'name': '',
            'title': '',
            'placeholder': self._text if self._editable else '',
            'test_id': 'save-button',
            'label_texts': [],
            'editable': self._editable,
            'interactive': self._interactive,
            'direct_interactive': self._interactive,
        }


class AsyncScenarioLocator:
    def __init__(self, count: int, text: str):
        self._count = count
        self._text = text
        self.first = self

    async def count(self):
        return self._count

    def nth(self, index):
        return self

    async def inner_text(self):
        return self._text

    async def text_content(self):
        return self._text

    async def input_value(self):
        return None

    async def get_attribute(self, name):
        return None

    async def is_visible(self, **kwargs):
        return self._count > 0

    async def is_enabled(self, **kwargs):
        return self._count > 0

    async def is_editable(self, **kwargs):
        return False

    async def bounding_box(self, **kwargs):
        return {'x': 1, 'y': 2, 'width': 80, 'height': 32} if self._count else None


class AsyncFixedLocatorPage:
    url = 'https://example.test/dialog'

    def locator(self, selector, **kwargs):
        if selector == 'xpath=//button[@id="save"]':
            return AsyncScenarioLocator(1, 'Save')
        return AsyncScenarioLocator(0, '')


class ScenarioPage:
    url = 'https://example.test/dialog'
    snapshot_id = 'scenario-snapshot'
    target_ref = 'e1'

    def __init__(self, *, target_count: int = 1, visible: bool = True, interactive: bool = True):
        marker = f'{self.snapshot_id}:{self.target_ref}'
        self.target = ScenarioLocator(
            target_count,
            visible=visible,
            interactive=interactive,
            attributes={SNAPSHOT_REF_ATTRIBUTE: marker},
        )
        self.missing = ScenarioLocator(0, text='Missing')

    def is_closed(self):
        return False

    def title(self):
        return 'Dialog'

    def get_by_role(self, role, name=None, **kwargs):
        if role == 'button' and name == 'Save':
            return self.target
        return self.missing

    def get_by_text(self, text, **kwargs):
        return self.target if text == 'Save' else self.missing

    def get_by_placeholder(self, text, **kwargs):
        return self.target if text == 'Save' else self.missing

    def get_by_label(self, text, **kwargs):
        return self.target if text == 'Save' else self.missing

    def locator(self, selector, **kwargs):
        if selector == SnapshotRefResolver.selector(self.snapshot_id, self.target_ref):
            return self.target
        if selector in ('#save', '[data-testid="save-button"]') or 'Save' in selector:
            return self.target
        if selector == '.ambiguous':
            return ScenarioLocator(2)
        return self.missing

    def evaluate(self, script, arg=None):
        return []


class StrictAgentModelClient:
    available = True
    model_name = 'strict-scenario-model'

    def __init__(self, *, malformed: bool = False, unknown_ref: bool = False):
        self.malformed = malformed
        self.unknown_ref = unknown_ref
        self.call_count = 0

    def _response(self):
        self.call_count += 1
        if self.malformed:
            return '{"candidates": [{"target_ref": "e1"}]}'
        return json.dumps({
            'schema_version': SCHEMA_VERSION,
            'candidates': [{
                'source': 'ai_accessibility',
                'target_ref': 'e99' if self.unknown_ref else 'e1',
                'reason': 'exact Save button in current accessibility snapshot',
                'confidence': 95,
            }],
        })

    async def complete_async(self, messages, **kwargs):
        return self._response()

    def complete_sync(self, messages, **kwargs):
        return self._response()


def accessibility_snapshot() -> AccessibilitySnapshot:
    return AccessibilitySnapshot(
        snapshot_id=ScenarioPage.snapshot_id,
        page_url=ScenarioPage.url,
        created_at_ms=1,
        nodes=[AccessibilitySnapshotNode(
            ref='e1',
            frame_index=0,
            frame_url=ScenarioPage.url,
            order=0,
            role='button',
            name='Save',
            text='Save',
            tag='button',
            interactive=True,
            attributes={'id': 'save', 'name': '', 'type': 'button', 'testid': 'save-button'},
            rect={'x': 10.0, 'y': 20.0, 'width': 80.0, 'height': 32.0},
        )],
        tree='frame "main frame"\n  - button "Save" [ref=e1]',
    )


def candidate(source, locator=TARGET_LOCATOR, score=90) -> LocatorCandidate:
    return LocatorCandidate(
        source=source,
        exp=ElementExpEnum.LOCATOR.value,
        loc=locator,
        initial_score=score,
    )


@dataclass(frozen=True)
class ElementHealingScenario:
    name: str
    element: ElementModel
    memory: dict = field(default_factory=dict)
    dom_candidates: tuple[LocatorCandidate, ...] = ()
    model_client: StrictAgentModelClient | None = None
    mode: int = 2
    expected_source: str | None = None
    expected_status: str = 'temporary_heal'
    expected_result: bool = True
    expected_agent_called: bool = False
    expected_reject_code: str | None = None
