# -*- coding: utf-8 -*-
import unittest
from itertools import cycle
from unittest.mock import AsyncMock, MagicMock
from unittest.mock import patch

from mangotools.data_processor import DataProcessor

from mangoautomation.element_healing import (
    BaselineCapturePolicy,
    InMemoryEventSink,
    InMemoryProvider,
    WebElementHealingHarness,
)
from mangoautomation.element_healing.agent.web.context_builder import WebAgentContextBuilder
from mangoautomation.element_healing.candidates import CandidateRegistry
from mangoautomation.element_healing.context import HealingContextBuilder
from mangoautomation.element_healing.models import HealingTrigger
from mangoautomation.element_healing.policy import AgentCircuitBreaker, StaticRuntimeConfig
from mangoautomation.enums import DriveTypeEnum, ElementExpEnum, ElementOperationEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.models import ElementListModel, ElementModel, ElementResultModel, MethodModel
from mangoautomation.uidrives import AsyncElement
from mangoautomation.uidrives._base_data import BaseData

from .objects import AsyncFixedLocatorPage, BROKEN_LOCATOR, ScenarioPage, accessibility_snapshot
from .scenarios import FLOW_SCENARIOS


class ElementHealingFlowScenarioTest(unittest.TestCase):
    def setUp(self):
        AgentCircuitBreaker.reset()

    def test_each_flowchart_stage_with_element_objects(self):
        for scenario in FLOW_SCENARIOS:
            with self.subTest(stage=scenario.name):
                self._run_scenario(scenario)

    def _run_scenario(self, scenario):
        AgentCircuitBreaker.reset()
        sink = InMemoryEventSink()
        harness = WebElementHealingHarness(
            memory_provider=InMemoryProvider({1001: scenario.memory}),
            event_sink=sink,
            model_client=scenario.model_client,
            runtime_config=StaticRuntimeConfig(enabled=True, mode=scenario.mode),
        )
        page = ScenarioPage()
        with patch.object(
                CandidateRegistry,
                'current_page_sync',
                return_value=list(scenario.dom_candidates),
        ), patch.object(
                WebAgentContextBuilder,
                'build_sync',
                return_value=accessibility_snapshot(),
        ):
            result = harness.locate_sync(
                page,
                scenario.element,
                None,
                [BROKEN_LOCATOR],
                {'ope_key': 'w_click'},
                RuntimeError('element not found'),
            )

        self.assertEqual(bool(result), scenario.expected_result)
        metadata = (result or {}).get('metadata') or harness.get_last_attempt(1001)
        self.assertIsNotNone(metadata)
        trace = metadata['trace']
        decision = trace['decision']
        self.assertEqual(decision['status'], scenario.expected_status)
        self.assertEqual(trace['agent_called'], scenario.expected_agent_called)
        stage_names = [stage['name'] for stage in trace['stages']]
        expected_stage_prefix = ['memory', 'historical_candidates']
        if scenario.expected_source == 'playwright_role':
            expected_stage_prefix.append('current_page_candidates')
        if scenario.expected_agent_called or scenario.expected_status == 'rejected':
            expected_stage_prefix = [
                'memory', 'historical_candidates', 'current_page_candidates', 'agent_candidates',
            ]
        self.assertEqual(stage_names, expected_stage_prefix)
        if scenario.expected_source:
            self.assertEqual(metadata['used_source'], scenario.expected_source)
        if scenario.expected_reject_code:
            self.assertIn(
                scenario.expected_reject_code,
                {item.get('reject_code') for item in metadata.get('candidates') or []},
            )
        if scenario.expected_agent_called and scenario.expected_result:
            selected = metadata['candidates'][metadata['candidate_index']]
            self.assertTrue(selected['agent_schema_validated'])
            self.assertTrue(selected['snapshot_ref_resolved'])
            self.assertEqual(selected['target_ref'], 'e1')
        if scenario.expected_result:
            self.assertTrue(decision['should_retry_operation'])
            self.assertTrue(decision['should_save_record'])
            self.assertTrue(decision['should_refresh_baseline'])
            self.assertTrue(BaselineCapturePolicy.should_capture(scenario.element, metadata))
        elif scenario.expected_status == 'suggested':
            self.assertFalse(decision['should_retry_operation'])
            self.assertTrue(decision['should_save_record'])
            self.assertFalse(decision['should_refresh_baseline'])
        else:
            self.assertFalse(decision['should_retry_operation'])
            self.assertFalse(decision['should_save_record'])
            self.assertFalse(decision['should_refresh_baseline'])
        self.assertEqual(sink.events[0][0], 'healing_trace')

    def test_all_healing_triggers_are_derived_from_element_failures(self):
        element = FLOW_SCENARIOS[0].element
        page = ScenarioPage()
        values = (
            ('element not found', {}, HealingTrigger.ZERO_MATCH),
            ('strict mode ambiguous', {}, HealingTrigger.AMBIGUOUS_MATCH),
            ('semantic mismatch', {}, HealingTrigger.SEMANTIC_MISMATCH),
            ('element is not editable', {}, HealingTrigger.NOT_ACTIONABLE),
            ('operation failed', {'operation_retry': True}, HealingTrigger.RECOVERABLE_OPERATION_ERROR),
            ('locator syntax error', {}, HealingTrigger.LOCATOR_EXCEPTION),
        )
        for message, extra, expected in values:
            with self.subTest(trigger=expected.value):
                context = HealingContextBuilder.build_sync(
                    page,
                    element,
                    [BROKEN_LOCATOR],
                    {'ope_key': 'w_click', **extra},
                    RuntimeError(message),
                )
                self.assertEqual(context.trigger, expected)


class FixedLocatorElementObjectTest(unittest.IsolatedAsyncioTestCase):
    async def test_primary_then_backup_locator_order_uses_real_element_model(self):
        base_data = BaseData(DataProcessor(), MagicMock())
        base_data.page = AsyncFixedLocatorPage()
        base_data.locator_engine = MagicMock()
        base_data.locator_engine.fixed_locator_semantic_reject_reason.return_value = (
            'AI提示词与固定定位器语义不一致'
        )
        element_runner = AsyncElement(base_data, DriveTypeEnum.WEB.value)
        element_model = ElementModel(
            id=201,
            element_id=2001,
            type=ElementOperationEnum.OPE,
            name='Save',
            elements=[
                ElementListModel(
                    exp=ElementExpEnum.XPATH.value,
                    loc='//button[@id="missing"]',
                ),
                ElementListModel(
                    exp=ElementExpEnum.XPATH.value,
                    loc='//button[@id="save"]',
                ),
            ],
            sleep=None,
            ope_key='w_click',
            ope_value=[],
        )
        element_runner.element_model = element_model
        element_runner.element_result_model = ElementResultModel(
            id=element_model.id,
            name=element_model.name,
            type=element_model.type.value,
            ope_key=element_model.ope_key,
            is_iframe=0,
        )
        element_runner.elements = cycle(element_model.elements)
        element_runner._AsyncElement__fixed_attempt_counts = {
            id(item): 0 for item in element_model.elements
        }
        locating = MethodModel(f='locating')

        with patch.object(
                element_runner,
                '_AsyncElement__fixed_locator_actionability_error',
                new=AsyncMock(return_value=None),
        ):
            with self.assertRaises(MangoAutomationError):
                await element_runner.query_element(locating, False)
            await element_runner.query_element(locating, False)

        self.assertEqual(element_runner.failed_expression[0], '//button[@id="missing"]')
        self.assertEqual(await locating.v.count(), 1)
        self.assertEqual(
            [item.loc for item in element_runner.element_result_model.elements],
            ['//button[@id="missing"]', '//button[@id="save"]'],
        )
        self.assertEqual(element_runner.element_result_model.elements[-1].loc, '//button[@id="save"]')
        base_data.locator_engine.fixed_locator_semantic_reject_reason.assert_not_called()
