import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

from mangoautomation.uidrives.web.highlight import WebElementHighlighter


class WebElementHighlighterTest(unittest.IsolatedAsyncioTestCase):
    def test_format_expression_uses_python_nth_syntax(self):
        self.assertEqual(
            WebElementHighlighter.format_expression('get_by_role("button")', 2),
            'get_by_role("button").nth(1)',
        )

    async def test_async_highlight_passes_platform_label(self):
        locator = SimpleNamespace(evaluate_all=AsyncMock(return_value=1))

        count = await WebElementHighlighter.highlight_async(
            locator,
            'get_by_role("button", name="创建合同")',
        )

        self.assertEqual(count, 1)
        options = locator.evaluate_all.await_args.args[1]
        self.assertEqual(options['label'], 'get_by_role("button", name="创建合同")')
        self.assertEqual(options['color'], '#f53f3f')

    def test_sync_highlight_passes_platform_label(self):
        locator = SimpleNamespace(evaluate_all=Mock(return_value=1))

        count = WebElementHighlighter.highlight(locator, 'locator("#submit")')

        self.assertEqual(count, 1)
        self.assertEqual(
            locator.evaluate_all.call_args.args[1]['label'],
            'locator("#submit")',
        )

    async def test_async_clear_supports_page_frame_and_locator(self):
        frame = SimpleNamespace(evaluate=AsyncMock(return_value=True))
        locator = SimpleNamespace(evaluate_all=AsyncMock(return_value=True))

        count = await WebElementHighlighter.clear_async([frame, locator])

        self.assertEqual(count, 2)
        frame.evaluate.assert_awaited_once()
        locator.evaluate_all.assert_awaited_once()

    def test_sync_clear_supports_page_frame_and_locator(self):
        frame = SimpleNamespace(evaluate=Mock(return_value=True))
        locator = SimpleNamespace(evaluate_all=Mock(return_value=True))

        count = WebElementHighlighter.clear([frame, locator])

        self.assertEqual(count, 2)
        frame.evaluate.assert_called_once()
        locator.evaluate_all.assert_called_once()


if __name__ == '__main__':
    unittest.main()
