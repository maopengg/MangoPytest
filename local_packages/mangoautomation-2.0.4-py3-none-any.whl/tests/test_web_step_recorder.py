from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase, mock

from mangoautomation.uidrives.web import WebStepRecorder


class WebStepRecorderTest(IsolatedAsyncioTestCase):
    async def test_click_resolves_element_before_execution(self):
        inspector = SimpleNamespace(pick=mock.AsyncMock(return_value={"text": "提交", "locators": []}))
        recorder = WebStepRecorder(inspector)
        page = SimpleNamespace(
            viewport_size={"width": 1000, "height": 800},
            mouse=SimpleNamespace(click=mock.AsyncMock()),
            title=mock.AsyncMock(return_value="测试页面"),
            url="https://example.test",
        )

        result = await recorder.execute(page, {"action": "click", "x": 0.2, "y": 0.5})

        inspector.pick.assert_awaited_once_with(page, 200, 400)
        page.mouse.click.assert_awaited_once_with(200, 400, button="left", click_count=1)
        self.assertEqual(result["element"]["text"], "提交")

    async def test_sensitive_input_is_masked(self):
        inspector = SimpleNamespace(pick=mock.AsyncMock(return_value={
            "sensitive_value_masked": True,
            "locators": [{"exp": 2, "loc": "get_by_label('密码')"}],
        }))
        recorder = WebStepRecorder(inspector)
        page = SimpleNamespace(
            evaluate=mock.AsyncMock(return_value={"x": 100, "y": 80}),
            keyboard=SimpleNamespace(insert_text=mock.AsyncMock()),
            title=mock.AsyncMock(return_value="登录"),
            url="https://example.test/login",
        )

        result = await recorder.execute(page, {"action": "input", "text": "secret"})

        self.assertTrue(result["sensitive"])
        self.assertEqual(result["input_value"], "******")

    async def test_passive_poll_returns_navigation_and_change_events(self):
        inspector = SimpleNamespace(pick=mock.AsyncMock(return_value={"text": "类型"}))
        recorder = WebStepRecorder(inspector)
        page = SimpleNamespace(
            evaluate=mock.AsyncMock(return_value=[{"action": "select", "value": "A", "x": 10, "y": 20}]),
            title=mock.AsyncMock(return_value="表单"),
            url="https://example.test/form",
        )

        result = await recorder.poll_passive_events(page)

        self.assertEqual(result[0]["action"], "select")
        self.assertEqual(result[0]["input_value"], "A")
        self.assertTrue(result[0]["passive"])

    async def test_drag_returns_pixel_displacement_for_step_generation(self):
        inspector = SimpleNamespace(pick=mock.AsyncMock(return_value={"text": "拖拽项", "locators": []}))
        recorder = WebStepRecorder(inspector)
        page = SimpleNamespace(
            viewport_size={"width": 1000, "height": 800},
            mouse=SimpleNamespace(
                move=mock.AsyncMock(),
                down=mock.AsyncMock(),
                up=mock.AsyncMock(),
            ),
            title=mock.AsyncMock(return_value="拖拽页面"),
            url="https://example.test/drag",
        )

        result = await recorder.execute(
            page,
            {"action": "drag", "x": 0.2, "y": 0.5, "to_x": 0.35, "to_y": 0.45},
        )

        self.assertEqual(result["drag_delta_x"], 150)
        self.assertEqual(result["drag_delta_y"], -40)
