import unittest
from unittest.mock import AsyncMock, MagicMock

from playwright._impl._errors import TargetClosedError, TimeoutError

from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.uidrives.web.async_web._browser import AsyncWebBrowser
from mangoautomation.uidrives.web.sync_web._browser import SyncWebBrowser


def _base_data(page):
    base_data = MagicMock()
    base_data.page = page
    base_data.screenshot_path = '/tmp'
    return base_data


class SyncScreenshotContextTest(unittest.TestCase):
    def test_timeout_falls_back_without_resetting_context(self):
        page = MagicMock()
        page.screenshot.side_effect = [TimeoutError('full page timeout'), None]
        base_data = _base_data(page)

        SyncWebBrowser(base_data).w_screenshot('failure.jpg')

        self.assertEqual(page.screenshot.call_count, 2)
        self.assertFalse(page.screenshot.call_args_list[1].kwargs['full_page'])
        base_data.setup.assert_not_called()
        self.assertIs(base_data.page, page)

    def test_timeout_does_not_report_browser_closed(self):
        page = MagicMock()
        page.screenshot.side_effect = TimeoutError('screenshot timeout')
        base_data = _base_data(page)

        with self.assertRaises(MangoAutomationError) as caught:
            SyncWebBrowser(base_data).w_screenshot('failure.jpg')

        self.assertEqual(caught.exception.code, 4064)
        base_data.setup.assert_not_called()
        self.assertIs(base_data.page, page)

    def test_target_closed_resets_context(self):
        page = MagicMock()
        page.screenshot.side_effect = TargetClosedError('target closed')
        base_data = _base_data(page)

        with self.assertRaises(MangoAutomationError) as caught:
            SyncWebBrowser(base_data).w_screenshot('failure.jpg')

        self.assertEqual(caught.exception.code, 4010)
        base_data.setup.assert_called_once_with()


class AsyncScreenshotContextTest(unittest.IsolatedAsyncioTestCase):
    async def test_timeout_falls_back_without_resetting_context(self):
        page = MagicMock()
        page.screenshot = AsyncMock(side_effect=[TimeoutError('full page timeout'), None])
        base_data = _base_data(page)

        await AsyncWebBrowser(base_data).w_screenshot('failure.jpg')

        self.assertEqual(page.screenshot.await_count, 2)
        self.assertFalse(page.screenshot.await_args_list[1].kwargs['full_page'])
        base_data.setup.assert_not_called()
        self.assertIs(base_data.page, page)

    async def test_timeout_does_not_report_browser_closed(self):
        page = MagicMock()
        page.screenshot = AsyncMock(side_effect=TimeoutError('screenshot timeout'))
        base_data = _base_data(page)

        with self.assertRaises(MangoAutomationError) as caught:
            await AsyncWebBrowser(base_data).w_screenshot('failure.jpg')

        self.assertEqual(caught.exception.code, 4064)
        base_data.setup.assert_not_called()
        self.assertIs(base_data.page, page)
