import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from mangoautomation.enums import ElementExpEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.uidrives.web import AsyncWebDevice, SyncWebDevice


class WebLocatorExpressionTest(unittest.IsolatedAsyncioTestCase):
    @staticmethod
    def _base_data():
        return SimpleNamespace(log=SimpleNamespace(debug=Mock(), error=Mock()))

    async def test_async_invalid_locator_is_normalized_for_healing(self):
        device = AsyncWebDevice(self._base_data())

        with self.assertRaises(MangoAutomationError):
            await device._AsyncWebDevice__find_ele(
                SimpleNamespace(),
                ElementExpEnum.LOCATOR.value,
                '合同名称',
            )

    async def test_async_python_locator_expression_is_supported(self):
        expected = object()
        page = SimpleNamespace(get_by_text=lambda value: expected)
        device = AsyncWebDevice(self._base_data())

        locator = await device._AsyncWebDevice__find_ele(
            page,
            ElementExpEnum.LOCATOR.value,
            'get_by_text("合同名称")',
        )

        self.assertIs(locator, expected)

    def test_sync_invalid_locator_is_normalized_for_healing(self):
        device = SyncWebDevice(self._base_data())

        with self.assertRaises(MangoAutomationError):
            device._SyncWebDevice__find_ele(
                SimpleNamespace(),
                ElementExpEnum.LOCATOR.value,
                '合同名称',
            )

    def test_sync_python_locator_expression_is_supported(self):
        expected = object()
        page = SimpleNamespace(get_by_text=lambda value: expected)
        device = SyncWebDevice(self._base_data())

        locator = device._SyncWebDevice__find_ele(
            page,
            ElementExpEnum.LOCATOR.value,
            'get_by_text("合同名称")',
        )

        self.assertIs(locator, expected)


if __name__ == '__main__':
    unittest.main()
