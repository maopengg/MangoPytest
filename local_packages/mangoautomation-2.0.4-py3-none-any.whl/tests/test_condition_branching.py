import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from mangoautomation.uidrives._async_element import AsyncElement
from mangoautomation.uidrives._sync_element import SyncElement


def build_element(element_class, branches):
    element = object.__new__(element_class)
    element.base_data = SimpleNamespace(
        log=MagicMock(),
        test_data=SimpleNamespace(replace=lambda value: value),
    )
    element.element_list_model = [
        SimpleNamespace(id=branch_id, condition_value=condition_value)
        for branch_id, condition_value in branches
    ]
    element.element_result_model = SimpleNamespace(next_node_id=None)
    return element


class SyncConditionBranchingTests(unittest.TestCase):
    def test_value_branches_are_checked_until_one_matches(self):
        element = build_element(
            SyncElement,
            [
                (11, {"expect": "第一项"}),
                (12, {"expect": "第二项"}),
            ],
        )
        assertion = MagicMock(side_effect=[AssertionError("不匹配"), None])
        element._SyncElement__ass = assertion

        element._SyncElement__condition()

        self.assertEqual(element.element_result_model.next_node_id, 12)
        self.assertEqual(
            [call.args[0] for call in assertion.call_args_list],
            [{"expect": "第一项"}, {"expect": "第二项"}],
        )

    def test_boolean_branch_uses_second_branch_when_assertion_fails(self):
        element = build_element(SyncElement, [(21, None), (22, None)])
        element._SyncElement__ass = MagicMock(side_effect=AssertionError("False"))

        element._SyncElement__condition()

        self.assertEqual(element.element_result_model.next_node_id, 22)


class AsyncConditionBranchingTests(unittest.IsolatedAsyncioTestCase):
    async def test_value_branches_are_checked_until_one_matches(self):
        element = build_element(
            AsyncElement,
            [
                (31, {"expect": "第一项"}),
                (32, {"expect": "第二项"}),
            ],
        )
        assertion = AsyncMock(side_effect=[AssertionError("不匹配"), None])
        element._AsyncElement__ass = assertion

        await element._AsyncElement__condition()

        self.assertEqual(element.element_result_model.next_node_id, 32)
        self.assertEqual(
            [call.args[0] for call in assertion.call_args_list],
            [{"expect": "第一项"}, {"expect": "第二项"}],
        )

    async def test_boolean_branch_uses_second_branch_when_assertion_fails(self):
        element = build_element(AsyncElement, [(41, None), (42, None)])
        element._AsyncElement__ass = AsyncMock(side_effect=AssertionError("False"))

        await element._AsyncElement__condition()

        self.assertEqual(element.element_result_model.next_node_id, 42)


if __name__ == "__main__":
    unittest.main()
