# -*- coding: utf-8 -*-
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Import modules for their decorator side effects. These imports populate func_info.
import mangoautomation.uidrives.android._application  # noqa: F401
import mangoautomation.uidrives.android._assertion  # noqa: F401
import mangoautomation.uidrives.android._element  # noqa: F401
import mangoautomation.uidrives.android._equipment  # noqa: F401
import mangoautomation.uidrives.android._page  # noqa: F401
import mangoautomation.uidrives.web.async_web._assertion  # noqa: F401
import mangoautomation.uidrives.web.async_web._browser  # noqa: F401
import mangoautomation.uidrives.web.async_web._element  # noqa: F401
import mangoautomation.uidrives.web.async_web._input_device  # noqa: F401
import mangoautomation.uidrives.web.async_web._page  # noqa: F401
import mangoautomation.uidrives.web.sync_web._assertion  # noqa: F401
import mangoautomation.uidrives.web.sync_web._browser  # noqa: F401
import mangoautomation.uidrives.web.sync_web._element  # noqa: F401
import mangoautomation.uidrives.web.sync_web._input_device  # noqa: F401
import mangoautomation.uidrives.web.sync_web._page  # noqa: F401
from mangoautomation.tools._decorator import func_info


def print_func_info():
    print(json.dumps(func_info, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    print_func_info()
