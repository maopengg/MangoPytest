# -*- coding: utf-8 -*-
import unittest
from pathlib import Path

from playwright.sync_api import sync_playwright

from mangoautomation.element_healing.candidates.dom_proximity import DOM_PROXIMITY_SCRIPT
from mangoautomation.element_healing.snapshot import ACCESSIBILITY_SNAPSHOT_SCRIPT


HTML = """
<main>
  <section id="contract-card" class="task-card selected" style="cursor: pointer" onclick="window.clicked = true">
    <div class="contract-title">1采购合同（无评论，无修订）</div>
    <div>合同编号：HTLX-20266287*-ZZ01</div>
    <div>节点：盖章节点</div>
  </section>
</main>
"""


class PlainTextHealingTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        chrome = Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
        options = {'headless': True}
        if chrome.exists():
            options['executable_path'] = str(chrome)
        cls.browser = cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def setUp(self):
        self.page = self.browser.new_page()
        self.page.set_content(HTML)

    def tearDown(self):
        self.page.close()

    def test_combined_element_name_finds_unique_visible_title(self):
        rows = self.page.evaluate(
            DOM_PROXIMITY_SCRIPT,
            ['合同终止1采购合同（无评论，无修订）签订中', '左侧的合同名称'],
        )

        candidate = next(row for row in rows if row.get('loc') == '1采购合同（无评论，无修订）')
        self.assertEqual(candidate['source'], 'unique_visible_text')
        self.assertEqual(candidate['exp'], 'text')
        self.assertEqual(candidate['score'], 83)

    def test_short_fragment_does_not_create_unrelated_label_candidate(self):
        self.page.set_content(
            '<div>评论</div><button>展开</button><div>其他合同</div>'
        )

        rows = self.page.evaluate(
            DOM_PROXIMITY_SCRIPT,
            ['合同终止1采购合同（无评论，无修订）签订中', '左侧的合同名称'],
        )

        self.assertFalse(any(row.get('matched_label') == '评论' for row in rows))

    def test_accessibility_snapshot_contains_clickable_leaf_text(self):
        result = self.page.evaluate(
            ACCESSIBILITY_SNAPSHOT_SCRIPT,
            {'snapshot_id': 'plain-text-test', 'start_index': 1, 'limit': 200},
        )

        title = next(node for node in result['nodes'] if node.get('text') == '1采购合同（无评论，无修订）')
        self.assertTrue(title['interactive'])
        self.assertEqual(title['role'], 'generic')
        card = next(node for node in result['nodes'] if node.get('attributes', {}).get('id') == 'contract-card')
        self.assertTrue(card['selected'])

    def test_accessibility_snapshot_does_not_spend_refs_on_page_root_text(self):
        result = self.page.evaluate(
            ACCESSIBILITY_SNAPSHOT_SCRIPT,
            {'snapshot_id': 'plain-text-root-test', 'start_index': 1, 'limit': 200},
        )

        self.assertFalse(any(node.get('tag') == 'body' for node in result['nodes']))


if __name__ == '__main__':
    unittest.main()
