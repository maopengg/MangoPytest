# -*- coding: utf-8 -*-
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from mangoautomation.uidrives.web.async_web import AsyncWebDevice
from mangoautomation.uidrives.web.sync_web import SyncWebDevice


class WebOpenUrlTest(unittest.IsolatedAsyncioTestCase):

    @staticmethod
    def _base_data(page):
        return SimpleNamespace(
            page=page,
            url='https://example.com/business',
            log=MagicMock(),
        )

    async def test_async_opens_target_when_page_is_blank(self):
        page = SimpleNamespace(url='about:blank')
        device = AsyncWebDevice.__new__(AsyncWebDevice)
        device.base_data = self._base_data(page)
        device.w_goto = AsyncMock()

        await device.open_url()

        device.w_goto.assert_awaited_once_with('https://example.com/business')

    async def test_async_keeps_current_page_after_navigation(self):
        page = SimpleNamespace(
            url='https://example.com/current',
            wait_for_load_state=AsyncMock(),
            wait_for_selector=AsyncMock(),
        )
        device = AsyncWebDevice.__new__(AsyncWebDevice)
        device.base_data = self._base_data(page)
        device.w_goto = AsyncMock()

        await device.open_url()

        device.w_goto.assert_not_awaited()

    async def test_async_force_switches_an_visited_page(self):
        page = SimpleNamespace(url='https://example.com/current')
        device = AsyncWebDevice.__new__(AsyncWebDevice)
        device.base_data = self._base_data(page)
        device.w_goto = AsyncMock()

        await device.open_url(is_open=True)

        device.w_goto.assert_awaited_once_with('https://example.com/business')


class SyncWebOpenUrlTest(unittest.TestCase):

    @staticmethod
    def _base_data(page):
        return SimpleNamespace(
            page=page,
            url='https://example.com/business',
            log=MagicMock(),
        )

    def test_sync_opens_target_when_page_is_blank(self):
        page = SimpleNamespace(url='about:blank')
        device = SyncWebDevice.__new__(SyncWebDevice)
        device.base_data = self._base_data(page)
        device.w_goto = MagicMock()

        device.open_url()

        device.w_goto.assert_called_once_with('https://example.com/business')

    def test_sync_keeps_current_page_after_navigation(self):
        page = SimpleNamespace(
            url='https://example.com/current',
            wait_for_load_state=MagicMock(),
            wait_for_selector=MagicMock(),
        )
        device = SyncWebDevice.__new__(SyncWebDevice)
        device.base_data = self._base_data(page)
        device.w_goto = MagicMock()

        device.open_url()

        device.w_goto.assert_not_called()

    def test_sync_force_switches_an_visited_page(self):
        page = SimpleNamespace(url='https://example.com/current')
        device = SyncWebDevice.__new__(SyncWebDevice)
        device.base_data = self._base_data(page)
        device.w_goto = MagicMock()

        device.open_url(is_open=True)

        device.w_goto.assert_called_once_with('https://example.com/business')


if __name__ == '__main__':
    unittest.main()
