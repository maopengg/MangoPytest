from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase, mock

from mangoautomation.uidrives.web import PageElementScanner, WebElementInspector


class WebElementInspectorTest(IsolatedAsyncioTestCase):
    def test_scanner_discovers_shadow_dom_without_reading_input_values(self):
        source = PageElementScanner.DISCOVERY_SCRIPT

        self.assertIn("target.shadowRoot", source)
        self.assertIn("mode === 'deep'", source)
        self.assertIn("sensitive_value_masked", source)
        self.assertNotIn("target.value", source)
        self.assertLess(source.index(".sort((left, right)"), source.index(".slice(0, maxCandidates)"))

    def test_scanner_prioritizes_stable_and_semantic_locators(self):
        locators = PageElementScanner.locator_suggestions({
            "role": "button",
            "accessible_name": "提交",
            "label": "提交",
            "text": "提交",
            "id": "submit-button",
            "css_path": "form button:nth-of-type(1)",
            "xpath": "/html/body/form[1]/button[1]",
            "attributes": {"data-testid": "submit-contract"},
        })

        self.assertEqual(locators[0]["source"], "testid")
        self.assertTrue(any(item["source"] == "role" for item in locators))
        self.assertTrue(any(item["source"] == "id_xpath" for item in locators))

    async def test_region_scan_uses_verified_picked_element_as_scan_root(self):
        region_root = SimpleNamespace(evaluate=mock.AsyncMock(return_value={
            "elements": [],
            "stats": {
                "visited": 3,
                "candidates": 0,
                "sensitive_values_masked": 0,
                "shadow_roots": 0,
            },
        }))
        region_locator = SimpleNamespace(
            count=mock.AsyncMock(return_value=1),
            first=region_root,
        )
        page = SimpleNamespace(
            frames=[],
            url="https://example.test/form",
            title=mock.AsyncMock(return_value="合同表单"),
        )
        scanner = PageElementScanner()
        scanner.playwright_locator = mock.Mock(return_value=region_locator)

        result = await scanner.scan(page, "region", {
            "frame_index": 0,
            "frame_url": page.url,
            "frame_locator_prefix": "",
            "locators": [{"exp": 9, "loc": "#contract-form"}],
        })

        self.assertEqual(result["scan_mode"], "region")
        self.assertTrue(result["scan_stats"]["region_selected"])
        self.assertEqual(result["scan_stats"]["visited"], 3)
        region_root.evaluate.assert_awaited_once()
        self.assertEqual(region_root.evaluate.await_args.args[1]["mode"], "quick")

    async def test_region_scan_requires_picked_element(self):
        with self.assertRaisesRegex(RuntimeError, "选择元素"):
            await PageElementScanner().scan(SimpleNamespace(frames=[]), "region")

    async def test_quick_scan_starts_from_each_frame_document_root(self):
        document_root = SimpleNamespace(evaluate=mock.AsyncMock(return_value={
            "elements": [],
            "stats": {
                "visited": 1,
                "candidates": 0,
                "sensitive_values_masked": 0,
                "shadow_roots": 0,
            },
        }))
        frame = SimpleNamespace(
            is_detached=lambda: False,
            locator=mock.Mock(return_value=document_root),
            url="https://example.test/form",
        )
        page = SimpleNamespace(
            frames=[frame],
            main_frame=frame,
            url=frame.url,
            title=mock.AsyncMock(return_value="合同表单"),
        )

        result = await PageElementScanner().scan(page, "quick")

        frame.locator.assert_called_once_with("html")
        document_root.evaluate.assert_awaited_once()
        self.assertEqual(result["scan_stats"]["visited"], 1)

    async def test_scanner_builds_nested_frame_locator_chain(self):
        main_frame = SimpleNamespace()
        outer_handle = SimpleNamespace(evaluate=mock.AsyncMock(return_value='iframe[name="outer"]'))
        inner_handle = SimpleNamespace(evaluate=mock.AsyncMock(return_value='iframe[name="inner"]'))
        outer_frame = SimpleNamespace(
            parent_frame=main_frame,
            frame_element=mock.AsyncMock(return_value=outer_handle),
            url="https://example.test/outer",
        )
        inner_frame = SimpleNamespace(
            parent_frame=outer_frame,
            frame_element=mock.AsyncMock(return_value=inner_handle),
            url="https://example.test/inner",
        )
        page = SimpleNamespace(main_frame=main_frame)
        scanner = PageElementScanner()

        prefix = await scanner._frame_locator_prefix(inner_frame, page)
        wrapped = scanner._apply_frame_locator_prefix([
            {"exp": 2, "loc": 'get_by_role("button", name="提交")', "source": "role"},
            {"exp": 9, "loc": "button.submit", "source": "css_path"},
        ], prefix)

        self.assertEqual(
            prefix,
            'frame_locator("iframe[name=\\"outer\\"]").frame_locator("iframe[name=\\"inner\\"]")',
        )
        self.assertIn('.get_by_role("button", name="提交")', wrapped[0]["loc"])
        self.assertIn('.locator("button.submit")', wrapped[1]["loc"])
        self.assertTrue(all(item["source"].endswith("_frame") for item in wrapped))

    async def test_picker_uses_deepest_iframe_at_pointer(self):
        main_frame = SimpleNamespace(is_detached=lambda: False)
        outer_handle = SimpleNamespace(bounding_box=mock.AsyncMock(return_value={
            "x": 100, "y": 80, "width": 600, "height": 500,
        }))
        inner_handle = SimpleNamespace(bounding_box=mock.AsyncMock(return_value={
            "x": 180, "y": 150, "width": 300, "height": 240,
        }))
        outer_frame = SimpleNamespace(
            parent_frame=main_frame,
            is_detached=lambda: False,
            frame_element=mock.AsyncMock(return_value=outer_handle),
        )
        inner_frame = SimpleNamespace(
            parent_frame=outer_frame,
            is_detached=lambda: False,
            frame_element=mock.AsyncMock(return_value=inner_handle),
        )
        page = SimpleNamespace(main_frame=main_frame, frames=[main_frame, outer_frame, inner_frame])
        inspector = WebElementInspector()

        frame, x, y, box = await inspector.frame_at_point(page, 240, 210)

        self.assertIs(frame, inner_frame)
        self.assertEqual((x, y), (60, 60))
        self.assertEqual(box, await inner_handle.bounding_box())

    def test_picker_masks_sensitive_values_and_supports_shadow_dom(self):
        source = WebElementInspector.PICK_SCRIPT

        self.assertNotIn("target.value", source)
        self.assertIn("sensitive_value_masked", source)
        self.assertIn("target.shadowRoot", source)

    async def test_suggest_from_locator_expands_confirmed_dom_target(self):
        locator = SimpleNamespace(evaluate=mock.AsyncMock(return_value={
            "role": "textbox",
            "accessible_name": "输入框",
            "placeholder": "请输入内容",
            "id": "chat-textarea",
            "text": "",
            "css_path": '[id="chat-textarea"]',
            "xpath": '//*[@id="chat-textarea"]',
            "attributes": {"name": "message"},
        }))

        candidates = await WebElementInspector().suggest_from_locator(locator)

        self.assertTrue(any(item["source"] == "role" for item in candidates))
        self.assertTrue(any(item["source"] == "placeholder" for item in candidates))
        self.assertTrue(any(item["source"] == "id_xpath" for item in candidates))
        locator.evaluate.assert_awaited_once()

    async def test_validate_returns_every_locator_group(self):
        def locator(count, *, visible=True, text=""):
            first = SimpleNamespace(
                bounding_box=mock.AsyncMock(return_value={"x": 10, "y": 20, "width": 80, "height": 30}),
                inner_text=mock.AsyncMock(return_value=text),
                text_content=mock.AsyncMock(return_value=text),
                is_visible=mock.AsyncMock(return_value=visible),
                is_enabled=mock.AsyncMock(return_value=True),
                is_editable=mock.AsyncMock(return_value=False),
            )
            return SimpleNamespace(count=mock.AsyncMock(return_value=count), first=first)

        inspector = WebElementInspector()
        inspector.playwright_locator = mock.Mock(side_effect=[
            locator(0),
            locator(2, text="提交"),
            locator(1, visible=False, text="隐藏提交"),
            locator(2, text="提交"),
        ])
        inspector.collect_baseline = mock.AsyncMock(return_value={"tag": "button"})
        with mock.patch(
            "mangoautomation.uidrives.web.inspection.inspector.WebElementHighlighter.highlight_async",
            new=mock.AsyncMock(return_value=2),
        ):
            result = await inspector.validate(
                SimpleNamespace(),
                [
                    {"exp": 2, "loc": 'get_by_role("button", name="不存在")'},
                    {"exp": 2, "loc": 'get_by_role("button", name="提交")'},
                    {"exp": 9, "loc": ".hidden-submit"},
                ],
                highlight=True,
                baseline_item={"label": "提交"},
            )

        self.assertTrue(result["status"])
        self.assertEqual(result["selected_group"], 2)
        self.assertEqual(
            [item["status"] for item in result["locator_groups"]],
            ["invalid", "risk", "invalid"],
        )
        self.assertTrue(result["locator_groups"][1]["highlighted"])
        self.assertEqual(result["baseline_snapshot"], {"tag": "button"})
