import unittest

from mangoautomation.enums import BrowserTypeEnum
from mangoautomation.uidrives.web.browser_compatibility import (
    AUTOMATION_COMPATIBILITY_INIT_SCRIPT,
    CHROMIUM_COMPATIBILITY_ARGS,
    apply_browser_compatibility_launch_args,
)


class BrowserCompatibilityTest(unittest.TestCase):
    def test_chromium_and_edge_share_compatibility_argument(self):
        for web_type in (BrowserTypeEnum.CHROMIUM.value, BrowserTypeEnum.EDGE.value):
            options = apply_browser_compatibility_launch_args(
                web_type,
                {"args": ["--window-size=1440,900"]},
            )
            self.assertIn("--window-size=1440,900", options["args"])
            self.assertIn(CHROMIUM_COMPATIBILITY_ARGS[0], options["args"])

    def test_compatibility_argument_is_not_duplicated(self):
        argument = CHROMIUM_COMPATIBILITY_ARGS[0]
        options = apply_browser_compatibility_launch_args(
            BrowserTypeEnum.CHROMIUM.value,
            {"args": [argument]},
        )
        self.assertEqual(options["args"].count(argument), 1)

    def test_non_chromium_browser_options_are_unchanged(self):
        original = {"headless": False, "args": ["--custom"]}
        options = apply_browser_compatibility_launch_args(BrowserTypeEnum.FIREFOX.value, original)
        self.assertEqual(options, original)
        self.assertIsNot(options, original)

    def test_context_script_normalizes_webdriver_marker(self):
        self.assertIn("navigatorPrototype", AUTOMATION_COMPATIBILITY_INIT_SCRIPT)
        self.assertIn("'webdriver'", AUTOMATION_COMPATIBILITY_INIT_SCRIPT)
        self.assertIn("get: () => undefined", AUTOMATION_COMPATIBILITY_INIT_SCRIPT)


if __name__ == "__main__":
    unittest.main()
