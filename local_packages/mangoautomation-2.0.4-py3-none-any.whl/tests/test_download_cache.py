# -*- coding: utf-8 -*-

import asyncio
import os
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, Mock

from mangoautomation.uidrives.web.async_web._element import AsyncWebElement
from mangoautomation.uidrives.web.sync_web._element import SyncWebElement


class TestDownloadCache(unittest.TestCase):

    def test_sync_download_caches_absolute_saved_path(self):
        download = SimpleNamespace(
            suggested_filename='contract.docx',
            save_as=Mock(),
        )
        download_context = MagicMock()
        download_context.__enter__.return_value = SimpleNamespace(value=download)
        page = SimpleNamespace(expect_download=Mock(return_value=download_context))
        test_data = SimpleNamespace(set_cache=Mock())
        base_data = SimpleNamespace(
            page=page,
            download_path='downloads',
            test_data=test_data,
        )
        locating = SimpleNamespace(first=SimpleNamespace(click=Mock()))

        SyncWebElement(base_data).w_download(locating, '下载文件')

        expected_path = os.path.abspath(os.path.join('downloads', 'contract.docx'))
        download.save_as.assert_called_once_with(expected_path)
        test_data.set_cache.assert_called_once_with('下载文件', expected_path)

    def test_async_download_caches_absolute_saved_path(self):
        async def run_test():
            download = SimpleNamespace(
                suggested_filename='contract.xlsx',
                save_as=AsyncMock(),
            )
            download_context = MagicMock()
            download_context.__aenter__ = AsyncMock(
                return_value=SimpleNamespace(
                    value=AsyncMock(return_value=download)(),
                )
            )
            download_context.__aexit__ = AsyncMock(return_value=None)
            page = SimpleNamespace(expect_download=Mock(return_value=download_context))
            test_data = SimpleNamespace(set_cache=Mock())
            base_data = SimpleNamespace(
                page=page,
                download_path='downloads',
                test_data=test_data,
            )
            locating = SimpleNamespace(first=SimpleNamespace(click=AsyncMock()))

            await AsyncWebElement(base_data).w_download(locating, '下载文件')

            expected_path = os.path.abspath(os.path.join('downloads', 'contract.xlsx'))
            download.save_as.assert_awaited_once_with(expected_path)
            test_data.set_cache.assert_called_once_with('下载文件', expected_path)

        asyncio.run(run_test())


if __name__ == '__main__':
    unittest.main()
