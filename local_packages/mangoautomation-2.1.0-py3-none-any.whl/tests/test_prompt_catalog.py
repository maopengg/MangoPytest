import ast
import re
from pathlib import Path

import pytest

from mangoautomation.prompts import get_prompt, validate_prompt_catalog
from mangoautomation.prompts.registry import PROMPT_FILES


PACKAGE_ROOT = Path(__file__).resolve().parents[1] / 'mangoautomation'
PROMPTS_ROOT = PACKAGE_ROOT / 'prompts'


def test_prompt_catalog_is_complete_and_valid():
    prompts = validate_prompt_catalog()
    assert len(prompts) == len(PROMPT_FILES)
    assert {prompt.id for prompt in prompts} == set(PROMPT_FILES)


def test_prompt_templates_render_and_reject_missing_variables():
    placeholder_pattern = re.compile(r'{{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*}}')
    for prompt in validate_prompt_catalog():
        for key, template in prompt.templates.items():
            variables = {
                name: f'<{name}>'
                for name in placeholder_pattern.findall(template)
            }
            assert prompt.render(key, **variables)
            if variables:
                with pytest.raises(ValueError):
                    prompt.render(key)


def test_prompt_bodies_do_not_return_to_business_modules():
    violations = []
    for path in PACKAGE_ROOT.rglob('*.py'):
        if PROMPTS_ROOT in path.parents or '__pycache__' in path.parts:
            continue
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if any(
                    isinstance(target, ast.Name)
                    and (target.id.endswith('_PROMPT') or target.id.endswith('_PROMPTS'))
                    for target in targets
                ) and isinstance(node.value, (ast.Constant, ast.Dict, ast.List, ast.Tuple)):
                    violations.append(f'{path.relative_to(PACKAGE_ROOT)}:{node.lineno}')
            if not isinstance(node, ast.Dict):
                continue
            literal = {
                key.value: value
                for key, value in zip(node.keys, node.values)
                if isinstance(key, ast.Constant) and isinstance(key.value, str)
            }
            if (
                isinstance(literal.get('role'), ast.Constant)
                and literal['role'].value in {'system', 'user'}
                and isinstance(literal.get('content'), ast.Constant)
                and isinstance(literal['content'].value, str)
                and len(literal['content'].value.strip()) >= 40
            ):
                violations.append(f'{path.relative_to(PACKAGE_ROOT)}:{node.lineno}')
    assert violations == []


def test_expected_prompt_versions_remain_public():
    assert get_prompt('step_healing.planner').version == 'page-step-healing-v7'
    assert get_prompt('element_healing.web_locator').version == 'web-snapshot-ref-v7'
    assert get_prompt('element_healing.visual_locator').version == 'visual-marker-v1'
