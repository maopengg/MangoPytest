import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from mangoautomation.enums import DriveTypeEnum, ElementExpEnum, ElementOperationEnum
from mangoautomation.models import ElementListModel, ElementModel, MethodModel
from mangoautomation.uidrives import AsyncElement
from mangoautomation.uidrives.ios import IOSDriver, IOSLocator
from mangoautomation.uidrives.runtime import IOSRuntime
from mangotools.enums import StatusEnum


class IOSRuntimeTests(unittest.TestCase):
    def test_runtime_builds_xcuitest_session_once(self):
        remote = MagicMock(return_value=SimpleNamespace(session_id='ios-session'))
        runtime = IOSRuntime('http://127.0.0.1:4723/', {
            'platformName': 'iOS',
            'appium:automationName': 'XCUITest',
            'appium:deviceName': 'iPhone 16',
        })

        with patch('mangoautomation.uidrives.runtime.ios_runtime.webdriver.Remote', remote):
            first = runtime.connect()
            second = runtime.connect()

        self.assertIs(first, second)
        self.assertEqual(remote.call_count, 1)
        self.assertEqual(runtime.server_url, 'http://127.0.0.1:4723')

    def test_ios_locator_refreshes_until_selected_element_exists(self):
        element = SimpleNamespace(text='提交')
        driver = MagicMock()
        driver.find_elements.side_effect = [[], [element]]
        locator = IOSLocator([], driver=driver, by='accessibility id', value='提交')

        self.assertEqual(locator.count, 0)
        locator.refresh()
        self.assertEqual(locator.count, 0)
        locator.refresh()
        self.assertEqual(locator.text, '提交')

    def test_driver_supports_ios_locator_strategies(self):
        element = SimpleNamespace(text='保存')
        appium_driver = MagicMock()
        appium_driver.find_elements.return_value = [element]
        base_data = SimpleNamespace(ios=appium_driver)
        driver = IOSDriver(base_data)

        locator, count, text = driver.i_find_ele(
            '保存',
            DriveTypeEnum.IOS.value,
            ElementExpEnum.IOS_ACCESSIBILITY_ID.value,
            '保存',
            None,
        )

        self.assertEqual(count, 1)
        self.assertEqual(text, '保存')
        self.assertIs(locator.element, element)


class IOSExecutionChainTests(unittest.IsolatedAsyncioTestCase):
    async def test_async_element_executes_ios_assertion_with_locator(self):
        appium_element = MagicMock()
        appium_element.text = '提交'
        appium_element.is_displayed.return_value = True
        appium_element.is_enabled.return_value = True
        appium_element.get_attribute.return_value = 'XCUIElementTypeButton'
        appium_element.rect = {'x': 10, 'y': 20, 'width': 100, 'height': 40}
        appium_driver = MagicMock()
        appium_driver.find_elements.return_value = [appium_element]
        test_data = SimpleNamespace(replace=lambda value: value)
        base_data = SimpleNamespace(
            ios=appium_driver,
            page=None,
            test_data=test_data,
            locator_engine=None,
            is_ai=False,
            log=MagicMock(),
            screenshot_path='/tmp',
            verify_equipment=lambda _drive_type: None,
        )
        model = ElementModel(
            id=1,
            type=ElementOperationEnum.ASS,
            name='提交按钮',
            elements=[ElementListModel(
                exp=ElementExpEnum.IOS_ACCESSIBILITY_ID.value,
                loc='提交',
            )],
            sleep=None,
            ope_key='i_assert_visible',
            ope_value=[MethodModel(f='actual')],
        )

        result = await AsyncElement(base_data, DriveTypeEnum.IOS.value).element_main(model)

        self.assertEqual(result.status, StatusEnum.SUCCESS.value)
        self.assertEqual(result.ass_msg, '实际=可见, 预期=可见')
        self.assertEqual(result.elements[0].ele_quantity, 1)
        self.assertTrue(result.elements[0].visible)


if __name__ == '__main__':
    unittest.main()
