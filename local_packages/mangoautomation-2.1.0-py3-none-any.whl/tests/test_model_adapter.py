# -*- coding: utf-8 -*-
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from mangoautomation.element_healing.agent.web.model_adapter import OpenAICompatibleModelClient


class ModelAdapterTest(unittest.TestCase):
    @patch('mangoautomation.element_healing.agent.web.model_adapter.AsyncOpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.OpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultAsyncHttpxClient')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultHttpxClient')
    def test_page_step_client_can_use_a_larger_independent_timeout_cap(
            self, sync_http_client, async_http_client, sync_openai, async_openai):
        client = OpenAICompatibleModelClient(
            'key', 'https://ai.example.test/v1', 'model', 1800,
            max_timeout_seconds=60,
        )

        self.assertEqual(client.timeout_seconds, 60.0)
        sync_http_client.assert_called_once_with(trust_env=False, timeout=60.0)
        async_http_client.assert_called_once_with(trust_env=False, timeout=60.0)

    @patch('mangoautomation.element_healing.agent.web.model_adapter.AsyncOpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.OpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultAsyncHttpxClient')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultHttpxClient')
    def test_ai_clients_ignore_environment_proxy(
            self, sync_http_client, async_http_client, sync_openai, async_openai):
        OpenAICompatibleModelClient('key', 'https://ai.example.test/v1', 'model', 20)

        sync_http_client.assert_called_once_with(trust_env=False, timeout=20.0)
        async_http_client.assert_called_once_with(trust_env=False, timeout=20.0)
        self.assertIs(sync_openai.call_args.kwargs['http_client'], sync_http_client.return_value)
        self.assertIs(async_openai.call_args.kwargs['http_client'], async_http_client.return_value)
        self.assertEqual(sync_openai.call_args.kwargs['max_retries'], 0)
        self.assertEqual(async_openai.call_args.kwargs['max_retries'], 0)

    @staticmethod
    def _response(content):
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=content))],
        )

    @patch('mangoautomation.element_healing.agent.web.model_adapter.AsyncOpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.OpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultAsyncHttpxClient')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultHttpxClient')
    def test_sync_retries_empty_reasoning_model_content_with_larger_budget(
            self, sync_http_client, async_http_client, sync_openai, async_openai):
        completion = MagicMock(side_effect=[
            self._response(''),
            self._response('{"ok":true}'),
        ])
        sync_openai.return_value.chat.completions.create = completion
        client = OpenAICompatibleModelClient('key', 'https://ai.example.test/v1', 'model', 20)

        content = client.complete_sync(
            [{'role': 'user', 'content': 'locate'}],
            max_tokens=800,
            temperature=0,
            response_format={'type': 'json_object'},
        )

        self.assertEqual(content, '{"ok":true}')
        self.assertEqual(completion.call_count, 2)
        self.assertEqual(completion.call_args_list[1].kwargs['max_tokens'], 3200)

    @patch('mangoautomation.element_healing.agent.web.model_adapter.AsyncOpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.OpenAI')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultAsyncHttpxClient')
    @patch('mangoautomation.element_healing.agent.web.model_adapter.DefaultHttpxClient')
    def test_async_retries_empty_reasoning_model_content_with_larger_budget(
            self, sync_http_client, async_http_client, sync_openai, async_openai):
        completion = AsyncMock(side_effect=[
            self._response(None),
            self._response([{'type': 'text', 'text': '{"ok":true}'}]),
        ])
        async_openai.return_value.chat.completions.create = completion
        client = OpenAICompatibleModelClient('key', 'https://ai.example.test/v1', 'model', 20)

        async def run():
            return await client.complete_async(
                [{'role': 'user', 'content': 'locate'}],
                max_tokens=800,
                temperature=0,
                response_format={'type': 'json_object'},
            )

        content = __import__('asyncio').run(run())

        self.assertEqual(content, '{"ok":true}')
        self.assertEqual(completion.await_count, 2)
        self.assertEqual(completion.call_args_list[1].kwargs['max_tokens'], 3200)


if __name__ == '__main__':
    unittest.main()
