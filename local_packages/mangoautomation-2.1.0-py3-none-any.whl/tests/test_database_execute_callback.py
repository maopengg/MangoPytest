from unittest import IsolatedAsyncioTestCase
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from mangotools.models import MethodModel
from mangoautomation.enums import DriveTypeEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.uidrives._async_element import AsyncElement
from mangoautomation.uidrives._sync_element import SyncElement
from mangoautomation.uidrives.context import AutomationContext
from mangoautomation.models import EnvironmentConfigModel, UiPublicModel


class DatabaseExecuteCallbackTest(IsolatedAsyncioTestCase):
    def test_runtime_models_do_not_expose_database_connection_fields(self):
        environment_payload = EnvironmentConfigModel(
            id=9,
            test_object_value='https://example.test',
        ).model_dump()
        public_payload = UiPublicModel(
            id=71,
            type=1,
            key='token',
            value='value',
            datasource_alias=12,
        ).model_dump()

        forbidden_fields = {
            'db_c_status',
            'db_rud_status',
            'db_type',
            'mysql_config',
            'database_connections',
        }
        self.assertTrue(forbidden_fields.isdisjoint(environment_payload))
        self.assertTrue(forbidden_fields.isdisjoint(public_payload))

    async def test_async_callback_receives_operation_and_context(self):
        callback = AsyncMock(return_value=[{'id': 7}])
        context = AutomationContext(MagicMock(), MagicMock())
        context.set_database_execute_callback(callback)

        result = await context.execute_database(
            'SELECT id FROM users',
            datasource_alias_id=12,
            source_context={'source_stage': 'sql_assertion', 'element_id': 31},
        )

        self.assertEqual(result, [{'id': 7}])
        callback.assert_awaited_once_with(
            operation_config='SELECT id FROM users',
            datasource_alias_id=12,
            source_context={'source_stage': 'sql_assertion', 'element_id': 31},
        )

    async def test_missing_callback_does_not_fallback_to_database_connection(self):
        context = AutomationContext(MagicMock(), MagicMock())
        context.database_result_adapter = MagicMock()

        with self.assertRaises(MangoAutomationError):
            await context.execute_database('SELECT 8')

        context.database_result_adapter.condition_execute.assert_not_called()

    def test_sync_callback_receives_operation_and_context(self):
        callback = MagicMock(return_value=[{'id': 8}])
        context = AutomationContext(MagicMock(), MagicMock())
        context.set_database_execute_callback(callback)

        result = context.execute_database_sync(
            'SELECT id FROM users',
            datasource_alias_id=13,
            source_context={'source_stage': 'page_step_sql', 'element_id': 32},
        )

        self.assertEqual(result, [{'id': 8}])
        callback.assert_called_once_with(
            operation_config='SELECT id FROM users',
            datasource_alias_id=13,
            source_context={'source_stage': 'page_step_sql', 'element_id': 32},
        )

    async def test_async_sql_step_uses_database_callback(self):
        element = AsyncElement.__new__(AsyncElement)
        test_data = SimpleNamespace(
            replace=lambda value: value,
            set_sql_cache=MagicMock(),
        )
        element.base_data = SimpleNamespace(
            database_execute_callback=object(),
            database_result_adapter=None,
            execute_database=AsyncMock(return_value=[{'id': 9}]),
            test_data=test_data,
            log=MagicMock(),
        )
        element.element_model = SimpleNamespace(
            id=31,
            sql_execute=[{
                'datasource_alias': 12,
                'sql': 'SELECT id FROM users',
                'key_list': 'id',
            }],
        )

        await element._AsyncElement__sql()

        element.base_data.execute_database.assert_awaited_once_with(
            'SELECT id FROM users',
            datasource_alias_id=12,
            source_context={'source_stage': 'page_step_sql', 'element_id': 31},
        )
        test_data.set_sql_cache.assert_called_once_with('id', {'id': 9})

    async def test_async_sql_assertion_uses_callback_result(self):
        element = AsyncElement.__new__(AsyncElement)
        original_adapter = object()
        element.base_data = SimpleNamespace(
            database_execute_callback=object(),
            database_result_adapter=original_adapter,
            execute_database=AsyncMock(return_value=[{'count': 1}]),
            log=MagicMock(),
        )
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_model = SimpleNamespace(
            id=41,
            name='SQL断言',
            ope_key='assert_sql_count',
            ope_value=[
                MethodModel(f='actual', v='SELECT 1'),
                MethodModel(f='expect', v=1),
                MethodModel(f='datasource_alias', v=15),
            ],
        )
        element.element_result_model = SimpleNamespace(ass_msg=None, ope_value=None)
        element._AsyncElement__ope_value = AsyncMock()
        element._AsyncElement__refresh_assertion_locator_result = AsyncMock()

        async def assertion(_name, _key, values):
            return element.base_data.database_result_adapter.condition_execute(values['actual'])

        element.web_assertion_element = assertion

        await element._AsyncElement__ass()

        element.base_data.execute_database.assert_awaited_once_with(
            'SELECT 1',
            datasource_alias_id=15,
            source_context={
                'source_stage': 'sql_assertion',
                'element_id': 41,
                'assertion': 'assert_sql_count',
            },
        )
        self.assertIs(element.base_data.database_result_adapter, original_adapter)

    def test_sync_sql_step_uses_database_callback(self):
        element = SyncElement.__new__(SyncElement)
        test_data = SimpleNamespace(
            replace=lambda value: value,
            set_sql_cache=MagicMock(),
        )
        element.base_data = SimpleNamespace(
            database_execute_callback=object(),
            execute_database_sync=MagicMock(return_value=[{'id': 10}]),
            test_data=test_data,
            log=MagicMock(),
        )
        element.element_model = SimpleNamespace(
            id=33,
            sql_execute=[{
                'datasource_alias': 16,
                'sql': 'SELECT id FROM users',
                'key_list': 'id',
            }],
        )

        element._SyncElement__sql()

        element.base_data.execute_database_sync.assert_called_once_with(
            'SELECT id FROM users',
            datasource_alias_id=16,
            source_context={'source_stage': 'page_step_sql', 'element_id': 33},
        )
        test_data.set_sql_cache.assert_called_once_with('id', {'id': 10})

    def test_package_source_has_no_direct_database_execution(self):
        package_root = Path(__file__).resolve().parents[1] / 'mangoautomation'
        forbidden = (
            'create_database_connection',
            'set_mysql(',
            '.condition_execute(',
            'pymysql',
            'mysql.connector',
            'sqlalchemy.create_engine',
        )
        violations = []
        for path in package_root.rglob('*.py'):
            content = path.read_text(encoding='utf-8')
            for marker in forbidden:
                if marker in content:
                    violations.append(f'{path.relative_to(package_root)}: {marker}')

        self.assertEqual(violations, [])
