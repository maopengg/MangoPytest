import unittest
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

from pydantic import ValidationError

from mangoautomation.element_healing.snapshot import AccessibilitySnapshot, AccessibilitySnapshotNode
from mangoautomation.step_healing import (
    StepCondition,
    StepHealingPlanner,
    StepHealingPolicy,
    StepRepairGuard,
    StepRepairPlan,
    StepRepairRejected,
    PageStepStateObserver,
)
from mangoautomation.step_healing.prompt import PageStepHealingPrompt


def snapshot():
    return AccessibilitySnapshot(
        snapshot_id='snapshot01', page_url='https://example.com/flow', created_at_ms=1,
        nodes=[AccessibilitySnapshotNode(
            ref='e1', frame_index=0, order=0, role='button', name='Continue',
            tag='button', interactive=True,
        )],
    )


class StepHealingProtocolTest(unittest.TestCase):
    def test_native_snapshot_tree_is_not_truncated_by_generic_sanitizer(self):
        long_tree = '- generic [ref=e1]\n' + ('x' * 2500) + '\n- button "下一步" [ref=e2]'
        value = snapshot().model_copy(update={
            'ref_engine': 'playwright_aria',
            'tree': long_tree,
        })

        messages = PageStepHealingPrompt.messages({'id': 1}, value)
        payload = json.loads(messages[1]['content'])

        self.assertIn('下一步', payload['page']['tree'])

    def test_large_snapshot_prioritizes_active_dialog_and_keeps_action_ref(self):
        noisy_rows = '\n'.join(
            f'    - generic "row {index} {"x" * 80}" [ref=e{index + 10}]'
            for index in range(300)
        )
        long_tree = (
            f'- generic [ref=e1]:\n{noisy_rows}\n'
            '  - generic [active] [ref=e500]:\n'
            '    - dialog:\n'
            '      - generic "上传合同文件" [ref=e501]\n'
            '      - button "下一步" [ref=e502]\n'
        )
        value = snapshot().model_copy(update={
            'ref_engine': 'playwright_aria',
            'tree': long_tree,
        })

        messages = PageStepHealingPrompt.messages({'id': 1}, value)
        tree = json.loads(messages[1]['content'])['page']['tree']

        self.assertLessEqual(len(tree), 3000)
        self.assertIn('上传合同文件', tree)
        self.assertIn('button "下一步" [ref=e502]', tree)
        self.assertNotIn('row 299', tree)

    def test_prompt_removes_non_actionable_graph_metadata(self):
        context = {
            'id': 1,
            'goal': 'Continue the upload flow',
            'failed_node_id': '3',
            'nodes': [{
                'node_id': '3', 'detail_id': 30, 'type': 0, 'name': 'Search',
                'operation_key': 'w_input', 'operation_intent': 'edit',
                'risk_level': 'low', 'precondition_keys': ['node:3:pre'],
                'later_checkpoints': ['success'],
            }],
        }

        messages = PageStepHealingPrompt.messages(context, snapshot())
        page_step = json.loads(messages[1]['content'])['workflow']

        self.assertEqual(page_step['current']['node_id'], '3')
        self.assertNotIn('detail_id', page_step['current'])
        self.assertNotIn('precondition_keys', page_step['current'])
        self.assertNotIn('later_checkpoints', page_step['current'])

    def test_prompt_keeps_runtime_dependency_failure_kind(self):
        context = {
            'id': 1,
            'goal': '搜索芒果测试平台一次',
            'failure_kind': 'runtime_data_dependency_missing',
            'failure_summary': 'missing cache key',
        }

        messages = PageStepHealingPrompt.messages(context, snapshot())
        payload = json.loads(messages[1]['content'])

        self.assertEqual(
            payload['workflow']['failure_kind'],
            'runtime_data_dependency_missing',
        )
        self.assertEqual(
            payload['workflow']['recovery_scope'],
            'replace_failed_node_with_goal_actions',
        )
        self.assertFalse(payload['workflow']['failed_node_is_authoritative_target'])
        self.assertIn('workflow.goal为准', payload['task'])
        self.assertTrue(any(
            'runtime_data_dependency_missing' in instruction
            and 'retry_node' in instruction
            for instruction in payload['instructions']
        ))
        self.assertTrue(any(
            'edit textbox/searchbox' in instruction
            for instruction in payload['instructions']
        ))
        self.assertTrue(any(
            'actions不能为空' in instruction
            for instruction in payload['instructions']
        ))
        self.assertTrue(any(
            'skip_node作为最后一个动作' in instruction
            for instruction in payload['instructions']
        ))
        self.assertEqual(payload['output_contract']['schema_version'], 1)
        self.assertTrue(any(
            '不得只返回actions' in instruction
            and 'diagnosis_code' in instruction
            and 'user_message' in instruction
            for instruction in payload['instructions']
        ))

    def test_prompt_replaces_completed_nodes_with_compact_history(self):
        context = {
            'id': 1,
            'execution_history': [{'node_id': '1', 'status': 'success', 'error': None}],
            'nodes': [
                {'node_id': '1', 'name': 'Upload file', 'operation_key': 'w_upload_files'},
                {'node_id': '2', 'name': 'Search type', 'operation_key': 'w_input'},
            ],
        }

        messages = PageStepHealingPrompt.messages(context, snapshot())
        page_step = json.loads(messages[1]['content'])['workflow']

        self.assertEqual(page_step['completed'], [
            {'node_id': '1', 'name': 'Upload file', 'status': 'success'},
        ])
        self.assertEqual([item['node_id'] for item in page_step['pending']], ['2'])

    def test_removed_condition_types_are_rejected(self):
        for condition_type, matcher in (
            ('dialog_state', 'open'),
            ('variable_state', 'exists'),
        ):
            with self.subTest(condition_type=condition_type), self.assertRaises(ValueError):
                StepCondition(type=condition_type, matcher=matcher)

    def test_incompatible_matcher_is_rejected(self):
        with self.assertRaises(ValueError):
            StepCondition(type='element_state', matcher='contains', element_id=1)

    def test_strict_response_is_parsed(self):
        result = StepHealingPlanner.parse('''{
          "schema_version": 1,
          "current_phase": "confirm",
          "diagnosis_code": "dialog_changed",
          "diagnosis_summary": "Continue action moved",
          "confidence": 0.92,
          "actions": [{
            "action": "insert_action", "operation_intent": "activate",
            "target_ref": "e1", "reason": "Close the harmless guide",
            "expected_condition": {"operator": "all", "conditions": []}
          }],
          "expected_checkpoint": null,
          "user_message": "A harmless guide was handled temporarily"
        }''')
        self.assertEqual(result.actions[0].target_ref, 'e1')

    def test_provider_plan_envelope_is_unwrapped(self):
        result = StepHealingPlanner.parse('''{
          "repair_plan": {
            "schema_version": 1,
            "diagnosis_code": "missing_step",
            "diagnosis_summary": "A safe action is required",
            "confidence": 0.91,
            "actions": [{
              "action": "insert_action", "operation_intent": "activate",
              "target_ref": "e1", "reason": "continue"
            }],
            "user_message": "Recovered"
          }
        }''')
        self.assertEqual(result.diagnosis_code, 'missing_step')

    def test_actions_only_response_is_not_silently_completed(self):
        with self.assertRaisesRegex(
            ValueError,
            'diagnosis_code:missing.*confidence:missing.*user_message:missing',
        ):
            StepHealingPlanner.parse('''{
              "schema_version": 1,
              "actions": [{"action": "abort", "reason": "uncertain"}]
            }''')

    def test_unknown_response_fields_are_rejected(self):
        with self.assertRaises((ValidationError, ValueError)):
            StepRepairPlan.model_validate({
                'schema_version': 1, 'diagnosis_code': 'x', 'diagnosis_summary': 'x',
                'confidence': .8, 'actions': [], 'user_message': 'x', 'selector': '#unsafe',
            })


class StepHealingPlannerCompatibilityTest(unittest.IsolatedAsyncioTestCase):
    async def test_planner_requests_openai_compatible_json_object(self):
        client = SimpleNamespace(
            available=True,
            complete_async=AsyncMock(return_value='''{
              "schema_version": 1,
              "diagnosis_code": "missing_step",
              "diagnosis_summary": "Continue is required",
              "confidence": 0.95,
              "actions": [{"action": "insert_action", "operation_intent": "activate", "target_ref": "e1", "reason": "continue"}],
              "user_message": "Recovered"
            }'''),
        )

        await StepHealingPlanner(client).plan_async({'id': 1}, snapshot())

        self.assertEqual(
            client.complete_async.await_args.kwargs['response_format'],
            {'type': 'json_object'},
        )
        self.assertEqual(client.complete_async.await_args.kwargs['max_tokens'], 1024)

    def test_guard_accepts_existing_ref_and_bound_data(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1, 'diagnosis_code': 'missing_field',
            'diagnosis_summary': 'A field must be filled', 'confidence': .9,
            'actions': [{
                'action': 'insert_action', 'operation_intent': 'edit', 'target_ref': 'e1',
                'value_binding': 'template_name', 'reason': 'fill existing data',
            }], 'user_message': 'Filled the newly required field',
        })
        result = StepRepairGuard.validate(
            plan, policy=StepHealingPolicy(mode='execute_low_risk'), current_node_id='1',
            node_map={'1': {'risk_level': 'low', 'type': 0}}, matched_checkpoints=set(),
            available_data={'template_name'}, snapshot=snapshot(),
        )
        self.assertIs(result, plan)

    def test_guard_accepts_expression_style_value_binding(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1, 'diagnosis_code': 'missing_field',
            'diagnosis_summary': 'A field must be filled', 'confidence': .9,
            'actions': [{
                'action': 'insert_action', 'operation_intent': 'edit', 'target_ref': 'e1',
                'value_binding': '${{ template_name }}', 'reason': 'fill existing data',
            }], 'user_message': 'Filled the newly required field',
        })
        result = StepRepairGuard.validate(
            plan, policy=StepHealingPolicy(mode='execute_low_risk'), current_node_id='1',
            node_map={'1': {'risk_level': 'low', 'type': 0}}, matched_checkpoints=set(),
            available_data={'template_name'}, snapshot=snapshot(),
        )
        self.assertIs(result, plan)

    def test_guard_accepts_literal_declared_by_step_goal(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1, 'diagnosis_code': 'missing_field',
            'diagnosis_summary': 'A search value must be entered', 'confidence': .9,
            'actions': [{
                'action': 'insert_action', 'operation_intent': 'edit', 'target_ref': 'e1',
                'value_literal': '芒果测试平台', 'reason': 'fill the value declared in the goal',
            }], 'user_message': 'Filled the search value',
        })
        result = StepRepairGuard.validate(
            plan, policy=StepHealingPolicy(mode='execute_low_risk'), current_node_id='1',
            node_map={'1': {'risk_level': 'low', 'type': 0}}, matched_checkpoints=set(),
            available_data=set(), snapshot=snapshot(),
            trusted_text_sources=['搜索芒果测试平台一次'],
        )
        self.assertIs(result, plan)

    def test_guard_rejects_literal_not_declared_by_step_goal(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1, 'diagnosis_code': 'missing_field',
            'diagnosis_summary': 'A search value must be entered', 'confidence': .9,
            'actions': [{
                'action': 'insert_action', 'operation_intent': 'edit', 'target_ref': 'e1',
                'value_literal': '未声明的内容', 'reason': 'invent a search value',
            }], 'user_message': 'Filled the search value',
        })
        with self.assertRaises(StepRepairRejected):
            StepRepairGuard.validate(
                plan, policy=StepHealingPolicy(mode='execute_low_risk'), current_node_id='1',
                node_map={'1': {'risk_level': 'low', 'type': 0}}, matched_checkpoints=set(),
                available_data=set(), snapshot=snapshot(),
                trusted_text_sources=['搜索芒果测试平台一次'],
            )

    def test_guard_rejects_invented_ref(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1, 'diagnosis_code': 'x', 'diagnosis_summary': 'x',
            'confidence': .9, 'actions': [{
                'action': 'insert_action', 'operation_intent': 'activate',
                'target_ref': 'e2', 'reason': 'try unknown target',
            }], 'user_message': 'No action taken',
        })
        with self.assertRaises(StepRepairRejected):
            StepRepairGuard.validate(
                plan, policy=StepHealingPolicy(mode='execute_low_risk'), current_node_id='1',
                node_map={'1': {'risk_level': 'low', 'type': 0}}, matched_checkpoints=set(),
                available_data=set(), snapshot=snapshot(),
            )

    def test_guard_allows_replaced_runtime_node_to_be_removed_without_checkpoint(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1,
            'diagnosis_code': 'runtime_dependency_replaced',
            'diagnosis_summary': 'The broken node was replaced',
            'confidence': .95,
            'actions': [{
                'action': 'skip_node', 'node_id': '1',
                'reason': 'remove the replaced node',
            }],
            'user_message': 'Replaced',
        })

        result = StepRepairGuard.validate(
            plan, policy=StepHealingPolicy(mode='execute_low_risk'),
            current_node_id='1',
            node_map={'1': {'risk_level': 'low', 'type': 0}},
            matched_checkpoints=set(), available_data=set(), snapshot=snapshot(),
            allow_replaced_current_node_skip=True,
        )

        self.assertIs(result, plan)


class PageStepStateObserverTest(unittest.IsolatedAsyncioTestCase):
    async def test_url_path_is_evaluated(self):
        observer = PageStepStateObserver(SimpleNamespace(url='https://example.com/template/list?q=demo'))
        matched = await observer.matches({
            'operator': 'all',
            'conditions': [{
                'type': 'url_path', 'matcher': 'equals', 'expected': '/template/list',
            }],
        })
        self.assertTrue(matched)

    async def test_visible_text_regex_uses_compiled_pattern(self):
        locator = SimpleNamespace(
            count=AsyncMock(return_value=1),
            nth=lambda _: SimpleNamespace(is_visible=AsyncMock(return_value=True)),
        )
        page = SimpleNamespace(get_by_text=lambda value, **_: locator)
        observer = PageStepStateObserver(page)
        matched = await observer.matches({
            'operator': 'all',
            'conditions': [{
                'type': 'visible_text', 'matcher': 'regex', 'expected': '^Done',
            }],
        })
        self.assertTrue(matched)

    async def test_visible_text_count_only_includes_visible_matches(self):
        locator = SimpleNamespace(
            count=AsyncMock(return_value=2),
            nth=lambda index: SimpleNamespace(
                is_visible=AsyncMock(return_value=index == 0),
            ),
        )
        page = SimpleNamespace(get_by_text=lambda value, **_: locator)
        observer = PageStepStateObserver(page)
        matched = await observer.matches({
            'operator': 'all',
            'conditions': [{
                'type': 'visible_text', 'matcher': 'count_gte',
                'expected': 'Done', 'count': 2,
            }],
        })
        self.assertFalse(matched)

    def test_assertion_node_cannot_be_skipped(self):
        plan = StepRepairPlan.model_validate({
            'schema_version': 1, 'diagnosis_code': 'already_done',
            'diagnosis_summary': 'Later state is visible', 'confidence': .95,
            'actions': [{'action': 'skip_node', 'node_id': '1', 'reason': 'already done'}],
            'user_message': 'Skip proposed',
        })
        with self.assertRaises(StepRepairRejected):
            StepRepairGuard.validate(
                plan, policy=StepHealingPolicy(mode='execute_low_risk'), current_node_id='1',
                node_map={'1': {'risk_level': 'low', 'type': 1, 'later_checkpoints': ['success']}},
                matched_checkpoints={'success'}, available_data=set(), snapshot=snapshot(),
            )


if __name__ == '__main__':
    unittest.main()
