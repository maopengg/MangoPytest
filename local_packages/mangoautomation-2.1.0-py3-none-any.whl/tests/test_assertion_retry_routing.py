# -*- coding: utf-8 -*-
import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

from mangoautomation.enums import DriveTypeEnum, ElementOperationEnum
from mangoautomation.uidrives._async_element import AsyncElement
from mangoautomation.uidrives._sync_element import SyncElement


def assertion_model(*, fields, elements):
    return SimpleNamespace(
        type=ElementOperationEnum.ASS,
        ope_value=[SimpleNamespace(f=field) for field in fields],
        elements=elements,
    )


class TestAssertionRetryRouting(unittest.TestCase):

    def test_sync_page_assertion_uses_its_own_wait_without_element_healing(self):
        element = SyncElement.__new__(SyncElement)
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_model = assertion_model(fields=['expect'], elements=[])
        element.base_data = SimpleNamespace(log=Mock())
        element._SyncElement__main = Mock()
        element._SyncElement__retry_then_heal = Mock()

        element._SyncElement__execute_with_retry_policy()

        element._SyncElement__main.assert_called_once_with()
        element._SyncElement__retry_then_heal.assert_not_called()

    def test_sync_element_assertion_keeps_element_healing_route(self):
        element = SyncElement.__new__(SyncElement)
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_model = assertion_model(
            fields=['actual', 'expect'], elements=[SimpleNamespace(loc='old')],
        )
        element.base_data = SimpleNamespace(
            log=Mock(),
            locator_engine=SimpleNamespace(locator_enabled=lambda: True),
        )
        element._SyncElement__retry_then_heal = Mock()

        element._SyncElement__execute_with_retry_policy()

        element._SyncElement__retry_then_heal.assert_called_once_with()

    def test_async_page_assertion_uses_its_own_wait_without_element_healing(self):
        element = AsyncElement.__new__(AsyncElement)
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_model = assertion_model(fields=['expect'], elements=[])
        element.base_data = SimpleNamespace(log=Mock())
        element._AsyncElement__main = AsyncMock()
        element._AsyncElement__retry_then_heal = AsyncMock()

        asyncio.run(element._AsyncElement__execute_with_retry_policy())

        element._AsyncElement__main.assert_awaited_once_with()
        element._AsyncElement__retry_then_heal.assert_not_awaited()

    def test_async_element_assertion_keeps_element_healing_route(self):
        element = AsyncElement.__new__(AsyncElement)
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_model = assertion_model(
            fields=['actual', 'expect'], elements=[SimpleNamespace(loc='old')],
        )
        element.base_data = SimpleNamespace(
            log=Mock(),
            locator_engine=SimpleNamespace(locator_enabled=lambda: True),
        )
        element._AsyncElement__retry_then_heal = AsyncMock()

        asyncio.run(element._AsyncElement__execute_with_retry_policy())

        element._AsyncElement__retry_then_heal.assert_awaited_once_with()


if __name__ == '__main__':
    unittest.main()
