# -*- coding: utf-8 -*-
import json
import unittest
import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from mangoautomation.element_healing import (
    InMemoryEventSink,
    InMemoryProvider,
    LocatorCandidate,
    WebElementHealingHarness,
)
from mangoautomation.element_healing.agent.web.candidate_normalizer import AgentCandidateNormalizer
from mangoautomation.element_healing.agent.web.agent import WebLocatorAgent
from mangoautomation.element_healing.agent.web.prompt import WebLocatorPrompt
from mangoautomation.element_healing.agent.web.snapshot_matcher import AccessibilitySnapshotMatcher
from mangoautomation.element_healing.agent.web.response_parser import (
    AgentResponseParser,
    AgentResponseSchemaError,
)
from mangoautomation.element_healing.agent.web.response_schema import (
    SCHEMA_VERSION,
    WebLocatorAgentResponse,
)
from mangoautomation.element_healing.agent.visual import WebVisualLocatorAgent
from mangoautomation.element_healing.agent.visual.response_schema import (
    SCHEMA_VERSION as VISUAL_SCHEMA_VERSION,
)
from mangoautomation.element_healing.candidates import AppliedRecordCandidateSource, CandidateRegistry
from mangoautomation.element_healing.agent.web.context_builder import WebAgentContextBuilder
from mangoautomation.element_healing.baseline import sanitize_snapshot
from mangoautomation.element_healing.baseline.collector import ELEMENT_SNAPSHOT_SCRIPT
from mangoautomation.element_healing.candidates.dom_proximity import DOM_PROXIMITY_SCRIPT
from mangoautomation.element_healing.context import semantic_required_texts, target_texts
from mangoautomation.element_healing.verification.target_intent import parse_target_intent
from mangoautomation.element_healing.locator import LocatorExpressionParser
from mangoautomation.element_healing.models import CandidateSource, HealingStatus, VerificationResult
from mangoautomation.element_healing.policy import (
    AgentCircuitBreaker,
    HealingPolicy,
    StaticRuntimeConfig,
    auto_apply_operation_compatibility_reason,
    operation_intent,
    operation_compatibility_reason,
)
from mangoautomation.element_healing.verification import (
    ActionabilityVerifier,
    AsyncCandidateVerifier,
    SemanticVerifier,
    SyncCandidateVerifier,
)
from mangoautomation.element_healing.verification.operation_target import OperationTargetResolver
from mangoautomation.element_healing.verification.scorer import CandidateScorer
from mangoautomation.element_healing.snapshot import (
    ACCESSIBILITY_SNAPSHOT_SCRIPT,
    SNAPSHOT_REF_ATTRIBUTE,
    AccessibilitySnapshot,
    AccessibilitySnapshotBuilder,
    AccessibilitySnapshotNode,
    DurableLocatorGenerator,
    LiveStableLocatorDeriver,
    SnapshotRefResolver,
)
from mangoautomation.enums import ElementExpEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.uidrives._element_retry_policy import DEFAULT_ELEMENT_RETRY_POLICY
from mangoautomation.uidrives._locator_failure import locator_failure_message


class _Element:
    id = 1
    element_id = 1
    name = 'Save'
    category = 'Dialog'
    elements = []


class ElementRetryPolicyTest(unittest.TestCase):

    def test_configuration_error_is_not_retried(self):
        error = MangoAutomationError(4048, 'invalid operation configuration')
        self.assertFalse(DEFAULT_ELEMENT_RETRY_POLICY.should_retry(error))

    def test_closed_browser_is_not_retried(self):
        error = MangoAutomationError(4010, 'web device is not initialized')
        self.assertFalse(DEFAULT_ELEMENT_RETRY_POLICY.should_retry(error))

    def test_missing_element_remains_retryable(self):
        error = MangoAutomationError(4053, 'element not found')
        self.assertTrue(DEFAULT_ELEMENT_RETRY_POLICY.should_retry(error))

    def test_fixed_phase_requires_shared_deadline_and_complete_round(self):
        policy = DEFAULT_ELEMENT_RETRY_POLICY
        self.assertFalse(policy.should_finish_fixed_phase(9.9, 10, [3, 3, 3]))
        self.assertFalse(policy.should_finish_fixed_phase(10, 10, [3, 3, 0]))
        self.assertTrue(policy.should_finish_fixed_phase(10, 10, [3, 3, 1]))

    def test_fixed_phase_is_skipped_without_configured_locators(self):
        self.assertTrue(
            DEFAULT_ELEMENT_RETRY_POLICY.should_finish_fixed_phase(0, 10, [])
        )

    def test_zero_second_window_still_attempts_every_configured_locator_once(self):
        policy = DEFAULT_ELEMENT_RETRY_POLICY
        self.assertFalse(policy.should_finish_fixed_phase(0, 0, [1, 0, 0]))
        self.assertTrue(policy.should_finish_fixed_phase(0, 0, [1, 1, 1]))


class _AsyncLocator:
    first = None

    def __init__(self, count=1, text='Save', attributes=None):
        self.first = self
        self._count = count
        self._text = text
        self._attributes = attributes or {}

    async def count(self):
        return self._count

    def nth(self, index):
        return self

    async def is_visible(self):
        return True

    async def click(self, **kwargs):
        return None

    async def inner_text(self):
        return self._text

    async def text_content(self):
        return self._text

    async def input_value(self):
        raise RuntimeError

    async def get_attribute(self, name):
        return self._attributes.get(name)

    async def evaluate(self, script):
        return {
            'tag': 'button',
            'role': 'button',
            'type': 'button',
            'text': self._text,
            'aria_label': self._text,
            'name': '',
            'title': '',
            'placeholder': '',
            'test_id': 'save-button',
            'label_texts': [],
            'editable': False,
            'interactive': True,
            'direct_interactive': True,
        }


class _AsyncPage:
    url = 'https://example.test/dialog'

    def is_closed(self):
        return False

    async def title(self):
        return 'Dialog'

    def get_by_role(self, role, name=None, **kwargs):
        return _AsyncLocator(1 if role == 'button' and name == 'Save' else 0)

    def get_by_text(self, *args, **kwargs):
        return _AsyncLocator(0)

    def get_by_placeholder(self, *args, **kwargs):
        return _AsyncLocator(0)

    def get_by_label(self, *args, **kwargs):
        return _AsyncLocator(0)

    def locator(self, *args, **kwargs):
        return _AsyncLocator(0)

    async def evaluate(self, script, arg=None):
        return []


class _SyncLocator:
    first = None

    def __init__(self, count=1, text='Save', attributes=None):
        self.first = self
        self._count = count
        self._text = text
        self._attributes = attributes or {}

    def count(self):
        return self._count

    def nth(self, index):
        return self

    def is_visible(self):
        return True

    def click(self, **kwargs):
        return None

    def inner_text(self):
        return self._text

    def text_content(self):
        return self._text

    def input_value(self):
        raise RuntimeError

    def get_attribute(self, name):
        return self._attributes.get(name)

    def evaluate(self, script):
        return {
            'tag': 'button',
            'role': 'button',
            'type': 'button',
            'text': self._text,
            'aria_label': self._text,
            'name': '',
            'title': '',
            'placeholder': '',
            'test_id': 'save-button',
            'label_texts': [],
            'editable': False,
            'interactive': True,
            'direct_interactive': True,
        }


class _SyncPage:
    url = 'https://example.test/dialog'

    def is_closed(self):
        return False

    def title(self):
        return 'Dialog'

    def get_by_role(self, role, name=None, **kwargs):
        return _SyncLocator(1 if role == 'button' and name == 'Save' else 0)

    def get_by_text(self, *args, **kwargs):
        return _SyncLocator(0)

    def get_by_placeholder(self, *args, **kwargs):
        return _SyncLocator(0)

    def get_by_label(self, *args, **kwargs):
        return _SyncLocator(0)

    def locator(self, *args, **kwargs):
        return _SyncLocator(0)

    def evaluate(self, script, arg=None):
        return []


class _AsyncSnapshotPage(_AsyncPage):
    snapshot_id = 'snapshot1234'
    marker = f'{snapshot_id}:e1'

    def get_by_role(self, role, name=None, **kwargs):
        if role == 'button' and name == 'Save':
            return _AsyncLocator(1, attributes={SNAPSHOT_REF_ATTRIBUTE: self.marker})
        return _AsyncLocator(0)

    def locator(self, selector, **kwargs):
        if selector == SnapshotRefResolver.selector(self.snapshot_id, 'e1'):
            return _AsyncLocator(1, attributes={SNAPSHOT_REF_ATTRIBUTE: self.marker})
        return _AsyncLocator(0)


class _FakeModelClient:
    available = True
    model_name = 'fake-locator-model'

    async def complete_async(self, messages, **kwargs):
        return json.dumps({
            'schema_version': SCHEMA_VERSION,
            'status': 'matched',
            'reason': 'target identified',
            'candidates': [{
                'source': 'ai_accessibility',
                'target_ref': 'e1',
                'reason': 'exact interactive button in current snapshot',
                'confidence': 95,
            }],
        })

    def complete_sync(self, messages, **kwargs):
        raise NotImplementedError


class _SyncSnapshotPage(_SyncPage):
    snapshot_id = 'snapshot1234'
    marker = f'{snapshot_id}:e1'

    def get_by_role(self, role, name=None, **kwargs):
        if role == 'button' and name == 'Save':
            return _SyncLocator(1, attributes={SNAPSHOT_REF_ATTRIBUTE: self.marker})
        return _SyncLocator(0)

    def locator(self, selector, **kwargs):
        if selector == SnapshotRefResolver.selector(self.snapshot_id, 'e1'):
            return _SyncLocator(1, attributes={SNAPSHOT_REF_ATTRIBUTE: self.marker})
        return _SyncLocator(0)


def _memory():
    return {
        1: {
            'latest_snapshot': {
                'id': 10,
                'exp': ElementExpEnum.LOCATOR.value,
                'loc': "get_by_role('button', name='Save')",
                'sub': None,
            },
            'snapshots': [],
            'heal_records': [],
        }
    }


def _accessibility_snapshot():
    nodes = [AccessibilitySnapshotNode(
        ref='e1',
        frame_index=0,
        frame_url='https://example.test/dialog',
        order=0,
        role='button',
        name='Save',
        text='Save',
        tag='button',
        interactive=True,
        attributes={'id': '', 'name': '', 'type': 'button', 'testid': ''},
        rect={'x': 10.0, 'y': 20.0, 'width': 80.0, 'height': 32.0},
    )]
    return AccessibilitySnapshot(
        snapshot_id='snapshot1234',
        page_url='https://example.test/dialog',
        created_at_ms=1,
        nodes=nodes,
        tree='frame "main frame"\n  - button "Save" [ref=e1]',
    )


def _contract_number_snapshot():
    rows = [
        ('e1', None, 'generic', 'TEST模板双明细模板-20260609-1503-A 合同编号： CT--20260609-000096TDFCA1503', ''),
        ('e2', 'e1', 'generic', 'TEST模板双明细模板-20260609-1503-A', ''),
        ('e3', 'e1', 'generic', '合同编号： CT--20260609-000096TDFCA1503', ''),
        ('e4', 'e3', 'generic', '合同编号：', ''),
        ('e5', 'e3', 'generic', 'CT--20260609-000096TDFCA1503', ''),
        ('e124', 'e1', 'generic', '合同编号： CT--20260707-00000512312312', ''),
        ('e126', 'e124', 'generic', 'CT--20260707-00000512312312', ''),
    ]
    nodes = [AccessibilitySnapshotNode(
        ref=ref,
        parent_ref=parent_ref,
        frame_index=0,
        frame_url='https://example.test/task-center',
        order=index,
        role=role,
        name=text,
        text=text,
        tag='div',
        attributes={},
    ) for index, (ref, parent_ref, role, text, _) in enumerate(rows)]
    return AccessibilitySnapshot(
        snapshot_id='contractsnapshot1',
        page_url='https://example.test/task-center',
        created_at_ms=1,
        nodes=nodes,
        tree='contract number snapshot',
    )


def _selected_contract_card_snapshot():
    rows = [
        ('e1', None, 'generic', 'TEST模板双明细模板-20260609-1503-A 合同编号： CT--20260609-000096TDFCA1503 流程类型： 修改合同表单', True),
        ('e2', 'e1', 'generic', 'TEST模板双明细模板-20260609-1503-A', None),
        ('e3', 'e1', 'generic', '合同编号： CT--20260609-000096TDFCA1503', None),
        ('e4', 'e1', 'generic', '流程类型：修改合同表单', None),
        ('e5', 'e1', 'generic', '张弘德', None),
        ('e6', 'e1', 'generic', '测试组验证', None),
    ]
    nodes = [AccessibilitySnapshotNode(
        ref=ref,
        parent_ref=parent_ref,
        frame_index=0,
        frame_url='https://example.test/task-center',
        order=index,
        role=role,
        name=text,
        text=text,
        tag='div',
        selected=selected,
        attributes={},
    ) for index, (ref, parent_ref, role, text, selected) in enumerate(rows)]
    return AccessibilitySnapshot(
        snapshot_id='selectedcontract1',
        page_url='https://example.test/task-center',
        created_at_ms=1,
        nodes=nodes,
        tree='selected contract card snapshot',
    )


def _snapshot_ref_candidate(target_ref='e1'):
    rows = AgentResponseParser.parse(json.dumps({
        'schema_version': SCHEMA_VERSION,
        'status': 'matched',
        'reason': 'target identified',
        'candidates': [{
            'source': 'ai_accessibility',
            'target_ref': target_ref,
            'reason': 'exact interactive button in current snapshot',
            'confidence': 95,
        }],
    })).candidates
    values = AgentCandidateNormalizer.normalize(rows, _accessibility_snapshot(), [])
    return values[0] if values else None


class ElementHealingUnitTest(unittest.IsolatedAsyncioTestCase):
    async def test_playwright_ai_snapshot_keeps_refs_beyond_legacy_limit(self):
        class NativeSnapshotPage:
            url = 'https://example.test/editor'

            async def aria_snapshot(self, **kwargs):
                self.options = kwargs
                toolbar = '\n'.join(
                    f'- button "Tool {index}" [ref=e{index}]'
                    for index in range(1, 201)
                )
                return (
                    f'{toolbar}\n'
                    '- textbox "合同模板内容区域" [ref=e201]\n'
                )

        page = NativeSnapshotPage()
        snapshot = await AccessibilitySnapshotBuilder.build_async(page)

        self.assertEqual(page.options, {'mode': 'ai', 'boxes': True})
        self.assertEqual(snapshot.ref_engine, SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE)
        self.assertEqual(len(snapshot.nodes), 201)
        self.assertEqual(snapshot.node_by_ref('e201').role, 'textbox')
        self.assertTrue(snapshot.node_by_ref('e201').editable)

    async def test_playwright_ai_snapshot_failure_falls_back_to_dom_snapshot(self):
        class NativeSnapshotPage:
            url = 'https://example.test/editor'

            async def aria_snapshot(self, **kwargs):
                raise RuntimeError('native snapshot failed')

            async def evaluate(self, script, options):
                return {
                    'nodes': [{
                        'ref': 'e1', 'frame_index': 0, 'order': 0,
                        'role': 'textbox', 'name': '内容区域', 'text': '',
                        'visible': True, 'disabled': False, 'editable': True,
                        'interactive': True, 'required': False,
                        'attributes': {}, 'path': [],
                    }],
                    'next_index': 2,
                }

        snapshot = await AccessibilitySnapshotBuilder.build_async(NativeSnapshotPage())

        self.assertEqual(snapshot.ref_engine, 'dom_marker')
        self.assertIsNotNone(snapshot.node_by_ref('e1'))
        self.assertIn('native snapshot failed', snapshot.errors[0])

    def test_native_snapshot_prompt_keeps_full_tree_without_duplicate_nodes(self):
        tree = '\n'.join(
            f'- button "Tool {index}" [ref=e{index}]'
            for index in range(1, 201)
        ) + '\n- textbox "合同模板内容区域" [ref=e201]'
        snapshot = AccessibilitySnapshotBuilder._build_native_snapshot(
            tree, 'https://example.test/editor',
        )
        context = SimpleNamespace(
            element_name='内容区域', category='编辑器', prompt='合同模板正文输入区域',
            expected_semantics=SimpleNamespace(target_texts=['内容区域']),
            operation_key='w_input', failed_locators=[],
        )

        payload = json.loads(WebLocatorPrompt.build(context, {}, snapshot))

        self.assertIn('[ref=e201]', payload['accessibility_snapshot']['tree'])
        self.assertEqual(payload['accessibility_snapshot']['nodes'], [])
        self.assertEqual(payload['target']['operation_intent'], 'edit')

    def test_playwright_snapshot_ref_uses_native_aria_ref_selector(self):
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.CSS.value,
            loc='aria-ref=e201',
            initial_score=90,
            metadata={
                'accessibility_snapshot_id': 'pw-snapshot1234',
                'snapshot_ref_engine': SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE,
                'target_ref': 'e201',
                'snapshot_frame_index': 0,
            },
        )

        class NativeRefPage:
            def locator(self, selector):
                self.selector = selector
                return _SyncLocator(1)

        page = NativeRefPage()
        locator = SnapshotRefResolver.resolve(page, candidate)

        self.assertEqual(page.selector, 'aria-ref=e201')
        self.assertEqual(locator.count(), 1)

    async def test_native_ref_input_promotes_child_to_editable_ancestor(self):
        class Target:
            def __init__(self, *, editable=False, count=1):
                self.first = self
                self.editable = editable
                self._count = count
                self.ancestor = self
                self.descendant = self

            async def is_editable(self):
                return self.editable

            async def count(self):
                return self._count

            def locator(self, selector):
                if selector == OperationTargetResolver.EDITABLE_ANCESTOR_SELECTOR:
                    return self.ancestor
                return self.descendant

        child = Target(editable=False)
        editor = Target(editable=True)
        child.ancestor = editor
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.CSS.value,
            loc='aria-ref=e201',
            initial_score=90,
            metadata={
                'accessibility_snapshot_id': 'pw-snapshot1234',
                'snapshot_ref_engine': SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE,
                'target_ref': 'e201',
            },
        )

        selected = await OperationTargetResolver.resolve_async(
            child, candidate, {'ope_key': 'w_input'},
        )

        self.assertIs(selected, editor)
        self.assertEqual(candidate.metadata['operation_target_strategy'], 'editable_ancestor')

    async def test_native_ref_input_records_editable_self_target(self):
        class Target:
            first = None

            def __init__(self):
                self.first = self

            async def is_editable(self):
                return True

        target = Target()
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.CSS.value,
            loc='aria-ref=e201',
            initial_score=90,
            metadata={
                'accessibility_snapshot_id': 'pw-snapshot1234',
                'snapshot_ref_engine': SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE,
                'target_ref': 'e201',
            },
        )

        selected = await OperationTargetResolver.resolve_async(
            target, candidate, {'ope_key': 'w_input'},
        )

        self.assertIs(selected, target)
        self.assertEqual(candidate.metadata['operation_target_strategy'], 'editable_self')

    async def test_native_ref_click_promotes_icon_to_button_ancestor(self):
        class Target:
            def __init__(self, *, direct=False, count=1):
                self.first = self
                self.direct = direct
                self._count = count
                self.ancestor = self
                self.descendant = self

            async def evaluate(self, script, state):
                return self.direct and state == 'click'

            async def count(self):
                return self._count

            def locator(self, selector):
                if selector == OperationTargetResolver.CLICK_ANCESTOR_SELECTOR:
                    return self.ancestor
                return self.descendant

        icon = Target(direct=False)
        button = Target(direct=True)
        icon.ancestor = button
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.CSS.value,
            loc='aria-ref=e202',
            initial_score=90,
            metadata={
                'accessibility_snapshot_id': 'pw-snapshot1234',
                'snapshot_ref_engine': SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE,
                'target_ref': 'e202',
            },
        )

        selected = await OperationTargetResolver.resolve_async(
            icon, candidate, {'ope_key': 'w_click'},
        )

        self.assertIs(selected, button)
        self.assertEqual(candidate.metadata['operation_target_strategy'], 'click_ancestor')

    def test_select_option_rejects_custom_combobox(self):
        state = {
            'tag': 'div',
            'role': 'combobox',
            'interactive': True,
            'direct_interactive': True,
        }

        error = operation_compatibility_reason(state, {'ope_key': 'w_select_option'})

        self.assertIn('requires native select', error)

    def test_native_snapshot_does_not_turn_ref_text_into_durable_text(self):
        role, name = AccessibilitySnapshotBuilder._native_role_and_name(
            'generic "[ref=e5883"',
        )

        self.assertEqual(role, 'generic')
        self.assertEqual(name, '')

    def test_visual_agent_returns_dom_backed_durable_locators(self):
        parsed = WebVisualLocatorAgent._parse(json.dumps({
            'schema_version': VISUAL_SCHEMA_VERSION,
            'status': 'matched',
            'reason': 'the numbered Save button matches the requested target',
            'candidates': [{
                'marker_id': 'v1',
                'confidence': 96,
                'reason': 'visible Save button',
            }],
        }))
        context = SimpleNamespace(failed_locators=[])
        agent = WebVisualLocatorAgent()
        candidates = agent._normalize(
            parsed,
            _accessibility_snapshot(),
            [{'marker_id': 'v1', 'target_ref': 'e1'}],
            context,
        )

        self.assertGreaterEqual(len(candidates), 1)
        self.assertTrue(all(item.source == CandidateSource.VISUAL_AGENT for item in candidates))
        self.assertTrue(all(item.metadata['target_ref'] == 'e1' for item in candidates))
        self.assertTrue(all(item.loc for item in candidates))

    def test_visual_agent_rejects_non_contract_response_and_masks_sensitive_fields(self):
        with self.assertRaises(ValueError):
            WebVisualLocatorAgent._parse('the target is marker v1')
        overlay_script = WebVisualLocatorAgent._overlay_script()
        self.assertIn('input[type="password"]', overlay_script)
        self.assertIn('[data-sensitive="true"]', overlay_script)
        self.assertIn('[name*="token" i]', overlay_script)

    def test_element_retry_policy_uses_fixed_defaults_and_all_trigger_conditions(self):
        policy = DEFAULT_ELEMENT_RETRY_POLICY
        self.assertEqual(policy.fixed_retry_seconds, 25)
        self.assertEqual(policy.healing_fixed_retry_seconds, 15)
        self.assertEqual(policy.retry_interval_seconds, 0.5)
        self.assertFalse(policy.should_start_healing(4.99, [2, 2, 2]))
        self.assertFalse(policy.should_start_healing(5, [2, 1, 2]))
        self.assertFalse(policy.should_start_healing(5, []))
        self.assertTrue(policy.should_start_healing(5, [2, 2, 2]))

    async def test_speculative_healing_event_is_committed_or_discarded_explicitly(self):
        sink = InMemoryEventSink()
        harness = WebElementHealingHarness(event_sink=sink)
        payload = {'element_id': 1, 'status': 'auto_apply'}

        await harness._publish_or_defer_async(1, 'healing_trace', payload, False)
        self.assertEqual(sink.events, [])
        await harness.commit_attempt_async(1)
        self.assertEqual(sink.events, [('healing_trace', payload)])

        await harness._publish_or_defer_async(1, 'healing_trace', payload, False)
        harness.discard_attempt(1)
        await harness.commit_attempt_async(1)
        self.assertEqual(sink.events, [('healing_trace', payload)])

    def test_accessibility_snapshot_builder_creates_versioned_ref_tree(self):
        errors = []
        nodes, next_index = AccessibilitySnapshotBuilder._normalize_frame_result(
            {
                'nodes': [{
                    'ref': 'e1',
                    'parent_ref': None,
                    'order': 0,
                    'role': 'button',
                    'name': 'Save',
                    'text': 'Save',
                    'tag': 'button',
                    'interactive': True,
                    'attributes': {'type': 'button'},
                    'rect': {'x': 1, 'y': 2, 'width': 80, 'height': 32},
                }],
                'next_index': 2,
            },
            0,
            'https://example.test/dialog',
            1,
            errors,
        )
        snapshot = AccessibilitySnapshotBuilder._build_snapshot(
            'snapshot1234', 'https://example.test/dialog', nodes, errors,
        )
        self.assertEqual(next_index, 2)
        self.assertEqual(snapshot.node_by_ref('e1').name, 'Save')
        self.assertIn('button "Save" [ref=e1]', snapshot.tree)

    def test_snapshot_match_keeps_temporary_ref_when_text_is_not_durably_unique(self):
        nodes = [
            AccessibilitySnapshotNode(
                ref=f'e{index}', frame_index=0, order=index, role='generic',
                name='全部部门', text='全部部门', tag='span', interactive=index == 2,
            )
            for index in (1, 2)
        ]
        snapshot = AccessibilitySnapshot(
            snapshot_id='snapshot1234', created_at_ms=1, nodes=nodes,
        )
        context = SimpleNamespace(
            element_name='全部部门', prompt='适用部门下拉框中的：全部部门',
            expected_semantics=SimpleNamespace(target_texts=['全部部门']),
            operation_key='w_click', failed_locators=[],
        )

        rows = AccessibilitySnapshotMatcher.match(context, snapshot)
        candidates = AgentCandidateNormalizer.normalize(
            rows, snapshot, [], generated_by_ai=False,
            selection_strategy='deterministic_snapshot',
        )

        self.assertEqual(len(candidates), 2)
        self.assertTrue(all(item.metadata['transient_snapshot_ref_only'] for item in candidates))
        self.assertTrue(all(item.metadata['durable_locator_strategy'] == 'snapshot_ref_temporary'
                            for item in candidates))
        self.assertTrue(all('data-mango-healing-ref' in item.loc for item in candidates))

    async def test_unique_delete_button_description_heals_without_calling_model(self):
        class ModelMustNotBeCalled:
            available = True

            async def complete_async(self, messages, **kwargs):
                raise AssertionError('unique interactive snapshot match must bypass the model')

        snapshot = AccessibilitySnapshot(
            snapshot_id='delete-dialog',
            page_url='https://example.test/dialog',
            created_at_ms=1,
            nodes=[
                AccessibilitySnapshotNode(
                    ref='e1', frame_index=0, order=0, role='tooltip',
                    name='确认删除吗？ 取消 删除', text='确认删除吗？ 取消 删除',
                    tag='div', attributes={},
                ),
                AccessibilitySnapshotNode(
                    ref='e2', parent_ref='e1', frame_index=0, order=1,
                    role='button', name='取消', text='取消', tag='button',
                    interactive=True, attributes={'type': 'button'},
                ),
                AccessibilitySnapshotNode(
                    ref='e3', parent_ref='e1', frame_index=0, order=2,
                    role='button', name='删除', text='删除', tag='button',
                    interactive=True, attributes={'type': 'button'},
                ),
            ],
        )
        context = SimpleNamespace(
            element_name='悬浮的删除按钮',
            category='表格',
            prompt='元素名称：悬浮的删除按钮\n元素位置：悬浮的删除按钮，点击可删除',
            expected_semantics=SimpleNamespace(target_texts=['悬浮的删除按钮']),
            operation_key='w_click',
            failed_locators=[],
        )
        agent = WebLocatorAgent(ModelMustNotBeCalled())

        with patch.object(WebAgentContextBuilder, 'build_async', return_value=snapshot):
            candidates = await agent.propose_async(object(), context, {})

        self.assertEqual(agent.last_status, 'snapshot_deterministic')
        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e3')
        self.assertEqual(candidates[0].loc, "get_by_role('button', name='删除', exact=True)")
        self.assertFalse(candidates[0].generated_by_ai)

    def test_live_node_derives_stable_component_scoped_locator(self):
        selected_candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.CSS.value,
            loc='[data-mango-healing-ref="snapshot1234:e2"]',
            initial_score=95,
            metadata={
                'accessibility_snapshot_id': 'snapshot1234',
                'target_ref': 'e2',
                'snapshot_frame_index': 0,
                'snapshot_node_role': 'generic',
                'snapshot_node_name': '全部部门',
                'snapshot_node_text': '全部部门',
                'transient_snapshot_ref_only': True,
            },
        )

        candidates = LiveStableLocatorDeriver._build(selected_candidate, {
            'target': {
                'tag': 'span', 'classes': ['arco-checkbox-label'],
                'class_counts': {'arco-checkbox-label': 8},
            },
            'ancestors': [
                {
                    'tag': 'div', 'classes': ['contract-tree-node'],
                    'class_counts': {'contract-tree-node': 20},
                },
                {
                    'tag': 'div', 'classes': ['contract-department-tree'],
                    'class_counts': {'contract-department-tree': 1},
                },
                {
                    'tag': 'div', 'classes': ['arco-trigger-popup', 'arco-trigger-position-bl'],
                    'class_counts': {'arco-trigger-popup': 2, 'arco-trigger-position-bl': 1},
                },
            ],
        })

        locations = [item.loc for item in candidates]
        self.assertIn(
            "locator('[class~=\"contract-department-tree\"]').get_by_text('全部部门', exact=True)",
            locations,
        )
        self.assertTrue(all(not item.metadata.get('transient_snapshot_ref_only') for item in candidates))
        LocatorExpressionParser.validate(
            "locator('[class~=\"arco-tree\"]').get_by_text('全部部门', exact=True)"
        )

    def test_normalized_control_derivation_uses_control_semantics(self):
        selected_candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.LOCATOR.value,
            loc="get_by_text('保存图标', exact=True)",
            initial_score=95,
            metadata={
                'accessibility_snapshot_id': 'snapshot1234',
                'target_ref': 'e2',
                'snapshot_node_role': 'generic',
                'snapshot_node_name': '保存图标',
                'snapshot_node_text': '保存图标',
                'operation_target_strategy': 'click_ancestor',
            },
        )

        candidates = LiveStableLocatorDeriver._build(selected_candidate, {
            'target': {
                'tag': 'button', 'role': 'button', 'text': '保存',
                'aria_label': '', 'classes': ['arco-btn'],
                'class_counts': {'arco-btn': 3},
            },
            'ancestors': [],
        })

        self.assertIn(
            "get_by_role('button', name='保存', exact=True)",
            [item.loc for item in candidates],
        )
        self.assertNotIn(
            "get_by_text('保存图标', exact=True)",
            [item.loc for item in candidates],
        )

    def test_empty_contenteditable_derives_capability_locator(self):
        selected_candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.CSS.value,
            loc='aria-ref=e2',
            initial_score=95,
            metadata={
                'accessibility_snapshot_id': 'snapshot1234',
                'target_ref': 'e2',
                'snapshot_node_text': '\u200b',
                'operation_target_strategy': 'editable_self',
            },
        )

        candidates = LiveStableLocatorDeriver._build(selected_candidate, {
            'target': {
                'tag': 'div', 'role': 'textbox', 'text': '\u200b',
                'editable': True, 'editable_count': 1,
                'classes': ['zone-container'], 'class_counts': {'zone-container': 1},
            },
            'ancestors': [],
        })

        locations = [item.loc for item in candidates]
        self.assertIn("locator('[contenteditable=\"true\"]')", locations)
        self.assertTrue(all('\u200b' not in item.loc for item in candidates))

    async def test_repeat_validation_reuses_normalized_operation_target(self):
        class Locator:
            async def count(self):
                return 1

        candidate = LocatorCandidate(
            source='test', exp=ElementExpEnum.CSS.value, loc='.target', initial_score=90,
        )
        first_state = {'tag': 'button', 'role': 'button'}
        normalized = object()
        with (
                patch.object(OperationTargetResolver, 'resolve_async',
                             AsyncMock(return_value=normalized)) as resolver,
                patch('mangoautomation.element_healing.verification.async_verifier.SnapshotRefVerifier.select',
                      return_value=object()),
                patch('mangoautomation.element_healing.verification.async_verifier.is_visible_async',
                      AsyncMock(return_value=True)),
                patch('mangoautomation.element_healing.verification.async_verifier.read_semantic_state_async',
                      AsyncMock(return_value=first_state)),
                patch.object(ActionabilityVerifier, 'reject_reason_async',
                             AsyncMock(return_value=None)),
                patch.object(SemanticVerifier, 'candidate_evaluation',
                             return_value=(100, ['text'], None))):
            passes, stable, error = await AsyncCandidateVerifier._repeat_validation(
                Locator(), candidate, _Element(), {'ope_key': 'w_click'}, 1,
                first_state, 800,
            )

        resolver.assert_awaited_once()
        self.assertEqual((passes, stable, error), (2, True, None))

    def test_snapshot_derived_text_uses_click_trial_as_actionability_gate(self):
        candidate = LocatorCandidate(
            source='snapshot_live_derived',
            exp=ElementExpEnum.LOCATOR.value,
            loc="get_by_text('全部部门', exact=True)",
            initial_score=96,
            metadata={
                'snapshot_ref_resolved': True,
                'snapshot_matcher_validated': True,
            },
        )

        self.assertFalse(ActionabilityVerifier._is_text_candidate(candidate))

    async def test_async_harness_works_without_http(self):
        sink = InMemoryEventSink()
        harness = WebElementHealingHarness(
            memory_provider=InMemoryProvider(_memory()),
            event_sink=sink,
            runtime_config=StaticRuntimeConfig(enabled=True, mode=2),
        )
        result = await harness.locate_async(
            _AsyncPage(), _Element(), None, ['broken'], {'ope_key': 'w_click'}, RuntimeError('broken'),
        )
        self.assertIsNotNone(result)
        self.assertEqual(result['metadata']['used_source'], 'latest_snapshot_locator')
        self.assertTrue(result['metadata']['trace_id'])
        self.assertEqual(sink.events[0][0], 'healing_trace')

    async def test_async_harness_falls_back_to_accessibility_agent_with_strict_schema(self):
        sink = InMemoryEventSink()
        harness = WebElementHealingHarness(
            memory_provider=InMemoryProvider({}),
            event_sink=sink,
            model_client=_FakeModelClient(),
            runtime_config=StaticRuntimeConfig(enabled=True, mode=2),
        )
        with patch.object(CandidateRegistry, 'current_page_async', return_value=[]), patch.object(
            WebAgentContextBuilder, 'build_async', return_value=_accessibility_snapshot()
        ):
            result = await harness.locate_async(
                _AsyncSnapshotPage(), _Element(), None, ['broken'],
                {'ope_key': 'w_click'}, RuntimeError('broken'),
            )
        self.assertIsNotNone(result)
        self.assertEqual(result['metadata']['used_source'], CandidateSource.ACCESSIBILITY_AGENT.value)
        self.assertTrue(result['metadata']['used_ai'])
        self.assertTrue(result['metadata']['trace']['agent_called'])
        self.assertEqual(result['metadata']['trace']['schema_version'], SCHEMA_VERSION)
        selected = result['metadata']['candidates'][result['metadata']['candidate_index']]
        self.assertTrue(selected['agent_schema_validated'])
        self.assertEqual(selected['agent_schema_version'], SCHEMA_VERSION)

    def test_applied_deterministic_record_is_not_marked_as_ai(self):
        candidates = AppliedRecordCandidateSource.build({
            'heal_records': [{
                'id': 1,
                'applied': True,
                'selected_exp': 2,
                'selected_loc': 'get_by_role("button", name="Save")',
                'candidates': [{
                    'loc': 'get_by_role("button", name="Save")',
                    'used_ai': False,
                }],
            }],
        })
        self.assertGreaterEqual(len(candidates), 1)
        self.assertFalse(candidates[0].generated_by_ai)

    def test_sync_harness_works_without_http(self):
        harness = WebElementHealingHarness(
            memory_provider=InMemoryProvider(_memory()),
            runtime_config=StaticRuntimeConfig(enabled=True, mode=2),
        )
        result = harness.locate_sync(
            _SyncPage(), _Element(), None, ['broken'], {'ope_key': 'w_click'}, RuntimeError('broken'),
        )
        self.assertIsNotNone(result)
        self.assertEqual(result['metadata']['used_source'], 'latest_snapshot_locator')

    def test_policy_modes(self):
        candidate = LocatorCandidate(source='test', exp=2, loc='get_by_text("Save")', initial_score=90)
        result = VerificationResult(
            candidate=candidate,
            valid=True,
            final_score=90,
            semantic_score=100,
            stability_score=90,
            operation_compatible=True,
            consecutive_passes=2,
            stable_context=True,
            auto_apply_eligible=True,
        )
        self.assertEqual(HealingPolicy(1).decide(result).status, HealingStatus.SUGGESTED)
        self.assertEqual(HealingPolicy(2).decide(result).status, HealingStatus.TEMPORARY_HEAL)
        self.assertEqual(HealingPolicy(3).decide(result).status, HealingStatus.AUTO_APPLY)

        result.auto_apply_eligible = False
        self.assertEqual(HealingPolicy(3).decide(result).status, HealingStatus.TEMPORARY_HEAL)

    def test_agent_contract_and_deduplication(self):
        content = json.dumps({
            'schema_version': SCHEMA_VERSION,
            'status': 'matched',
            'reason': 'target identified',
            'candidates': [{
                'source': 'ai_accessibility',
                'target_ref': 'e1',
                'reason': 'exact interactive button in current snapshot',
                'confidence': 90,
            }],
        })
        rows = AgentResponseParser.parse(content).candidates
        candidates = AgentCandidateNormalizer.normalize(rows, _accessibility_snapshot(), [])
        self.assertGreaterEqual(len(candidates), 1)
        self.assertTrue(candidates[0].generated_by_ai)
        self.assertEqual(candidates[0].metadata['agent_schema_version'], SCHEMA_VERSION)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e1')
        self.assertEqual(candidates[0].loc, "get_by_role('button', name='Save', exact=True)")
        remaining = AgentCandidateNormalizer.normalize(
            rows, _accessibility_snapshot(), [candidates[0].loc],
        )
        self.assertTrue(all(item.loc != candidates[0].loc for item in remaining))

    def test_snapshot_matcher_selects_value_next_to_contract_number_label(self):
        context = SimpleNamespace(
            element_name='获取合同编号',
            prompt='在左侧找一个合同编号',
            expected_semantics=SimpleNamespace(target_texts=['获取合同编号', '在左侧找一个合同编号']),
            failed_locators=[],
        )
        snapshot = _contract_number_snapshot()

        rows = AccessibilitySnapshotMatcher.match(context, snapshot)
        candidates = AgentCandidateNormalizer.normalize(
            rows,
            snapshot,
            [],
            generated_by_ai=False,
            selection_strategy='deterministic_snapshot',
        )

        self.assertGreaterEqual(len(rows), 1)
        self.assertEqual(rows[0].target_ref, 'e5')
        self.assertEqual(candidates[0].loc, "get_by_text('CT--20260609-000096TDFCA1503', exact=True)")
        self.assertFalse(candidates[0].generated_by_ai)
        self.assertTrue(candidates[0].metadata['snapshot_matcher_validated'])
        self.assertEqual(candidates[0].metadata['snapshot_parent_text'], '合同编号： CT--20260609-000096TDFCA1503')

    async def test_agent_uses_snapshot_matcher_when_model_returns_empty_candidates(self):
        class EmptyModelClient:
            available = True

            async def complete_async(self, messages, **kwargs):
                return json.dumps({
                    'schema_version': SCHEMA_VERSION,
                    'status': 'not_found',
                    'reason': 'the first snapshot is still loading',
                    'candidates': [],
                })

        context = SimpleNamespace(
            element_name='获取合同编号',
            category='待办详情',
            prompt='在左侧找一个合同编号',
            expected_semantics=SimpleNamespace(target_texts=['获取合同编号']),
            operation_key='w_get_text',
            failed_locators=[],
        )
        agent = WebLocatorAgent(EmptyModelClient())
        with patch.object(
            WebAgentContextBuilder, 'build_async', return_value=_contract_number_snapshot(),
        ):
            candidates = await agent.propose_async(object(), context, {})

        self.assertEqual(agent.last_status, 'snapshot_deterministic')
        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e5')
        self.assertFalse(candidates[0].generated_by_ai)

    def test_snapshot_matcher_selects_title_inside_selected_contract_card(self):
        context = SimpleNamespace(
            element_name='合同名称',
            prompt='左侧卡片title的名称',
            operation_key='w_get_text',
            expected_semantics=SimpleNamespace(target_texts=['合同名称', '左侧卡片title的名称']),
            failed_locators=[],
        )
        snapshot = _selected_contract_card_snapshot()

        rows = AccessibilitySnapshotMatcher.match(context, snapshot)
        candidates = AgentCandidateNormalizer.normalize(
            rows,
            snapshot,
            [],
            generated_by_ai=False,
            selection_strategy='deterministic_snapshot',
        )

        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e2')
        self.assertEqual(
            candidates[0].loc,
            "get_by_text('TEST模板双明细模板-20260609-1503-A', exact=True)",
        )
        self.assertFalse(any(candidate.metadata['target_ref'] == 'e5' for candidate in candidates))

    def test_snapshot_matcher_selects_applicant_after_flow_type(self):
        context = SimpleNamespace(
            element_name='申请人',
            prompt='左侧卡片中流程类型下面的用户名称',
            operation_key='w_get_text',
            expected_semantics=SimpleNamespace(target_texts=['申请人', '用户名称']),
            failed_locators=[],
        )
        snapshot = _selected_contract_card_snapshot()

        rows = AccessibilitySnapshotMatcher.match(context, snapshot)
        candidates = AgentCandidateNormalizer.normalize(
            rows,
            snapshot,
            [],
            generated_by_ai=False,
            selection_strategy='deterministic_snapshot',
        )

        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e5')
        self.assertEqual(candidates[0].loc, "get_by_text('张弘德', exact=True)")

    def test_snapshot_matcher_selects_first_structured_card_without_selected_attribute(self):
        context = SimpleNamespace(
            element_name='合同名称',
            prompt='左侧卡片title的名称',
            operation_key='w_get_text',
            expected_semantics=SimpleNamespace(target_texts=['合同名称']),
            failed_locators=[],
        )
        snapshot = _selected_contract_card_snapshot().model_copy(deep=True)
        snapshot.nodes[0].selected = None

        rows = AccessibilitySnapshotMatcher.match(context, snapshot)
        candidates = AgentCandidateNormalizer.normalize(
            rows,
            snapshot,
            [],
            generated_by_ai=False,
            selection_strategy='deterministic_snapshot',
        )

        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e2')

    async def test_agent_uses_snapshot_fallback_when_model_times_out(self):
        class TimeoutModelClient:
            available = True

            async def complete_async(self, messages, **kwargs):
                raise TimeoutError('model timeout')

        context = SimpleNamespace(
            element_name='合同名称',
            category='待办详情',
            prompt='左侧卡片title的名称',
            expected_semantics=SimpleNamespace(target_texts=['合同名称']),
            operation_key='w_get_text',
            failed_locators=[],
        )
        agent = WebLocatorAgent(TimeoutModelClient())
        with patch.object(
            WebAgentContextBuilder, 'build_async', return_value=_selected_contract_card_snapshot(),
        ):
            candidates = await agent.propose_async(object(), context, {})

        self.assertEqual(agent.last_status, 'snapshot_fallback')
        self.assertEqual(agent.last_error, 'model timeout')
        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e2')
        self.assertFalse(candidates[0].generated_by_ai)

    async def test_agent_refreshes_snapshot_after_late_page_content_loads(self):
        class EmptyModelClient:
            available = True

            async def complete_async(self, messages, **kwargs):
                return json.dumps({
                    'schema_version': SCHEMA_VERSION,
                    'status': 'not_found',
                    'reason': 'the first snapshot is still loading',
                    'candidates': [],
                })

        empty_snapshot = AccessibilitySnapshot(
            snapshot_id='emptysnapshot1',
            page_url='https://example.test/task-center',
            created_at_ms=1,
            nodes=[],
            tree='loading skeleton',
        )
        context = SimpleNamespace(
            element_name='合同名称',
            category='待办详情',
            prompt='左侧卡片title的名称',
            expected_semantics=SimpleNamespace(target_texts=['合同名称']),
            operation_key='w_get_text',
            failed_locators=[],
        )
        agent = WebLocatorAgent(EmptyModelClient())
        with patch.object(
            WebAgentContextBuilder,
            'build_async',
            side_effect=[empty_snapshot, _selected_contract_card_snapshot()],
        ):
            candidates = await agent.propose_async(object(), context, {})

        self.assertEqual(agent.last_status, 'success')
        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(candidates[0].metadata['target_ref'], 'e2')
        self.assertEqual(agent.last_snapshot_id, 'selectedcontract1')

    async def test_agent_repairs_one_invalid_schema_response(self):
        valid_content = json.dumps({
            'schema_version': SCHEMA_VERSION,
            'status': 'matched',
            'reason': 'target identified',
            'candidates': [{
                'source': 'ai_accessibility',
                'target_ref': 'e1',
                'reason': 'exact interactive button in current snapshot',
                'confidence': 90,
            }],
        })

        class RepairingModelClient:
            available = True

            def __init__(self):
                self.responses = ['not-json', valid_content]
                self.messages = []
                self.response_formats = []

            async def complete_async(self, messages, **kwargs):
                self.messages.append(messages)
                self.response_formats.append(kwargs.get('response_format'))
                return self.responses.pop(0)

        client = RepairingModelClient()
        agent = WebLocatorAgent(client)
        context = SimpleNamespace(failed_locators=[])
        with patch.object(WebAgentContextBuilder, 'build_async', return_value=_accessibility_snapshot()), \
                patch.object(WebLocatorPrompt, 'build', return_value='locate Save'):
            candidates = await agent.propose_async(object(), context, {})

        self.assertEqual(agent.last_status, 'success')
        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(len(client.messages), 2)
        self.assertIn('Previous response failed strict schema validation', client.messages[1][-1]['content'])
        self.assertEqual(client.response_formats[0]['type'], 'json_schema')
        self.assertEqual(client.response_formats[1], {'type': 'json_object'})

    def test_agent_parser_accepts_openai_compatible_legacy_json(self):
        content = '''模型结果如下：
```json
{"candidates":[{"ref":"e1","confidence":"91"}]}
```'''
        parsed = AgentResponseParser.parse(content)

        self.assertEqual(parsed.schema_version, SCHEMA_VERSION)
        self.assertEqual(parsed.status, 'matched')
        self.assertEqual(parsed.candidates[0].target_ref, 'e1')
        self.assertEqual(parsed.candidates[0].confidence, 91)

    def test_agent_parser_accepts_python_mapping_and_plain_snapshot_ref(self):
        mapping = AgentResponseParser.parse("{'candidates': [{'ref': 'e2', 'score': 87}]}")
        plain = AgentResponseParser.parse('建议选择当前快照中的 e3 节点。')

        self.assertEqual(mapping.candidates[0].target_ref, 'e2')
        self.assertEqual(mapping.candidates[0].confidence, 87)
        self.assertEqual(plain.candidates[0].target_ref, 'e3')

    def test_sync_agent_repairs_invalid_schema_with_json_object_fallback(self):
        valid_content = json.dumps({
            'schema_version': SCHEMA_VERSION,
            'status': 'matched',
            'reason': 'target identified',
            'candidates': [{
                'source': 'ai_accessibility',
                'target_ref': 'e1',
                'reason': 'exact interactive button in current snapshot',
                'confidence': 90,
            }],
        })

        class RepairingModelClient:
            available = True

            def __init__(self):
                self.responses = ['not-json', valid_content]
                self.response_formats = []

            def complete_sync(self, messages, **kwargs):
                self.response_formats.append(kwargs.get('response_format'))
                return self.responses.pop(0)

        client = RepairingModelClient()
        agent = WebLocatorAgent(client)
        context = SimpleNamespace(failed_locators=[])
        with patch.object(WebAgentContextBuilder, 'build_sync', return_value=_accessibility_snapshot()), \
                patch.object(WebLocatorPrompt, 'build', return_value='locate Save'):
            candidates = agent.propose_sync(object(), context, {})

        self.assertEqual(agent.last_status, 'success')
        self.assertGreaterEqual(len(candidates), 1)
        self.assertEqual(client.response_formats[0]['type'], 'json_schema')
        self.assertEqual(client.response_formats[1], {'type': 'json_object'})

    def test_locator_failure_message_maps_provider_and_schema_errors(self):
        quota = {'trace': {'stages': [{'name': 'agent_candidates', 'error': '余额不足或无可用资源包'}]}}
        schema = {'trace': {'stages': [
            {'name': 'agent_candidates', 'error': 'Agent响应不符合Schema：response:json_invalid'},
        ]}}

        self.assertIn('余额不足', locator_failure_message(quota))
        self.assertIn('JSON 格式', locator_failure_message(schema))
        not_found = {'trace': {'stages': [{'error': '当前抽屉中未包含目标元素'}]}}
        self.assertIn('当前抽屉中未包含目标元素', locator_failure_message(not_found))

    def test_locator_failure_message_hides_agent_technical_details(self):
        no_snapshot_target = {'trace': {'stages': [{
            'name': 'agent_candidates',
            'error': (
                "No node in the accessibility snapshot exposes text containing '毛鹏'; "
                'no supported target_ref exists.'
            ),
        }]}}
        semantic_mismatch = {
            'reject_reasons': ['candidate semantic mismatch: expected target "部门下拉框"'],
        }

        snapshot_message = locator_failure_message(no_snapshot_target, '回答结果包含毛鹏')
        mismatch_message = locator_failure_message(semantic_mismatch)

        self.assertIn('目标内容已显示', snapshot_message)
        self.assertIn('“回答结果包含毛鹏”', snapshot_message)
        self.assertNotIn('accessibility snapshot', snapshot_message)
        self.assertNotIn('target_ref', snapshot_message)
        self.assertIn('元素描述不一致', mismatch_message)
        self.assertNotIn('semantic mismatch', mismatch_message)

    def test_locator_failure_message_distinguishes_verified_but_not_adopted(self):
        message = locator_failure_message({
            'candidates': [{
                'verified': True,
                'final_score': 73.95,
                'decision_status': 'suggested',
            }],
        }, '内容区域')

        self.assertIn('已找到并验证', message)
        self.assertIn('73.95', message)
        self.assertNotIn('没有候选通过', message)

    def test_agent_unknown_snapshot_ref_is_rejected(self):
        self.assertIsNone(_snapshot_ref_candidate('e99'))

    async def test_async_snapshot_ref_resolves_and_validates_durable_locator(self):
        candidate = _snapshot_ref_candidate()
        selected, row = await AsyncCandidateVerifier().verify(
            _AsyncSnapshotPage(), _Element(), candidate, {'ope_key': 'w_click'},
        )
        self.assertIsNotNone(selected)
        self.assertTrue(row['verified'])
        self.assertEqual(row['target_ref'], 'e1')
        self.assertEqual(row['durable_locator_count'], 1)

    def test_sync_snapshot_ref_resolves_and_validates_durable_locator(self):
        candidate = _snapshot_ref_candidate()
        selected, row = SyncCandidateVerifier().verify(
            _SyncSnapshotPage(), _Element(), candidate, {'ope_key': 'w_click'},
        )
        self.assertIsNotNone(selected)
        self.assertTrue(row['verified'])
        self.assertEqual(row['target_ref'], 'e1')
        self.assertEqual(row['durable_locator_count'], 1)

    def test_snapshot_ref_rejects_durable_locator_pointing_to_another_node(self):
        class _MismatchedPage(_SyncSnapshotPage):
            def get_by_role(self, role, name=None, **kwargs):
                if role == 'button' and name == 'Save':
                    return _SyncLocator(
                        1, attributes={SNAPSHOT_REF_ATTRIBUTE: f'{self.snapshot_id}:e2'},
                    )
                return _SyncLocator(0)

        selected, row = SyncCandidateVerifier().verify(
            _MismatchedPage(), _Element(), _snapshot_ref_candidate(), {'ope_key': 'w_click'},
        )
        self.assertIsNone(selected)
        self.assertEqual(row['reject_code'], 'snapshot_ref_durable_mismatch')

    def test_agent_response_parser_rejects_unsafe_compatible_output(self):
        valid_candidate = {
            'source': 'ai_accessibility',
            'target_ref': 'e1',
            'reason': 'unique accessible role and name',
            'confidence': 92,
        }
        invalid_values = [
            'not-json',
            json.dumps({
                'schema_version': SCHEMA_VERSION,
                'candidates': [{**valid_candidate, 'target_ref': 'unknown'}],
            }),
            json.dumps({
                'schema_version': SCHEMA_VERSION,
                'status': 'matched',
                'candidates': [{'loc': 'get_by_role("button")'}],
            }),
        ]
        for value in invalid_values:
            with self.subTest(value=value[:80]):
                with self.assertRaises(AgentResponseSchemaError):
                    AgentResponseParser.parse(value)

    def test_agent_openai_response_format_uses_strict_schema(self):
        response_format = WebLocatorAgentResponse.openai_response_format()
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertTrue(response_format['json_schema']['strict'])
        schema = response_format['json_schema']['schema']
        self.assertFalse(schema['additionalProperties'])
        self.assertEqual(
            set(schema['required']), {'schema_version', 'status', 'reason', 'candidates'},
        )

    def test_locator_expression_parser_rejects_code_execution(self):
        with self.assertRaises(ValueError):
            LocatorExpressionParser.evaluate(_SyncPage(), "__import__('os').system('echo unsafe')")

    def test_baseline_sanitizer_removes_sensitive_values(self):
        value = sanitize_snapshot({
            'element_type': 'password',
            'element_value': 'secret',
            'element_attributes': {'data-token': 'secret', 'aria-label': 'Password'},
            'outer_html': '<input value="secret" data-token="abc"> user@example.com 13800138000',
            'parent_html': 'Authorization: Bearer abcdefghijklmnop',
            'nearby_html': '<textarea>private</textarea>',
        })
        self.assertEqual(value['element_value'], '')
        self.assertNotIn('data-token', value['element_attributes'])
        self.assertEqual(value['element_attributes']['aria-label'], 'Password')
        self.assertNotIn('secret', value['outer_html'])
        self.assertNotIn('user@example.com', value['outer_html'])
        self.assertNotIn('13800138000', value['outer_html'])
        self.assertNotIn('abcdefghijklmnop', value['parent_html'])
        self.assertNotIn('private', value['nearby_html'])
        self.assertIn('data-mango-healing-ref', ELEMENT_SNAPSHOT_SCRIPT)
        self.assertIn('transientName.test', ELEMENT_SNAPSHOT_SCRIPT)

    def test_agent_prompt_is_sanitized_and_digest_does_not_read_input_value(self):
        context = SimpleNamespace(
            element_name='user@example.com',
            category='登录',
            prompt='token=super-secret',
            expected_semantics=SimpleNamespace(target_texts=['13800138000']),
            operation_key='w_input',
            failed_locators=[SimpleNamespace(loc='get_by_text("13800138000")')],
        )
        snapshot = _accessibility_snapshot().model_copy(deep=True)
        snapshot.nodes[0].name = '[REDACTED_EMAIL]'
        snapshot.tree = 'button "[REDACTED_EMAIL]" [ref=e1]'
        prompt = WebLocatorPrompt.build(
            context,
            {'snapshots': [{'element_text': 'Authorization=Bearer abcdefghijklmnop'}]},
            snapshot,
        )
        self.assertNotIn('super-secret', prompt)
        self.assertNotIn('user@example.com', prompt)
        self.assertNotIn('13800138000', prompt)
        self.assertNotIn('abcdefghijklmnop', prompt)
        self.assertNotIn('el.value', ACCESSIBILITY_SNAPSHOT_SCRIPT)
        self.assertNotIn('el.value', DOM_PROXIMITY_SCRIPT)

    def test_accessibility_snapshot_prioritizes_active_layers_before_limit(self):
        self.assertIn('activeLayerOf(element)', ACCESSIBILITY_SNAPSHOT_SCRIPT)
        self.assertIn('[class*="sidesheet" i]', ACCESSIBILITY_SNAPSHOT_SCRIPT)
        self.assertIn("['fixed', 'absolute'].includes(style.position)", ACCESSIBILITY_SNAPSHOT_SCRIPT)
        self.assertIn('right.priority - left.priority', ACCESSIBILITY_SNAPSHOT_SCRIPT)
        self.assertIn('candidates.slice(0, limit)', ACCESSIBILITY_SNAPSHOT_SCRIPT)

    def test_semantic_verification_does_not_trust_candidate_reason(self):
        score, evidence, error = SemanticVerifier.candidate_evaluation(
            _Element(),
            {
                'tag': 'button',
                'role': 'button',
                'text': 'Delete',
                'aria_label': 'Delete',
                'label_texts': [],
            },
        )
        self.assertLess(score, 80)
        self.assertTrue(set(evidence).issubset({'text', 'aria_label'}))
        self.assertIn('semantic mismatch', error)

    def test_semantic_verification_accepts_trusted_baseline_locator_runtime_text(self):
        candidate = LocatorCandidate(
            source=CandidateSource.LATEST_SNAPSHOT_LOCATOR,
            exp=2,
            loc='get_by_role("textbox", name="键盘输入测试")',
            initial_score=90,
        )
        score, evidence, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(name='按键输入框', elements=[]),
            {'role': 'textbox', 'text': '键盘输入测试', 'placeholder': '键盘输入测试'},
            candidate,
        )
        self.assertEqual(score, 100)
        self.assertEqual(evidence, ['trusted_memory_locator'])
        self.assertIsNone(error)

    def test_semantic_verification_accepts_trusted_baseline_placeholder(self):
        candidate = LocatorCandidate(
            source=CandidateSource.BASELINE_SEMANTIC,
            exp=4,
            loc='键盘输入测试',
            initial_score=82,
            metadata={'semantic_kind': 'placeholder'},
        )
        score, evidence, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(name='按键输入框', elements=[]),
            {'role': 'textbox', 'placeholder': '键盘输入测试'},
            candidate,
        )
        self.assertEqual(score, 100)
        self.assertEqual(evidence, ['trusted_memory_placeholder'])
        self.assertIsNone(error)

    def test_dynamic_text_baseline_does_not_bypass_current_read_semantics(self):
        candidate = LocatorCandidate(
            source=CandidateSource.LATEST_SNAPSHOT_LOCATOR,
            exp=0,
            loc="//div[normalize-space(.)='错误的合同标题']",
            initial_score=90,
        )
        score, _, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(
                name='申请人',
                elements=[SimpleNamespace(prompt='左侧卡片中流程类型下面的用户名称')],
            ),
            {'role': '', 'text': '错误的合同标题'},
            candidate,
            {'ope_key': 'w_get_text'},
        )

        self.assertLess(score, 80)
        self.assertIn('semantic mismatch', error)

    def test_semantic_verification_does_not_trust_unverified_candidate_literal(self):
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=2,
            loc='get_by_role("button", name="Delete")',
            initial_score=90,
        )
        score, _, error = SemanticVerifier.candidate_evaluation(
            _Element(),
            {'role': 'button', 'text': 'Delete', 'aria_label': 'Delete'},
            candidate,
        )
        self.assertLess(score, 80)
        self.assertIn('semantic mismatch', error)

    def test_semantic_verification_accepts_verified_empty_editable_agent_target(self):
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.LOCATOR.value,
            loc='aria-ref=e2',
            initial_score=95,
            generated_by_ai=True,
            metadata={
                'agent_schema_validated': True,
                'snapshot_ref_resolved': True,
                'operation_target_strategy': 'editable_self',
            },
        )

        score, evidence, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(name='内容区域', elements=[]),
            {'tag': 'div', 'role': 'textbox', 'text': '\u200b', 'editable': True},
            candidate,
            {'ope_key': 'w_input', '_semantic_strength': 0},
        )

        self.assertEqual(score, 90)
        self.assertEqual(evidence, ['trusted_agent_empty_editable_target'])
        self.assertIsNone(error)

    def test_semantic_verification_rejects_contradictory_editable_text(self):
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.LOCATOR.value,
            loc='aria-ref=e2',
            initial_score=95,
            generated_by_ai=True,
            metadata={
                'agent_schema_validated': True,
                'snapshot_ref_resolved': True,
                'operation_target_strategy': 'editable_ancestor',
            },
        )

        _, _, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(name='内容区域', elements=[]),
            {'tag': 'div', 'role': 'textbox', 'text': '删除按钮', 'editable': True},
            candidate,
            {'ope_key': 'w_input', '_semantic_strength': 0},
        )

        self.assertIn('semantic mismatch', error)

    def test_descriptive_contract_number_prompt_uses_snapshot_parent_context(self):
        element = SimpleNamespace(
            name='获取合同编号',
            elements=[SimpleNamespace(prompt='在左侧找一个合同编号')],
        )
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=2,
            loc="get_by_text('CT--20260609-000096TDFCA1503', exact=True)",
            initial_score=90,
            generated_by_ai=True,
            metadata={
                'agent_schema_validated': True,
                'snapshot_ref_resolved': True,
                'snapshot_node_name': 'CT--20260609-000096TDFCA1503',
                'snapshot_node_text': 'CT--20260609-000096TDFCA1503',
                'snapshot_parent_text': '合同编号： CT--20260609-000096TDFCA1503',
                'snapshot_node_path': ['generic:待办列表', 'generic:合同编号： CT--20260609-000096TDFCA1503'],
            },
        )

        score, evidence, error = SemanticVerifier.candidate_evaluation(
            element,
            {'role': 'generic', 'text': 'CT--20260609-000096TDFCA1503'},
            candidate,
        )

        self.assertEqual(semantic_required_texts(element), ['合同编号'])
        self.assertGreaterEqual(score, 80)
        self.assertIn('snapshot_parent_text', evidence)
        self.assertIsNone(error)

        restored = WebElementHealingHarness._to_candidate(candidate.to_runtime_dict())
        restored_score, restored_evidence, restored_error = SemanticVerifier.candidate_evaluation(
            element,
            {'role': 'generic', 'text': 'CT--20260609-000096TDFCA1503'},
            restored,
        )
        self.assertGreaterEqual(restored_score, 80)
        self.assertIn('snapshot_parent_text', restored_evidence)
        self.assertIsNone(restored_error)

    def test_exclusion_description_is_not_required_target_semantics(self):
        element = SimpleNamespace(
            name='收支类型',
            elements=[SimpleNamespace(prompt=(
                '元素名称：收支类型\n'
                '元素位置与周边文字：左侧字段选择菜单中的默认字段分组\n'
                '排除项：右侧模板字段列表中的收支类型'
            ))],
        )

        texts = target_texts(element, limit=20)
        required = semantic_required_texts(element, limit=20)

        self.assertTrue(any('左侧字段选择菜单' in item for item in texts))
        self.assertFalse(any('右侧模板字段列表' in item for item in texts))
        self.assertFalse(any('右侧模板字段列表' in item for item in required))

    def test_card_target_rejects_nearby_search_input(self):
        element = SimpleNamespace(
            name='点击合同类型',
            elements=[SimpleNamespace(prompt=(
                '元素名称：点击合同类型\n'
                '元素分类：选择合同类型\n'
                '元素位置与周边文字：合同类型搜索结果中，点击'
                '“【线上自动化回归-1-1】”卡片左侧的单选圆圈'
            ))],
        )

        self.assertIn('【线上自动化回归-1-1】', target_texts(element, limit=20))
        self.assertIn('【线上自动化回归-1-1】', semantic_required_texts(element, limit=20))

        score, evidence, error = SemanticVerifier.candidate_evaluation(
            element,
            {
                'tag': 'input',
                'role': '',
                'placeholder': '搜索合同类型',
                'label_texts': ['选择合同类型'],
                'editable': True,
                'interactive': True,
            },
            find_params={'ope_key': 'w_click'},
        )

        self.assertEqual(score, 0)
        self.assertEqual(evidence, [])
        self.assertIn('expected 单选框', error)

        radio_score, _, radio_error = SemanticVerifier.candidate_evaluation(
            element,
            {
                'tag': 'input',
                'role': 'radio',
                'type': 'radio',
                'name': '【线上自动化回归-1-1】',
                'interactive': True,
            },
            find_params={'ope_key': 'w_click'},
        )

        self.assertGreaterEqual(radio_score, 80)
        self.assertIsNone(radio_error)

        intent = parse_target_intent(target_texts(element, limit=20))
        self.assertEqual(intent.scope, 'card')
        self.assertEqual(intent.control.name, 'radio')

    def test_operation_intent_uses_capability_instead_of_html_shape(self):
        cases = {
            'w_click': 'activate',
            'w_set_checked': 'select',
            'w_select_option': 'select',
            'w_input': 'edit',
            'w_upload_files': 'upload',
            'w_get_text': 'read',
            'custom_operation': 'unknown',
        }
        for key, expected in cases.items():
            with self.subTest(key=key):
                self.assertEqual(operation_intent(key), expected)
                self.assertEqual(operation_intent({'ope_key': key}), expected)

    def test_scoped_click_accepts_equivalent_radio_but_not_search_input(self):
        targets = ['合同类型搜索结果中的“线上自动化”卡片']
        radio_error = SemanticVerifier._target_kind_reject_reason(
            targets,
            {
                'tag': 'input', 'role': 'radio', 'type': 'radio',
                'interactive': True, 'editable': False,
            },
            {'ope_key': 'w_click'},
        )
        search_error = SemanticVerifier._target_kind_reject_reason(
            targets,
            {
                'tag': 'input', 'role': 'searchbox', 'type': 'text',
                'interactive': True, 'editable': True,
            },
            {'ope_key': 'w_click'},
        )

        self.assertIsNone(radio_error)
        self.assertIn('expected card', search_error)

    def test_scoped_edit_accepts_custom_editable_control(self):
        error = SemanticVerifier._target_kind_reject_reason(
            ['合同卡片中的名称区域'],
            {
                'tag': 'div', 'role': '', 'interactive': True, 'editable': True,
            },
            {'ope_key': 'w_input'},
        )

        self.assertIsNone(error)

    def test_click_target_resolution_includes_custom_selection_roles(self):
        self.assertIn('[role="radio"]', OperationTargetResolver.CLICK_DESCENDANT_SELECTOR)
        self.assertIn('[role="switch"]', OperationTargetResolver.CLICK_DESCENDANT_SELECTOR)
        self.assertIn('cursor === \'pointer\'', OperationTargetResolver.DIRECT_CONTROL_SCRIPT)

    def test_target_intent_prefers_specific_control_inside_scope(self):
        cases = (
            ('弹窗里的名称输入框', 'dialog', 'textbox'),
            ('表格行中的启用开关', 'row', 'switch'),
            ('卡片中的提交按钮', 'card', 'button'),
            ('抽屉里的附件上传控件', 'drawer', 'file_input'),
        )
        for text, scope, control in cases:
            with self.subTest(text=text):
                intent = parse_target_intent([text])
                self.assertEqual(intent.scope, scope)
                self.assertEqual(intent.control.name, control)

    def test_trusted_agent_dynamic_text_is_allowed_only_for_read_operation(self):
        element = SimpleNamespace(
            name='合同名称',
            elements=[SimpleNamespace(prompt='左侧卡片title的名称')],
        )
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.LOCATOR.value,
            loc="get_by_text('TEST模板双明细模板-20260609-1503-A', exact=True)",
            initial_score=90,
            generated_by_ai=True,
            metadata={
                'agent_schema_validated': True,
                'snapshot_ref_resolved': True,
                'durable_locator_strategy': 'text',
            },
        )
        state = {'tag': 'span', 'text': 'TEST模板双明细模板-20260609-1503-A'}

        score, evidence, error = SemanticVerifier.candidate_evaluation(
            element, state, candidate, {'ope_key': 'w_get_text'},
        )
        self.assertEqual(score, 90)
        self.assertEqual(evidence, ['trusted_agent_read_target'])
        self.assertIsNone(error)

        _, _, strict_error = SemanticVerifier.candidate_evaluation(
            element,
            state,
            candidate,
            {'ope_key': 'w_get_text', '_semantic_strength': 20},
        )
        self.assertIn('semantic mismatch', strict_error)

        _, _, click_error = SemanticVerifier.candidate_evaluation(
            element, state, candidate, {'ope_key': 'w_click'},
        )
        self.assertIn('semantic mismatch', click_error)

    def test_semantic_strength_has_standalone_default_and_clamps_invalid_values(self):
        self.assertEqual(StaticRuntimeConfig().semantic_strength(), 0)
        self.assertEqual(StaticRuntimeConfig(semantic_strength_value=50).semantic_strength(), 50)
        self.assertEqual(StaticRuntimeConfig(semantic_strength_value=120).semantic_strength(), 100)
        self.assertEqual(StaticRuntimeConfig(semantic_strength_value='invalid').semantic_strength(), 0)

    def test_accessibility_text_node_generates_playwright_and_xpath_locators(self):
        text = "TEST模板双明细模板-20260609-1503-A"
        node = AccessibilitySnapshotNode(
            ref='e1', frame_index=0, order=0, role='generic', name=text,
            text=text, tag='span', attributes={},
        )

        candidates = DurableLocatorGenerator.build_all(node, [node])

        self.assertTrue(any(
            item.exp == ElementExpEnum.LOCATOR.value and item.strategy == 'text' and
            item.loc == f'get_by_text({text!r}, exact=True)'
            for item in candidates
        ))
        self.assertTrue(any(
            item.exp == ElementExpEnum.XPATH.value and item.strategy == 'xpath_text' and
            item.loc == f"//span[normalize-space(.)='{text}']"
            for item in candidates
        ))

    def test_xpath_literal_supports_both_quote_types(self):
        value = "甲'乙\"丙"
        self.assertEqual(
            DurableLocatorGenerator._xpath_literal(value),
            "concat('甲', \"'\", '乙\"丙')",
        )

    def test_agent_candidate_carries_parent_snapshot_context(self):
        snapshot = AccessibilitySnapshot(
            snapshot_id='contractsnapshot',
            page_url='https://example.test/task',
            created_at_ms=1,
            nodes=[
                AccessibilitySnapshotNode(
                    ref='e1', frame_index=0, order=0, role='generic',
                    name='合同编号： CT--001', text='合同编号： CT--001', tag='div',
                    attributes={},
                ),
                AccessibilitySnapshotNode(
                    ref='e2', parent_ref='e1', frame_index=0, order=1, role='generic',
                    name='CT--001', text='CT--001', tag='div', attributes={},
                    path=['generic:合同编号： CT--001', 'generic:CT--001'],
                ),
            ],
            tree='frame\n  - generic "合同编号： CT--001" [ref=e1]',
        )
        rows = AgentResponseParser.parse(json.dumps({
            'schema_version': SCHEMA_VERSION,
            'status': 'matched',
            'reason': 'target identified',
            'candidates': [{
                'source': 'ai_accessibility',
                'target_ref': 'e2',
                'reason': 'contract number value under its label',
                'confidence': 90,
            }],
        })).candidates

        candidate = AgentCandidateNormalizer.normalize(rows, snapshot, [])[0]

        self.assertEqual(candidate.metadata['snapshot_parent_text'], '合同编号： CT--001')
        self.assertEqual(candidate.metadata['snapshot_node_path'][-1], 'generic:CT--001')

    def test_unvalidated_snapshot_context_is_not_semantic_evidence(self):
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=2,
            loc="get_by_text('CT--20260609-000096TDFCA1503', exact=True)",
            metadata={'snapshot_parent_text': '合同编号： CT--20260609-000096TDFCA1503'},
        )
        score, _, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(name='获取合同编号', elements=[]),
            {'role': 'generic', 'text': 'CT--20260609-000096TDFCA1503'},
            candidate,
        )

        self.assertLess(score, 80)
        self.assertIn('semantic mismatch', error)

    def test_semantic_verification_skips_generic_target_name(self):
        score, evidence, error = SemanticVerifier.candidate_evaluation(
            SimpleNamespace(name='结果', elements=[]),
            {'role': '', 'text': '按下的键: Enter'},
        )
        self.assertEqual(score, 100)
        self.assertEqual(evidence, ['semantic_not_required'])
        self.assertIsNone(error)

    def test_fixed_semantic_verification_skips_generic_element_name(self):
        element = SimpleNamespace(name='输入框', elements=[])
        self.assertIsNone(
            SemanticVerifier.fixed_reject_reason(element, '当前已输入的值', 'locator("#kw")')
        )

    def test_fixed_semantic_verification_skips_runtime_variable_locator(self):
        element = SimpleNamespace(
            name='演示-元素中包含全局变量',
            elements=[SimpleNamespace(loc='get_by_role("button", name="${{菜单名称}}")')],
        )
        self.assertIsNone(
            SemanticVerifier.fixed_reject_reason(element, '文件上传测试', 'get_by_role("button", name="文件上传测试")')
        )

    def test_fixed_semantic_verification_accepts_locator_literal_matching_element_text(self):
        element = SimpleNamespace(
            name='按键输入框',
            elements=[SimpleNamespace(
                loc='get_by_role("textbox", name="键盘输入测试")',
                prompt='按键输入框',
            )],
        )
        self.assertIsNone(
            SemanticVerifier.fixed_reject_reason(
                element,
                '键盘输入测试',
                'get_by_role("textbox", name="键盘输入测试")',
            )
        )

    def test_fixed_semantic_verification_accepts_unique_icon_without_text(self):
        element = SimpleNamespace(
            name='新增对话',
            elements=[SimpleNamespace(
                loc='//*[@data-qfei-icon="add-two"]',
                prompt='创建新的对话，对应的是+号',
            )],
        )
        self.assertIsNone(
            SemanticVerifier.fixed_reject_reason(
                element,
                None,
                '//*[@data-qfei-icon="add-two"]',
            )
        )

    def test_fixed_semantic_verification_skips_resolved_runtime_variable(self):
        element = SimpleNamespace(
            name='演示-元素中包含全局变量',
            elements=[SimpleNamespace(
                loc='get_by_role("button", name="页面导航测试")',
                prompt='查找元素：演示-元素中包含全局变量',
            )],
        )
        self.assertIsNone(
            SemanticVerifier.fixed_reject_reason(
                element, '页面导航测试', 'get_by_role("button", name="页面导航测试")',
            )
        )

    def test_agent_configuration_error_opens_global_circuit_breaker(self):
        AgentCircuitBreaker.reset()
        status = AgentCircuitBreaker.failure(
            1,
            'https://example.test/a',
            error='Error code: 401 - Authentication Fails, api key is invalid',
            configuration_error=True,
            now=10,
        )
        self.assertFalse(status.allowed)
        self.assertTrue(status.configuration_error)
        other_element = AgentCircuitBreaker.status(2, 'https://example.test/b', now=11)
        self.assertFalse(other_element.allowed)
        self.assertTrue(other_element.configuration_error)
        AgentCircuitBreaker.reset()

    async def test_expired_deterministic_budget_stops_candidate_validation(self):
        harness = WebElementHealingHarness(runtime_config=StaticRuntimeConfig(enabled=True, mode=2))
        candidates = [LocatorCandidate(
            source='test', exp=2, loc='get_by_role("button", name="Save")', initial_score=100,
        )]
        results = []
        rejects = []
        selected = await harness._verify_async(
            _AsyncPage(), _Element(), candidates, {'ope_key': 'w_click'}, results, rejects, 0,
            deadline=time.perf_counter() - 0.01,
        )
        self.assertIsNone(selected)
        self.assertEqual(results, [])
        self.assertIn('deterministic healing budget exhausted', rejects)

    def test_agent_circuit_breaker_cools_down_repeated_failures(self):
        AgentCircuitBreaker.reset()
        first = AgentCircuitBreaker.failure(
            1, 'https://example.test/page', error='schema invalid', now=10,
        )
        self.assertEqual(first.failure_count, 1)
        self.assertEqual(first.last_error, 'schema invalid')
        self.assertTrue(AgentCircuitBreaker.allow(1, 'https://example.test/page', now=11))
        opened = AgentCircuitBreaker.failure(
            1, 'https://example.test/page', error='model timeout', now=12,
        )
        self.assertFalse(opened.allowed)
        blocked = AgentCircuitBreaker.status(1, 'https://example.test/page', now=13)
        self.assertFalse(blocked.allowed)
        self.assertEqual(blocked.failure_count, 2)
        self.assertEqual(blocked.last_error, 'model timeout')
        self.assertEqual(blocked.cooldown_remaining_seconds, 59)
        probe = AgentCircuitBreaker.status(1, 'https://example.test/page', now=100)
        self.assertTrue(probe.allowed)
        self.assertTrue(probe.recovery_probe)

    def test_inherited_pointer_click_can_heal_temporarily_but_cannot_auto_apply(self):
        state = {
            'tag': 'span',
            'role': '',
            'interactive': True,
            'direct_interactive': False,
        }
        params = {'ope_key': 'w_click'}
        self.assertIsNone(operation_compatibility_reason(state, params))
        self.assertIn('direct interactive signal', auto_apply_operation_compatibility_reason(state, params))

    def test_click_rejects_non_interactive_heading(self):
        state = {
            'tag': 'h3',
            'role': '',
            'interactive': False,
            'direct_interactive': False,
        }
        error = operation_compatibility_reason(state, {'ope_key': 'w_click'})
        self.assertIn('requires an interactive element', error)

    def test_unique_visible_text_is_temporary_grade_not_auto_apply_grade(self):
        candidate = LocatorCandidate(
            source='unique_visible_text',
            exp=0,
            loc='/html/body/div[2]/div[1]',
            initial_score=85,
        )
        stability = CandidateScorer.stability_score(candidate)
        score = CandidateScorer.final_score(
            candidate,
            visible=True,
            semantic_score=100,
            stability_score=stability,
            actionable=True,
            operation_compatible=True,
        )
        self.assertEqual(stability, 65)
        self.assertGreaterEqual(score, 85)
        self.assertLess(stability, 80)

    def test_snapshot_matched_text_with_subscript_reaches_temporary_heal_grade(self):
        candidate = LocatorCandidate(
            source=CandidateSource.ACCESSIBILITY_AGENT,
            exp=ElementExpEnum.XPATH.value,
            loc="//div[normalize-space(.)='动态合同名称']",
            sub=2,
            initial_score=88,
            metadata={'snapshot_matcher_validated': True},
        )
        stability = CandidateScorer.stability_score(candidate)
        score = CandidateScorer.final_score(
            candidate,
            visible=True,
            semantic_score=90,
            stability_score=stability,
            actionable=True,
            operation_compatible=True,
        )

        self.assertEqual(stability, 80)
        self.assertGreaterEqual(score, 85)

    def test_verified_agent_read_candidate_reaches_temporary_grade(self):
        score = CandidateScorer.verified_read_score(
            82.75,
            semantic_evidence=['trusted_agent_read_target'],
            count=1,
            consecutive_passes=2,
            stable_context=True,
            durable_count=1,
            has_subscript=False,
            find_params={'ope_key': 'w_get_text'},
        )

        self.assertEqual(score, 85)

    def test_verified_agent_click_candidate_does_not_receive_read_floor(self):
        score = CandidateScorer.verified_read_score(
            82.75,
            semantic_evidence=['trusted_agent_read_target'],
            count=1,
            consecutive_passes=2,
            stable_context=True,
            durable_count=1,
            has_subscript=False,
            find_params={'ope_key': 'w_click'},
        )

        self.assertEqual(score, 82.75)

    def test_verified_agent_read_subscript_can_resolve_non_unique_durable_locator(self):
        score = CandidateScorer.verified_read_score(
            84.45,
            semantic_evidence=['trusted_agent_read_target'],
            count=1,
            consecutive_passes=2,
            stable_context=True,
            durable_count=22,
            has_subscript=True,
            find_params={'ope_key': 'w_get_text'},
        )

        self.assertEqual(score, 85)

    def test_verified_empty_editor_reaches_temporary_heal_grade(self):
        score = CandidateScorer.verified_empty_editable_score(
            73.95,
            semantic_evidence=['trusted_agent_empty_editable_target'],
            count=1,
            consecutive_passes=2,
            stable_context=True,
            durable_count=1,
            has_subscript=False,
            find_params={'ope_key': 'w_input'},
        )

        self.assertEqual(score, 85)

    def test_empty_editor_without_repeat_validation_keeps_original_score(self):
        score = CandidateScorer.verified_empty_editable_score(
            73.95,
            semantic_evidence=['trusted_agent_empty_editable_target'],
            count=1,
            consecutive_passes=1,
            stable_context=False,
            durable_count=1,
            has_subscript=False,
            find_params={'ope_key': 'w_input'},
        )

        self.assertEqual(score, 73.95)


if __name__ == '__main__':
    unittest.main()
