import asyncio
import io
import json
from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, Mock, patch

from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.reporting import (AutomationErrorReporter, configure_error_callback, developer_error,
                                       error_payload, report_automation_error, _NoRedirect)
from mangoautomation.tools import async_method_callback, sync_method_callback
from mangoautomation.uidrives.context import AutomationContext


class ErrorReportingTests(IsolatedAsyncioTestCase):
    async def test_optional_callback_default_is_noop(self):
        self.assertFalse(await AutomationErrorReporter().report(TypeError('bug'), 'element'))

    async def test_unknown_error_is_reported_once_across_boundaries(self):
        callback = AsyncMock(return_value=True)
        reporter = AutomationErrorReporter(callback)
        error = TypeError('logic bug')
        self.assertTrue(await reporter.report(error, 'element'))
        self.assertFalse(await reporter.report(error, 'case'))
        callback.assert_awaited_once_with(error, 'element')

    async def test_business_assertion_timeout_and_cancellation_not_reported(self):
        reporter = AutomationErrorReporter(AsyncMock())
        for error in (MangoAutomationError(1, 'expected'), AssertionError('failed'), TimeoutError('timeout'), asyncio.CancelledError()):
            self.assertFalse(await reporter.report(error, 'case'))
        reporter.callback.assert_not_called()

    async def test_callback_error_timeout_and_recursion_do_not_change_result(self):
        error = KeyError('bug')
        callback = AsyncMock(side_effect=RuntimeError('reporter broken'))
        self.assertFalse(await AutomationErrorReporter(callback).report(error, 'element'))
        async def wait(*args):
            await asyncio.sleep(10)
        self.assertFalse(await AutomationErrorReporter(wait, timeout=0.1).report(error, 'element'))
        reporter = AutomationErrorReporter(lambda exc, op: reporter.report(exc, op))
        self.assertFalse(await reporter.report(error, 'element'))

    def test_sync_callback_and_url_payload(self):
        callback = Mock(return_value=True)
        reporter = AutomationErrorReporter(callback)
        error = AttributeError('bug')
        self.assertTrue(reporter.report_sync(error, 'driver'))
        callback.assert_called_once_with(error, 'driver')
        response = Mock()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        response.read.return_value = b'{"code":200}'
        opener = Mock()
        opener.open.return_value = response
        reporter = AutomationErrorReporter(url='https://errors.example.com/report', headers={'Authorization': 'test-only'})
        with patch('mangoautomation.reporting.build_opener', return_value=opener):
            self.assertTrue(reporter.report_sync(TypeError('password=hidden'), 'driver'))
        request = opener.open.call_args.args[0]
        self.assertEqual(request.get_method(), 'POST')
        self.assertNotIn('hidden', request.data.decode())
        self.assertEqual(json.loads(request.data)['exception_type'], 'TypeError')

    def test_http_business_rejection_is_not_success_or_followed_to_another_host(self):
        reporter = AutomationErrorReporter(url='https://errors.example.com/report')
        response = Mock()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        response.read.return_value = b'{"code":403}'
        with patch('mangoautomation.reporting.build_opener') as opener:
            opener.return_value.open.return_value = response
            self.assertFalse(reporter.report_sync(TypeError('bug'), 'driver'))
        self.assertIsNone(_NoRedirect().redirect_request(None, None, 302, '', {}, 'https://other.example.com'))

    async def test_context_and_decorated_operations_keep_original_exception(self):
        callback = AsyncMock(return_value=True)
        context = AutomationContext(Mock(), Mock(), system_error_callback=callback)
        class Driver:
            base_data = context
            @async_method_callback('test', 'test', 'test')
            async def operate(self):
                raise TypeError('bug')
        with self.assertRaisesRegex(TypeError, 'bug'):
            await Driver().operate()
        callback.assert_awaited_once()
        with self.assertRaisesRegex(TypeError, 'bug'):
            @sync_method_callback('test', 'test', 'sync')
            def sync_operation(self):
                raise TypeError('bug')
            context.set_system_error_callback(Mock(return_value=True))
            sync_operation(Driver())

    async def test_default_callback_is_optional_and_can_be_cleared(self):
        callback = Mock(return_value=True)
        try:
            configure_error_callback(callback)
            context = AutomationContext(Mock(), Mock())
            self.assertTrue(await context.system_error_reporter.report(TypeError('bug'), 'pytest'))
        finally:
            configure_error_callback(None)
        self.assertFalse(await AutomationErrorReporter().report(TypeError('bug'), 'independent'))

    def test_payload_redacts_secrets_and_does_not_capture_source_lines_or_locals(self):
        try:
            secret_local = 'do-not-collect-locals'
            raise TypeError('password="hidden value" Authorization=Bearer abc123 cookie="session=secret"')
        except TypeError as error:
            payload = error_payload(error, 'case')
        value = json.dumps(payload)
        for secret in ('hidden value', 'abc123', 'session=secret', secret_local, 'raise TypeError'):
            self.assertNotIn(secret, value)
        self.assertIn('test_payload_redacts_secrets', payload['traceback'])

    async def test_legacy_context_or_broken_reporter_is_safe(self):
        self.assertFalse(await report_automation_error(SimpleNamespace(), TypeError('bug'), 'legacy'))
        owner = SimpleNamespace(base_data=SimpleNamespace(system_error_reporter=object()))
        self.assertFalse(await report_automation_error(owner, TypeError('bug'), 'legacy'))

    async def test_async_element_unknown_failure_is_reported_even_when_converted_to_result(self):
        from mangoautomation.enums import DriveTypeEnum, ElementOperationEnum
        from mangoautomation.uidrives._async_element import AsyncElement
        callback = AsyncMock(return_value=True)
        context = AutomationContext(Mock(), Mock(), system_error_callback=callback)
        element = AsyncElement(context, DriveTypeEnum.ANDROID.value)
        element.init_element = AsyncMock(side_effect=TypeError('element implementation bug'))
        element._AsyncElement__error = AsyncMock()
        element._AsyncElement__fill_runtime_snapshot = AsyncMock()
        model = SimpleNamespace(id=1, name='example', sleep=0, type=ElementOperationEnum.OPE,
                                ope_key='a_click', sql_execute=None, custom=None, elements=[])
        result = await element.element_main(model)
        self.assertEqual(result.status, 0)
        callback.assert_awaited_once()
        self.assertIsInstance(callback.call_args.args[0], TypeError)

    def test_sync_element_unknown_failure_is_reported_even_when_converted_to_result(self):
        from mangoautomation.enums import DriveTypeEnum, ElementOperationEnum
        from mangoautomation.uidrives._sync_element import SyncElement
        callback = Mock(return_value=True)
        context = AutomationContext(Mock(), Mock(), system_error_callback=callback)
        element = SyncElement(context, DriveTypeEnum.ANDROID.value)
        element.init_element = Mock(side_effect=TypeError('element implementation bug'))
        element._SyncElement__error = Mock()
        model = SimpleNamespace(id=1, name='example', sleep=0, type=ElementOperationEnum.OPE,
                                ope_key='a_click', sql_execute=None, custom=None, elements=[])
        result = element.element_main(model)
        self.assertEqual(result.status, 0)
        callback.assert_called_once()

    async def test_healing_event_sink_unknown_failure_is_not_silently_lost(self):
        from mangoautomation.element_healing import WebElementHealingHarness
        callback = AsyncMock(return_value=True)
        harness = WebElementHealingHarness(event_sink=SimpleNamespace(emit_async=AsyncMock(side_effect=TypeError('sink bug'))),
                                          system_error_callback=callback)
        await harness._emit_async('attempt', {})
        callback.assert_awaited_once()

    def test_invalid_callback_url_is_rejected_without_network(self):
        for url in ('file:///tmp/report', 'https://user:pass@errors.example.com/report'):
            with self.assertRaises(ValueError):
                AutomationErrorReporter(url=url)
        with self.assertRaises(ValueError):
            AutomationErrorReporter(lambda *args: True, url='https://errors.example.com')

    def test_multi_cookie_headers_and_signed_url_queries_are_redacted(self):
        value = error_payload(TypeError('Cookie: first=secret-one; second=secret-two\n'
                                       'https://files.example.com/path?X-Amz-Signature=secret-three&key=value'), 'case')
        for secret in ('secret-one', 'secret-two', 'secret-three', 'key=value'):
            self.assertNotIn(secret, json.dumps(value))

    def test_original_cause_is_retained_without_source_or_locals(self):
        try:
            try:
                raise KeyError('root cause')
            except KeyError as error:
                raise RuntimeError('outer failure') from error
        except RuntimeError as error:
            value = error_payload(error, 'driver')
        self.assertIn('KeyError', value['traceback'])
        self.assertIn('root cause', value['traceback'])
        self.assertNotIn('raise KeyError', value['traceback'])


if __name__ == '__main__':
    import unittest
    unittest.main()
