# -*- coding: utf-8 -*-
from typing import Any

from mangoautomation.uidrives.runtime.ios_runtime import IOSRuntime


class IOSDriverFactory:
    @staticmethod
    def create_runtime(server_url: str, capabilities: dict[str, Any]) -> IOSRuntime:
        return IOSRuntime(server_url, capabilities)
