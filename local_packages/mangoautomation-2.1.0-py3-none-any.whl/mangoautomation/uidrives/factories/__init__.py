# -*- coding: utf-8 -*-
from .android_factory import AndroidDriverFactory
from .desktop_factory import WindowsDriverFactory
from .web_factory import WebDriverFactory

__all__ = [
    "AndroidDriverFactory",
    "IOSDriverFactory",
    "WebDriverFactory",
    "WindowsDriverFactory",
]


def __getattr__(name):
    if name == "IOSDriverFactory":
        from .ios_factory import IOSDriverFactory

        return IOSDriverFactory
    raise AttributeError(name)
