# -*- coding: utf-8 -*-
import inspect
from typing import Any, Callable, Optional
from unittest.mock import MagicMock

import sys
from mangoautomation.enums import DriveTypeEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0010, ERROR_MSG_0007
from mangotools.assertion import MangoAssertion
from mangotools.data_processor import DataProcessor

if not sys.platform.startswith("win32"):
    WindowControl = MagicMock()
    print("警告: uiautomation 仅支持 Windows，当前环境已自动跳过")
else:
    from uiautomation import WindowControl


class AutomationContext:
    """公共运行上下文。

    设备对象由外部 runtime/session 注入和管理，本类只提供操作层访问当前
    page/context/android/window 的轻量引用，不负责创建、复用或关闭设备。
    """

    def __init__(self, test_data: DataProcessor, log):
        self.test_data = test_data
        self.log = log
        self.assertion_class = MangoAssertion
        self.download_path: Optional[str | None] = None
        self.screenshot_path: Optional[str | None] = None

        self.is_ai = False
        self.api_key = None
        self.base_url = None
        self.model = None
        self.locator_engine = None

        # SQL 断言只读取平台回调结果；这里不允许保存真实数据库连接。
        self.database_result_adapter: Optional[Any] = None
        self.database_execute_callback: Optional[Callable[..., Any]] = None

        self.url: Optional[str | None] = None
        self.package_name: Optional[str | None] = None
        self.bundle_id: Optional[str | None] = None
        self.is_open_app = False

        self._web_runtime = None
        self._android_runtime = None
        self._desktop_runtime = None
        self._ios_runtime = None
        self._page = None
        self._context = None
        self._android = None
        self._ios = None
        self._window: Optional[None | WindowControl] = None

    @property
    def page(self):
        return self._page

    @page.setter
    def page(self, value):
        self._page = value

    @property
    def context(self):
        return self._context

    @context.setter
    def context(self, value):
        self._context = value

    @property
    def android(self):
        return self._android

    @android.setter
    def android(self, value):
        self._android = value

    @property
    def ios(self):
        return self._ios

    @ios.setter
    def ios(self, value):
        self._ios = value

    @property
    def window(self):
        return self._window

    @window.setter
    def window(self, value):
        self._window = value

    def bind_web(self, web_runtime, context=None, page=None):
        self._web_runtime = web_runtime
        if context is not None:
            self._context = context
        if page is not None:
            self._page = page
        self.log.debug("[上下文绑定] Web runtime 已绑定")
        return self

    def bind_android(self, android_runtime, android=None, package_name: str | None = None):
        self._android_runtime = android_runtime
        if android is not None:
            self._android = android
        if package_name is not None:
            self.package_name = package_name
        self.log.debug("[上下文绑定] Android runtime 已绑定")
        return self

    def bind_ios(self, ios_runtime, ios=None, bundle_id: str | None = None):
        self._ios_runtime = ios_runtime
        if ios is not None:
            self._ios = ios
        if bundle_id is not None:
            self.bundle_id = bundle_id
        self.log.debug("[上下文绑定] iOS runtime 已绑定")
        return self

    def bind_desktop(self, desktop_runtime, window=None):
        self._desktop_runtime = desktop_runtime
        if window is not None:
            self._window = window
        self.log.debug("[上下文绑定] Desktop runtime 已绑定")
        return self

    def set_file_path(self, download_path, screenshot_path):
        self.download_path = download_path
        self.screenshot_path = screenshot_path
        self.log.debug(f"[路径配置] 下载路径: {download_path}, 截图路径: {screenshot_path}")
        return self

    def set_url(self, url: str):
        self.url = url
        self.log.debug(f"[URL配置] 设置URL: {url}")
        return self

    def set_package_name(self, package_name: str):
        self.package_name = package_name
        self.log.debug(f"[包名配置] 设置包名: {package_name}")
        return self

    def set_bundle_id(self, bundle_id: str):
        self.bundle_id = bundle_id
        self.log.debug(f"[Bundle ID配置] 设置Bundle ID: {bundle_id}")
        return self

    def setup(self) -> None:
        self.log.debug("[资源清理] 开始清理上下文引用")
        self.url = None
        self.page = None
        self.context = None
        self.package_name = None
        self.bundle_id = None
        self.android = None
        self.ios = None
        self.window = None
        self.is_open_app = False
        self.database_result_adapter = None
        self.database_execute_callback = None
        self._web_runtime = None
        self._android_runtime = None
        self._desktop_runtime = None
        self._ios_runtime = None
        self.log.debug("[资源清理] 上下文引用清理完成")

    async def async_base_close(self):
        self.log.info("[资源关闭] 开始关闭异步上下文资源")
        if self.context:
            await self.context.close()
            self.log.debug("[资源关闭] Context已关闭")
        if self.page:
            await self.page.close()
            self.log.debug("[资源关闭] Page已关闭")
        if self.database_result_adapter and callable(getattr(self.database_result_adapter, 'close', None)):
            self.database_result_adapter.close()
            self.log.debug("[资源关闭] SQL结果适配器已关闭")
        self.setup()
        self.log.info("[资源关闭] 异步上下文资源关闭完成")

    def sync_base_close(self):
        self.log.info("[资源关闭] 开始关闭同步上下文资源")
        if self.context:
            self.context.close()
            self.log.debug("[资源关闭] Context已关闭")
        if self.page:
            self.page.close()
            self.log.debug("[资源关闭] Page已关闭")
        if self.database_result_adapter and callable(getattr(self.database_result_adapter, 'close', None)):
            self.database_result_adapter.close()
            self.log.debug("[资源关闭] SQL结果适配器已关闭")
        self.setup()
        self.log.info("[资源关闭] 同步上下文资源关闭完成")

    def set_database_execute_callback(self, callback: Callable[..., Any] | None):
        """注入业务数据源执行回调，避免自动化运行库持有数据库连接。"""
        self.database_execute_callback = callback
        callback_status = "已设置" if callback else "已清除"
        self.log.debug(f"[数据库回调] {callback_status}业务数据源执行回调")
        return self

    async def execute_database(
            self,
            operation_config,
            *,
            datasource_alias_id=None,
            source_context: dict | None = None,
    ):
        """通过调用方回调执行，自动化库自身不连接或操作数据库。"""
        if not self.database_execute_callback:
            raise MangoAutomationError(4036, '未注入数据源执行回调')
        result = self.database_execute_callback(
            operation_config=operation_config,
            datasource_alias_id=datasource_alias_id,
            source_context=source_context or {},
        )
        return await result if inspect.isawaitable(result) else result

    def execute_database_sync(
            self,
            operation_config,
            *,
            datasource_alias_id=None,
            source_context: dict | None = None,
    ):
        """同步运行链路使用同步回调；禁止在此处启动事件循环或直连数据库。"""
        if not self.database_execute_callback:
            raise MangoAutomationError(4036, '未注入数据源执行回调')
        result = self.database_execute_callback(
            operation_config=operation_config,
            datasource_alias_id=datasource_alias_id,
            source_context=source_context or {},
        )
        if inspect.isawaitable(result):
            close = getattr(result, 'close', None)
            if callable(close):
                close()
            raise MangoAutomationError(4036, '同步自动化需要注入同步数据源执行回调')
        return result

    def verify_equipment(self, drive_type: int):
        if drive_type == DriveTypeEnum.WEB.value:
            if not self.page or not self.context:
                self.log.error("[设备验证] Web设备未初始化")
                raise MangoAutomationError(*ERROR_MSG_0010)
            self.log.debug("[设备验证] Web设备验证通过")
        elif drive_type == DriveTypeEnum.ANDROID.value:
            if not self.android:
                self.log.error("[设备验证] Android设备未初始化")
                raise MangoAutomationError(*ERROR_MSG_0007)
            self.log.debug("[设备验证] Android设备验证通过")
        elif drive_type == DriveTypeEnum.IOS.value:
            if not self.ios:
                self.log.error("[设备验证] iOS设备未初始化")
                raise MangoAutomationError(*ERROR_MSG_0007)
            self.log.debug("[设备验证] iOS设备验证通过")
        else:
            self.log.debug(f"[设备验证] 设备类型 {drive_type} 无需验证")

    def set_agent(
        self,
        is_ai: bool,
        api_key: str,
        base_url: str = "https://api.siliconflow.cn/v1",
        model: str = "THUDM/GLM-Z1-9B-0414",
    ):
        self.is_ai = is_ai
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        if is_ai:
            self.log.info(f"[AI配置] 启用AI定位，模型: {model}")
            if self.locator_engine is None:
                from mangoautomation.element_healing import WebElementHealingHarness

                self.locator_engine = WebElementHealingHarness.standalone(
                    api_key=api_key,
                    base_url=base_url,
                    model=model,
                    mode=2,
                    logger=self.log,
                )
        else:
            self.log.debug("[AI配置] AI定位未启用")
        return self

    def set_locator_engine(self, locator_engine):
        self.locator_engine = locator_engine
        self.log.debug(f"[定位引擎配置] 设置定位引擎: {locator_engine.__class__.__name__ if locator_engine else None}")
        return self

    def set_assertion_class(self, assertion_class):
        self.assertion_class = assertion_class
        self.log.debug(f"[断言配置] 设置公共断言类: {assertion_class.__name__}")
        return self


BaseData = AutomationContext
