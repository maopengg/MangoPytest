from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0065


try:
    from mangoautomation.uidrives.ios import IOSAssertion, IOSDriver
except ModuleNotFoundError as error:
    missing_module = str(getattr(error, 'name', '') or error)
    if not (missing_module == 'appium' or missing_module.startswith('appium.')):
        raise

    class IOSAssertion:
        """未安装 iOS 可选依赖时的空断言类型。"""

    class IOSDriver:
        """让非 iOS 执行器无需安装 Appium，同时为误选 iOS 提供明确提示。"""

        @staticmethod
        def _ios_dependency_required():
            raise MangoAutomationError(*ERROR_MSG_0065)

        def open_ios_app(self):
            self._ios_dependency_required()

        def i_action_element(self, *_args, **_kwargs):
            self._ios_dependency_required()

        def i_assertion_element(self, *_args, **_kwargs):
            self._ios_dependency_required()

        def i_find_ele(self, *_args, **_kwargs):
            self._ios_dependency_required()

        def i_screenshot(self, *_args, **_kwargs):
            self._ios_dependency_required()


__all__ = ['IOSAssertion', 'IOSDriver']
