# -*- coding: utf-8 -*-


def locator_failure_message(metadata: dict | None, target_name: str | None = None) -> str:
    """Return a safe, actionable summary for an exhausted locator-engine attempt."""
    metadata = metadata if isinstance(metadata, dict) else {}
    target_text = ' '.join(str(target_name or '').split())[:80]
    target_label = f'“{target_text}”' if target_text else '与元素描述匹配的内容'
    trace = metadata.get('trace') if isinstance(metadata.get('trace'), dict) else {}
    stages = trace.get('stages') if isinstance(trace.get('stages'), list) else []
    error_text = next((
        str(item.get('error') or '').strip()
        for item in reversed(stages)
        if isinstance(item, dict) and item.get('error')
    ), '')
    normalized = error_text.lower()
    if any(value in error_text for value in ('余额不足', '无可用资源包')) or 'insufficient_quota' in normalized:
        return 'AI 服务余额不足或无可用资源包，请检查模型账户额度'
    if 'json_invalid' in normalized or '不符合schema' in normalized:
        return 'AI 模型返回内容不符合 OpenAI 兼容的 JSON 格式，请检查模型或兼容网关'
    if 'circuit breaker' in normalized or '熔断' in error_text:
        return 'AI 定位连续失败已进入短暂冷却，请稍后重试或检查模型配置'
    if 'timeout' in normalized or 'timed out' in normalized or '超时' in error_text:
        return '智能定位请求超时，请检查模型服务或适当增加智能定位超时时间'

    if any(value in normalized for value in (
        'javascript-disabled',
        'no rendered ui elements',
        'only a generic node with script content',
    )):
        return '当前页面未正常加载可操作内容，请确认页面加载完成后重试'
    if any(value in normalized for value in (
        'accessibility snapshot',
        'no supported target_ref',
        'no node',
        'no ref matching',
    )):
        return f'页面中未找到可定位的{target_label}，请确认目标内容已显示，或调整元素描述和等待时间'

    reject_reasons = metadata.get('reject_reasons')
    if isinstance(reject_reasons, list) and reject_reasons:
        reject_reason = str(reject_reasons[0] or '')
        normalized_reject_reason = reject_reason.lower()
        if 'semantic mismatch' in normalized_reject_reason:
            return 'AI 找到了相似元素，但与元素描述不一致，请补充更明确的元素位置或周边文字'
        if 'generated durable locator does not resolve' in normalized_reject_reason:
            return 'AI 找到了候选元素，但生成的定位方式无法稳定命中，请补充元素描述或配置固定定位'
        if 'candidate generation budget exhausted' in normalized_reject_reason:
            return '页面候选元素较多，AI 未能确定唯一目标，请补充更明确的元素位置或周边文字'
        return '找到了候选元素，但浏览器验证未通过，请确认目标内容已显示并且可操作'
    candidates = metadata.get('candidates')
    if not isinstance(candidates, list):
        candidates = trace.get('candidates') if isinstance(trace.get('candidates'), list) else []
    verified = [item for item in candidates if isinstance(item, dict) and item.get('verified')]
    if verified:
        highest_score = max(float(item.get('final_score') or 0) for item in verified)
        return (
            f'已找到并验证可操作元素，但可信度 {highest_score:g} 未达到安全采用条件；'
            '系统为避免误操作未执行，请补充更明确的元素位置或周边文字'
        )
    if error_text:
        if '\u4e00' <= error_text[0] <= '\u9fff':
            return f'智能定位未找到目标：{error_text[:300]}'
        return f'智能定位未找到{target_label}，请确认页面内容已加载完成，或调整元素描述'
    return '没有候选通过浏览器验证，请查看元素自愈详情'
