# -*- coding: utf-8 -*-
from .android_runtime import AndroidRuntime
from .desktop_runtime import DesktopRuntime
from .web_runtime import AsyncWebRuntime, SyncWebRuntime

__all__ = [
    "AndroidRuntime",
    "IOSRuntime",
    "AsyncWebRuntime",
    "DesktopRuntime",
    "SyncWebRuntime",
]


def __getattr__(name):
    if name == "IOSRuntime":
        from .ios_runtime import IOSRuntime

        return IOSRuntime
    raise AttributeError(name)
