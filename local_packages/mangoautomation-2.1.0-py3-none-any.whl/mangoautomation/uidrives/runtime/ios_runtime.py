# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any

from appium import webdriver
from appium.options.ios import XCUITestOptions


class IOSRuntime:
    """Appium 3 / XCUITest 会话运行时。

    Runtime 只拥有 Appium session；Appium Server 和 WebDriverAgent 的安装、
    签名及生命周期由执行器配置层负责。
    """

    def __init__(self, server_url: str, capabilities: dict[str, Any]):
        self.server_url = server_url.rstrip('/')
        self.capabilities = dict(capabilities)
        self.driver = None

    def connect(self):
        if self.driver is None:
            options = XCUITestOptions().load_capabilities(self.capabilities)
            self.driver = webdriver.Remote(self.server_url, options=options)
        return self.driver

    def close(self):
        if self.driver is not None:
            try:
                self.driver.quit()
            finally:
                self.driver = None
