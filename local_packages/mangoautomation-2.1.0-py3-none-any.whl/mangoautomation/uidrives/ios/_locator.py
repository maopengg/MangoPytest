# -*- coding: utf-8 -*-
from __future__ import annotations


class IOSLocator:
    """保留匹配集合，同时兼容元素操作所需的 WebElement 接口。"""

    def __init__(self, elements, sub=None, driver=None, by=None, value=None):
        self.driver = driver
        self.by = by
        self.value = value
        index = max(int(sub or 1) - 1, 0)
        self.index = index
        self._set_elements(elements)

    def _set_elements(self, elements):
        self.elements = list(elements)
        self.count = len(self.elements)
        self.element = self.elements[self.index] if self.index < self.count else None
        return self

    def refresh(self):
        if self.driver is not None and self.by and self.value is not None:
            self._set_elements(self.driver.find_elements(self.by, self.value))
        return self

    def require(self):
        if self.element is None:
            raise LookupError("未定位到 iOS 元素")
        return self.element

    @property
    def text(self):
        return self.require().text

    def __getattr__(self, item):
        return getattr(self.require(), item)
