# -*- coding: utf-8 -*-
from appium.webdriver.common.appiumby import AppiumBy
from mangotools.assertion import MangoAssertion

from mangoautomation.enums import ElementExpEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0017, ERROR_MSG_0020, ERROR_MSG_0030, ERROR_MSG_0031, ERROR_MSG_0048
from ._assertion import IOSAssertion
from ._element import IOSElement
from ._locator import IOSLocator


class IOSDriver(IOSElement):
    def __init__(self, base_data):
        super().__init__(base_data)

    def open_ios_app(self):
        if not self.base_data.is_open_app and self.base_data.bundle_id:
            self.base_data.ios.activate_app(self.base_data.bundle_id)
            self.base_data.is_open_app = True

    def i_action_element(self, name, ope_key, ope_value):
        method = getattr(self, ope_key, None)
        if not callable(method):
            raise MangoAutomationError(*ERROR_MSG_0048)
        return method(**(ope_value or {}))

    def i_assertion_element(self, name, ope_key, ope_value):
        assertion = IOSAssertion(self.base_data)
        method = getattr(assertion, ope_key, None)
        try:
            if callable(method):
                if 'actual' in (ope_value or {}) and ope_value.get('actual') is None:
                    raise MangoAutomationError(*ERROR_MSG_0031, value=(name,))
                return method(**(ope_value or {}))
            assertion_class = getattr(self.base_data, 'assertion_class', MangoAssertion)
            return assertion_class(self.base_data.database_result_adapter, self.base_data.test_data).ass(
                ope_key, ope_value.get('actual'), ope_value.get('expect'))
        except AssertionError as error:
            raise MangoAutomationError(*ERROR_MSG_0017, value=error.args)
        except AttributeError:
            raise MangoAutomationError(*ERROR_MSG_0030)

    def i_find_ele(self, name, _type, exp, loc, sub):
        strategies = {
            ElementExpEnum.XPATH.value: AppiumBy.XPATH,
            ElementExpEnum.IOS_ACCESSIBILITY_ID.value: AppiumBy.ACCESSIBILITY_ID,
            ElementExpEnum.IOS_PREDICATE.value: AppiumBy.IOS_PREDICATE,
            ElementExpEnum.IOS_CLASS_CHAIN.value: AppiumBy.IOS_CLASS_CHAIN,
            ElementExpEnum.IOS_CLASS_NAME.value: AppiumBy.CLASS_NAME,
        }
        by = strategies.get(exp)
        if by is None:
            raise MangoAutomationError(*ERROR_MSG_0020)
        wrapper = IOSLocator(
            self.base_data.ios.find_elements(by, loc),
            sub,
            driver=self.base_data.ios,
            by=by,
            value=loc,
        )
        text = wrapper.text if wrapper.count else None
        return wrapper, wrapper.count, text

    def i_screenshot(self, file_path):
        import os
        self.base_data.ios.save_screenshot(os.path.join(self.base_data.screenshot_path, file_path))
