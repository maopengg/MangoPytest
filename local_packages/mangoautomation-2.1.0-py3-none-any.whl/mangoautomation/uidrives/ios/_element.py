# -*- coding: utf-8 -*-
import os

from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait

from mangoautomation.models import MethodModel
from mangoautomation.tools import Meta, sync_method_callback


class IOSElement(metaclass=Meta):
    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('ios', '元素操作', '元素单击', 0, [MethodModel(f='locating')])
    def i_click(self, locating):
        locating.click()

    @sync_method_callback('ios', '元素操作', '元素输入', 1, [
        MethodModel(f='locating'), MethodModel(n='输入文本', f='text', p='请输入内容', d=True)])
    def i_input(self, locating, text):
        locating.click()
        locating.send_keys(text)

    @sync_method_callback('ios', '元素操作', '设置文本', 2, [
        MethodModel(f='locating'), MethodModel(n='设置文本', f='text', p='请输入内容', d=True)])
    def i_set_value(self, locating, text):
        locating.clear()
        locating.send_keys(text)

    @sync_method_callback('ios', '元素操作', '清空输入框', 3, [MethodModel(f='locating')])
    def i_clear(self, locating):
        locating.clear()

    @sync_method_callback('ios', '元素操作', '获取元素文本', 4, [
        MethodModel(f='locating'), MethodModel(n='缓存的key', f='set_cache_key', p='请输入缓存key', d=True)])
    def i_get_text(self, locating, set_cache_key=None):
        value = locating.text
        if set_cache_key:
            self.base_data.test_data.set_cache(set_cache_key, value)
        return value

    @sync_method_callback('ios', '元素操作', '长按元素', 5, [
        MethodModel(f='locating'), MethodModel(n='长按秒数', f='duration', p='请输入长按秒数', d=True)])
    def i_long_press(self, locating, duration=1):
        rect = locating.rect
        self.base_data.ios.execute_script('mobile: touchAndHold', {
            'x': rect['x'] + rect['width'] / 2,
            'y': rect['y'] + rect['height'] / 2,
            'duration': float(duration),
        })

    @sync_method_callback('ios', '元素操作', '等待元素出现', 6, [
        MethodModel(f='locating'), MethodModel(n='等待时间', f='time_', p='请输入秒数', d=True)])
    def i_wait(self, locating, time_):
        WebDriverWait(self.base_data.ios, float(time_)).until(
            lambda _: locating.refresh().element is not None
        )

    @sync_method_callback('ios', '元素操作', '元素截图', 7, [
        MethodModel(f='locating'), MethodModel(n='截图名称', f='file_name', p='请输入截图名称', d=True)])
    def i_element_screenshot(self, locating, file_name):
        file_path = os.path.join(self.base_data.screenshot_path, file_name)
        locating.screenshot(file_path)
        self.base_data.test_data.set_cache(file_name, file_path)

    @sync_method_callback('ios', '元素操作', '坐标单击', 8, [
        MethodModel(n='x坐标', f='x', p='请输入x坐标', d=True),
        MethodModel(n='y坐标', f='y', p='请输入y坐标', d=True)])
    def i_tap(self, x, y):
        self.base_data.ios.execute_script('mobile: tap', {'x': float(x), 'y': float(y)})

    @sync_method_callback('ios', '元素操作', '滑动页面', 9, [
        MethodModel(n='方向', f='direction', p='up/down/left/right', d=True)])
    def i_swipe(self, direction):
        self.base_data.ios.execute_script('mobile: swipe', {'direction': direction})
