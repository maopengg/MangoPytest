# -*- coding: utf-8 -*-
from mangoautomation.models import MethodModel
from mangoautomation.tools import Meta, sync_method_callback


class IOSAssertion(metaclass=Meta):
    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('ass_ios', '元素断言', '元素存在', 0, [MethodModel(f='actual')])
    def i_assert_exists(self, actual):
        assert actual.count > 0, '预期元素存在，实际未定位到元素'
        return f'实际={actual.count}, 预期=元素存在'

    @sync_method_callback('ass_ios', '元素断言', '元素不存在', 1, [MethodModel(f='actual')])
    def i_assert_not_exists(self, actual):
        assert actual.count == 0, f'实际匹配={actual.count}, 预期=元素不存在'
        return f'实际={actual.count}, 预期=元素不存在'

    @sync_method_callback('ass_ios', '元素断言', '元素计数', 2, [
        MethodModel(f='actual'), MethodModel(n='预期值', f='expect', p='请输入预期数量', d=True)])
    def i_assert_count(self, actual, expect):
        assert actual.count == int(expect), f'实际={actual.count}, 预期={expect}'
        return f'实际={actual.count}, 预期={expect}'

    @sync_method_callback('ass_ios', '元素断言', '元素文本等于', 3, [
        MethodModel(f='actual'), MethodModel(n='预期值', f='expect', p='请输入预期文本', d=True)])
    def i_assert_text(self, actual, expect):
        assert actual.text == expect, f"实际='{actual.text}', 预期='{expect}'"
        return f'实际={actual.text}, 预期={expect}'

    @sync_method_callback('ass_ios', '元素断言', '元素包含文本', 4, [
        MethodModel(f='actual'), MethodModel(n='预期值', f='expect', p='请输入预期文本', d=True)])
    def i_assert_contains_text(self, actual, expect):
        assert expect in actual.text, f"实际='{actual.text}', 预期包含='{expect}'"
        return f'实际={actual.text}, 预期包含={expect}'

    @sync_method_callback('ass_ios', '元素断言', '元素可见', 5, [MethodModel(f='actual')])
    def i_assert_visible(self, actual):
        assert actual.count > 0 and actual.is_displayed(), '预期元素可见，实际不可见'
        return '实际=可见, 预期=可见'

    @sync_method_callback('ass_ios', '元素断言', '元素可用', 6, [MethodModel(f='actual')])
    def i_assert_enabled(self, actual):
        assert actual.count > 0 and actual.is_enabled(), '预期元素可用，实际不可用'
        return '实际=可用, 预期=可用'
