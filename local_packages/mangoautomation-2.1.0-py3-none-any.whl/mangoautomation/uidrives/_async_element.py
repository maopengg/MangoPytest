# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-04-12 15:53
# @Author : 毛鹏
import asyncio
import os
import time
import traceback
import uuid
from datetime import datetime
from typing import Optional

import itertools
from playwright._impl._errors import TargetClosedError, Error

from mangoautomation.uidrives.android import AndroidDriver
from mangoautomation.uidrives._ios_optional import IOSAssertion, IOSDriver
from mangoautomation.uidrives.web import AsyncWebDevice, AsyncWebAssertion, WebElementHighlighter
from mangotools.assertion import MangoAssertion
from mangotools.enums import StatusEnum
from ..enums import ElementOperationEnum, DriveTypeEnum
from ..exceptions import MangoAutomationError
from ..exceptions.error_msg import *
from ..models import ElementResultModel, ElementModel, ElementListModel, ElementListResultModel
from ..element_healing import BaselineCapturePolicy, BaselineCollector, SnapshotRefResolver
from ..element_healing.policy.operation_rules import operation_compatibility_reason
from ..element_healing.verification.state import read_semantic_state_async
from ._element_retry_policy import DEFAULT_ELEMENT_RETRY_POLICY
from ._locator_failure import locator_failure_message


class _CallbackResultAdapter:
    """把异步数据源回调结果适配为断言库所需的结果读取接口。"""

    def __init__(self, result):
        self.result = result

    def condition_execute(self, _operation_config):
        return self.result

    def close(self):
        return None


class AsyncElement(AsyncWebDevice, AndroidDriver, IOSDriver):

    RETRY_POLICY = DEFAULT_ELEMENT_RETRY_POLICY

    def __init__(self, base_data, drive_type: int, ):
        super().__init__(base_data)
        self.drive_type = drive_type
        self.element_model: Optional[ElementModel | None] = None
        self.element_result_model: Optional[ElementResultModel | None] = None
        self.element_list_model: list[ElementModel] = []
        self.test_data = self.base_data.test_data
        self.elements = itertools.cycle([])
        self.elements_count = 0
        self.failed_expression = []
        self.__last_locator_context = None
        self.__fixed_attempt_counts = {}
        self.__background_healing_task = None
        self.__last_healing_request = None
        self.__pending_healing_result = None
        self.__defer_locator_engine = False
        self.__highlight_result = False
        self.__result_highlighted = False

    async def open_device(self, is_open: bool = False):
        self.base_data.log.debug(f'[设备打开] 设备类型: {self.drive_type}, 强制打开: {is_open}')
        if self.drive_type == DriveTypeEnum.WEB.value:
            await self.open_url(is_open)
            self.base_data.log.debug('[设备打开] Web设备已就绪')
        elif self.drive_type == DriveTypeEnum.ANDROID.value:
            self.open_app()
            self.base_data.log.debug('[设备打开] Android设备已就绪')
        elif self.drive_type == DriveTypeEnum.IOS.value:
            self.open_ios_app()
            self.base_data.log.debug('[设备打开] iOS设备已就绪')
        elif self.drive_type == DriveTypeEnum.DESKTOP.value:
            self.base_data.log.debug('[设备打开] Desktop设备已就绪')
        else:
            self.base_data.log.error(f'[设备打开失败] 不支持的设备类型: {self.drive_type}')
            raise Exception('不存在的设备类型')

    async def element_main(self,
                           element_model: ElementModel,
                           element_list_model: list[ElementModel] | None = None,
                           *,
                           highlight_result: bool = False) -> ElementResultModel:
        started_at = time.perf_counter()
        test_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.element_model = element_model
        if (
            self.drive_type == DriveTypeEnum.WEB.value
            and not self.element_model.elements
            and self.__operation_accepts_element_locator()
            and self.base_data.locator_engine
            and (self.element_model.description_template or self.element_model.name)
        ):
            self.element_model.elements = [ElementListModel(
                prompt=self.element_model.description_template or self.element_model.name,
                is_placeholder=True,
            )]
        if self.element_model and self.element_model.elements:
            self.elements = itertools.cycle(self.element_model.elements)
        self.__last_locator_context = None
        self.__fixed_attempt_counts = {
            id(item): 0 for item in (self.element_model.elements or []) if item.loc
        }
        self.__background_healing_task = None
        self.__last_healing_request = None
        self.__pending_healing_result = None
        self.__defer_locator_engine = False
        self.__highlight_result = bool(highlight_result)
        self.__result_highlighted = False
        self.element_list_model = element_list_model
        self.element_result_model = ElementResultModel(
            id=self.element_model.id,
            name=self.element_model.name,
            sleep=self.element_model.sleep,

            type=self.element_model.type.value,
            ope_key=self.element_model.ope_key,
            sql_execute=self.element_model.sql_execute,
            custom=self.element_model.custom,
            test_time=test_time,

            status=StatusEnum.FAIL.value,
        )
        
        self.base_data.log.debug(f'[元素执行] ========== 开始执行元素: {self.element_model.name} (ID: {self.element_model.id}) ==========')
        self.base_data.log.debug(f'[元素执行] 元素类型: {self.element_model.type.value}, 操作: {self.element_model.ope_key}')
        
        try:
            await self.init_element()
            await self.__execute_with_retry_policy()
            if self.element_model.sleep:
                self.base_data.log.debug(f'[元素执行] 等待 {self.element_model.sleep}秒')
                await asyncio.sleep(self.element_model.sleep)
            self.element_result_model.status = StatusEnum.SUCCESS.value
            self.element_result_model.error_message = None
            self.element_result_model.locator_engine = self.element_result_model.locator_engine or {
                'used_source': 'fixed_locator',
                'used_ai': False,
                'temporary_heal_used': False,
                'heal_record_id': None,
                'candidate_count': 0,
                'final_score': 100,
                'reject_reasons': [],
            }
            self.base_data.log.debug(f'[元素执行] ========== 元素执行成功: {self.element_model.name} ==========')
        except MangoAutomationError as error:
            self.base_data.log.debug(f'[元素执行异常] 业务异常 -> {self.element_model.name}: {error.msg}')
            await self.__error(error.msg)
        except TargetClosedError as error:
            self.base_data.setup()
            self.base_data.log.error(f'[元素执行异常] 页面已关闭 -> {self.element_model.name}')
            await self.__error(ERROR_MSG_0010[1], False)
        except Error as error:
            self.base_data.log.error(f'[元素执行异常] Playwright错误 -> {self.element_model.name}: {error.message}\n{traceback.format_exc()}')
            await self.__error(f'Playwright错误，请检查测试数据或联系管理员，提示：{error.message}')
        except Exception as error:
            error_msg = f'未知错误，请检查测试数据或联系管理员，提示：{error.args}'
            if hasattr(error, 'msg'):
                error_msg = error.msg
            self.base_data.log.error(f'[元素执行异常] 未知错误 -> {self.element_model.name}: {str(error)}\n{traceback.format_exc()}')
            await self.__error(error_msg)
        await self.__fill_runtime_snapshot(started_at)
        if self.__background_healing_task is not None:
            await self.__cancel_background_healing(discard_attempt=True)
        snapshot_id = (self.element_result_model.locator_engine or {}).get('accessibility_snapshot_id')
        if snapshot_id and self.drive_type == DriveTypeEnum.WEB.value:
            await SnapshotRefResolver.clear_async(self.base_data.page, snapshot_id)
        return self.element_result_model

    async def __execute_with_retry_policy(self):
        if self.__is_assertion_without_element_locator():
            self.base_data.log.debug(
                '[断言重试策略] 当前断言没有元素定位参数，使用断言自身等待，不进入元素自愈'
            )
            await self.__main()
            return
        self.__defer_locator_engine = True
        try:
            if not self.__healing_available():
                await self.__retry_fixed_only(self.RETRY_POLICY.fixed_retry_seconds)
                return
            await self.__retry_then_heal()
        finally:
            self.__defer_locator_engine = False

    async def __retry_then_heal(self):
        configured_locators = [item for item in self.element_model.elements if item.loc]
        retry_seconds = self.__configured_fixed_retry_seconds() if configured_locators else 0
        started = time.perf_counter()
        last_error = None
        self.base_data.log.debug(
            f'[元素重试策略] 异步模式：{len(configured_locators)} 组固定定位共用 '
            f'{retry_seconds:g} 秒，且每组至少尝试一遍；窗口结束后执行一次统一智能定位'
        )
        while True:
            try:
                return await self.__main()
            except Exception as error:
                if not self.RETRY_POLICY.should_retry(error):
                    raise
                last_error = error
            elapsed = time.perf_counter() - started
            attempt_counts = list(self.__fixed_attempt_counts.values())
            if self.RETRY_POLICY.should_finish_fixed_phase(
                    elapsed, retry_seconds, attempt_counts,
            ):
                break
            if elapsed < retry_seconds:
                await asyncio.sleep(self.RETRY_POLICY.retry_interval_seconds)

        fixed_elapsed_ms = self.__elapsed_ms(started)
        self.base_data.log.debug(
            f'[元素重试策略] 固定定位阶段结束：耗时 {fixed_elapsed_ms}ms，'
            f'各组尝试次数={list(self.__fixed_attempt_counts.values()) or []}，进入统一智能定位'
        )

        request = self.__last_healing_request
        if not request:
            raise last_error or MangoAutomationError(*ERROR_MSG_0053)
        failed_locator, find_params = request
        self.__defer_locator_engine = False
        engine_result = await self.__query_locator_engine(failed_locator, find_params, last_error)
        if not engine_result:
            last_attempt = self.__last_engine_attempt()
            if last_attempt:
                raise MangoAutomationError(
                    *ERROR_MSG_0066,
                    value=(locator_failure_message(last_attempt, self.element_model.name),),
                )
            raise last_error or MangoAutomationError(*ERROR_MSG_0053)
        metadata = engine_result.get('metadata') or {}
        metadata.update({
            'background_healing': False,
            'async_deferred_healing': True,
            'fixed_retry_attempts': list(self.__fixed_attempt_counts.values()),
            'fixed_locator_elapsed_ms': fixed_elapsed_ms,
        })
        engine_result['metadata'] = metadata
        self.__pending_healing_result = engine_result
        return await self.__main()

    def __configured_fixed_retry_seconds(self) -> float:
        runtime_config = getattr(self.base_data.locator_engine, 'runtime_config', None)
        callback = getattr(runtime_config, 'fixed_locator_retry_seconds', None)
        try:
            return max(0.0, float(callback())) if callable(callback) else 10.0
        except (TypeError, ValueError):
            return 10.0

    async def __retry_fixed_only(self, retry_seconds: float):
        started = time.perf_counter()
        while True:
            try:
                return await self.__main()
            except Exception as error:
                if not self.RETRY_POLICY.should_retry(error):
                    raise
                if time.perf_counter() - started >= retry_seconds:
                    raise
                await asyncio.sleep(self.RETRY_POLICY.retry_interval_seconds)

    async def __retry_with_background_healing(self):
        started = time.perf_counter()
        last_error = None
        self.base_data.log.debug(
            '[元素重试策略] 自愈已开启：固定定位最多重试 15 秒；'
            '执行满 5 秒且每个已配置定位组至少尝试 2 次后启动后台自愈'
        )
        while True:
            try:
                result = await self.__main()
            except Exception as error:
                if not self.RETRY_POLICY.should_retry(error):
                    await self.__cancel_background_healing(discard_attempt=True)
                    raise
                last_error = error
            else:
                await self.__cancel_background_healing(discard_attempt=True)
                return result

            elapsed = time.perf_counter() - started
            if self.__background_healing_task is None and self.__should_start_background_healing(elapsed):
                self.__start_background_healing(last_error, elapsed)
            if (elapsed >= self.RETRY_POLICY.healing_fixed_retry_seconds
                    and self.__background_healing_task is not None):
                break
            await asyncio.sleep(self.RETRY_POLICY.retry_interval_seconds)

        self.base_data.log.debug('[元素重试策略] 固定定位 15 秒仍失败，停止重试并获取后台自愈结果')
        engine_result = await self.__consume_background_healing()
        if engine_result:
            self.__pending_healing_result = engine_result
            try:
                result = await self.__main()
            except Exception:
                await self.__discard_healing_attempt()
                raise
            await self.__commit_healing_attempt()
            return result
        if last_error:
            raise last_error
        raise MangoAutomationError(*ERROR_MSG_0053)

    def __should_start_background_healing(self, elapsed: float) -> bool:
        return self.RETRY_POLICY.should_start_healing(
            elapsed, list(self.__fixed_attempt_counts.values()),
        )

    def __start_background_healing(self, error: Exception, elapsed: float):
        request = self.__last_healing_request
        if not request:
            return
        failed_locator, find_params = request
        failed_expression = list(dict.fromkeys([
            *self.failed_expression,
            *[item.loc for item in (self.element_model.elements or []) if item.loc],
        ]))
        locator_engine = self.base_data.locator_engine
        element_model = self.element_model.model_copy()
        self.base_data.log.debug(
            f'[元素后台自愈] 触发后台任务，已执行 {elapsed:.2f} 秒，'
            f'固定定位尝试次数：{list(self.__fixed_attempt_counts.values())}'
        )
        self.__background_healing_task = asyncio.create_task(
            locator_engine.locate_async(
                page=self.base_data.page,
                element_model=element_model,
                failed_locator=failed_locator,
                failed_expression=failed_expression,
                find_params=dict(find_params),
                error=error,
                speculative=True,
            ),
            name=f'element-healing-{getattr(self.element_model, "element_id", None) or self.element_model.id}',
        )

    async def __consume_background_healing(self):
        task = self.__background_healing_task
        if task is None:
            return None
        try:
            if not task.done():
                self.base_data.log.debug('[元素后台自愈] 后台任务尚未完成，等待候选结果')
            result = await task
        except asyncio.CancelledError:
            return None
        except Exception as error:
            self.base_data.log.warning(f'[元素后台自愈] 后台任务失败: {error}')
            return None
        finally:
            self.__background_healing_task = None
        element_id = getattr(self.element_model, 'element_id', None) or self.element_model.id
        if not result:
            commit = getattr(self.base_data.locator_engine, 'commit_attempt_async', None)
            if callable(commit):
                await commit(element_id)
            return None
        metadata = result.get('metadata') or {}
        metadata.update({
            'background_healing': True,
            'fixed_retry_attempts': list(self.__fixed_attempt_counts.values()),
        })
        result['metadata'] = metadata
        self.base_data.log.debug('[元素后台自愈] 已取得候选，开始在当前页面重新验证')
        revalidated = await self.base_data.locator_engine.revalidate_async(
            self.base_data.page,
            self.element_model,
            result,
            dict((self.__last_healing_request or ({}, {}))[1]),
        )
        if not revalidated:
            self.base_data.locator_engine.discard_attempt(element_id)
        return revalidated

    async def __cancel_background_healing(self, discard_attempt: bool = False):
        task = self.__background_healing_task
        self.__background_healing_task = None
        if task is not None:
            if not task.done():
                task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        if task is not None:
            await SnapshotRefResolver.clear_async(self.base_data.page)
        if discard_attempt:
            await self.__discard_healing_attempt()

    async def __commit_healing_attempt(self):
        if not self.base_data.locator_engine:
            return
        commit = getattr(self.base_data.locator_engine, 'commit_attempt_async', None)
        if callable(commit):
            await commit(getattr(self.element_model, 'element_id', None) or self.element_model.id)

    async def __discard_healing_attempt(self):
        if not self.base_data.locator_engine:
            return
        discard = getattr(self.base_data.locator_engine, 'discard_attempt', None)
        if callable(discard):
            discard(getattr(self.element_model, 'element_id', None) or self.element_model.id)

    def __healing_available(self) -> bool:
        if self.drive_type != DriveTypeEnum.WEB.value:
            return False
        if not self.base_data.locator_engine:
            return False
        enabled = getattr(self.base_data.locator_engine, 'locator_enabled', None)
        if not callable(enabled):
            return True
        try:
            return bool(enabled())
        except Exception:
            return False

    def __operation_accepts_element_locator(self) -> bool:
        if self.element_model.type in (ElementOperationEnum.OPE, ElementOperationEnum.OPE.value):
            return True
        if self.element_model.type not in (ElementOperationEnum.ASS, ElementOperationEnum.ASS.value):
            return False
        return any(
            self.__is_locator_param(item.f, True)
            for item in (self.element_model.ope_value or [])
        )

    def __is_assertion_without_element_locator(self) -> bool:
        return (
            self.element_model.type in (ElementOperationEnum.ASS, ElementOperationEnum.ASS.value)
            and not (
                self.__operation_accepts_element_locator()
                and bool(self.element_model.elements)
            )
        )

    async def __main(self):
        self.base_data.verify_equipment(self.drive_type)
        self.base_data.log.debug(f'[元素类型判断] 元素类型: {self.element_model.type}')
        
        if self.element_model.type == ElementOperationEnum.OPE:
            self.base_data.log.debug('[元素类型判断] 执行操作类型')
            await self.__ope()
        elif self.element_model.type == ElementOperationEnum.ASS:
            self.base_data.log.debug('[元素类型判断] 执行断言类型')
            await self.__ass()
        elif self.element_model.type == ElementOperationEnum.SQL:
            self.base_data.log.debug('[元素类型判断] 执行SQL类型')
            await self.__sql()
        elif self.element_model.type == ElementOperationEnum.CUSTOM:
            self.base_data.log.debug('[元素类型判断] 执行自定义类型')
            await self.__custom()
        elif self.element_model.type == ElementOperationEnum.CONDITION:
            self.base_data.log.debug('[元素类型判断] 执行条件判断类型')
            await self.__condition()
        elif self.element_model.type == ElementOperationEnum.PYTHON_CODE:
            self.base_data.log.debug('[元素类型判断] 执行Python代码类型')
            await self.__python_code()
        else:
            self.base_data.log.error(f'[元素类型判断] 不支持的元素类型: {self.element_model.type}')
            raise MangoAutomationError(*ERROR_MSG_0015)

    async def init_element(self):
        try:
            self.base_data.log.debug('[元素初始化] 开始解析元素数据')
            for i in self.element_model.elements:
                i.loc = self.base_data.test_data.replace(i.loc)
                i.sub = self.base_data.test_data.replace(i.sub)
                i.prompt = self.base_data.test_data.replace(i.prompt)
            self.element_model.name = self.base_data.test_data.replace(self.element_model.name)
            self.element_model.sleep = self.base_data.test_data.replace(self.element_model.sleep)
            self.element_result_model.sleep = self.element_model.sleep
            self.element_result_model.name = self.element_model.name
            self.base_data.log.debug('[元素初始化] 元素数据解析完成')
        except MangoAutomationError as error:
            self.base_data.log.error(f'[元素初始化失败] 数据解析失败: {error.msg}')
            raise MangoAutomationError(error.code, error.msg)

    async def __ope(self):
        method_name = getattr(self.element_model, 'ope_key', None)
        if not method_name:
            self.base_data.log.error('[操作执行] ope_key不存在或为空')
            raise MangoAutomationError(*ERROR_MSG_0048)
        if not hasattr(self, method_name):
            self.base_data.log.error(f'[操作执行] 方法不存在: {method_name}')
            raise MangoAutomationError(*ERROR_MSG_0048)
        if not callable(getattr(self, method_name)):
            self.base_data.log.error(f'[操作执行] 属性不可调用: {method_name}')
            raise MangoAutomationError(*ERROR_MSG_0048)
        
        await self.__ope_value()
        self.base_data.log.debug(f'[操作执行] 执行操作方法: {method_name}')
        
        if self.drive_type == DriveTypeEnum.WEB.value:
            try:
                await self.web_action_element(
                    self.element_model.name,
                    self.element_model.ope_key,
                    {i.f: i.v for i in self.element_model.ope_value}
                )
            except MangoAutomationError as error:
                if not await self.__retry_web_operation_with_locator_engine(error):
                    raise error
        elif self.drive_type == DriveTypeEnum.ANDROID.value:
            self.a_action_element(
                self.element_model.name,
                self.element_model.ope_key,
                {i.f: i.v for i in self.element_model.ope_value}
            )
        elif self.drive_type == DriveTypeEnum.IOS.value:
            self.i_action_element(
                self.element_model.name,
                self.element_model.ope_key,
                {i.f: i.v for i in self.element_model.ope_value}
            )
        else:
            pass
        self.element_result_model.ope_value = self.element_model.ope_value
        for i in self.element_result_model.ope_value:
            if not isinstance(i.v, str):
                i.v = str(i.v)

    async def __ass(self, _ope_value: dict | None = None):
        if self.element_model.ope_value is None:
            self.base_data.log.error('[断言执行] ope_value为空')
            raise MangoAutomationError(*ERROR_MSG_0054)
        
        await self.__ope_value(True)
        ope_value = {i.f: i.v for i in self.element_model.ope_value}
        if _ope_value is not None:
            ope_value.update(_ope_value)
        
        self.base_data.log.debug(f'[断言执行] 执行断言: {self.element_model.ope_key}')
        
        original_adapter = self.base_data.database_result_adapter
        callback_adapter_installed = False
        try:
            if (
                str(self.element_model.ope_key or '').startswith('assert_sql_')
                and self.base_data.database_execute_callback
            ):
                sql_result = await self.base_data.execute_database(
                    ope_value.get('actual'),
                    datasource_alias_id=ope_value.get('datasource_alias'),
                    source_context={
                        'source_stage': 'sql_assertion',
                        'element_id': self.element_model.id,
                        'assertion': self.element_model.ope_key,
                    },
                )
                self.base_data.database_result_adapter = _CallbackResultAdapter(sql_result)
                callback_adapter_installed = True
            if self.drive_type == DriveTypeEnum.WEB.value:
                self.element_result_model.ass_msg = await self.web_assertion_element(
                    self.element_model.name,
                    self.element_model.ope_key,
                    ope_value
                )
                await self.__refresh_assertion_locator_result()
            elif self.drive_type == DriveTypeEnum.ANDROID.value:
                self.element_result_model.ass_msg = self.a_assertion_element(
                    self.element_model.name,
                    self.element_model.ope_key,
                    ope_value
                )
            elif self.drive_type == DriveTypeEnum.IOS.value:
                self.element_result_model.ass_msg = self.i_assertion_element(
                    self.element_model.name,
                    self.element_model.ope_key,
                    ope_value
                )
            else:
                pass
        except MangoAutomationError as error:
            self.element_result_model.ass_msg = error.msg
            raise error
        finally:
            if callback_adapter_installed:
                self.base_data.database_result_adapter = original_adapter
        
        self.element_result_model.ope_value = self.element_model.ope_value
        for i in self.element_result_model.ope_value:
            if not isinstance(i.v, str):
                i.v = str(i.v)

    async def __sql(self):
        async def run(item):
            sql = item.get('sql')
            key_list = item.get('key_list')
            replaced_sql = self.base_data.test_data.replace(sql)
            self.base_data.log.debug(f'[SQL执行] 执行SQL: {replaced_sql}')
            result_list: list[dict] = await self.base_data.execute_database(
                replaced_sql,
                datasource_alias_id=item.get('datasource_alias'),
                source_context={
                    'source_stage': 'page_step_sql',
                    'element_id': self.element_model.id,
                },
            )
            self.base_data.log.debug(f'[SQL执行] SQL结果: {result_list}')
            if not isinstance(result_list, list) or not len(result_list) > 0:
                self.base_data.log.error(f'[SQL执行失败] SQL未返回有效结果')
                raise MangoAutomationError(*ERROR_MSG_0036, value=(self.element_model.sql_execute,))
            self.base_data.test_data.set_sql_cache(key_list, result_list[0])
            self.base_data.log.debug(f'[SQL执行] 结果已缓存，key: {key_list}')

        if self.base_data.database_execute_callback:
            for i in self.element_model.sql_execute:
                await run(i)
        else:
            self.base_data.log.error('[SQL执行失败] 未注入数据源执行回调')
            raise MangoAutomationError(*ERROR_MSG_0036, value=(self.element_model.sql_execute,))

    async def __custom(self):
        self.base_data.log.debug(f'[自定义变量] 开始设置 {len(self.element_model.custom)} 个自定义变量')
        for i in self.element_model.custom:
            value = self.base_data.test_data.replace(i.get('value'))
            self.base_data.log.debug(f'[自定义变量] 设置变量 -> key: {i.get("key")}, value: {value}')
            self.base_data.test_data.set_cache(i.get('key'), value)

    async def __condition(self):
        self.base_data.log.debug(f'[条件判断] 开始条件判断，共 {len(self.element_list_model)} 个分支')
        if not self.element_list_model:
            raise MangoAutomationError(*ERROR_MSG_0051)

        has_branch_value = any(i.condition_value is not None for i in self.element_list_model)
        if not has_branch_value:
            try:
                await self.__ass(None)
                self.element_result_model.next_node_id = self.element_list_model[0].id
                self.base_data.log.debug(
                    f'[条件判断] 结果为True，跳转到节点: {self.element_list_model[0].id}'
                )
                return
            except Exception:
                if len(self.element_list_model) < 2:
                    raise
                self.element_result_model.next_node_id = self.element_list_model[1].id
                self.base_data.log.debug(
                    f'[条件判断] 结果为False，跳转到节点: {self.element_list_model[1].id}'
                )
                return

        error_list = []
        default_branch = None
        for idx, i in enumerate(self.element_list_model):
            if i.condition_value is None:
                default_branch = i
                continue
            try:
                condition_value = self.base_data.test_data.replace(i.condition_value)
                self.base_data.log.debug(f'[条件判断] 分支[{idx}] 条件: {condition_value}')
                await self.__ass(condition_value)
                self.element_result_model.next_node_id = i.id
                self.base_data.log.debug(f'[条件判断] 分支[{idx}]匹配成功，跳转到节点: {i.id}')
                return
            except Exception as error:
                self.base_data.log.debug(f'[条件判断] 分支[{idx}]不匹配: {str(error)}')
                error_list.append(error)

        if default_branch is not None:
            self.element_result_model.next_node_id = default_branch.id
            self.base_data.log.debug(f'[条件判断] 默认分支，跳转到节点: {default_branch.id}')
            return
        self.base_data.log.error('[条件判断失败] 所有分支都不匹配')
        if error_list:
            raise error_list[0]
        raise MangoAutomationError(*ERROR_MSG_0051)

    async def __python_code(self):
        self.base_data.log.debug(f'[Python代码] 开始执行自定义Python函数')
        self.base_data.log.debug(f'[Python代码] 函数代码:\n{self.element_model.func}')
        global_namespace = {}
        exec(self.element_model.func, global_namespace)
        global_namespace['func'](self)
        self.base_data.log.debug('[Python代码] 函数执行完成')

    async def __ope_value(self, is_ass: bool = False):
        try:
            self.base_data.log.debug(f'[操作值获取] 获取{"断言" if is_ass else "定位"}值')
            for i in self.element_model.ope_value:
                if self.__is_locator_param(i.f, is_ass) and self.element_model.elements:
                    await self.query_element(i, is_ass)
                else:
                    i.v = self.base_data.test_data.replace(i.v)
        except AttributeError as error:
            self.base_data.log.error(f'[操作值获取失败] 属性错误: {str(error)}\n{traceback.format_exc()}')
            raise MangoAutomationError(*ERROR_MSG_0027)

    async def query_element(self, i, is_ass):
        random_element = next(self.elements)
        self.elements_count += 1
        locate_started_at = time.perf_counter()
        find_params = {
            'name': self.element_model.name,
            '_type': self.element_model.type,
            'exp': random_element.exp,
            'loc': random_element.loc,
            'sub': random_element.sub
        }
        engine_find_params = {**find_params, 'ope_key': getattr(self.element_model, 'ope_key', None)}
        loc_text = random_element.loc
        result_exp = random_element.exp
        result_loc = random_element.loc
        result_sub = random_element.sub
        result_is_iframe = random_element.is_iframe
        
        self.base_data.log.debug(f'[元素定位] 尝试定位元素 (第{self.elements_count}次): {random_element.loc}')

        engine_result = self.__pending_healing_result
        if engine_result:
            self.__pending_healing_result = None
            loc = engine_result['locator']
            loc_text = engine_result.get('loc') or loc_text
            result_exp = engine_result.get('exp', result_exp)
            result_loc = engine_result.get('loc', result_loc)
            result_sub = engine_result.get('sub', result_sub)
            result_is_iframe = engine_result.get('is_iframe', 0)
            ele_quantity = engine_result.get('count') or 0
            element_text = engine_result.get('text')
            locate_duration_ms = self.__elapsed_ms(locate_started_at)
            self.element_result_model.locator_engine = engine_result.get('metadata') or {}
            self.base_data.log.debug(f'[元素后台自愈] 使用重新验证通过的定位器: {loc_text}')
        else:
            locator_key = id(random_element)
            if locator_key in self.__fixed_attempt_counts:
                self.__fixed_attempt_counts[locator_key] += 1
            self.__last_healing_request = (random_element, dict(engine_find_params))
            try:
                if self.drive_type == DriveTypeEnum.WEB.value:
                    if getattr(random_element, 'is_placeholder', False) or (
                            getattr(random_element, 'exp', None) is None
                            and not getattr(random_element, 'loc', None)):
                        raise MangoAutomationError(*ERROR_MSG_0053)
                    loc, ele_quantity, element_text = await self.web_find_element(
                        **find_params, is_iframe=random_element.is_iframe,
                    )
                elif self.drive_type == DriveTypeEnum.ANDROID.value:
                    loc, ele_quantity, element_text = self.a_find_ele(**find_params)
                elif self.drive_type == DriveTypeEnum.IOS.value:
                    loc, ele_quantity, element_text = self.i_find_ele(**find_params)
                else:
                    loc, ele_quantity, element_text = None, 0, None
                locate_duration_ms = self.__elapsed_ms(locate_started_at)
            except MangoAutomationError as e:
                if not self.base_data.is_ai and not self.base_data.locator_engine:
                    raise e
                if self.elements_count < len(self.element_model.elements):
                    raise e
                self.failed_expression.append(find_params.get('loc'))
                self.elements_count = 0
                engine_result = await self.__query_locator_engine(random_element, engine_find_params, e)
                if engine_result:
                    loc = engine_result['locator']
                    loc_text = engine_result.get('loc') or loc_text
                    result_exp = engine_result.get('exp', result_exp)
                    result_loc = engine_result.get('loc', result_loc)
                    result_sub = engine_result.get('sub', result_sub)
                    result_is_iframe = engine_result.get('is_iframe', 0)
                    ele_quantity = engine_result.get('count') or 0
                    element_text = engine_result.get('text')
                    locate_duration_ms = self.__elapsed_ms(locate_started_at)
                    self.element_result_model.locator_engine = engine_result.get('metadata') or {}
                    self.base_data.log.debug(f'[统一定位引擎] 定位成功: {loc_text}')
                else:
                    last_attempt = self.__last_engine_attempt()
                    self.element_result_model.locator_engine = (
                        last_attempt or self.element_result_model.locator_engine
                    )
                    if last_attempt:
                        raise MangoAutomationError(
                            *ERROR_MSG_0066,
                            value=(locator_failure_message(last_attempt, self.element_model.name),),
                        )
                    raise e

        await self.__record_element_result(
            loc,
            result_exp,
            result_loc,
            result_sub,
            ele_quantity,
            element_text,
            locate_duration_ms,
            result_is_iframe,
        )

        requires_resolved_element = (
            self.element_model.type in (ElementOperationEnum.OPE, ElementOperationEnum.OPE.value)
            or (is_ass and callable(getattr(MangoAssertion(), self.element_model.ope_key, None)))
        )
        if ele_quantity < 1 and requires_resolved_element:
            if self.base_data.locator_engine and self.elements_count >= len(self.element_model.elements):
                self.failed_expression.append(find_params.get('loc'))
                engine_result = await self.__query_locator_engine(
                    random_element,
                    engine_find_params,
                    MangoAutomationError(*ERROR_MSG_0053)
                )
                if engine_result:
                    loc = engine_result['locator']
                    loc_text = engine_result.get('loc') or loc_text
                    result_exp = engine_result.get('exp', result_exp)
                    result_loc = engine_result.get('loc', result_loc)
                    result_sub = engine_result.get('sub', result_sub)
                    result_is_iframe = engine_result.get('is_iframe', 0)
                    ele_quantity = engine_result.get('count') or 0
                    element_text = engine_result.get('text')
                    locate_duration_ms = self.__elapsed_ms(locate_started_at)
                    self.element_result_model.locator_engine = engine_result.get('metadata') or {}
                    self.base_data.log.debug(f'[统一定位引擎] 零匹配后定位成功: {loc_text}')
                else:
                    self.element_result_model.locator_engine = self.__last_engine_attempt() or self.element_result_model.locator_engine

        if self.__should_refine_ambiguous_locator(ele_quantity, result_sub):
            self.failed_expression.append(find_params.get('loc'))
            engine_result = await self.__query_locator_engine(
                random_element,
                engine_find_params,
                MangoAutomationError(*ERROR_MSG_0032, value=(self.element_model.name,))
            )
            if engine_result:
                loc = engine_result['locator']
                loc_text = engine_result.get('loc') or loc_text
                result_exp = engine_result.get('exp', result_exp)
                result_loc = engine_result.get('loc', result_loc)
                result_sub = engine_result.get('sub', result_sub)
                result_is_iframe = engine_result.get('is_iframe', 0)
                ele_quantity = engine_result.get('count') or 0
                element_text = engine_result.get('text')
                locate_duration_ms = self.__elapsed_ms(locate_started_at)
                self.element_result_model.locator_engine = engine_result.get('metadata') or {}
                self.base_data.log.debug(f'[统一定位引擎] 多匹配定位已收敛: {loc_text}')
            else:
                self.element_result_model.locator_engine = self.__last_engine_attempt() or self.element_result_model.locator_engine
                raise MangoAutomationError(*ERROR_MSG_0032, value=(self.element_model.name,))

        # Engine results already passed uniqueness, actionability, semantics and
        # consecutive validation. Running fixed-locator prechecks again can reject
        # a valid healed input whose visible text is empty.
        fixed_actionability_error = (
            None if engine_result
            else await self.__fixed_locator_actionability_error(loc, ele_quantity)
        )
        if fixed_actionability_error:
            self.failed_expression.append(find_params.get('loc'))
            self.base_data.log.debug(f'[统一定位引擎] 固定定位可操作性预检失败，尝试自愈: {fixed_actionability_error}')
            engine_result = await self.__query_locator_engine(
                random_element,
                engine_find_params,
                MangoAutomationError(*ERROR_MSG_0032, value=(self.element_model.name,))
            )
            if engine_result:
                loc = engine_result['locator']
                loc_text = engine_result.get('loc') or loc_text
                result_exp = engine_result.get('exp', result_exp)
                result_loc = engine_result.get('loc', result_loc)
                result_sub = engine_result.get('sub', result_sub)
                result_is_iframe = engine_result.get('is_iframe', 0)
                ele_quantity = engine_result.get('count') or 0
                element_text = engine_result.get('text')
                locate_duration_ms = self.__elapsed_ms(locate_started_at)
                self.element_result_model.locator_engine = engine_result.get('metadata') or {}
                self.base_data.log.debug(f'[统一定位引擎] 固定定位可操作性自愈成功: {loc_text}')
            else:
                self.element_result_model.locator_engine = self.__last_engine_attempt() or self.element_result_model.locator_engine
                raise MangoAutomationError(*ERROR_MSG_0032, value=(self.element_model.name,))

        if loc_text not in self.failed_expression:
            self.failed_expression.append(loc_text)

        element_text = await self.__record_element_result(
            loc,
            result_exp,
            result_loc,
            result_sub,
            ele_quantity,
            element_text,
            locate_duration_ms,
            result_is_iframe,
            collect_state=True,
        )
        
        if ele_quantity < 1 and requires_resolved_element:
            self.base_data.log.debug(f'[元素定位未命中] 未找到元素: {random_element.loc}')
            last_attempt = self.__last_engine_attempt()
            if last_attempt:
                self.element_result_model.locator_engine = last_attempt
                raise MangoAutomationError(
                    *ERROR_MSG_0066,
                    value=(locator_failure_message(last_attempt, self.element_model.name),),
                )
            raise MangoAutomationError(*ERROR_MSG_0053)

        if (
            self.drive_type == DriveTypeEnum.WEB.value
            and self.__highlight_result
            and not self.__result_highlighted
            and ele_quantity > 0
        ):
            try:
                highlighted_count = await WebElementHighlighter.highlight_async(loc, result_loc)
                self.__result_highlighted = highlighted_count > 0
                metadata = self.element_result_model.locator_engine or {}
                metadata.update({
                    'highlighted': self.__result_highlighted,
                    'highlighted_count': highlighted_count,
                })
                self.element_result_model.locator_engine = metadata
            except Exception as highlight_error:
                metadata = self.element_result_model.locator_engine or {}
                metadata.update({
                    'highlighted': False,
                    'highlight_error': str(highlight_error)[:200],
                })
                self.element_result_model.locator_engine = metadata

        await self.__freeze_baseline_snapshot(
            loc, result_exp, result_loc, result_sub, ele_quantity, element_text,
        )
        
        self.__last_locator_context = {
            'random_element': random_element,
            'find_params': engine_find_params,
            'loc_text': loc_text,
            'result_exp': result_exp,
            'result_loc': result_loc,
            'result_sub': result_sub,
            'result_is_iframe': result_is_iframe,
            'locator': loc,
            'locate_duration_ms': locate_duration_ms,
        }
        if is_ass:
            if (
                callable(getattr(AsyncWebAssertion, self.element_model.ope_key, None))
                or (
                    self.drive_type == DriveTypeEnum.IOS.value
                    and callable(getattr(IOSAssertion, self.element_model.ope_key, None))
                )
            ):
                i.v = loc
            elif callable(getattr(MangoAssertion(), self.element_model.ope_key, None)):
                i.v = element_text
        else:
            i.v = loc

    async def __refresh_assertion_locator_result(self):
        context = self.__last_locator_context
        if self.drive_type != DriveTypeEnum.WEB.value or not context:
            return
        locator = context.get('locator')
        if locator is None:
            return
        try:
            count = await locator.count()
        except Exception:
            return
        await self.__record_element_result(
            locator,
            context['result_exp'],
            context['result_loc'],
            context['result_sub'],
            count,
            None,
            context.get('locate_duration_ms'),
            context['result_is_iframe'],
            collect_state=True,
        )

    async def __record_element_result(
            self, loc, exp, loc_text, sub, count, element_text,
            locate_duration_ms, is_iframe, collect_state=False):
        element_state = {}
        if collect_state:
            element_state = await self.__collect_element_state(loc, element_text)
            element_text = element_text or element_state.get('element_text')
        existing = next((
            item for item in self.element_result_model.elements
            if item.exp == exp
            and item.loc == loc_text
            and item.sub == sub
            and item.is_iframe == is_iframe
        ), None)
        values = {
            'ele_quantity': count,
            'element_text': element_text,
            'locate_duration_ms': locate_duration_ms,
        }
        if collect_state:
            values.update({
                'text_snippets': element_state.get('text_snippets') or [],
                'visible': element_state.get('visible'),
                'enabled': element_state.get('enabled'),
                'editable': element_state.get('editable'),
                'bounding_box': element_state.get('bounding_box'),
            })
        if existing:
            for key, value in values.items():
                setattr(existing, key, value)
        else:
            self.element_result_model.elements.append(ElementListResultModel(
                exp=exp,
                loc=loc_text,
                sub=sub,
                is_iframe=is_iframe,
                **values,
            ))
        return element_text

    async def __freeze_baseline_snapshot(self, loc, exp, loc_text, sub, count, element_text):
        if self.drive_type != DriveTypeEnum.WEB.value:
            return
        metadata = self.element_result_model.locator_engine or {}
        if not BaselineCapturePolicy.should_capture(self.element_model, metadata):
            return
        snapshot = await BaselineCollector.freeze_async(self.base_data.page, loc)
        if not snapshot:
            metadata['baseline_capture_failed'] = True
            self.element_result_model.locator_engine = metadata
            return
        snapshot.update({
            'exp': exp,
            'loc': loc_text,
            'sub': sub,
            'match_count': count,
            'element_text': element_text,
        })
        self.element_result_model._baseline_snapshot = snapshot
        metadata['baseline_capture_failed'] = False
        self.element_result_model.locator_engine = metadata

    async def __retry_web_operation_with_locator_engine(self, error: MangoAutomationError) -> bool:
        if not self.__operation_error_can_heal(error):
            self.base_data.log.debug(f'[统一定位引擎] 操作失败属于业务失败或不可自愈错误，跳过自愈: {error.msg}')
            return False
        if self.drive_type != DriveTypeEnum.WEB.value or not self.base_data.locator_engine:
            return False
        if not self.__last_locator_context:
            return False
        self.base_data.log.debug(
            f'[统一定位引擎] 操作失败后尝试自愈，元素：{self.element_model.name}，'
            f'操作：{self.element_model.ope_key}，错误：{error.msg}'
        )
        failed_loc = self.__last_locator_context.get('loc_text')
        if failed_loc and failed_loc not in self.failed_expression:
            self.failed_expression.append(failed_loc)
        engine_result = await self.__query_locator_engine(
            self.__last_locator_context['random_element'],
            self.__last_locator_context['find_params'],
            error,
        )
        if not engine_result:
            self.element_result_model.locator_engine = self.__last_engine_attempt() or self.element_result_model.locator_engine
            return False
        locator = engine_result['locator']
        for item in self.element_model.ope_value:
            if self.__is_locator_param(item.f, False):
                item.v = locator
        self.element_result_model.locator_engine = engine_result.get('metadata') or {}
        self.base_data.log.debug(
            f"[统一定位引擎] 操作失败自愈命中，使用候选重试操作：{engine_result.get('loc')}"
        )
        await self.web_action_element(
            self.element_model.name,
            self.element_model.ope_key,
            {i.f: i.v for i in self.element_model.ope_value}
        )
        return True

    @staticmethod
    def __operation_error_can_heal(error: MangoAutomationError) -> bool:
        message = getattr(error, 'msg', '') or ''
        if '业务上传失败' in message:
            return False
        if 'Request failed with status code' in message:
            return False
        return getattr(error, 'code', None) in {4011, 4024, 4032, 4052}

    def __should_refine_ambiguous_locator(self, ele_quantity, sub):
        if self.drive_type != DriveTypeEnum.WEB.value or not self.base_data.locator_engine:
            return False
        if self.element_model.type not in (ElementOperationEnum.OPE, ElementOperationEnum.OPE.value):
            return False
        if getattr(self.element_model, 'ope_key', None) == 'w_many_click':
            return False
        if sub not in (None, '', 0):
            return False
        try:
            return int(ele_quantity or 0) > 1
        except (TypeError, ValueError):
            return False

    async def __fixed_locator_actionability_error(self, loc, ele_quantity):
        if self.drive_type != DriveTypeEnum.WEB.value or not self.base_data.locator_engine:
            return None
        if self.element_model.type not in (ElementOperationEnum.OPE, ElementOperationEnum.OPE.value):
            return None
        if loc is None:
            return None
        try:
            if int(ele_quantity or 0) < 1:
                return None
        except (TypeError, ValueError):
            return None
        ope_key = getattr(self.element_model, 'ope_key', None)
        try:
            semantic_state = await read_semantic_state_async(loc.first)
            compatibility_error = operation_compatibility_reason(
                semantic_state,
                {'ope_key': ope_key},
            )
            if compatibility_error:
                return compatibility_error
            if ope_key in self.__click_action_keys():
                await loc.first.click(trial=True, timeout=1200)
            elif ope_key in self.__editable_action_keys():
                target = loc.first
                if not await target.is_enabled():
                    return 'fixed locator is disabled'
                if not await target.is_editable():
                    return 'fixed locator is not editable'
            else:
                return None
        except Exception as error:
            return str(getattr(error, 'message', None) or error)[:240]
        return None

    @staticmethod
    def __click_action_keys():
        return {
            'w_click', 'w_force_click', 'w_dblclick', 'w_many_click', 'w_right_click', 'w_time_click',
            'w_check', 'w_uncheck', 'w_set_checked', 'w_tap', 'w_download',
        }

    @staticmethod
    def __editable_action_keys():
        return {
            'w_input', 'w_clear_input', 'w_clear', 'w_type', 'w_press_sequentially',
        }

    async def __query_locator_engine(self, random_element, find_params, error):
        if self.drive_type != DriveTypeEnum.WEB.value:
            return None
        locator_engine = self.base_data.locator_engine
        if not locator_engine:
            return None
        self.__last_healing_request = (random_element, dict(find_params or {}))
        if self.__defer_locator_engine:
            return None
        try:
            self.base_data.log.debug(
                f"[统一定位引擎] 开始尝试自愈，元素：{self.element_model.name}，"
                f"失败定位：{getattr(random_element, 'loc', None)}，操作：{find_params.get('ope_key')}"
            )
            result = await locator_engine.locate_async(
                page=self.base_data.page,
                element_model=self.element_model,
                failed_locator=random_element,
                failed_expression=list(self.failed_expression),
                find_params=find_params,
                error=error,
            )
            if not result:
                last_attempt = self.__last_engine_attempt()
                self.base_data.log.debug(
                    f"[统一定位引擎] 未产出可用候选，元素：{self.element_model.name}，"
                    f"最近尝试：{last_attempt}"
                )
            return result
        except Exception as engine_error:
            self.base_data.log.warning(f'[统一定位引擎] 定位失败，继续原兜底逻辑: {engine_error}')
            return None

    def __last_engine_attempt(self):
        locator_engine = self.base_data.locator_engine
        getter = getattr(locator_engine, 'get_last_attempt', None) if locator_engine else None
        if callable(getter):
            return getter(getattr(self.element_model, 'element_id', None) or self.element_model.id)
        return {}

    @staticmethod
    def __is_locator_param(field_name, is_ass: bool) -> bool:
        if is_ass:
            return field_name == 'actual'
        return str(field_name or '').startswith('locating')

    @staticmethod
    def __elapsed_ms(started_at: float) -> int:
        return max(0, int((time.perf_counter() - started_at) * 1000))

    @staticmethod
    def __truncate_text(value, max_length: int = 160) -> str | None:
        if value is None:
            return None
        text = str(value).strip()
        if not text:
            return None
        return text if len(text) <= max_length else f'{text[:max_length]}...'

    @staticmethod
    def __normalize_bounding_box(box):
        if not isinstance(box, dict):
            return None
        return {
            key: round(value, 2) if isinstance(value, (int, float)) else value
            for key, value in box.items()
            if key in {'x', 'y', 'width', 'height'}
        }

    async def __collect_element_state(self, loc, element_text) -> dict:
        state = {
            'text_snippets': [],
            'visible': None,
            'enabled': None,
            'editable': None,
            'bounding_box': None,
            'element_text': None,
        }
        if loc is None:
            return state

        if self.drive_type == DriveTypeEnum.IOS.value:
            text = self.__truncate_text(element_text)
            if text:
                state['element_text'] = text
                state['text_snippets'] = [text]
            try:
                state['visible'] = loc.is_displayed()
            except Exception:
                pass
            try:
                state['enabled'] = loc.is_enabled()
            except Exception:
                pass
            try:
                element = loc.require()
                state['editable'] = str(element.get_attribute('type') or '').lower() in {
                    'xcuielementtypetextfield',
                    'xcuielementtypesecuretextfield',
                    'xcuielementtypetextview',
                }
                state['bounding_box'] = self.__normalize_bounding_box(element.rect)
            except Exception:
                pass
            return state

        if self.drive_type != DriveTypeEnum.WEB.value:
            return state

        text = self.__truncate_text(element_text)
        if not text:
            try:
                text = self.__truncate_text(await self._read_text(loc))
            except Exception:
                text = None
        if text:
            state['element_text'] = text
            state['text_snippets'] = [text]

        try:
            state['visible'] = await loc.is_visible(timeout=500)
        except Exception:
            pass
        try:
            state['enabled'] = await loc.is_enabled(timeout=500)
        except Exception:
            pass
        try:
            state['editable'] = await loc.is_editable(timeout=500)
        except Exception:
            pass
        try:
            state['bounding_box'] = self.__normalize_bounding_box(await loc.bounding_box(timeout=500))
        except Exception:
            pass
        return state

    async def __fill_runtime_snapshot(self, started_at: float):
        if not self.element_result_model:
            return
        self.element_result_model.stop_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.element_result_model.duration_ms = self.__elapsed_ms(started_at)
        if self.drive_type != DriveTypeEnum.WEB.value:
            return
        page = getattr(self.base_data, 'page', None)
        if page is None:
            return
        try:
            self.element_result_model.page_url = page.url
        except Exception:
            pass
        try:
            self.element_result_model.page_title = await page.title()
        except Exception:
            pass
        try:
            self.element_result_model.viewport = page.viewport_size
        except Exception:
            pass

    async def __error(self, msg: str, is_screenshot: bool = True):
        try:
            self.element_result_model.status = StatusEnum.FAIL.value
            self.element_result_model.error_message = msg
            self.base_data.log.warning(f'[元素执行未通过] 元素: {self.element_model.name}')
            self.base_data.log.warning(f'[元素执行未通过] 原因: {msg}')
            self.base_data.log.debug(f'[元素执行失败] 元素详情: {self.element_model.model_dump() if self.element_model else None}')
            
            if is_screenshot:
                safe_name = ''.join(
                    char if char.isalnum() or char in ('-', '_') else '_'
                    for char in str(self.element_model.name or '未知元素')
                )
                file_name = f'失败截图-{safe_name}-{uuid.uuid4().hex}.jpg'
                self.base_data.log.debug(f'[失败截图] 开始截图: {file_name}')
                await self.__error_screenshot(file_name)
                self.element_result_model.picture_path = os.path.join(self.base_data.screenshot_path, file_name)
                self.element_result_model.picture_name = file_name
                self.base_data.log.debug(f'[失败截图] 截图已保存: {file_name}')
        except MangoAutomationError as error:
            self.element_result_model.error_message += f'，截图失败: {error.msg}'
            self.base_data.log.error(f'[失败截图] 截图失败: {error.msg}')
        except Exception as error:
            self.base_data.log.error(f'[失败截图] 截图异常: {str(error)}\n{traceback.format_exc()}')

    async def __error_screenshot(self, file_path):
        if self.drive_type == DriveTypeEnum.WEB.value:
            await self.w_screenshot(file_path)
        elif self.drive_type == DriveTypeEnum.ANDROID.value:
            self.a_screenshot(file_path)
        elif self.drive_type == DriveTypeEnum.IOS.value:
            self.i_screenshot(file_path)
        else:
            self.base_data.log.debug(f'[失败截图] 设备类型 {self.drive_type} 不支持截图')
