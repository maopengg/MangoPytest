# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2023-09-09 23:17
# @Author : 毛鹏
from uiautomator2 import UiObject

from mangoautomation.tools import Meta
from mangoautomation.models import MethodModel
from mangoautomation.tools import sync_method_callback


class AndroidAssertion(metaclass=Meta):
    """元素断言"""

    def __init__(self, base_data):
        self.base_data = base_data

    @sync_method_callback('ass_android', '元素断言', '元素存在', 1, [
        MethodModel(f='actual')])
    def a_assert_ele_exists(self, actual):
        """元素存在"""
        assert actual.count, f'实际={actual.count}, 预期=元素存在'
        return f'实际={actual.count}, 预期=元素存在'

    @sync_method_callback('ass_android', '元素断言', '元素计数', 2, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入预期内容', d=True)])
    def a_assert_ele_count(self, actual, expect):
        """元素计数"""
        assert int(actual.count) == int(expect), f'实际={actual.count}, 预期={expect}'
        return f'实际={actual.count}, 预期={expect}'

    @sync_method_callback('ass_android', '元素断言', '元素文本内容', 3, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入预期文本', d=True)])
    def a_assert_ele_text(self, actual, expect):
        """元素文本内容"""
        assert actual.get_text() == expect, f"实际='{actual.get_text()}', 预期='{expect}'"
        return f'实际={actual.get_text()}, 预期={expect}'

    @sync_method_callback('ass_android', '元素断言', '元素可点击', 4, [
        MethodModel(f='actual')])
    def a_assert_ele_clickable_true(self, actual):
        """元素可点击"""
        assert actual.info['clickable'], f"实际={actual.info['clickable']}, 预期=可点击"
        return f"实际={actual.info['clickable']}, 预期=可点击"

    @sync_method_callback('ass_android', '元素断言', '元素不可点击', 5, [
        MethodModel(f='actual')])
    def a_assert_ele_clickable_false(self, actual):
        """元素不可点击"""
        assert not actual.info['clickable'], f"实际={actual.info['clickable']}, 预期=元素不可点击"
        return f"实际={actual.info['clickable']}, 预期=元素不可点击"

    @sync_method_callback('ass_android', '元素断言', '元素可见', 6, [
        MethodModel(f='actual')])
    def a_assert_ele_visible_true(self, actual):
        """元素可见"""
        assert actual.exists and actual.info['visible'], f"实际={actual.info['visible']}, 预期=元素可见"

        return f"实际={actual.info['visible']}, 预期=元素可见"

    @sync_method_callback('ass_android', '元素断言', '元素不可见', 7, [
        MethodModel(f='actual')])
    def a_assert_ele_visible_false(self, actual):
        """元素不可见"""
        assert actual.exists and not actual.info['visible'], f"实际={actual.info['visible']}, 预期=元素不可见"
        return f"实际={actual.info['visible']}, 预期=元素不可见"

    @sync_method_callback('ass_android', '元素断言', '弹窗存在', 8, [
        MethodModel(n='预期值', f='expect', p='请输入弹窗标题文本', d=False)])
    def a_assert_dialog_exists(self, expect):
        """弹窗存在"""
        dialog = self.base_data.android(text=expect) if expect else self.base_data.android(
            className="android.app.AlertDialog")
        assert dialog.exists, "未找到预期弹窗"
        return f"实际={dialog.exists}, 预期=弹窗存在"

    @sync_method_callback('ass_android', '元素断言', '列表滑动后目标元素存在', 9, [
        MethodModel(f='actual'),
        MethodModel(n='预期值', f='expect', p='请输入断言目标文本', d=True)])
    def a_assert_ele_in_list(self, actual, expect):
        """列表滑动后目标元素存在"""
        if not actual.exists:
            raise AssertionError("传入的元素不是可滑动的列表")
        actual.scroll.vert.to(text=expect)
        assert self.base_data.android(text=expect).exists, f"列表中未找到文本: {expect}"
        return f"实际={self.base_data.android(text=expect).exists}, 预期={expect}"
