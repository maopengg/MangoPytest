# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: # @Time   : 2023-07-15 11:57
# @Author : 毛鹏

from .context import AutomationContext, BaseData
from .factories import AndroidDriverFactory, WebDriverFactory, WindowsDriverFactory
from .runtime import AndroidRuntime, AsyncWebRuntime, DesktopRuntime, SyncWebRuntime
from .web import AsyncWebDevice, AsyncWebCustomization, SyncWebDevice, SyncWebCustomization
from ..uidrives._async_element import AsyncElement
from ..uidrives._sync_element import SyncElement

__all__ = [
    'AutomationContext',
    'BaseData',
    'AndroidDriverFactory',
    'AndroidRuntime',
    'IOSDriverFactory',
    'IOSRuntime',
    'AsyncElement',
    'AsyncWebRuntime',
    'SyncElement',
    'SyncWebRuntime',
    'DesktopRuntime',
    'WebDriverFactory',
    'WindowsDriverFactory',
    'AsyncWebDevice',
    'SyncWebDevice',
    'AsyncWebCustomization',
    'SyncWebCustomization',
]


def __getattr__(name):
    if name == 'IOSDriverFactory':
        from .factories.ios_factory import IOSDriverFactory

        return IOSDriverFactory
    if name == 'IOSRuntime':
        from .runtime.ios_runtime import IOSRuntime

        return IOSRuntime
    raise AttributeError(name)
