# -*- coding: utf-8 -*-
import ast
import json

from pydantic import ValidationError

from .models import StepRepairPlan
from .prompt import PageStepHealingPrompt


class StepHealingResponseError(ValueError):
    pass


class StepHealingPlanner:
    def __init__(self, model_client):
        self.model_client = model_client

    @property
    def available(self) -> bool:
        return bool(self.model_client and getattr(self.model_client, 'available', True))

    async def plan_async(self, context: dict, snapshot, *, repair_on_error: bool = True) -> StepRepairPlan:
        if not self.available:
            raise StepHealingResponseError('AI模型未配置，无法执行页面步骤自愈')
        messages = PageStepHealingPrompt.messages(context, snapshot)
        content = await self.model_client.complete_async(
            messages,
            # The plan is deliberately small. A bounded output budget keeps
            # reasoning gateways from spending the whole workflow timeout.
            max_tokens=1024,
            temperature=0,
            # Page-step healing runs against multiple OpenAI-compatible gateways.
            # Some accept json_schema without rejecting it but never complete the
            # request. Ask for a JSON object and enforce the full schema locally.
            response_format=StepRepairPlan.openai_json_object_response_format(),
        )
        try:
            return self.parse(content)
        except StepHealingResponseError:
            if not repair_on_error:
                raise
            repaired = await self.model_client.complete_async(
                [
                    *messages,
                    {'role': 'assistant', 'content': str(content or '')},
                    {
                        'role': 'user',
                        'content': PageStepHealingPrompt.schema_repair_message(),
                    },
                ],
                max_tokens=3200,
                temperature=0,
                response_format=StepRepairPlan.openai_json_object_response_format(),
            )
            return self.parse(repaired)

    @classmethod
    def parse(cls, content: str) -> StepRepairPlan:
        text = str(content or '').strip()
        try:
            return StepRepairPlan.model_validate_json(text)
        except ValidationError:
            pass
        value = cls._extract_json(text)
        value = cls._unwrap_plan(value)
        try:
            return StepRepairPlan.model_validate(value)
        except ValidationError as error:
            details = ', '.join(
                f'{".".join(str(part) for part in item.get("loc") or ())}:{item.get("type")}'
                for item in error.errors(include_input=False)[:8]
            )
            raise StepHealingResponseError(f'步骤自愈响应不符合协议：{details}') from None

    @staticmethod
    def _unwrap_plan(value: dict) -> dict:
        """Accept harmless provider envelopes without inventing required plan metadata."""
        for key in ('plan', 'repair_plan', 'result'):
            nested = value.get(key)
            if isinstance(nested, dict):
                return nested
        return value

    @staticmethod
    def _extract_json(content: str):
        decoder = json.JSONDecoder()
        for index, char in enumerate(content):
            if char not in '{[':
                continue
            try:
                value, _ = decoder.raw_decode(content[index:])
            except json.JSONDecodeError:
                try:
                    value = ast.literal_eval(content[index:])
                except (SyntaxError, ValueError):
                    continue
            if isinstance(value, dict):
                return value
        raise StepHealingResponseError('步骤自愈响应不是有效JSON')
