# -*- coding: utf-8 -*-
from .models import StepHealingPolicy, StepRepairPlan


HIGH_RISK_OPERATION_FRAGMENTS = {
    'delete', 'remove', 'publish', 'submit', 'approve', 'reject', 'payment', 'pay', 'upload',
    '删除', '发布', '提交', '审批', '驳回', '支付', '上传',
}
NON_SKIPPABLE_NODE_TYPES = {1, 2, 5}


class StepRepairRejected(ValueError):
    pass


class StepRepairGuard:
    @classmethod
    def validate(
        cls,
        plan: StepRepairPlan,
        *,
        policy: StepHealingPolicy,
        current_node_id: str,
        node_map: dict[str, dict],
        matched_checkpoints: set[str],
        available_data: set[str],
        snapshot,
        trusted_text_sources: list[str] | None = None,
        allow_replaced_current_node_skip: bool = False,
    ) -> StepRepairPlan:
        if len(plan.actions) > policy.max_patch_actions:
            raise StepRepairRejected('AI建议的恢复动作超过本步骤安全上限')
        if not plan.actions:
            raise StepRepairRejected('AI没有返回可执行的恢复动作')
        refs = {node.ref for node in snapshot.nodes}
        ref_nodes = {node.ref: node for node in snapshot.nodes}
        for item in plan.actions:
            if item.action != 'abort' and item.action not in policy.allowed_actions:
                raise StepRepairRejected(f'恢复动作 {item.action} 未被当前策略允许')
            if item.target_ref and item.target_ref not in refs:
                raise StepRepairRejected(f'页面快照中不存在目标 {item.target_ref}')
            if item.target_ref:
                target = ref_nodes[item.target_ref]
                target_text = ' '.join(str(getattr(target, key, '') or '') for key in ('name', 'text', 'label')).lower()
                if any(value in target_text for value in HIGH_RISK_OPERATION_FRAGMENTS):
                    raise StepRepairRejected('恢复目标可能触发高风险业务动作，不允许自动执行')
            binding_name = cls._binding_name(item.value_binding)
            if binding_name and binding_name not in available_data:
                raise StepRepairRejected(f'缺少恢复动作所需测试数据：{binding_name}')
            if item.value_literal and not any(
                item.value_literal in str(source or '')
                for source in (trusted_text_sources or [])
            ):
                raise StepRepairRejected('恢复动作的输入文字未在步骤目标中明确声明')
            if item.node_id and item.node_id not in node_map:
                raise StepRepairRejected(f'恢复计划引用了不存在的节点：{item.node_id}')
            if item.action == 'skip_node':
                cls._validate_skip(
                    item.node_id, current_node_id, node_map, matched_checkpoints,
                    allow_replaced_current_node_skip=allow_replaced_current_node_skip,
                )
            if item.action == 'jump_to_node':
                cls._validate_jump(item.node_id, node_map, matched_checkpoints)
            if item.action == 'insert_action' and item.operation_intent in {'edit', 'select'}:
                if not item.value_binding and not item.value_literal:
                    raise StepRepairRejected(
                        '输入或选择恢复动作必须引用已有测试数据'
                        '或步骤目标中明确声明的文字',
                    )
            if item.action == 'replace_target':
                cls._validate_node_risk(item.node_id, node_map, allow_low=True)
            if item.action == 'retry_node':
                cls._validate_node_risk(item.node_id, node_map, allow_low=True)
        return plan

    @staticmethod
    def _binding_name(value: str | None) -> str:
        value = str(value or '').strip()
        if value.startswith('${{') and value.endswith('}}'):
            return value[3:-2].strip()
        return value

    @classmethod
    def _validate_skip(
        cls, node_id, current_node_id, node_map, matched_checkpoints,
        *, allow_replaced_current_node_skip: bool = False,
    ):
        if node_id != current_node_id:
            raise StepRepairRejected('只能跳过当前失败节点')
        cls._validate_node_risk(node_id, node_map, allow_low=True)
        node = node_map[node_id]
        if int(node.get('type', -1)) in NON_SKIPPABLE_NODE_TYPES:
            raise StepRepairRejected('断言、数据库或代码节点不能自动跳过')
        if allow_replaced_current_node_skip:
            return
        later = set(node.get('later_checkpoints') or [])
        if not later.intersection(matched_checkpoints):
            raise StepRepairRejected('没有命中后续检查点，不能确认当前节点已经失效或完成')

    @classmethod
    def _validate_jump(cls, node_id, node_map, matched_checkpoints):
        cls._validate_node_risk(node_id, node_map, allow_low=True)
        required = set(node_map[node_id].get('precondition_keys') or [])
        if required and not required.intersection(matched_checkpoints):
            raise StepRepairRejected('跳转目标的前置检查点尚未满足')

    @staticmethod
    def _validate_node_risk(node_id, node_map, allow_low: bool):
        node = node_map[node_id]
        risk = str(node.get('risk_level') or 'low')
        text = ' '.join(str(node.get(key) or '') for key in ('name', 'operation_key')).lower()
        if risk in {'medium', 'high'} or any(value in text for value in HIGH_RISK_OPERATION_FRAGMENTS):
            raise StepRepairRejected('该节点可能产生业务副作用，不能自动跳过或重复执行')
        if not allow_low and risk != 'read_only':
            raise StepRepairRejected('当前恢复动作只允许只读节点')
