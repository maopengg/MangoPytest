# -*- coding: utf-8 -*-
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


ConditionType = Literal[
    'url_path', 'page_title', 'visible_text', 'element_state',
]
ConditionMatcher = Literal[
    'equals', 'contains', 'starts_with', 'regex', 'count_gte',
    'visible', 'hidden', 'enabled', 'editable', 'checked',
]
RepairActionType = Literal[
    'retry_node', 'replace_target', 'insert_action', 'skip_node', 'jump_to_node', 'abort',
]
OperationIntent = Literal['activate', 'select', 'edit', 'close', 'expand', 'navigate']


class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)


class StepCondition(StrictModel):
    type: ConditionType
    matcher: ConditionMatcher
    expected: Any = None
    element_id: int | None = Field(default=None, ge=1)
    count: int | None = Field(default=None, ge=0)

    @model_validator(mode='after')
    def validate_shape(self):
        compatible = {
            'url_path': {'equals', 'contains', 'starts_with', 'regex'},
            'page_title': {'equals', 'contains', 'starts_with', 'regex'},
            'visible_text': {'equals', 'contains', 'starts_with', 'regex', 'count_gte'},
            'element_state': {'visible', 'hidden', 'enabled', 'editable', 'checked'},
        }
        if self.matcher not in compatible[self.type]:
            raise ValueError(f'{self.matcher} is not supported for {self.type}')
        if self.type == 'element_state' and not self.element_id:
            raise ValueError('element_state requires element_id')
        if self.matcher == 'count_gte' and self.count is None:
            raise ValueError('count_gte requires count')
        if (
            self.type != 'element_state'
            and self.matcher not in {'visible', 'hidden', 'enabled', 'editable', 'checked'}
            and self.expected in (None, '')
        ):
            raise ValueError(f'{self.type} requires expected')
        return self


class ConditionGroup(StrictModel):
    operator: Literal['all', 'any'] = 'all'
    conditions: list[StepCondition] = Field(default_factory=list, max_length=20)


class StepHealingPolicy(StrictModel):
    mode: Literal['off', 'suggest_only', 'execute_low_risk'] = 'off'
    total_timeout_seconds: int = Field(default=60, ge=5, le=120)
    max_model_calls: int = Field(default=2, ge=1, le=3)
    max_patch_actions: int = Field(default=3, ge=1, le=5)
    max_recovery_rounds: int = Field(default=1, ge=1, le=2)
    allowed_actions: list[RepairActionType] = Field(default_factory=lambda: [
        'retry_node', 'replace_target', 'insert_action', 'skip_node', 'jump_to_node',
    ])
    auto_writeback: bool = True
    auto_writeback_min_confidence: float = Field(default=0.9, ge=0.7, le=1)

    @field_validator('allowed_actions')
    @classmethod
    def unique_actions(cls, value):
        return list(dict.fromkeys(value))

class FlowNodeSummary(StrictModel):
    node_id: str
    detail_id: int | None = None
    name: str = ''
    operation_key: str | None = None
    operation_intent: str = 'unknown'
    risk_level: Literal['read_only', 'low', 'medium', 'high'] = 'low'
    precondition: ConditionGroup | None = None
    postcondition: ConditionGroup | None = None


class ExecutionEventSummary(StrictModel):
    node_id: str
    status: Literal['success', 'failed', 'skipped', 'healed']
    error: str | None = None


class PageStateSignature(StrictModel):
    captured_at: int
    normalized_url_path: str = ''
    page_title: str = ''
    active_frame_path: list[str] = Field(default_factory=list)
    dialogs: list[dict] = Field(default_factory=list)
    controls: list[dict] = Field(default_factory=list)
    visible_text_digest: str = ''
    form_state_digest: str = ''
    matched_checkpoints: list[str] = Field(default_factory=list)


class StepRepairAction(StrictModel):
    action: RepairActionType
    node_id: str | None = None
    operation_intent: OperationIntent | None = None
    target_ref: str | None = Field(default=None, pattern=r'^e[1-9]\d*$')
    target_name: str | None = Field(default=None, max_length=256)
    target_role: str | None = Field(default=None, max_length=80)
    target_tag: str | None = Field(default=None, max_length=80)
    durable_locators: list[dict] = Field(default_factory=list, max_length=3)
    placement: Literal['before', 'after'] | None = None
    value_binding: str | None = Field(default=None, max_length=256)
    value_literal: str | None = Field(default=None, min_length=1, max_length=256)
    reason: str = Field(min_length=1, max_length=500)
    expected_condition: ConditionGroup = Field(default_factory=ConditionGroup)

    @model_validator(mode='after')
    def validate_action_fields(self):
        if self.action in {'retry_node', 'skip_node', 'jump_to_node', 'replace_target'} and not self.node_id:
            raise ValueError(f'{self.action} requires node_id')
        if self.action in {'replace_target', 'insert_action'} and not self.target_ref:
            raise ValueError(f'{self.action} requires target_ref')
        if self.action == 'insert_action' and not self.operation_intent:
            raise ValueError('insert_action requires operation_intent')
        if self.value_binding and self.value_literal:
            raise ValueError('value_binding and value_literal are mutually exclusive')
        return self


class StepRepairPlan(StrictModel):
    schema_version: Literal[1] = 1
    current_phase: str | None = Field(default=None, max_length=128)
    diagnosis_code: str = Field(min_length=1, max_length=128)
    diagnosis_summary: str = Field(min_length=1, max_length=500)
    confidence: float = Field(ge=0, le=1)
    actions: list[StepRepairAction] = Field(default_factory=list, max_length=5)
    expected_checkpoint: str | None = Field(default=None, max_length=128)
    user_message: str = Field(min_length=1, max_length=500)

    @model_validator(mode='after')
    def reject_conflicting_flow_control(self):
        control_actions = [
            item for item in self.actions
            if item.action in {'skip_node', 'jump_to_node', 'abort'}
        ]
        if len(control_actions) > 1:
            raise ValueError('a repair plan may contain only one flow-control action')
        if control_actions and self.actions[-1] is not control_actions[0]:
            raise ValueError('a flow-control action must be the final repair action')
        return self

    @classmethod
    def openai_response_format(cls) -> dict:
        return {
            'type': 'json_schema',
            'json_schema': {
                'name': 'ui_page_step_repair_plan',
                'strict': True,
                'schema': cls.model_json_schema(),
            },
        }

    @staticmethod
    def openai_json_object_response_format() -> dict:
        return {'type': 'json_object'}


class StepHealingOutcome(StrictModel):
    trace_id: str
    status: Literal['disabled', 'suggested', 'recovered', 'failed', 'rejected']
    trigger: str
    source_version: int
    failed_node_id: str | None = None
    before_state: dict = Field(default_factory=dict)
    after_state: dict = Field(default_factory=dict)
    proposed_plan: dict = Field(default_factory=dict)
    executed_plan: dict = Field(default_factory=dict)
    confidence: float = 0
    user_message: str = ''
    error_message: str | None = None
    next_node_id: str | None = None
    retry_current_node: bool = False
    skip_current_node: bool = False
