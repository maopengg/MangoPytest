# -*- coding: utf-8 -*-
import hashlib
import json
import re
import time
from urllib.parse import urlsplit

from mangoautomation.element_healing.snapshot import AccessibilitySnapshotBuilder
from mangoautomation.element_healing.locator import LocatorFactory

from .models import ConditionGroup, PageStateSignature, StepCondition


class PageStepStateObserver:
    def __init__(self, page, *, variables: dict | None = None, elements: list | None = None):
        self.page = page
        self.variables = variables or {}
        self.elements = elements or []

    async def snapshot(self, checkpoints: dict[str, ConditionGroup] | None = None):
        snapshot = await AccessibilitySnapshotBuilder.build_async(self.page, limit=240)
        matched = []
        for key, group in (checkpoints or {}).items():
            if await self.matches(group):
                matched.append(key)
        dialogs = [
            self._node_summary(node) for node in snapshot.nodes
            if node.role in {'dialog', 'alertdialog'} and node.visible
        ][:20]
        controls = [
            self._node_summary(node) for node in snapshot.nodes
            if node.visible and (node.interactive or node.editable)
        ][:80]
        visible_text = '|'.join(
            f'{node.role}:{node.name or node.text}'
            for node in snapshot.nodes if node.visible and (node.name or node.text)
        )
        form_state = '|'.join(
            f'{node.ref}:{node.checked}:{node.selected}:{node.expanded}:{node.disabled}'
            for node in snapshot.nodes if node.interactive or node.editable
        )
        signature = PageStateSignature(
            captured_at=int(time.time() * 1000),
            normalized_url_path=urlsplit(str(getattr(self.page, 'url', '') or '')).path,
            page_title=await self._title(),
            active_frame_path=[
                urlsplit(str(getattr(frame, 'url', '') or '')).path
                for frame in getattr(self.page, 'frames', [])
            ],
            dialogs=dialogs,
            controls=controls,
            visible_text_digest=self._digest(visible_text),
            form_state_digest=self._digest(form_state),
            matched_checkpoints=matched,
        )
        return signature, snapshot

    async def matches(self, group: ConditionGroup | dict | None) -> bool:
        if group in (None, {}, ''):
            return False
        value = group if isinstance(group, ConditionGroup) else ConditionGroup.model_validate(group)
        if not value.conditions:
            return False
        results = [await self._match(condition) for condition in value.conditions]
        return all(results) if value.operator == 'all' else any(results)

    async def _match(self, condition: StepCondition) -> bool:
        expected = self._resolve(condition.expected)
        if condition.type == 'url_path':
            actual = urlsplit(str(getattr(self.page, 'url', '') or '')).path
            return self._text_match(actual, expected, condition.matcher)
        if condition.type == 'page_title':
            return self._text_match(await self._title(), expected, condition.matcher)
        if condition.type == 'visible_text':
            try:
                if condition.matcher == 'regex':
                    locator = self.page.get_by_text(re.compile(str(expected)))
                elif condition.matcher == 'starts_with':
                    locator = self.page.get_by_text(re.compile(f'^{re.escape(str(expected))}'))
                else:
                    locator = self.page.get_by_text(
                        str(expected), exact=condition.matcher == 'equals',
                    )
            except re.error:
                return False
            count = await locator.count()
            if condition.matcher == 'count_gte':
                visible_count = 0
                for index in range(count):
                    try:
                        visible_count += int(await locator.nth(index).is_visible())
                    except Exception:
                        continue
                return visible_count >= int(condition.count or 0)
            for index in range(min(count, 20)):
                try:
                    if await locator.nth(index).is_visible():
                        return True
                except Exception:
                    continue
            return False
        if condition.type == 'element_state':
            locator = await self._element_locator(condition.element_id)
            if locator is None:
                return False
            count = await locator.count()
            if condition.matcher == 'hidden':
                return count == 0 or not await self._any_visible(locator)
            if count < 1:
                return False
            selected = locator.first
            if condition.matcher == 'visible':
                return await selected.is_visible()
            if condition.matcher == 'enabled':
                return await selected.is_enabled()
            if condition.matcher == 'editable':
                return await selected.is_editable()
            if condition.matcher == 'checked':
                return await selected.is_checked()
        return False

    async def _element_locator(self, element_id: int | None):
        model = next(
            (item for item in self.elements if getattr(item, 'element_id', None) == element_id),
            None,
        )
        if model is None:
            return None
        fallback = None
        for item in getattr(model, 'elements', []) or []:
            exp = getattr(item, 'exp', None)
            loc = self._resolve(getattr(item, 'loc', ''))
            if not loc:
                continue
            try:
                locator = LocatorFactory.create_persistent(
                    self.page,
                    {'exp': exp, 'loc': loc, 'sub': getattr(item, 'sub', None)},
                )
                sub = getattr(item, 'sub', None)
                locator = locator.nth(int(sub) - 1) if sub else locator
                if fallback is None:
                    fallback = locator
                if await locator.count() > 0:
                    return locator
            except Exception:
                continue
        return fallback

    def _resolve(self, value):
        if not isinstance(value, str):
            return value
        pattern = re.compile(r'^\$\{\{\s*([\w.-]+)\s*}}$')
        match = pattern.match(value)
        return self.variables.get(match.group(1)) if match else value

    @staticmethod
    async def _any_visible(locator) -> bool:
        for index in range(min(await locator.count(), 20)):
            try:
                if await locator.nth(index).is_visible():
                    return True
            except Exception:
                continue
        return False

    async def _title(self) -> str:
        try:
            return str(await self.page.title() or '')
        except Exception:
            return ''

    @staticmethod
    def _node_summary(node) -> dict:
        return {
            key: value for key, value in {
                'ref': node.ref,
                'role': node.role,
                'name': node.name,
                'text': node.text,
                'editable': node.editable,
                'interactive': node.interactive,
                'checked': node.checked,
                'selected': node.selected,
                'expanded': node.expanded,
            }.items() if value not in ('', None, False)
        }

    @staticmethod
    def _text_match(actual, expected, matcher: str) -> bool:
        actual_text = str(actual or '')
        expected_text = str(expected or '')
        if matcher == 'equals':
            return actual_text == expected_text
        if matcher == 'contains':
            return expected_text in actual_text
        if matcher == 'starts_with':
            return actual_text.startswith(expected_text)
        if matcher == 'regex':
            try:
                return re.search(expected_text, actual_text) is not None
            except re.error:
                return False
        return False

    @staticmethod
    def _digest(value: str) -> str:
        return hashlib.sha256(value.encode('utf-8')).hexdigest()[:24]
