# -*- coding: utf-8 -*-
import json
import re

from mangoautomation.element_healing.baseline import redact_sensitive_text, sanitize_json_value
from mangoautomation.prompts import get_prompt

from .models import StepRepairPlan


_PROMPT = get_prompt('step_healing.planner')
PROMPT_VERSION = _PROMPT.version


class PageStepHealingPrompt:
    @staticmethod
    def schema_repair_message() -> str:
        return _PROMPT.template('schema_repair')

    @classmethod
    def messages(cls, context: dict, snapshot) -> list[dict]:
        snapshot_tree = cls._compact_snapshot_tree(
            redact_sensitive_text(snapshot.tree),
        )
        runtime_dependency_missing = (
            context.get('failure_kind') == 'runtime_data_dependency_missing'
        )
        payload = {
            'task': _PROMPT.values[
                'runtime_dependency_task' if runtime_dependency_missing else 'default_task'
            ],
            'workflow': cls._compact_context(context),
            'page': {
                'url': snapshot.page_url,
                'tree': snapshot.tree,
                'nodes': [] if snapshot.ref_engine == 'playwright_aria' else snapshot.prompt_nodes(80),
            },
            'output_contract': _PROMPT.values['output_contract'],
            'instructions': _PROMPT.values['instructions'],
        }
        sanitized = sanitize_json_value(payload)
        # The generic JSON sanitizer intentionally caps ordinary strings at 2000
        # characters. A native Playwright accessibility tree is the authoritative
        # ref index for recovery and commonly exceeds that size; truncating it can
        # hide active dialogs and newly inserted controls near the end of the tree.
        sanitized['page']['tree'] = snapshot_tree
        return [
            {'role': 'system', 'content': _PROMPT.system},
            {'role': 'user', 'content': json.dumps(sanitized, ensure_ascii=False)},
        ]

    @staticmethod
    def _compact_context(context: dict) -> dict:
        """Keep workflow intent while removing graph metadata the planner cannot act on."""
        nodes = context.get('nodes') or []
        node_by_id = {str(node.get('node_id')): node for node in nodes}
        execution_history = []
        completed_ids = set()
        for event in context.get('execution_history') or []:
            node_id = str(event.get('node_id'))
            completed_ids.add(node_id)
            node = node_by_id.get(node_id) or {}
            execution_history.append({
                'node_id': node_id,
                'name': node.get('name') or '',
                'status': event.get('status'),
                **({'error': event.get('error')} if event.get('error') else {}),
            })
        failed_node_id = str(context.get('failed_node_id') or '')
        compact = {
            key: context.get(key)
            for key in (
                'id', 'name', 'goal', 'trigger', 'failure_kind', 'failure_summary',
                'available_data', 'previous_response_error',
            )
            if key in context
        }
        if context.get('failure_kind') == 'runtime_data_dependency_missing':
            compact['recovery_scope'] = 'replace_failed_node_with_goal_actions'
            compact['failed_node_is_authoritative_target'] = False
        compact['completed'] = execution_history
        pending = [
            {
                key: node.get(key)
                for key in (
                    'node_id', 'name', 'operation_intent', 'precondition', 'postcondition',
                )
                if node.get(key) not in (None, [], {})
            }
            for node in nodes
            if str(node.get('node_id')) not in completed_ids
        ]
        compact['current'] = next(
            (node for node in pending if str(node.get('node_id')) == failed_node_id),
            None,
        )
        compact['pending'] = [
            node for node in pending if str(node.get('node_id')) != failed_node_id
        ]
        return compact

    @classmethod
    def _compact_snapshot_tree(cls, tree: str, max_length: int = 3000) -> str:
        """Keep active layers and actionable refs ahead of noisy page content."""
        lines = tree.splitlines()
        priority_indexes = set()
        for index, line in enumerate(lines):
            if '[active]' not in line and not re.search(r'- (?:dialog|alertdialog)\b', line):
                continue
            base_indent = len(line) - len(line.lstrip(' '))
            priority_indexes.add(index)
            for child_index in range(index + 1, len(lines)):
                child = lines[child_index]
                if child.strip() and len(child) - len(child.lstrip(' ')) <= base_indent:
                    break
                priority_indexes.add(child_index)

        actionable = re.compile(
            r'- (?:button|textbox|searchbox|combobox|checkbox|radio|link|tab|menuitem|option|treeitem|switch)\b',
        )
        selected = [lines[index] for index in sorted(priority_indexes)]
        selected_set = set(priority_indexes)
        selected.extend(
            line for index, line in enumerate(lines)
            if index not in selected_set and '[ref=e' in line and actionable.search(line)
        )
        compact = '\n'.join(dict.fromkeys(selected))
        compact = re.sub(r' \[box=[^\]]+\]', '', compact)
        if len(compact) <= max_length:
            return compact
        return compact[:max_length].rsplit('\n', 1)[0]
