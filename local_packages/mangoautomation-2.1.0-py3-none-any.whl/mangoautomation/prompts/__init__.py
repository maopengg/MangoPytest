"""mangoautomation 统一 AI 提示词目录。"""

from .base import PromptDefinition, render_template
from .loader import get_prompt, validate_prompt_catalog

__all__ = ['PromptDefinition', 'get_prompt', 'render_template', 'validate_prompt_catalog']
