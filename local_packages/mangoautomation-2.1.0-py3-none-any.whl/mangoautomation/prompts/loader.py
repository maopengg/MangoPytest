"""可在源码和 wheel 中工作的 YAML 提示词加载器。"""

from __future__ import annotations

from functools import lru_cache
from importlib import resources

from ruamel.yaml import YAML

from .base import PromptDefinition
from .registry import PROMPT_FILES


CATALOG_PACKAGE = 'mangoautomation.prompts.catalog'


@lru_cache(maxsize=None)
def get_prompt(prompt_id: str) -> PromptDefinition:
    try:
        file_name = PROMPT_FILES[prompt_id]
    except KeyError as error:
        raise KeyError(f'提示词未注册：{prompt_id}') from error
    resource = resources.files(CATALOG_PACKAGE).joinpath(file_name)
    yaml = YAML(typ='safe')
    with resource.open('r', encoding='utf-8') as stream:
        raw = yaml.load(stream) or {}
    prompt = PromptDefinition.model_validate(raw)
    if prompt.id != prompt_id:
        raise ValueError(
            f'提示词文件 {file_name} 的 id={prompt.id}，与注册 id={prompt_id} 不一致',
        )
    return prompt


def validate_prompt_catalog() -> tuple[PromptDefinition, ...]:
    prompts = tuple(get_prompt(prompt_id) for prompt_id in PROMPT_FILES)
    file_names = list(PROMPT_FILES.values())
    if len(file_names) != len(set(file_names)):
        raise ValueError('提示词注册表存在重复文件')
    catalog_files = {
        item.name
        for item in resources.files(CATALOG_PACKAGE).iterdir()
        if item.name.endswith('.yaml')
    }
    unregistered = sorted(catalog_files - set(file_names))
    missing = sorted(set(file_names) - catalog_files)
    if unregistered or missing:
        raise ValueError(f'提示词文件注册不完整：未注册={unregistered}，缺失={missing}')
    return prompts
