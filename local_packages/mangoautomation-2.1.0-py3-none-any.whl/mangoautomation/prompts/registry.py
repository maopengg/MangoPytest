"""显式提示词注册表。"""

PROMPT_FILES = {
    'element_healing.visual_locator': 'visual_locator.yaml',
    'element_healing.web_locator': 'web_locator.yaml',
    'step_healing.planner': 'step_healing.yaml',
}
