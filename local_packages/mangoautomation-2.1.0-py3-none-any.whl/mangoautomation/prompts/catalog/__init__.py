"""随 wheel 分发的 YAML 提示词资源。"""
