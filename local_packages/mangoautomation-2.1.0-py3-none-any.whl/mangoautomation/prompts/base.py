"""提示词契约与无代码执行能力的安全模板渲染。"""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


_PLACEHOLDER_PATTERN = re.compile(r'{{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*}}')


class PromptDefinition(BaseModel):
    model_config = ConfigDict(extra='forbid', frozen=True)

    id: str = Field(min_length=1)
    version: str = Field(min_length=1)
    owner: str = Field(min_length=1)
    description: str = Field(min_length=1)
    system: str = ''
    templates: dict[str, str] = Field(default_factory=dict)
    values: dict[str, Any] = Field(default_factory=dict)

    @field_validator('id', 'version', 'owner', 'description', 'system', mode='before')
    @classmethod
    def normalize_text(cls, value: Any) -> str:
        return str(value or '').strip()

    def template(self, key: str) -> str:
        try:
            return self.templates[key]
        except KeyError as error:
            raise KeyError(f'提示词 {self.id} 未定义模板：{key}') from error

    def render(self, key: str, **variables: Any) -> str:
        return render_template(self.template(key), **variables)


def render_template(template: str, **variables: Any) -> str:
    required = set(_PLACEHOLDER_PATTERN.findall(template))
    missing = sorted(required - variables.keys())
    if missing:
        raise ValueError(f"提示词模板缺少变量：{', '.join(missing)}")

    def replace(match: re.Match) -> str:
        value = variables[match.group(1)]
        return '' if value is None else str(value)

    return _PLACEHOLDER_PATTERN.sub(replace, template).strip()
