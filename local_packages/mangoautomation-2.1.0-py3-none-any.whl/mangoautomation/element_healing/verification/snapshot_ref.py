# -*- coding: utf-8 -*-
from ..locator import LocatorFactory
from ..snapshot import SNAPSHOT_REF_ATTRIBUTE, SnapshotRefResolver
from .operation_target import OperationTargetResolver


class SnapshotRefVerifier:
    @classmethod
    async def verify_durable_async(cls, page, candidate) -> tuple[int | None, str | None]:
        if not SnapshotRefResolver.supports(candidate):
            return None, None
        try:
            locator = LocatorFactory.create_persistent(
                SnapshotRefResolver.scope(page, candidate), candidate,
            )
            count = await locator.count()
            error = await cls._compare_async(page, locator, count, candidate)
            return count, error
        except Exception as error:
            return None, f'generated durable locator validation failed: {error}'

    @classmethod
    def verify_durable_sync(cls, page, candidate) -> tuple[int | None, str | None]:
        if not SnapshotRefResolver.supports(candidate):
            return None, None
        try:
            locator = LocatorFactory.create_persistent(
                SnapshotRefResolver.scope(page, candidate), candidate,
            )
            count = locator.count()
            error = cls._compare_sync(page, locator, count, candidate)
            return count, error
        except Exception as error:
            return None, f'generated durable locator validation failed: {error}'

    @classmethod
    async def _compare_async(cls, page, locator, count: int, candidate) -> str | None:
        error = cls._count_error(count, candidate)
        if error:
            return error
        selected = locator.nth(candidate.sub - 1) if candidate.sub else locator.first
        if cls._uses_playwright_ref(candidate):
            return await cls._native_identity_error_async(page, selected, candidate)
        marker = await selected.get_attribute(SNAPSHOT_REF_ATTRIBUTE)
        return cls._marker_error(marker, candidate)

    @classmethod
    def _compare_sync(cls, page, locator, count: int, candidate) -> str | None:
        error = cls._count_error(count, candidate)
        if error:
            return error
        selected = locator.nth(candidate.sub - 1) if candidate.sub else locator.first
        if cls._uses_playwright_ref(candidate):
            return cls._native_identity_error_sync(page, selected, candidate)
        marker = selected.get_attribute(SNAPSHOT_REF_ATTRIBUTE)
        return cls._marker_error(marker, candidate)

    @staticmethod
    def _uses_playwright_ref(candidate) -> bool:
        metadata = getattr(candidate, 'metadata', {}) or {}
        return metadata.get('snapshot_ref_engine') == SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE

    @classmethod
    async def _native_identity_error_async(cls, page, selected, candidate) -> str | None:
        reference = SnapshotRefResolver.resolve(page, candidate)
        selected = await OperationTargetResolver.apply_recorded_async(selected, candidate)
        reference = await OperationTargetResolver.apply_recorded_async(reference, candidate)
        reference_handle = await reference.first.element_handle()
        if reference_handle is None:
            return 'selected Playwright aria ref is no longer attached'
        same_node = await selected.evaluate('(element, target) => element === target', reference_handle)
        return None if same_node else 'generated durable locator does not resolve to selected snapshot ref'

    @classmethod
    def _native_identity_error_sync(cls, page, selected, candidate) -> str | None:
        reference = SnapshotRefResolver.resolve(page, candidate)
        selected = OperationTargetResolver.apply_recorded_sync(selected, candidate)
        reference = OperationTargetResolver.apply_recorded_sync(reference, candidate)
        reference_handle = reference.first.element_handle()
        if reference_handle is None:
            return 'selected Playwright aria ref is no longer attached'
        same_node = selected.evaluate('(element, target) => element === target', reference_handle)
        return None if same_node else 'generated durable locator does not resolve to selected snapshot ref'

    @staticmethod
    def _count_error(count: int, candidate) -> str | None:
        if count < 1:
            return 'generated durable locator count=0'
        if candidate.sub and candidate.sub > count:
            return f'generated durable locator sub={candidate.sub} exceeds count={count}'
        return None

    @staticmethod
    def _marker_error(marker, candidate) -> str | None:
        expected = SnapshotRefResolver.marker(
            candidate.metadata['accessibility_snapshot_id'], candidate.metadata['target_ref'],
        )
        if marker != expected:
            return 'generated durable locator does not resolve to selected snapshot ref'
        return None

    @staticmethod
    def select(locator, candidate):
        return SnapshotRefResolver.select(locator, candidate)
