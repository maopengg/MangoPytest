# -*- coding: utf-8 -*-
from dataclasses import dataclass

from ..locator import clean
from ..policy.operation_rules import (
    OPERATION_INTENT_ACTIVATE,
    OPERATION_INTENT_EDIT,
    OPERATION_INTENT_SELECT,
    operation_intent,
)


@dataclass(frozen=True)
class ControlKind:
    name: str
    label: str
    aliases: tuple[str, ...]
    priority: int
    roles: frozenset[str] = frozenset()
    tags: frozenset[str] = frozenset()
    input_types: frozenset[str] = frozenset()
    editable: bool = False

    def matches(self, state: dict) -> bool:
        tag = clean(state.get('tag')).lower()
        role = clean(state.get('role')).lower()
        input_type = clean(state.get('type')).lower()
        if role in self.roles or tag in self.tags:
            return True
        if tag == 'input' and input_type in self.input_types:
            return True
        return self.editable and state.get('editable') is True


@dataclass(frozen=True)
class TargetIntent:
    control: ControlKind | None
    scope: str | None


# Adding a supported control means adding data here; combinations such as
# "dialog -> form -> radio" do not require new branches.
CONTROL_KINDS = (
    ControlKind(
        'file_input', '文件上传控件', ('文件上传', '上传控件', '选择文件'), 120,
        input_types=frozenset({'file'}),
    ),
    ControlKind(
        'radio', '单选框', ('单选圆圈', '单选按钮', '单选框'), 110,
        roles=frozenset({'radio'}), input_types=frozenset({'radio'}),
    ),
    ControlKind(
        'checkbox', '复选框', ('复选框', '勾选框', '多选框'), 108,
        roles=frozenset({'checkbox'}), input_types=frozenset({'checkbox'}),
    ),
    ControlKind(
        'switch', '开关', ('开关按钮', '开关'), 106,
        roles=frozenset({'switch'}),
    ),
    ControlKind(
        'combobox', '选择框', ('下拉选择框', '下拉框', '选择框', '组合框'), 100,
        roles=frozenset({'combobox', 'listbox'}), tags=frozenset({'select'}),
    ),
    ControlKind(
        'textbox', '输入框', ('搜索输入框', '文本输入框', '输入框', '文本框', '编辑区'), 98,
        roles=frozenset({'textbox', 'searchbox'}), tags=frozenset({'textarea'}),
        editable=True,
    ),
    ControlKind(
        'button', '按钮', ('按钮',), 90,
        roles=frozenset({'button'}), tags=frozenset({'button'}),
        input_types=frozenset({'button', 'submit', 'reset'}),
    ),
    ControlKind(
        'link', '链接', ('链接',), 88,
        roles=frozenset({'link'}), tags=frozenset({'a'}),
    ),
)

SCOPE_KINDS = (
    ('card', ('卡片',)),
    ('row', ('表格行', '列表行', '行记录')),
    ('list_item', ('列表项',)),
    ('dialog', ('弹窗', '对话框')),
    ('drawer', ('抽屉', '半屏窗口')),
    ('form', ('表单',)),
)


def parse_target_intent(targets: list[str]) -> TargetIntent:
    text = ' '.join(clean(item) for item in targets)
    controls = [
        spec for spec in CONTROL_KINDS
        if any(alias in text for alias in spec.aliases)
    ]
    control = max(controls, key=lambda item: item.priority, default=None)
    scope = next(
        (name for name, aliases in SCOPE_KINDS if any(alias in text for alias in aliases)),
        None,
    )
    return TargetIntent(control=control, scope=scope)


def target_kind_reject_reason(targets: list[str], state: dict,
                              find_params: dict | None = None) -> str | None:
    intent = parse_target_intent(targets)
    tag = clean(state.get('tag')).lower()
    role = clean(state.get('role')).lower()
    if intent.control:
        if intent.control.matches(state):
            return None
        return (
            f'candidate target-kind mismatch: expected {intent.control.label}, '
            f'actual tag={tag or "-"}, role={role or "-"}'
        )
    if intent.scope and _scope_control_is_equivalent(state, find_params):
        return None
    if intent.scope and _is_form_control(state):
        return (
            f'candidate target-kind mismatch: expected {intent.scope}, '
            f'actual tag={tag or "-"}, role={role or "-"}'
        )
    return None


def _scope_control_is_equivalent(state: dict, find_params: dict | None) -> bool:
    """Allow a control inside a described scope when it fulfils the step intent.

    This is capability based rather than a combination list.  Consequently a
    card, row or list item can resolve to native or custom radio/button/label
    controls without teaching the verifier every component-library DOM shape.
    """
    intent = operation_intent(find_params)
    if intent == OPERATION_INTENT_EDIT:
        return state.get('editable') is True
    if intent in {OPERATION_INTENT_ACTIVATE, OPERATION_INTENT_SELECT}:
        return state.get('interactive') is True and not _is_text_entry(state)
    return False


def _is_form_control(state: dict) -> bool:
    tag = clean(state.get('tag')).lower()
    role = clean(state.get('role')).lower()
    return tag in {'input', 'textarea', 'select'} or role in {
        'textbox', 'searchbox', 'combobox', 'listbox', 'checkbox', 'radio', 'switch',
    }


def _is_text_entry(state: dict) -> bool:
    tag = clean(state.get('tag')).lower()
    role = clean(state.get('role')).lower()
    input_type = clean(state.get('type')).lower()
    return bool(
        state.get('editable') is True and (
            tag == 'textarea' or role in {'textbox', 'searchbox'} or
            (tag == 'input' and input_type not in {'button', 'submit', 'reset', 'checkbox', 'radio'})
        )
    )
