# -*- coding: utf-8 -*-
from ..policy.operation_rules import (
    CHECK_ACTION_KEYS,
    CLICK_ACTION_KEYS,
    EDITABLE_ACTION_KEYS,
    SELECT_ACTION_KEYS,
    operation_key,
)
from ..snapshot import SnapshotRefResolver


class OperationTargetResolver:
    """Normalize a snapshot ref to the concrete control required by the operation."""

    EDITABLE_ANCESTOR_SELECTOR = (
        'xpath=ancestor-or-self::*['
        '@contenteditable="true" or @role="textbox" or self::textarea or '
        'self::input[not(@type="button") and not(@type="submit") and '
        'not(@type="reset") and not(@type="checkbox") and not(@type="radio") and '
        'not(@type="file") and not(@type="hidden")]'
        '][1]'
    )
    EDITABLE_DESCENDANT_SELECTOR = (
        '[contenteditable="true"], [role="textbox"], textarea, '
        'input:not([type="button"]):not([type="submit"]):not([type="reset"]):'
        'not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="hidden"])'
    )
    CLICK_ANCESTOR_SELECTOR = (
        'xpath=ancestor-or-self::*['
        'self::button or self::a[@href] or self::label or '
        'self::input[not(@type="hidden")] or self::select or '
        '@role="button" or @role="link" or @role="menuitem" or '
        '@role="treeitem" or @role="option" or @role="checkbox" or '
        '@role="radio" or @role="switch" or @role="combobox" or '
        '@role="listbox" or @aria-haspopup or '
        '(@tabindex and @tabindex!="-1")'
        '][1]'
    )
    CLICK_DESCENDANT_SELECTOR = (
        'button, a[href], label, input:not([type="hidden"]), select, '
        '[role="button"], [role="link"], [role="menuitem"], [role="treeitem"], '
        '[role="option"], [role="checkbox"], [role="radio"], [role="switch"], '
        '[role="combobox"], [role="listbox"], [aria-haspopup], '
        '[tabindex]:not([tabindex="-1"])'
    )
    CHECK_ANCESTOR_SELECTOR = (
        'xpath=ancestor-or-self::input['
        'translate(@type, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")="checkbox" or '
        'translate(@type, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")="radio"'
        '][1]'
    )
    CHECK_DESCENDANT_SELECTOR = 'input[type="checkbox"], input[type="radio"]'
    SELECT_ANCESTOR_SELECTOR = 'xpath=ancestor-or-self::select[1]'
    SELECT_DESCENDANT_SELECTOR = 'select'
    DIRECT_CONTROL_SCRIPT = r"""
        (el, kind) => {
          if (!el || el.nodeType !== Node.ELEMENT_NODE || el.disabled) return false;
          const tag = String(el.tagName || '').toLowerCase();
          const type = String(el.getAttribute('type') || '').toLowerCase();
          const role = String(el.getAttribute('role') || '').toLowerCase();
          if (kind === 'check') return tag === 'input' && ['checkbox', 'radio'].includes(type);
          if (kind === 'select') return tag === 'select';
          if (kind === 'click') {
            const cls = String(el.className || '').toLowerCase();
            const cursor = window.getComputedStyle(el).cursor;
            return ['button', 'a', 'label', 'input', 'select'].includes(tag) ||
              ['button', 'link', 'menuitem', 'treeitem', 'option', 'checkbox', 'radio',
               'switch', 'combobox', 'listbox'].includes(role) ||
              el.hasAttribute('aria-haspopup') ||
              (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1') ||
              cursor === 'pointer' ||
              /select|picker|selector|selection|trigger|dropdown|radio|checkbox|switch/.test(cls);
          }
          return false;
        }
    """
    METADATA_KEY = 'operation_target_strategy'

    @classmethod
    async def resolve_async(cls, locator, candidate, find_params):
        if not cls._should_resolve(candidate, find_params):
            return locator
        spec = cls._target_spec(find_params)
        if spec is None:
            return locator
        if await cls._matches_async(locator, spec['state']):
            candidate.metadata.setdefault(cls.METADATA_KEY, f'{spec["name"]}_self')
            return locator
        ancestor = locator.locator(spec['ancestor'])
        if await cls._is_single_match_async(ancestor, spec['state']):
            candidate.metadata[cls.METADATA_KEY] = f'{spec["name"]}_ancestor'
            return ancestor.first
        descendant = locator.locator(spec['descendant'])
        if await cls._is_single_match_async(descendant, spec['state']):
            candidate.metadata[cls.METADATA_KEY] = f'{spec["name"]}_descendant'
            return descendant.first
        return locator

    @classmethod
    def resolve_sync(cls, locator, candidate, find_params):
        if not cls._should_resolve(candidate, find_params):
            return locator
        spec = cls._target_spec(find_params)
        if spec is None:
            return locator
        if cls._matches_sync(locator, spec['state']):
            candidate.metadata.setdefault(cls.METADATA_KEY, f'{spec["name"]}_self')
            return locator
        ancestor = locator.locator(spec['ancestor'])
        if cls._is_single_match_sync(ancestor, spec['state']):
            candidate.metadata[cls.METADATA_KEY] = f'{spec["name"]}_ancestor'
            return ancestor.first
        descendant = locator.locator(spec['descendant'])
        if cls._is_single_match_sync(descendant, spec['state']):
            candidate.metadata[cls.METADATA_KEY] = f'{spec["name"]}_descendant'
            return descendant.first
        return locator

    @classmethod
    async def apply_recorded_async(cls, locator, candidate):
        strategy = (getattr(candidate, 'metadata', {}) or {}).get(cls.METADATA_KEY)
        spec, direction = cls._recorded_spec(strategy)
        if spec and direction == 'self':
            return locator
        if spec:
            value = locator.locator(spec[direction])
            return value.first if await cls._is_single_match_async(value, spec['state']) else locator
        return locator

    @classmethod
    def apply_recorded_sync(cls, locator, candidate):
        strategy = (getattr(candidate, 'metadata', {}) or {}).get(cls.METADATA_KEY)
        spec, direction = cls._recorded_spec(strategy)
        if spec and direction == 'self':
            return locator
        if spec:
            value = locator.locator(spec[direction])
            return value.first if cls._is_single_match_sync(value, spec['state']) else locator
        return locator

    @classmethod
    def _should_resolve(cls, candidate, find_params) -> bool:
        metadata = getattr(candidate, 'metadata', {}) or {}
        return bool(cls._target_spec(find_params) and
                    metadata.get('snapshot_ref_engine') == SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE)

    @classmethod
    def _target_spec(cls, find_params):
        key = operation_key(find_params)
        if key in EDITABLE_ACTION_KEYS:
            return cls._spec('editable', cls.EDITABLE_ANCESTOR_SELECTOR,
                             cls.EDITABLE_DESCENDANT_SELECTOR, 'editable')
        if key in CHECK_ACTION_KEYS:
            return cls._spec('check', cls.CHECK_ANCESTOR_SELECTOR,
                             cls.CHECK_DESCENDANT_SELECTOR, 'check')
        if key in SELECT_ACTION_KEYS:
            return cls._spec('select', cls.SELECT_ANCESTOR_SELECTOR,
                             cls.SELECT_DESCENDANT_SELECTOR, 'select')
        if key in CLICK_ACTION_KEYS:
            return cls._spec('click', cls.CLICK_ANCESTOR_SELECTOR,
                             cls.CLICK_DESCENDANT_SELECTOR, 'click')
        return None

    @staticmethod
    def _spec(name, ancestor, descendant, state):
        return {'name': name, 'ancestor': ancestor, 'descendant': descendant, 'state': state}

    @classmethod
    def _recorded_spec(cls, strategy):
        if not strategy or '_' not in strategy:
            return None, None
        name, direction = strategy.rsplit('_', 1)
        if direction not in {'self', 'ancestor', 'descendant'}:
            return None, None
        specs = {
            spec['name']: spec for spec in (
                cls._target_spec({'ope_key': 'w_input'}),
                cls._target_spec({'ope_key': 'w_click'}),
                cls._target_spec({'ope_key': 'w_check'}),
                cls._target_spec({'ope_key': 'w_select_option'}),
            )
        }
        return specs.get(name), direction

    @staticmethod
    async def _is_editable_async(locator) -> bool:
        try:
            return bool(await locator.is_editable())
        except Exception:
            return False

    @classmethod
    async def _matches_async(cls, locator, state: str) -> bool:
        if state == 'editable':
            return await cls._is_editable_async(locator)
        try:
            return bool(await locator.evaluate(cls.DIRECT_CONTROL_SCRIPT, state))
        except Exception:
            return False

    @classmethod
    async def _is_single_match_async(cls, locator, state: str) -> bool:
        try:
            return await locator.count() == 1 and await cls._matches_async(locator.first, state)
        except Exception:
            return False

    @staticmethod
    def _is_editable_sync(locator) -> bool:
        try:
            return bool(locator.is_editable())
        except Exception:
            return False

    @classmethod
    def _matches_sync(cls, locator, state: str) -> bool:
        if state == 'editable':
            return cls._is_editable_sync(locator)
        try:
            return bool(locator.evaluate(cls.DIRECT_CONTROL_SCRIPT, state))
        except Exception:
            return False

    @classmethod
    def _is_single_match_sync(cls, locator, state: str) -> bool:
        try:
            return locator.count() == 1 and cls._matches_sync(locator.first, state)
        except Exception:
            return False
