# -*- coding: utf-8 -*-
import time

from ..models import HealingTrace, TraceStage
from .summary import CandidateSummary


class TraceRecorder:
    def __init__(self, context):
        self.context = context
        self.started = time.perf_counter()
        self.trace = HealingTrace(
            trace_id=context.trace_id,
            element_id=context.element_id,
            trigger=context.trigger.value,
        )

    def stage(self, name: str, started: float, candidate_count: int = 0, error: str | None = None):
        self.trace.stages.append(TraceStage(
            name=name,
            duration_ms=max(0, int((time.perf_counter() - started) * 1000)),
            candidate_count=candidate_count,
            error=str(error)[:300] if error else None,
        ))

    def finish(self, candidates, results, reject_reasons, decision, *, agent=None):
        self.trace.duration_ms = max(0, int((time.perf_counter() - self.started) * 1000))
        self.trace.candidates = list(results or [])
        self.trace.reject_reasons = list(reject_reasons or [])[:10]
        self.trace.decision = decision
        if agent and getattr(agent, 'available', False):
            self.trace.agent_called = self.trace.agent_called or any(
                (row.get('used_ai') or row.get('source') == 'ai_accessibility')
                for row in results or []
            )
            client = getattr(agent, 'model_client', None)
            self.trace.model = getattr(client, 'model_name', None)
            self.trace.prompt_version = getattr(agent, 'prompt_version', None)
            self.trace.schema_version = getattr(agent, 'schema_version', None)
        return self.trace

    @staticmethod
    def runtime_metadata(selected, candidates, results, reject_reasons, mode, context, trace, decision=None):
        candidate = selected.verification.candidate
        row = candidate.to_runtime_dict()
        selected_index = selected.runtime_row.get('candidate_index')
        target_ref = row.get('target_ref')
        locator_updates = []
        seen = set()
        for result in results or []:
            if not result.get('verified'):
                continue
            if result.get('transient_snapshot_ref_only'):
                continue
            # A native snapshot ref may point at an icon/text child and be promoted
            # at runtime to the concrete button, input, checkbox or select.  The
            # original durable locator still addresses the child, so only locators
            # re-derived from the normalized live control are safe to persist.
            if (
                    result.get('operation_target_strategy') and
                    result.get('source') != 'snapshot_live_derived'):
                continue
            if target_ref and result.get('target_ref') != target_ref:
                continue
            key = (result.get('exp'), result.get('loc'), result.get('sub'))
            if not key[1] or key in seen:
                continue
            seen.add(key)
            locator_updates.append({
                'exp': result.get('exp'),
                'loc': result.get('loc'),
                'sub': result.get('sub'),
                'source': result.get('source'),
                'strategy': result.get('durable_locator_strategy'),
                'score': result.get('final_score') or result.get('score') or 0,
                'frame_index': result.get('snapshot_frame_index') or 0,
                'frame_url': result.get('snapshot_frame_url'),
                'same_target': True,
                'verified': True,
            })
            if len(locator_updates) >= 3:
                break
        return {
            'trace_id': context.trace_id,
            'used_source': row.get('source'),
            'used_ai': row.get('used_ai', False),
            'temporary_heal_used': bool(
                decision and decision.status.value in ('temporary_heal', 'auto_apply')
            ),
            'auto_apply_eligible': selected.verification.auto_apply_eligible,
            'candidate_count': len(candidates),
            'candidate_index': selected_index,
            'final_score': selected.verification.final_score,
            'selected_exp': candidate.exp,
            'selected_loc': candidate.loc,
            'selected_sub': candidate.sub,
            'base_locator_version': context.element_version,
            'description_has_variables': '${{' in str(context.description_template or ''),
            'runtime_config': TraceRecorder._runtime_config(context),
            'locator_updates': locator_updates,
            'accessibility_snapshot_id': row.get('accessibility_snapshot_id'),
            'snapshot_ref': row.get('target_ref'),
            'snapshot_frame_index': row.get('snapshot_frame_index'),
            'snapshot_frame_url': row.get('snapshot_frame_url'),
            'durable_locator_strategy': row.get('durable_locator_strategy'),
            'baseline_snapshot_id': candidate.snapshot_id,
            'heal_record_id': candidate.heal_record_id,
            'reject_reasons': list(reject_reasons)[:10],
            'candidates': results,
            'candidate_summary': CandidateSummary.build(candidates, results, reject_reasons),
            'trigger': {
                'type': context.trigger.value,
                'error': context.trigger_error,
                'failed_expression': [item.loc for item in context.failed_locators][-10:],
                'ope_key': context.operation_key,
                'operation_intent': context.operation_intent,
                'origin_exp': context.origin_exp,
                'origin_loc': context.origin_loc,
                'origin_sub': context.origin_sub,
            },
            'trace': trace.model_dump(mode='json'),
        }

    @staticmethod
    def _runtime_config(context) -> dict:
        return {
            'fixed_locator_retry_seconds': context.fixed_locator_retry_seconds,
            'smart_locator_timeout_seconds': context.smart_locator_timeout_seconds,
            'visual_locator_enabled': context.visual_locator_enabled,
        }

    @staticmethod
    def exhausted_metadata(candidates, results, reject_reasons, context, trace):
        return {
            'trace_id': context.trace_id,
            'used_source': 'candidate_exhausted',
            'used_ai': trace.agent_called,
            'temporary_heal_used': False,
            'candidate_count': len(candidates),
            'final_score': 0,
            'reject_reasons': list(reject_reasons)[:10],
            'candidates': results,
            'candidate_summary': CandidateSummary.build(candidates, results, reject_reasons),
            'base_locator_version': context.element_version,
            'description_has_variables': '${{' in str(context.description_template or ''),
            'runtime_config': TraceRecorder._runtime_config(context),
            'trigger': {
                'type': context.trigger.value,
                'error': context.trigger_error,
                'failed_expression': [item.loc for item in context.failed_locators][-10:],
                'ope_key': context.operation_key,
                'operation_intent': context.operation_intent,
                'origin_exp': context.origin_exp,
                'origin_loc': context.origin_loc,
                'origin_sub': context.origin_sub,
            },
            'trace': trace.model_dump(mode='json'),
        }
