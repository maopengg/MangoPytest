# -*- coding: utf-8 -*-
import json

from ...baseline import redact_sensitive_text, sanitize_json_value
from ...policy.operation_rules import operation_intent
from ...snapshot import SnapshotRefResolver
from mangoautomation.prompts import get_prompt
from .response_schema import SCHEMA_VERSION, WebLocatorAgentResponse

_PROMPT = get_prompt('element_healing.web_locator')
PROMPT_VERSION = _PROMPT.version


class WebLocatorPrompt:
    @staticmethod
    def build(context, memory: dict, snapshot) -> str:
        native_snapshot = snapshot.ref_engine == SnapshotRefResolver.PLAYWRIGHT_ARIA_ENGINE
        snapshot_tree = redact_sensitive_text(snapshot.tree)
        snapshots = memory.get('snapshots') or []
        snapshot_summary = [{
            'role': item.get('element_role'),
            'name': item.get('element_name'),
            'text': item.get('element_text'),
            'placeholder': item.get('element_placeholder'),
            'attributes': item.get('element_attributes'),
        } for item in snapshots[:3]]
        payload = {
            'task': _PROMPT.values['task'],
            'prompt_version': PROMPT_VERSION,
            'schema_version': SCHEMA_VERSION,
            'target': {
                'name': context.element_name,
                'category': context.category,
                'prompt': context.prompt,
                'target_texts': context.expected_semantics.target_texts,
                'operation_key': context.operation_key,
                'operation_intent': getattr(context, 'operation_intent', None) or
                                    operation_intent(context.operation_key),
            },
            'failed_locators': [item.loc for item in context.failed_locators][-10:],
            'baseline_snapshots': snapshot_summary,
            'accessibility_snapshot': {
                'snapshot_id': snapshot.snapshot_id,
                'ref_engine': snapshot.ref_engine,
                'page_url': snapshot.page_url,
                # The native tree is the authoritative Playwright representation.
                # Do not duplicate it as a flat node list in the model request.
                'tree': '',
                'nodes': [] if native_snapshot else snapshot.prompt_nodes(len(snapshot.nodes)),
            },
            'output_contract': WebLocatorAgentResponse.model_json_schema(),
            'rules': _PROMPT.values['rules'],
        }
        sanitized = sanitize_json_value(payload)
        sanitized['accessibility_snapshot']['tree'] = snapshot_tree
        return json.dumps(sanitized, ensure_ascii=False)

    @staticmethod
    def system_message() -> str:
        return _PROMPT.system

    @staticmethod
    def schema_repair_message(error: Exception) -> str:
        return _PROMPT.render('schema_repair', error=error)
