# -*- coding: utf-8 -*-
import ast
import json
import re

from pydantic import ValidationError

from .response_schema import SCHEMA_VERSION, WebLocatorAgentResponse


class AgentResponseSchemaError(ValueError):
    pass


class AgentResponseParser:
    @classmethod
    def parse(cls, content: str) -> WebLocatorAgentResponse:
        content = str(content or '').strip()
        try:
            value = WebLocatorAgentResponse.model_validate_json(content)
        except ValidationError:
            try:
                value = WebLocatorAgentResponse.model_validate(
                    cls._normalize_compatible_payload(cls._extract_json(content)),
                )
            except (TypeError, ValueError, ValidationError) as error:
                cls._raise_schema_error(error)
        if value.status == 'matched' and not value.candidates:
            raise AgentResponseSchemaError('Agent响应标记为matched但未返回候选')
        return value

    @staticmethod
    def _extract_json(content: str):
        decoder = json.JSONDecoder()
        for index, char in enumerate(content):
            if char not in '{[':
                continue
            try:
                value, _ = decoder.raw_decode(content[index:])
            except json.JSONDecodeError:
                try:
                    value = ast.literal_eval(content[index:])
                except (SyntaxError, ValueError):
                    continue
            if isinstance(value, (dict, list)):
                return value
        refs = list(dict.fromkeys(re.findall(r'\be[1-9]\d*\b', content)))[:5]
        if refs:
            return {
                'reason': 'snapshot refs extracted from compatible model text response',
                'candidates': [{'ref': ref} for ref in refs],
            }
        raise ValueError('response:json_invalid')

    @staticmethod
    def _normalize_compatible_payload(value) -> dict:
        if isinstance(value, list):
            value = {'candidates': value}
        if not isinstance(value, dict):
            raise ValueError('response:type_invalid')
        if isinstance(value.get('data'), dict) and not value.get('candidates'):
            value = value['data']

        raw_candidates = value.get('candidates') or value.get('elements') or []
        if isinstance(raw_candidates, dict):
            raw_candidates = [raw_candidates]
        candidates = []
        for item in raw_candidates[:5] if isinstance(raw_candidates, list) else []:
            if not isinstance(item, dict):
                continue
            target_ref = item.get('target_ref') or item.get('ref')
            if not isinstance(target_ref, str):
                continue
            raw_confidence = item.get('confidence', item.get('score', 80))
            try:
                confidence = max(0, min(100, int(float(raw_confidence))))
            except (TypeError, ValueError):
                confidence = 80
            candidates.append({
                'source': 'ai_accessibility',
                'target_ref': target_ref.strip(),
                'reason': str(item.get('reason') or 'model selected snapshot ref')[:300],
                'confidence': confidence,
            })

        raw_status = str(value.get('status') or '').strip().lower()
        if raw_status in {'matched', 'success', 'found'}:
            status = 'matched'
        elif raw_status in {'ambiguous', 'uncertain'}:
            status = 'ambiguous'
        elif raw_status in {'not_found', 'not found', 'no_match', 'failed'}:
            status = 'not_found'
        else:
            status = 'matched' if candidates else 'not_found'
        reason = str(value.get('reason') or value.get('message') or (
            'target identified' if candidates else 'model returned no supported candidate'
        ))[:500]
        return {
            'schema_version': SCHEMA_VERSION,
            'status': status,
            'reason': reason,
            'candidates': candidates,
        }

    @staticmethod
    def _raise_schema_error(error) -> None:
        if isinstance(error, ValidationError):
            details = []
            for item in error.errors(include_input=False)[:5]:
                location = '.'.join(str(value) for value in item.get('loc') or ()) or 'response'
                details.append(f'{location}:{item.get("type", "invalid")}')
            summary = ', '.join(details) or 'invalid response'
        else:
            summary = str(error) or 'invalid response'
        raise AgentResponseSchemaError(f'Agent响应不符合Schema：{summary}') from None
