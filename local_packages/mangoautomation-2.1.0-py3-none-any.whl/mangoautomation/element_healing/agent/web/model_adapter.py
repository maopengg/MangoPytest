# -*- coding: utf-8 -*-
from openai import AsyncOpenAI, DefaultAsyncHttpxClient, DefaultHttpxClient, OpenAI

from ...policy.thresholds import AGENT_TIMEOUT_SECONDS


class OpenAICompatibleModelClient:
    EMPTY_CONTENT_RETRY_MIN_TOKENS = 2048
    EMPTY_CONTENT_RETRY_MAX_TOKENS = 4096

    def __init__(self, api_key: str, base_url: str, model: str, timeout: int | None = None,
                 proxy_url: str | None = None, max_timeout_seconds: float | None = None):
        self.model_name = model
        try:
            timeout_cap = (
                float(max_timeout_seconds)
                if max_timeout_seconds is not None
                else AGENT_TIMEOUT_SECONDS
            )
        except (TypeError, ValueError):
            timeout_cap = AGENT_TIMEOUT_SECONDS
        timeout_cap = max(1.0, timeout_cap)
        try:
            configured_timeout = float(timeout) if timeout else AGENT_TIMEOUT_SECONDS
        except (TypeError, ValueError):
            configured_timeout = AGENT_TIMEOUT_SECONDS
        self.timeout_seconds = max(1.0, min(configured_timeout, timeout_cap))
        # Retry policy belongs to the caller (element/page-step orchestration).
        # SDK retries multiply one configured timeout into several invisible
        # requests and can consume the whole recovery budget.
        kwargs = {
            'api_key': api_key,
            'base_url': base_url,
            'timeout': self.timeout_seconds,
            'max_retries': 0,
        }
        http_kwargs = {'trust_env': False, 'timeout': self.timeout_seconds}
        if str(proxy_url or '').strip():
            http_kwargs['proxy'] = str(proxy_url).strip()
        self.client = OpenAI(
            **kwargs,
            http_client=DefaultHttpxClient(**http_kwargs),
        )
        self.async_client = AsyncOpenAI(
            **kwargs,
            http_client=DefaultAsyncHttpxClient(**http_kwargs),
        )
        self._response_format_mode = 'json_schema'

    async def complete_async(self, messages: list[dict], *, max_tokens: int, temperature: float,
                             response_format: dict | None = None) -> str:
        kwargs = self._completion_kwargs(messages, max_tokens, temperature, response_format)
        try:
            response = await self.async_client.chat.completions.create(**kwargs)
        except Exception as error:
            if not self._can_fallback_to_json_object(error, response_format):
                raise
            self._response_format_mode = 'json_object'
            kwargs['response_format'] = {'type': 'json_object'}
            response = await self.async_client.chat.completions.create(**kwargs)
        content = self._response_content(response)
        if not content:
            retry_kwargs = self._empty_content_retry_kwargs(kwargs)
            response = await self.async_client.chat.completions.create(**retry_kwargs)
            content = self._response_content(response)
        return content

    def complete_sync(self, messages: list[dict], *, max_tokens: int, temperature: float,
                      response_format: dict | None = None) -> str:
        kwargs = self._completion_kwargs(messages, max_tokens, temperature, response_format)
        try:
            response = self.client.chat.completions.create(**kwargs)
        except Exception as error:
            if not self._can_fallback_to_json_object(error, response_format):
                raise
            self._response_format_mode = 'json_object'
            kwargs['response_format'] = {'type': 'json_object'}
            response = self.client.chat.completions.create(**kwargs)
        content = self._response_content(response)
        if not content:
            retry_kwargs = self._empty_content_retry_kwargs(kwargs)
            response = self.client.chat.completions.create(**retry_kwargs)
            content = self._response_content(response)
        return content

    @staticmethod
    def _response_content(response) -> str:
        if not getattr(response, 'choices', None):
            return ''
        content = getattr(response.choices[0].message, 'content', '')
        if isinstance(content, str):
            return content.strip()
        if not isinstance(content, list):
            return ''
        parts = []
        for item in content:
            if isinstance(item, dict):
                value = item.get('text') or item.get('content')
            else:
                value = getattr(item, 'text', None) or getattr(item, 'content', None)
            if isinstance(value, str):
                parts.append(value)
        return ''.join(parts).strip()

    def _empty_content_retry_kwargs(self, kwargs: dict) -> dict:
        retry_kwargs = dict(kwargs)
        current_tokens = int(retry_kwargs.get('max_tokens') or 0)
        retry_kwargs['max_tokens'] = min(
            self.EMPTY_CONTENT_RETRY_MAX_TOKENS,
            max(self.EMPTY_CONTENT_RETRY_MIN_TOKENS, current_tokens * 4),
        )
        return retry_kwargs

    def _completion_kwargs(self, messages: list[dict], max_tokens: int, temperature: float,
                           response_format: dict | None) -> dict:
        kwargs = {
            'model': self.model_name,
            'messages': messages,
            'temperature': temperature,
            'max_tokens': max_tokens,
        }
        if response_format:
            kwargs['response_format'] = (
                {'type': 'json_object'}
                if self._response_format_mode == 'json_object'
                else response_format
            )
        return kwargs

    def _can_fallback_to_json_object(self, error: Exception, response_format: dict | None) -> bool:
        if not response_format or self._response_format_mode != 'json_schema':
            return False
        if getattr(error, 'status_code', None) not in (400, 404, 422):
            return False
        message = str(error).lower()
        return any(value in message for value in (
            'response_format', 'json_schema', 'json schema', 'structured output',
        ))
