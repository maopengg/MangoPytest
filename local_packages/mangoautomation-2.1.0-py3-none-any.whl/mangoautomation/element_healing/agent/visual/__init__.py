# -*- coding: utf-8 -*-
from .agent import WebVisualLocatorAgent

__all__ = ['WebVisualLocatorAgent']
