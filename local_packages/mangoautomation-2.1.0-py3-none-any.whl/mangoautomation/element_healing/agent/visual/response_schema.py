# -*- coding: utf-8 -*-
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


SCHEMA_VERSION = 'visual-target-v1'


class VisualCandidatePayload(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)

    marker_id: str = Field(pattern=r'^v[1-9]\d*$')
    confidence: int = Field(ge=0, le=100)
    reason: str = Field(min_length=1, max_length=300)


class VisualLocatorResponse(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)

    schema_version: Literal[SCHEMA_VERSION]
    status: Literal['matched', 'ambiguous', 'not_found']
    reason: str = Field(min_length=1, max_length=500)
    candidates: list[VisualCandidatePayload] = Field(max_length=5)

    @classmethod
    def openai_response_format(cls) -> dict:
        return {
            'type': 'json_schema',
            'json_schema': {
                'name': 'web_visual_target_candidates',
                'strict': True,
                'schema': cls.model_json_schema(),
            },
        }
