# -*- coding: utf-8 -*-
import base64
import json
import logging

from pydantic import ValidationError
from mangoautomation.prompts import get_prompt

from ...models import CandidateSource
from ...snapshot import AccessibilitySnapshotBuilder
from ..web.candidate_normalizer import AgentCandidateNormalizer
from ..web.response_schema import WebLocatorCandidatePayload
from .response_schema import SCHEMA_VERSION, VisualLocatorResponse

log = logging.getLogger(__name__)

_OVERLAY_ATTRIBUTE = 'data-mango-visual-overlay'
_PROMPT = get_prompt('element_healing.visual_locator')


class WebVisualLocatorAgent:
    """Vision fallback that can only select numbered DOM-backed targets."""

    prompt_version = _PROMPT.version
    schema_version = SCHEMA_VERSION

    def __init__(self, model_client=None):
        self.model_client = model_client
        self.last_error: str | None = None
        self.last_status = 'idle'
        self.last_snapshot_id: str | None = None

    @property
    def available(self) -> bool:
        return bool(self.model_client and getattr(self.model_client, 'available', True))

    def reset_attempt(self):
        self.last_error = None
        self.last_status = 'idle'
        self.last_snapshot_id = None

    async def propose_async(self, page, context, _memory: dict):
        if not self.available:
            self.last_status = 'unavailable'
            self.last_error = '视觉模型未配置或当前不可用'
            return []
        snapshot = await AccessibilitySnapshotBuilder.build_async(page, limit=240)
        self.last_snapshot_id = snapshot.snapshot_id
        markers = self._markers(snapshot)
        if not markers:
            self.last_status = 'not_found'
            self.last_error = '当前视口内没有可供视觉模型选择的可交互元素'
            return []
        try:
            await self._draw_async(page, snapshot.snapshot_id, markers)
            image = await page.screenshot(type='jpeg', quality=55, full_page=False, timeout=8000)
        except Exception as error:
            self.last_status = 'screenshot_failed'
            self.last_error = f'视觉定位截图生成失败：{str(error)[:300]}'
            return []
        finally:
            try:
                await self._clear_async(page)
            except Exception:
                pass
        return await self._complete_async(context, snapshot, markers, image)

    def propose_sync(self, page, context, _memory: dict):
        if not self.available:
            self.last_status = 'unavailable'
            self.last_error = '视觉模型未配置或当前不可用'
            return []
        snapshot = AccessibilitySnapshotBuilder.build_sync(page, limit=240)
        self.last_snapshot_id = snapshot.snapshot_id
        markers = self._markers(snapshot)
        if not markers:
            self.last_status = 'not_found'
            self.last_error = '当前视口内没有可供视觉模型选择的可交互元素'
            return []
        try:
            self._draw_sync(page, snapshot.snapshot_id, markers)
            image = page.screenshot(type='jpeg', quality=55, full_page=False, timeout=8000)
        except Exception as error:
            self.last_status = 'screenshot_failed'
            self.last_error = f'视觉定位截图生成失败：{str(error)[:300]}'
            return []
        finally:
            try:
                self._clear_sync(page)
            except Exception:
                pass
        return self._complete_sync(context, snapshot, markers, image)

    async def _complete_async(self, context, snapshot, markers, image: bytes):
        try:
            content = await self.model_client.complete_async(
                self._messages(context, markers, image), max_tokens=600, temperature=0,
                response_format=VisualLocatorResponse.openai_response_format(),
            )
            parsed = self._parse(content)
            return self._normalize(parsed, snapshot, markers, context)
        except Exception as error:
            self.last_status = 'failed'
            self.last_error = f'视觉模型响应无效：{str(error)[:400]}'
            log.debug('[Web Visual Locator Agent] %s', self.last_error)
            return []

    def _complete_sync(self, context, snapshot, markers, image: bytes):
        try:
            content = self.model_client.complete_sync(
                self._messages(context, markers, image), max_tokens=600, temperature=0,
                response_format=VisualLocatorResponse.openai_response_format(),
            )
            parsed = self._parse(content)
            return self._normalize(parsed, snapshot, markers, context)
        except Exception as error:
            self.last_status = 'failed'
            self.last_error = f'视觉模型响应无效：{str(error)[:400]}'
            log.debug('[Web Visual Locator Agent] %s', self.last_error)
            return []

    def _normalize(self, parsed, snapshot, markers, context):
        self.last_status = parsed.status
        if parsed.status != 'matched':
            self.last_error = parsed.reason
        ref_by_marker = {item['marker_id']: item['target_ref'] for item in markers}
        rows = []
        for item in parsed.candidates:
            target_ref = ref_by_marker.get(item.marker_id)
            if not target_ref:
                continue
            rows.append(WebLocatorCandidatePayload(
                source='ai_accessibility',
                target_ref=target_ref,
                confidence=item.confidence,
                reason=item.reason,
            ))
        result = AgentCandidateNormalizer.normalize(
            rows,
            snapshot,
            [item.loc for item in context.failed_locators],
            generated_by_ai=True,
            selection_strategy='visual_marker',
            source=CandidateSource.VISUAL_AGENT,
            schema_version=SCHEMA_VERSION,
        )
        if not result and not self.last_error:
            self.last_error = parsed.reason or '视觉模型返回的编号无法生成唯一稳定定位器'
        if result:
            self.last_status = 'success'
        return result

    @staticmethod
    def _parse(content: str) -> VisualLocatorResponse:
        text = str(content or '').strip()
        if not text:
            raise ValueError('视觉模型返回内容为空')
        try:
            value = json.loads(text)
            parsed = VisualLocatorResponse.model_validate(value, strict=True)
        except (json.JSONDecodeError, ValidationError) as error:
            raise ValueError(f'未返回 visual-target-v1 JSON：{error}') from error
        if parsed.status == 'matched' and not parsed.candidates:
            raise ValueError('视觉模型声明已匹配，但没有返回候选编号')
        return parsed

    @staticmethod
    def _markers(snapshot) -> list[dict]:
        result = []
        for node in snapshot.nodes:
            rect = node.rect
            if (
                node.frame_index != 0 or not node.visible or not node.interactive or
                rect is None or rect.width < 2 or rect.height < 2 or
                rect.x + rect.width <= 0 or rect.y + rect.height <= 0
            ):
                continue
            result.append({
                'marker_id': f'v{len(result) + 1}',
                'target_ref': node.ref,
                'role': node.role,
                'name': node.name,
                'text': node.text[:120],
                'nearby_text': node.nearby_text[:160],
                'rect': rect.model_dump(),
            })
            if len(result) >= 80:
                break
        return result

    @staticmethod
    def _messages(context, markers, image: bytes) -> list[dict]:
        target = {
            'element_name': context.element_name,
            'description': context.resolved_description or context.description_template,
            'operation': context.operation_key,
            'page_url': context.page_url,
            'candidates': markers,
        }
        prompt = _PROMPT.render(
            'user',
            target=json.dumps(target, ensure_ascii=False, separators=(',', ':')),
        )
        data_url = 'data:image/jpeg;base64,' + base64.b64encode(image).decode('ascii')
        return [
            {
                'role': 'system',
                'content': _PROMPT.system,
            },
            {
                'role': 'user',
                'content': [
                    {'type': 'text', 'text': prompt},
                    {'type': 'image_url', 'image_url': {'url': data_url, 'detail': 'low'}},
                ],
            },
        ]

    @staticmethod
    async def _draw_async(page, snapshot_id: str, markers: list[dict]):
        await page.evaluate(WebVisualLocatorAgent._overlay_script(), {
            'snapshot_id': snapshot_id,
            'markers': markers,
        })

    @staticmethod
    def _draw_sync(page, snapshot_id: str, markers: list[dict]):
        page.evaluate(WebVisualLocatorAgent._overlay_script(), {
            'snapshot_id': snapshot_id,
            'markers': markers,
        })

    @staticmethod
    async def _clear_async(page):
        await page.evaluate("document.querySelectorAll('[data-mango-visual-overlay]').forEach(e => e.remove())")

    @staticmethod
    def _clear_sync(page):
        page.evaluate("document.querySelectorAll('[data-mango-visual-overlay]').forEach(e => e.remove())")

    @staticmethod
    def _overlay_script() -> str:
        return r"""(options) => {
          document.querySelectorAll('[data-mango-visual-overlay]').forEach(e => e.remove());
          const root = document.createElement('div');
          root.setAttribute('data-mango-visual-overlay', 'root');
          root.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:none;overflow:hidden';
          const sensitiveSelectors = [
            'input[type="password"]',
            '[autocomplete="current-password"]',
            '[autocomplete="new-password"]',
            '[data-sensitive="true"]',
            '[name*="token" i]',
            '[name*="secret" i]',
            '[name*="authorization" i]',
            '[name*="cookie" i]',
            '[name*="api-key" i]',
            '[name*="access-key" i]'
          ];
          for (const element of document.querySelectorAll(sensitiveSelectors.join(','))) {
            const rect = element.getBoundingClientRect();
            if (rect.width < 1 || rect.height < 1 || rect.bottom <= 0 || rect.right <= 0) continue;
            const mask = document.createElement('div');
            mask.setAttribute('data-mango-visual-overlay', 'sensitive-mask');
            mask.style.cssText = `position:absolute;left:${rect.x}px;top:${rect.y}px;width:${rect.width}px;height:${rect.height}px;background:#111;box-sizing:border-box`;
            root.appendChild(mask);
          }
          for (const marker of options.markers || []) {
            const expected = `${options.snapshot_id}:${marker.target_ref}`;
            const element = document.querySelector(`[data-mango-healing-ref="${expected}"]`);
            if (!element) continue;
            const rect = element.getBoundingClientRect();
            const box = document.createElement('div');
            box.setAttribute('data-mango-visual-overlay', marker.marker_id);
            box.style.cssText = `position:absolute;left:${rect.x}px;top:${rect.y}px;width:${rect.width}px;height:${rect.height}px;border:2px solid #ff2d2d;box-sizing:border-box`;
            const label = document.createElement('span');
            label.textContent = marker.marker_id;
            label.style.cssText = 'position:absolute;left:-2px;top:-20px;background:#ff2d2d;color:white;font:700 13px/18px sans-serif;padding:0 4px;border-radius:2px';
            box.appendChild(label);
            root.appendChild(box);
          }
          document.documentElement.appendChild(root);
        }"""
