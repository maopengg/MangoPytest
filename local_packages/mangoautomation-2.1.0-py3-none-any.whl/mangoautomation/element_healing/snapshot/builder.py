# -*- coding: utf-8 -*-
import json
import re
import time
from uuid import uuid4

from pydantic import ValidationError

from ..baseline import sanitize_json_value
from ..baseline.sanitizer import sanitize_attributes, sanitize_url
from .models import AccessibilitySnapshot, AccessibilitySnapshotNode
from .renderer import AccessibilitySnapshotRenderer
from .scripts import ACCESSIBILITY_SNAPSHOT_SCRIPT


class AccessibilitySnapshotBuilder:
    DEFAULT_LIMIT = 200
    PLAYWRIGHT_ARIA_ENGINE = 'playwright_aria'
    _NATIVE_REF_PATTERN = re.compile(r'\[ref=(e[1-9]\d*)\]')
    _NATIVE_PROPERTY_PATTERN = re.compile(r'\[([^\]]+)\]')

    @classmethod
    async def build_async(cls, page, limit: int | None = None) -> AccessibilitySnapshot:
        native_error = None
        native_method = getattr(page, 'aria_snapshot', None)
        if callable(native_method):
            try:
                tree = await native_method(mode='ai', boxes=True)
                snapshot = cls._build_native_snapshot(tree, cls._url(page))
                if snapshot.nodes:
                    return snapshot
                native_error = 'Playwright AI snapshot did not expose any element refs'
            except Exception as error:
                native_error = f'Playwright AI snapshot unavailable: {str(error)[:300]}'
        snapshot = await cls._build_dom_async(page, limit or cls.DEFAULT_LIMIT)
        if native_error:
            snapshot.errors.insert(0, native_error)
            snapshot.errors = snapshot.errors[:10]
        return snapshot

    @classmethod
    async def _build_dom_async(cls, page, limit: int) -> AccessibilitySnapshot:
        snapshot_id = uuid4().hex[:16]
        nodes = []
        errors = []
        next_index = 1
        for frame_index, frame in enumerate(cls._frames(page)):
            remaining = max(0, int(limit) - len(nodes))
            if not remaining:
                break
            try:
                raw = await frame.evaluate(ACCESSIBILITY_SNAPSHOT_SCRIPT, {
                    'snapshot_id': snapshot_id,
                    'start_index': next_index,
                    'limit': remaining,
                })
                frame_nodes, next_index = cls._normalize_frame_result(
                    raw, frame_index, cls._url(frame), next_index, errors,
                )
                nodes.extend(frame_nodes)
            except Exception as error:
                errors.append(f'frame[{frame_index}] {str(error)[:300]}')
        return cls._build_snapshot(snapshot_id, cls._url(page), nodes, errors)

    @classmethod
    def build_sync(cls, page, limit: int | None = None) -> AccessibilitySnapshot:
        native_error = None
        native_method = getattr(page, 'aria_snapshot', None)
        if callable(native_method):
            try:
                tree = native_method(mode='ai', boxes=True)
                snapshot = cls._build_native_snapshot(tree, cls._url(page))
                if snapshot.nodes:
                    return snapshot
                native_error = 'Playwright AI snapshot did not expose any element refs'
            except Exception as error:
                native_error = f'Playwright AI snapshot unavailable: {str(error)[:300]}'
        snapshot = cls._build_dom_sync(page, limit or cls.DEFAULT_LIMIT)
        if native_error:
            snapshot.errors.insert(0, native_error)
            snapshot.errors = snapshot.errors[:10]
        return snapshot

    @classmethod
    def _build_dom_sync(cls, page, limit: int) -> AccessibilitySnapshot:
        snapshot_id = uuid4().hex[:16]
        nodes = []
        errors = []
        next_index = 1
        for frame_index, frame in enumerate(cls._frames(page)):
            remaining = max(0, int(limit) - len(nodes))
            if not remaining:
                break
            try:
                raw = frame.evaluate(ACCESSIBILITY_SNAPSHOT_SCRIPT, {
                    'snapshot_id': snapshot_id,
                    'start_index': next_index,
                    'limit': remaining,
                })
                frame_nodes, next_index = cls._normalize_frame_result(
                    raw, frame_index, cls._url(frame), next_index, errors,
                )
                nodes.extend(frame_nodes)
            except Exception as error:
                errors.append(f'frame[{frame_index}] {str(error)[:300]}')
        return cls._build_snapshot(snapshot_id, cls._url(page), nodes, errors)

    @classmethod
    def _build_native_snapshot(cls, tree, page_url: str) -> AccessibilitySnapshot:
        if not isinstance(tree, str):
            raise TypeError('Playwright AI snapshot must be YAML text')
        snapshot_id = f'pw-{uuid4().hex[:16]}'
        nodes = []
        parent_stack = []
        for order, raw_line in enumerate(tree.splitlines()):
            ref_match = cls._NATIVE_REF_PATTERN.search(raw_line)
            if not ref_match:
                continue
            indent = len(raw_line) - len(raw_line.lstrip(' '))
            while parent_stack and parent_stack[-1][0] >= indent:
                parent_stack.pop()
            body = raw_line.strip()
            if body.startswith('- '):
                body = body[2:]
            ref = ref_match.group(1)
            prefix = cls._NATIVE_PROPERTY_PATTERN.sub(
                '', body[:ref_match.start()],
            ).strip().rstrip(':').strip()
            role, name = cls._native_role_and_name(prefix)
            properties = cls._native_properties(body)
            editable = role in {'textbox', 'searchbox', 'combobox', 'spinbutton'}
            node = AccessibilitySnapshotNode(
                ref=ref,
                parent_ref=parent_stack[-1][1] if parent_stack else None,
                frame_index=0,
                frame_url=page_url,
                order=order,
                role=role,
                name=name,
                text=name,
                visible=True,
                disabled=cls._native_bool(properties.get('disabled')) is True,
                editable=editable,
                interactive=True,
                checked=cls._native_bool(properties.get('checked')),
                selected=cls._native_bool(properties.get('selected')),
                expanded=cls._native_bool(properties.get('expanded')),
                required=cls._native_bool(properties.get('required')) is True,
                level=cls._native_int(properties.get('level')),
                attributes={},
                path=[],
            )
            nodes.append(node)
            parent_stack.append((indent, ref))
        return AccessibilitySnapshot(
            snapshot_id=snapshot_id,
            ref_engine=cls.PLAYWRIGHT_ARIA_ENGINE,
            page_url=page_url,
            created_at_ms=int(time.time() * 1000),
            nodes=nodes,
            tree=tree,
            errors=[],
        )

    @staticmethod
    def _native_role_and_name(prefix: str) -> tuple[str, str]:
        if not prefix:
            return 'generic', ''
        role, _, remainder = prefix.partition(' ')
        name = remainder.strip()
        if name.startswith('"'):
            try:
                name, _ = json.JSONDecoder().raw_decode(name)
            except (TypeError, ValueError, json.JSONDecodeError):
                name = name.strip('"')
        if '[ref=e' in str(name):
            name = ''
        return role.strip() or 'generic', str(name or '').strip()

    @classmethod
    def _native_properties(cls, body: str) -> dict[str, str | bool]:
        result = {}
        for value in cls._NATIVE_PROPERTY_PATTERN.findall(body):
            if value.startswith('ref=') or value.startswith('box='):
                continue
            key, separator, item = value.partition('=')
            result[key.strip()] = item.strip() if separator else True
        return result

    @staticmethod
    def _native_bool(value) -> bool | None:
        if value is None:
            return None
        if value is True:
            return True
        if str(value).lower() == 'true':
            return True
        if str(value).lower() == 'false':
            return False
        return None

    @staticmethod
    def _native_int(value) -> int | None:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _frames(page) -> list:
        frames = getattr(page, 'frames', None)
        return list(frames) if isinstance(frames, (list, tuple)) and frames else [page]

    @staticmethod
    def _url(target) -> str:
        value = getattr(target, 'url', '')
        return sanitize_url(value if isinstance(value, str) else '')

    @classmethod
    def _normalize_frame_result(cls, raw, frame_index: int, frame_url: str,
                                next_index: int, errors: list[str]):
        if not isinstance(raw, dict):
            return [], next_index
        result = []
        for row in raw.get('nodes') or []:
            if not isinstance(row, dict):
                continue
            value = sanitize_json_value(row)
            value['frame_index'] = frame_index
            value['frame_url'] = frame_url
            value['attributes'] = {
                str(key): str(item or '')
                for key, item in sanitize_attributes(value.get('attributes')).items()
            }
            try:
                result.append(AccessibilitySnapshotNode.model_validate(value, strict=True))
            except ValidationError as error:
                errors.append(f'frame[{frame_index}] invalid node: {str(error)[:300]}')
        raw_next = raw.get('next_index')
        try:
            parsed_next = int(raw_next)
        except (TypeError, ValueError):
            parsed_next = next_index + len(result)
        return result, max(parsed_next, next_index + len(result))

    @staticmethod
    def _build_snapshot(snapshot_id: str, page_url: str,
                        nodes: list[AccessibilitySnapshotNode], errors: list[str]):
        return AccessibilitySnapshot(
            snapshot_id=snapshot_id,
            page_url=page_url,
            created_at_ms=int(time.time() * 1000),
            nodes=nodes,
            tree=AccessibilitySnapshotRenderer.render(nodes),
            errors=errors[:10],
        )
