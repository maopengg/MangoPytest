# -*- coding: utf-8 -*-
import re

from mangoautomation.enums import ElementExpEnum

from ..models import LocatorCandidate


class LiveStableLocatorDeriver:
    """Derive persistent locators from an exact, snapshot-marked live node."""

    MAX_CANDIDATES = 16
    COMPONENT_CLASS_PATTERN = re.compile(
        r'^(?:arco|ant|el|ivu|van|mui)-[a-z][a-z0-9_-]*$', re.I,
    )
    GENERIC_CLASS_PATTERN = re.compile(r'^[a-z_][a-z0-9_-]{2,79}$', re.I)
    UNSTABLE_CLASS_PARTS = (
        'active', 'checked', 'disabled', 'focus', 'hidden', 'hover', 'open',
        'selected', 'visible', 'enter', 'leave', 'animation', 'position-',
    )

    _ELEMENT_CONTEXT_SCRIPT = r"""(element) => {
      const compact = (value, limit = 500) => String(value || '')
        .replace(/\s+/g, ' ').trim().slice(0, limit);
      const attributeValue = (target, names) => {
        for (const name of names) {
          const value = compact(target.getAttribute(name), 180);
          if (value) return value;
        }
        return '';
      };
      const roleOf = target => {
        const explicit = compact(target.getAttribute('role'), 60).split(' ')[0];
        if (explicit) return explicit;
        const tag = target.tagName.toLowerCase();
        const type = compact(target.getAttribute('type'), 30).toLowerCase();
        if (tag === 'button') return 'button';
        if (tag === 'a' && target.hasAttribute('href')) return 'link';
        if (tag === 'select') return 'combobox';
        if (tag === 'textarea') return 'textbox';
        if (target.isContentEditable) return 'textbox';
        if (tag === 'input' && type === 'checkbox') return 'checkbox';
        if (tag === 'input' && type === 'radio') return 'radio';
        if (tag === 'input' && !['button', 'submit', 'reset', 'file', 'hidden'].includes(type)) return 'textbox';
        return '';
      };
      const row = (target) => ({
        tag: target.tagName.toLowerCase(),
        role: roleOf(target),
        text: compact(target.innerText || target.textContent, 240),
        aria_label: compact(target.getAttribute('aria-label'), 240),
        id: compact(target.getAttribute('id'), 180),
        name: compact(target.getAttribute('name'), 180),
        placeholder: compact(target.getAttribute('placeholder'), 240),
        title: compact(target.getAttribute('title'), 240),
        editable: target.isContentEditable,
        editable_count: target.isContentEditable
          ? document.querySelectorAll('[contenteditable="true"]').length : 0,
        testid: attributeValue(target, ['data-testid', 'data-test-id', 'data-cy', 'data-qa']),
        classes: Array.from(target.classList || []).map((item) => compact(item, 120)).filter(Boolean),
        class_counts: Object.fromEntries(
          Array.from(target.classList || []).map((item) => [
            compact(item, 120), document.getElementsByClassName(item).length
          ])
        )
      });
      const ancestors = [];
      let current = element.parentElement;
      while (current && current !== document.documentElement && ancestors.length < 12) {
        ancestors.push(row(current));
        current = current.parentElement;
      }
      return { target: row(element), ancestors };
    }"""

    @classmethod
    async def build_async(cls, selected) -> list[LocatorCandidate]:
        try:
            context = await selected.locator.evaluate(cls._ELEMENT_CONTEXT_SCRIPT)
        except Exception:
            return []
        return cls._build(selected.verification.candidate, context)

    @classmethod
    def build_sync(cls, selected) -> list[LocatorCandidate]:
        try:
            context = selected.locator.evaluate(cls._ELEMENT_CONTEXT_SCRIPT)
        except Exception:
            return []
        return cls._build(selected.verification.candidate, context)

    @classmethod
    def _build(cls, selected_candidate, context) -> list[LocatorCandidate]:
        if not isinstance(context, dict):
            return []
        target = context.get('target') or {}
        metadata = dict(getattr(selected_candidate, 'metadata', None) or {})
        metadata.pop('transient_snapshot_ref_only', None)
        normalized_target = bool(metadata.get('operation_target_strategy'))
        text = cls._clean(
            target.get('text') if normalized_target else metadata.get('snapshot_node_text')
        )
        name = cls._clean(
            target.get('aria_label') or target.get('text')
            if normalized_target else metadata.get('snapshot_node_name')
        )
        role = cls._clean(
            target.get('role') if normalized_target else metadata.get('snapshot_node_role')
        )
        label = '' if normalized_target else cls._clean(metadata.get('snapshot_node_label'))

        expressions = []
        testid = cls._clean(target.get('testid'))
        element_id = cls._clean(target.get('id'))
        element_name = cls._clean(target.get('name'))
        tag = cls._clean(target.get('tag')).lower()
        placeholder = cls._clean(target.get('placeholder'))
        title = cls._clean(target.get('title'))
        aria_label = cls._clean(target.get('aria_label'))
        if target.get('editable') and target.get('editable_count') == 1:
            expressions.append(('editable_attribute', "locator('[contenteditable=\"true\"]')"))
        if testid:
            expressions.append(('test_id', f'get_by_test_id({testid!r})'))
        if element_id and not cls._dynamic_id(element_id):
            expressions.append(('stable_id', f'locator({cls._attribute_selector("id", element_id)!r})'))
        if tag and element_name:
            selector = f'{tag}{cls._attribute_selector("name", element_name)}'
            expressions.append(('name_attribute', f'locator({selector!r})'))
        if label:
            expressions.append(('label', f'get_by_label({label!r}, exact=True)'))
        if placeholder:
            expressions.append(('placeholder', f'get_by_placeholder({placeholder!r}, exact=True)'))
        if title:
            expressions.append(('title', f'get_by_title({title!r}, exact=True)'))
        for token in cls._stable_class_tokens(target):
            selector = cls._attribute_selector('class~', token)
            expressions.append(('unique_class', f'locator({selector!r})'))
        if role and role != 'generic' and (name or aria_label):
            expressions.append(('role_name', f'get_by_role({role!r}, name={(name or aria_label)!r}, exact=True)'))
        if text:
            expressions.append(('text', f'get_by_text({text!r}, exact=True)'))

        child_expressions = []
        if role and role != 'generic' and (name or aria_label):
            child_expressions.append(f'get_by_role({role!r}, name={(name or aria_label)!r}, exact=True)')
        if text:
            child_expressions.append(f'get_by_text({text!r}, exact=True)')
        ancestors = context.get('ancestors') or []
        prioritized_anchors = []
        for depth, ancestor in enumerate(ancestors):
            for priority, anchor_strategy, anchor in cls._ancestor_anchors(ancestor):
                prioritized_anchors.append((priority, depth, anchor_strategy, anchor))
        for _, _, anchor_strategy, anchor in sorted(prioritized_anchors):
                for child in child_expressions:
                    expressions.append((f'{anchor_strategy}_scoped', f'{anchor}.{child}'))

        result = []
        seen = set()
        for strategy, loc in expressions:
            key = (ElementExpEnum.LOCATOR.value, loc, None)
            if key in seen:
                continue
            seen.add(key)
            result.append(LocatorCandidate(
                source='snapshot_live_derived',
                initial_score=96,
                exp=ElementExpEnum.LOCATOR.value,
                loc=loc,
                sub=None,
                reason='derived from the exact live node selected by snapshot ref',
                generated_by_ai=False,
                metadata={
                    **metadata,
                    'snapshot_matcher_validated': True,
                    'snapshot_ref_resolved': True,
                    'durable_locator_strategy': strategy,
                },
            ))
            if len(result) >= cls.MAX_CANDIDATES:
                break
        return result

    @classmethod
    def _ancestor_anchors(cls, ancestor):
        if not isinstance(ancestor, dict):
            return []
        result = []
        testid = cls._clean(ancestor.get('testid'))
        element_id = cls._clean(ancestor.get('id'))
        role = cls._clean(ancestor.get('role'))
        if testid:
            result.append((0, 'ancestor_test_id', f'get_by_test_id({testid!r})'))
        if element_id and not cls._dynamic_id(element_id):
            selector = cls._attribute_selector('id', element_id)
            result.append((0, 'ancestor_stable_id', f'locator({selector!r})'))
        if role in {'dialog', 'listbox', 'menu', 'tree', 'grid', 'form'}:
            result.append((1, 'ancestor_role', f'get_by_role({role!r})'))
        class_counts = ancestor.get('class_counts') or {}
        for token in cls._stable_class_tokens(ancestor):
            selector = cls._attribute_selector('class~', token)
            count = class_counts.get(token)
            priority = 2 if count == 1 else 3
            result.append((priority, 'component_scope', f'locator({selector!r})'))
        return result

    @classmethod
    def _stable_class_tokens(cls, row) -> list[str]:
        if not isinstance(row, dict):
            return []
        counts = row.get('class_counts') or {}
        result = []
        for raw_token in row.get('classes') or []:
            token = cls._clean(raw_token)
            lowered = token.lower()
            if not cls.GENERIC_CLASS_PATTERN.fullmatch(token):
                continue
            if any(part in lowered for part in cls.UNSTABLE_CLASS_PARTS):
                continue
            if re.search(r'(?:^|[-_])[a-f0-9]{8,}(?:[-_]|$)|\d{6,}', token, re.I):
                continue
            if lowered in {
                    'block', 'container', 'content', 'flex', 'grid', 'relative',
                    'absolute', 'fixed', 'wrapper', 'root', 'item'}:
                continue
            result.append(token)
        return sorted(
            set(result),
            key=lambda token: (
                0 if counts.get(token) == 1 else 1,
                0 if cls.COMPONENT_CLASS_PATTERN.fullmatch(token) else 1,
                len(token),
                token,
            ),
        )

    @staticmethod
    def _attribute_selector(name: str, value: str) -> str:
        escaped = value.replace('\\', '\\\\').replace('"', '\\"')
        if name == 'class~':
            return f'[class~="{escaped}"]'
        return f'[{name}="{escaped}"]'

    @staticmethod
    def _dynamic_id(value: str) -> bool:
        return bool(re.search(r'(?:^|[-_])[0-9a-f]{8,}(?:[-_]|$)|\d{8,}|^[0-9]+$', value, re.I))

    @staticmethod
    def _clean(value) -> str:
        value = re.sub(r'[\u200b\u200c\u200d\ufeff]+', '', str(value or ''))
        return ' '.join(value.split()).strip()[:500]
