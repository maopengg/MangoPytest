# -*- coding: utf-8 -*-
from uuid import uuid4

from ..models import ElementSemantics, FailedLocator, HealingContext, HealingTrigger
from ..policy.operation_rules import operation_intent
from .sanitizer import first_prompt, target_texts


class HealingContextBuilder:
    @classmethod
    async def build_async(cls, page, element_model, failed_expression, find_params, error, test_env=None,
                          runtime_config=None):
        title = None
        try:
            title = await page.title()
        except Exception:
            pass
        return cls._build(
            page, title, element_model, failed_expression, find_params, error, test_env,
            runtime_config,
        )

    @classmethod
    def build_sync(cls, page, element_model, failed_expression, find_params, error, test_env=None,
                   runtime_config=None):
        title = None
        try:
            title = page.title()
        except Exception:
            pass
        return cls._build(
            page, title, element_model, failed_expression, find_params, error, test_env,
            runtime_config,
        )

    @classmethod
    def _build(cls, page, title, element_model, failed_expression, find_params, error, test_env,
               runtime_config=None):
        trigger_error = getattr(error, 'msg', None) or getattr(error, 'message', None) or str(error or '')
        prompt = first_prompt(element_model)
        fixed_locators = [item for item in getattr(element_model, 'elements', []) if getattr(item, 'loc', None)]
        current_operation_key = (find_params or {}).get('ope_key')
        return HealingContext(
            trace_id=uuid4().hex,
            element_id=getattr(element_model, 'element_id', None) or getattr(element_model, 'id', None),
            element_name=getattr(element_model, 'name', None),
            category=getattr(element_model, 'category', None),
            prompt=prompt,
            description_template=getattr(element_model, 'description_template', None) or prompt,
            resolved_description=prompt,
            element_version=getattr(element_model, 'element_version', None),
            test_env=test_env,
            operation_key=current_operation_key,
            operation_intent=operation_intent(current_operation_key),
            operation_type=(find_params or {}).get('type') or (find_params or {}).get('_type'),
            origin_exp=(find_params or {}).get('exp'),
            origin_loc=(find_params or {}).get('loc'),
            origin_sub=(find_params or {}).get('sub'),
            page_url=getattr(page, 'url', None),
            page_title=title,
            expected_page_url=getattr(element_model, 'page_url', None),
            frame_path=list(getattr(element_model, 'frame_path', None) or []),
            failed_locators=[FailedLocator(loc=str(item)) for item in failed_expression or [] if item],
            trigger=(
                HealingTrigger.DESCRIPTION_ONLY
                if not fixed_locators
                else cls._trigger(error, failed_expression, find_params)
            ),
            trigger_error=str(trigger_error or '')[:500] or None,
            expected_semantics=ElementSemantics(target_texts=target_texts(element_model)),
            fixed_locator_retry_seconds=cls._runtime_number(
                runtime_config, 'fixed_locator_retry_seconds', 10,
            ),
            smart_locator_timeout_seconds=cls._runtime_number(
                runtime_config, 'smart_locator_timeout_seconds', 30,
            ),
            visual_locator_enabled=cls._runtime_bool(
                runtime_config, 'visual_locator_enabled', False,
            ),
        )

    @staticmethod
    def _runtime_number(runtime_config, method: str, default: float) -> float:
        callback = getattr(runtime_config, method, None)
        try:
            return max(0.0, float(callback())) if callable(callback) else default
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _runtime_bool(runtime_config, method: str, default: bool) -> bool:
        callback = getattr(runtime_config, method, None)
        try:
            return bool(callback()) if callable(callback) else default
        except Exception:
            return default

    @staticmethod
    def _trigger(error, failed_expression, find_params):
        text = str(getattr(error, 'msg', None) or getattr(error, 'message', None) or error or '').lower()
        if '数量小于1' in text or 'count=0' in text or 'not found' in text:
            return HealingTrigger.ZERO_MATCH
        if '多个' in text or 'strict mode' in text or 'ambiguous' in text:
            return HealingTrigger.AMBIGUOUS_MATCH
        if 'semantic' in text or '语义' in text:
            return HealingTrigger.SEMANTIC_MISMATCH
        if 'clickable' in text or 'editable' in text or 'actionability' in text:
            return HealingTrigger.NOT_ACTIONABLE
        if error and (find_params or {}).get('operation_retry'):
            return HealingTrigger.RECOVERABLE_OPERATION_ERROR
        return HealingTrigger.LOCATOR_EXCEPTION
