"""Optional developer-error reporting, independent of the testing platform."""
import asyncio
import inspect
import json
import re
import traceback
from contextvars import ContextVar
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from mangoautomation.exceptions import MangoAutomationError
from mangotools.exceptions import MangoToolsError


_default_callback = ContextVar('automation_default_error_callback', default=None)


def configure_error_callback(callback):
    """为当前运行上下文创建的新驱动设置默认回调；传 None 清除。"""
    if callback is not None and not callable(callback):
        raise TypeError('异常回调必须可调用')
    return _default_callback.set(callback)


def reporter_for(owner):
    context = getattr(owner, 'base_data', owner)
    return getattr(context, 'system_error_reporter', None)


async def report_automation_error(owner, error, operation):
    try:
        reporter = reporter_for(owner)
        return await reporter.report(error, operation) if reporter is not None else False
    except Exception:
        return False


def report_automation_error_sync(owner, error, operation):
    try:
        reporter = reporter_for(owner)
        return reporter.report_sync(error, operation) if reporter is not None else False
    except Exception:
        return False


def redact(value):
    text = str(value or '')
    text = re.sub(r'(?i)(Bearer\s+)\S+', r'\1[REDACTED]', text)
    text = re.sub(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', '[REDACTED]', text)
    text = re.sub(r'(?i)([\w+.-]+://)[^\s/@]+:[^\s/@]+@', r'\1[REDACTED]@', text)
    text = re.sub(r'''(?i)(https?://[^\s?'"<>]+)\?[^\s'"<>]+''', r'\1?[REDACTED]', text)
    text = re.sub(r'(?im)\b((?:set-)?cookie|authorization)\s*:\s*[^\r\n]+', r'\1: [REDACTED]', text)
    text = re.sub(r'''(?ix)(["']?(?:authorization|cookie|password|passwd|secret(?:[-_]?key)?|access[-_]?key|api[-_]?key|token|signature|credential)["']?\s*[:=]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s,;}]+)''', r'\1[REDACTED]', text)
    return text


def developer_error(error):
    if not isinstance(error, Exception):
        return False
    if isinstance(error, (MangoAutomationError, MangoToolsError, AssertionError, TimeoutError, ConnectionError)):
        return False
    if any(base.__module__.startswith('httpx') and base.__name__ == 'HTTPError' for base in type(error).__mro__):
        return False
    # 定位超时、页面主动关闭是测试/设备状态，不是 Python 逻辑错误。
    if type(error).__module__.startswith(('playwright.', 'httpx.', 'websockets.')):
        return type(error).__name__ not in {'TimeoutError', 'TargetClosedError', 'ConnectError', 'ReadTimeout', 'ConnectionClosed', 'ConnectionClosedOK', 'ConnectionClosedError'}
    return True


def _message(error):
    if type(error).__module__.startswith('pydantic') and callable(getattr(error, 'errors', None)):
        return '; '.join(f'{item["loc"]}: {item["type"]}' for item in error.errors(include_input=False))
    return str(error) or type(error).__name__


def error_payload(error, operation, traceback_text=None):
    message = _message(error)
    # 不收集 locals、源码行、请求体或环境；保留文件/函数/行号用于定位。
    chain, seen, current = [], set(), error
    while isinstance(current, BaseException) and id(current) not in seen and len(chain) < 8:
        seen.add(id(current))
        frames = ''.join(f'  File "{frame.filename}", line {frame.lineno}, in {frame.name}\n'
                         for frame in traceback.extract_tb(current.__traceback__))
        chain.append(frames + type(current).__name__ + ': ' + _message(current))
        current = current.__cause__ or (None if current.__suppress_context__ else current.__context__)
    trace = traceback_text if traceback_text is not None else '\nCaused by:\n'.join(chain)
    return {'operation': redact(operation or 'unknown')[:255], 'exception_type': type(error).__name__[:128],
            'message': redact(message)[:500], 'traceback': redact(trace)[:50000]}


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class AutomationErrorReporter:
    """callback(error, operation) 或 url 二选一；均不改变原异常及测试结果。"""
    _reporting = ContextVar('automation_error_reporting', default=False)

    def __init__(self, callback=None, *, url=None, headers=None, timeout=3):
        if callback is None and url is None:
            callback = _default_callback.get()
        if callback is not None and not callable(callback):
            raise TypeError('system_error_callback 必须是可调用对象')
        if callback and url:
            raise ValueError('callback 和 url 只能设置一个')
        if url:
            parsed = urlsplit(url)
            if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.fragment:
                raise ValueError('异常回调地址必须是 HTTP/HTTPS 地址，凭据请放 headers')
        self.callback, self.url, self.headers = callback, url, dict(headers or {})
        self.timeout = min(10, max(0.1, float(timeout)))

    def _eligible(self, error):
        return ((self.callback is not None or self.url is not None) and developer_error(error)
                and not self._reporting.get() and not getattr(error, '_mango_system_error_reported', False))

    def _post(self, payload):
        request = Request(self.url, data=json.dumps(payload).encode(), method='POST',
                          headers={**self.headers, 'Content-Type': 'application/json'})
        with build_opener(_NoRedirect()).open(request, timeout=self.timeout) as response:
            body = response.read(65536)
            if body:
                data = json.loads(body)
                if isinstance(data, dict) and ('code' in data and data['code'] != 200 or data.get('success') is False):
                    return False
        return True

    async def report(self, error, operation):
        if not self._eligible(error):
            return False
        token = self._reporting.set(True)
        try:
            if self.callback:
                result = self.callback(error, operation)
                result = await asyncio.wait_for(result, timeout=self.timeout) if inspect.isawaitable(result) else result
            else:
                result = await asyncio.to_thread(self._post, error_payload(error, operation))
            if result is not False:
                error._mango_system_error_reported = True
                return True
        except Exception:
            pass  # 上报端异常不能替换原来的自动化异常，也不能递归上报自身。
        finally:
            self._reporting.reset(token)
        return False

    def report_sync(self, error, operation):
        if not self._eligible(error):
            return False
        token = self._reporting.set(True)
        try:
            result = self.callback(error, operation) if self.callback else self._post(error_payload(error, operation))
            if inspect.isawaitable(result):
                if inspect.iscoroutine(result):
                    result.close()
                return False  # 同步驱动必须注入同步回调，不在已有事件循环中强行 run。
            if result is not False:
                error._mango_system_error_reported = True
                return True
        except Exception:
            pass
        finally:
            self._reporting.reset(token)
        return False
