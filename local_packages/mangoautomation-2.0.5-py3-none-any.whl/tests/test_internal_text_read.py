from unittest.mock import AsyncMock, MagicMock

import pytest

from mangoautomation.uidrives.web.async_web import AsyncWebDevice
from mangoautomation.uidrives.web.sync_web import SyncWebDevice


def test_sync_element_info_uses_unreported_internal_text_reader():
    device = object.__new__(SyncWebDevice)
    device._read_text = MagicMock(return_value="状态文本")
    device.w_get_text = MagicMock(side_effect=AssertionError("不应调用公开步骤方法"))
    locator = MagicMock()
    locator.count.return_value = 1

    result = device._SyncWebDevice__element_info(locator, None)

    assert result == (locator, 1, "状态文本")
    device._read_text.assert_called_once_with(locator)
    device.w_get_text.assert_not_called()


@pytest.mark.asyncio
async def test_async_element_info_uses_unreported_internal_text_reader():
    device = object.__new__(AsyncWebDevice)
    device._read_text = AsyncMock(return_value="状态文本")
    device.w_get_text = AsyncMock(side_effect=AssertionError("不应调用公开步骤方法"))
    locator = MagicMock()
    locator.count = AsyncMock(return_value=1)

    result = await device._AsyncWebDevice__element_info(locator, None)

    assert result == (locator, 1, "状态文本")
    device._read_text.assert_awaited_once_with(locator)
    device.w_get_text.assert_not_awaited()
