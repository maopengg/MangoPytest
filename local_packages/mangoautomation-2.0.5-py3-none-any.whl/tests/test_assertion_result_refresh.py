import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from mangoautomation.enums import DriveTypeEnum
from mangoautomation.models import ElementListResultModel
from mangoautomation.uidrives._async_element import AsyncElement
from mangoautomation.uidrives._sync_element import SyncElement


def element_result():
    return SimpleNamespace(elements=[
        ElementListResultModel(
            exp=2,
            loc='get_by_text("已完成")',
            sub=None,
            is_iframe=0,
            ele_quantity=0,
            visible=False,
        )
    ])


def locator_context(locator):
    return {
        'locator': locator,
        'result_exp': 2,
        'result_loc': 'get_by_text("已完成")',
        'result_sub': None,
        'result_is_iframe': 0,
        'locate_duration_ms': 13,
    }


class AssertionResultRefreshTests(unittest.TestCase):

    def test_sync_assertion_refreshes_final_locator_state(self):
        locator = MagicMock()
        locator.count.return_value = 1
        locator.is_visible.return_value = True
        locator.is_enabled.return_value = True
        locator.is_editable.return_value = False
        locator.bounding_box.return_value = {'x': 10, 'y': 20, 'width': 30, 'height': 40}

        element = SyncElement.__new__(SyncElement)
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_result_model = element_result()
        element._SyncElement__last_locator_context = locator_context(locator)
        element._read_text = MagicMock(return_value='已完成')

        element._SyncElement__refresh_assertion_locator_result()

        result = element.element_result_model.elements[0]
        self.assertEqual(result.ele_quantity, 1)
        self.assertTrue(result.visible)
        self.assertEqual(result.element_text, '已完成')
        self.assertEqual(result.text_snippets, ['已完成'])
        self.assertEqual(result.bounding_box, {'x': 10, 'y': 20, 'width': 30, 'height': 40})


class AsyncAssertionResultRefreshTests(unittest.IsolatedAsyncioTestCase):

    async def test_async_assertion_refreshes_final_locator_state(self):
        locator = MagicMock()
        locator.count = AsyncMock(return_value=1)
        locator.is_visible = AsyncMock(return_value=True)
        locator.is_enabled = AsyncMock(return_value=True)
        locator.is_editable = AsyncMock(return_value=False)
        locator.bounding_box = AsyncMock(
            return_value={'x': 10, 'y': 20, 'width': 30, 'height': 40}
        )

        element = AsyncElement.__new__(AsyncElement)
        element.drive_type = DriveTypeEnum.WEB.value
        element.element_result_model = element_result()
        element._AsyncElement__last_locator_context = locator_context(locator)
        element._read_text = AsyncMock(return_value='已完成')

        await element._AsyncElement__refresh_assertion_locator_result()

        result = element.element_result_model.elements[0]
        self.assertEqual(result.ele_quantity, 1)
        self.assertTrue(result.visible)
        self.assertEqual(result.element_text, '已完成')
        self.assertEqual(result.text_snippets, ['已完成'])
        self.assertEqual(result.bounding_box, {'x': 10, 'y': 20, 'width': 30, 'height': 40})
