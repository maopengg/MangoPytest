# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-04-04 21:42
# @Author : 毛鹏
import inspect
import re

from playwright._impl._errors import TargetClosedError
from playwright.sync_api import Locator, TimeoutError, Error

from mangotools.assertion import MangoAssertion
from mangotools.enums import StatusEnum
from ._browser import SyncWebBrowser
from ._customization import SyncWebCustomization
from ._assertion import SyncWebAssertion
from ._element import SyncWebElement
from ._input_device import SyncWebDeviceInput
from ._page import SyncWebPage
from ._new_browser import SyncWebNewBrowser

from ....enums import ElementExpEnum
from ....exceptions import MangoAutomationError
from ....exceptions.error_msg import *

re = re


class SyncWebDevice(SyncWebBrowser,
                    SyncWebPage,
                    SyncWebElement,
                    SyncWebDeviceInput,
                    SyncWebCustomization):

    def __init__(self, base_data):
        super().__init__(base_data)

    def open_url(self, is_open: bool = False):
        current_url = self.base_data.page.url
        has_visited = current_url not in ('', 'about:blank', 'chrome://newtab/', 'edge://newtab/')
        if not has_visited or is_open:
            self.base_data.log.debug(f'[URL导航] 准备打开URL: {self.base_data.url} (强制打开: {is_open})')
            self.w_goto(self.base_data.url)
            self.base_data.log.debug('[URL导航] URL打开成功')
            return
        try:
            self.base_data.log.debug('[页面状态检查] 等待DOM加载完成')
            self.base_data.page.wait_for_load_state('domcontentloaded', timeout=5000)
            self.base_data.page.wait_for_selector('body', state='visible', timeout=5000)
            try:
                self.base_data.log.debug('[页面状态检查] 短暂等待页面网络空闲')
                self.base_data.page.wait_for_load_state('networkidle', timeout=2000)
            except Exception as e:
                self.base_data.log.debug(f"[页面状态检查] 网络空闲等待超时，继续执行: {str(e)}")
            self.base_data.log.debug("[页面状态检查] 页面已就绪")
        except TargetClosedError:
            self.base_data.log.error('[页面状态检查] 页面已关闭，需要重新初始化')
            self.base_data.setup()
            raise MangoAutomationError(*ERROR_MSG_0010)
        except Exception as e:
            self.base_data.log.debug(f"[页面状态检查] 等待页面就绪时出现异常（可忽略）: {str(e)}")
        
        self.base_data.log.debug('[URL导航] URL已打开，跳过导航')

    def web_action_element(self, name, ope_key, ope_value, ):
        self.base_data.log.debug(f'[元素操作] 开始执行 -> 元素: {name}, 操作: {ope_key}, 操作参数：{ope_value}')
        try:
            method = getattr(self, ope_key)
            if isinstance(ope_value, str):
                return method(ope_value)
            elif isinstance(ope_value, dict):
                return method(**ope_value)
            elif ope_value is None:
                return method()
            self.base_data.log.debug(f'[元素操作] 操作成功 -> {name}.{ope_key}')
        except TimeoutError as error:
            self.base_data.log.error(f'[元素操作超时] 元素: {name}, 操作: {ope_key}, 原因: 等待超时')
            raise MangoAutomationError(*ERROR_MSG_0011, value=(name,))
        except Error as error:
            self.base_data.log.error(f'[元素操作失败] 元素: {name}, Playwright错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0032, value=(name,))
        except ValueError as error:
            self.base_data.log.error(f'[元素操作失败] 元素: {name}, 参数错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0012)

    def web_assertion_element(self, name, ope_key, ope_value) -> str:
        self.base_data.log.debug(f'[元素断言] 开始断言 -> 元素: {name}, 断言方法: {ope_key}')
        self.base_data.log.debug(f'[元素断言] 断言参数: {ope_value}')
        is_method = callable(getattr(SyncWebAssertion, ope_key, None))
        try:
            if is_method:
                method = getattr(SyncWebAssertion(self.base_data), ope_key)
                if 'actual' in inspect.signature(method).parameters and ope_value.get('actual', None) is None:
                    self.base_data.log.error(f'[元素断言失败] 元素: {name}, 原因: 缺少actual参数')
                    raise MangoAutomationError(*ERROR_MSG_0031, value=(name,))
                self.base_data.log.debug(f'[元素断言] 使用Web断言方法: {ope_key}')
                if isinstance(ope_value, str):
                    return method(ope_value)
                elif isinstance(ope_value, dict):
                    return method(**ope_value)
                elif ope_value is None:
                    return method()
            else:
                self.base_data.log.debug(f'[元素断言] 使用通用断言方法: {ope_key}')
                assertion_class = getattr(self.base_data, 'assertion_class', MangoAssertion)
                result = assertion_class(self.base_data.mysql_connect, self.base_data.test_data) \
                    .ass(ope_key, ope_value.get('actual'), ope_value.get('expect'))
            
            self.base_data.log.debug(f'[元素断言] 断言成功 -> {name}.{ope_key}')
            return result
        except AssertionError as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, 断言不通过: {error.args}')
            raise MangoAutomationError(*ERROR_MSG_0017, value=error.args)
        except AttributeError as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, 方法不存在: {ope_key}')
            raise MangoAutomationError(*ERROR_MSG_0048)
        except ValueError as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, 参数错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0005)
        except Error as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, Playwright错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0052, value=(name,), )

    def web_find_element(self, name, _type, exp, loc, sub, is_iframe) \
            -> tuple[Locator, int, str] | tuple[list[Locator], int, str]:
        self.base_data.log.debug(f'[元素查找] 元素: {name}, 表达式: {exp}, 定位: {loc}, 下标: {sub}, iframe: {is_iframe}')
        
        if is_iframe != StatusEnum.SUCCESS.value:
            locator: Locator = self.__find_ele(self.base_data.page, exp, loc)
            try:
                result = self.__element_info(locator, sub)
                self.base_data.log.debug(f'[元素查找] 找到元素 -> {name}, 数量: {result[1]}')
                return result
            except TargetClosedError:
                self.base_data.log.error('[元素查找失败] 页面已关闭')
                self.base_data.setup()
                raise MangoAutomationError(*ERROR_MSG_0010)
            except Error as error:
                self.base_data.log.debug(f'[元素查找失败] 元素: {name}, 定位: {loc}, 错误: {str(error)}')
                raise MangoAutomationError(*ERROR_MSG_0041, )
        else:
            self.base_data.log.debug(f'[元素查找] 在iframe中查找元素: {name}')
            return self.__is_iframe(_type, exp, loc, sub)


    def __element_info(self, locator: Locator, sub) -> tuple[Locator, int, str]:
        count = locator.count()
        if sub is not None:
            locator = locator.nth(sub - 1) if sub else locator
        try:
            text = self._read_text(locator)
        except Exception:
            text = None
        return locator, count, text

    def ai_element_info(self, locator: Locator) -> tuple[Locator, int, str]:
        count = locator.count()
        try:
            text = self._read_text(locator)
        except Exception:
            text = None
        return locator, count, text

    def __is_iframe(self, _type, exp, loc, sub):
        ele_list: list[Locator] = []
        frame_count = len(self.base_data.page.frames)
        self.base_data.log.debug(f'[iframe查找] 检测到 {frame_count} 个frame')
        
        for idx, frame in enumerate(self.base_data.page.frames):
            locator: Locator = self.__find_ele(frame, exp, loc)
            try:
                count = locator.count()
                if count > 0:
                    self.base_data.log.debug(f'[iframe查找] 在frame[{idx}]中找到 {count} 个元素')
                    for nth in range(0, count):
                        ele_list.append(locator.nth(nth))
            except Error as error:
                self.base_data.log.debug(f'[iframe查找] frame[{idx}]查找失败: {str(error)}')
                raise MangoAutomationError(*ERROR_MSG_0041, )
        
        if not ele_list:
            self.base_data.log.error(f'[iframe查找失败] 在所有frame中都未找到元素')
            raise MangoAutomationError(*ERROR_MSG_0023)
        
        try:
            count = len(ele_list)
            loc = ele_list[sub - 1] if sub else ele_list[0]
            try:
                text = self._read_text(loc)
            except Exception:
                text = None
            self.base_data.log.debug(f'[iframe查找] 找到元素，总数: {count}, 选择下标: {sub if sub else 0}')
            return loc, count, text
        except IndexError:
            self.base_data.log.error(f'[iframe查找失败] 下标越界，总数: {len(ele_list)}, 请求下标: {sub}')
            raise MangoAutomationError(*ERROR_MSG_0025, value=(len(ele_list),))

    def __find_ele(self, page, exp, loc) -> Locator:
        if exp == ElementExpEnum.LOCATOR.value:
            try:
                return eval(f"page.{loc}", {'page': page})
            except SyntaxError:
                self.base_data.log.debug(f'[定位表达式无效] LOCATOR语法错误: {loc}')
                raise MangoAutomationError(*ERROR_MSG_0022)
            except NameError:
                self.base_data.log.debug(f'[定位表达式无效] LOCATOR变量未定义: {loc}')
                raise MangoAutomationError(*ERROR_MSG_0060)
            except (AttributeError, TypeError, ValueError) as error:
                self.base_data.log.debug(f'[定位表达式无效] LOCATOR无法解析: {loc}，原因: {error}')
                raise MangoAutomationError(*ERROR_MSG_0022)
        elif exp == ElementExpEnum.XPATH.value:
            self.base_data.log.debug(f'[定位方式] 使用XPATH: {loc}')
            return page.locator(f'xpath={loc}')
        elif exp == ElementExpEnum.CSS.value:
            self.base_data.log.debug(f'[定位方式] 使用CSS: {loc}')
            return page.locator(loc)
        elif exp == ElementExpEnum.TEXT.value:
            self.base_data.log.debug(f'[定位方式] 使用TEXT: {loc}')
            return page.get_by_text(loc, exact=True)
        elif exp == ElementExpEnum.PLACEHOLDER.value:
            self.base_data.log.debug(f'[定位方式] 使用PLACEHOLDER: {loc}')
            return page.get_by_placeholder(loc)
        else:
            self.base_data.log.error(f'[定位方式错误] 不支持的定位方式: {exp}')
            raise MangoAutomationError(*ERROR_MSG_0020)
